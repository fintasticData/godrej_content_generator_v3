
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {supabase, fetchDynamicAssets, saveDynamicAsset, updateDynamicAsset, deleteDynamicAsset, uploadBlob, fetchCharacters, fetchLocations} from '../services/supabaseClient';
import {analyzeImage, generateAssetProfile, generateImagenImage, enhanceVisualPrompt, editImage} from '../services/geminiService';
import {Asset, DynamicAsset, AspectRatio, Location} from '../types';
import {
  FileImageIcon,
  MusicIcon,
  SparklesIcon,
  UploadCloudIcon,
  XMarkIcon,
  CubeIcon,
  UserIcon,
  MapPinIcon,
  FilmIcon,
  PencilSquareIcon,
  TrashIcon,
  SaveIcon,
  LightBulbIcon,
  MagicWandIcon,
  ArrowRightIcon,
  EraserIcon,
  PlusIcon,
  ArrowPathIcon,
  PhotoIcon,
  PresentationIcon
} from './icons';
import Modal from './Modal';

const BUCKET_NAME = 'RetailData';
const FOLDER_NAME = 'godrej';

type Filter = 'all' | 'image' | 'video' | 'audio';
type ViewMode = 'storage' | 'library';

const getAssetType = (
  mimeType?: string,
): 'image' | 'video' | 'audio' | 'other' => {
  if (!mimeType) return 'other';
  if (mimeType.startsWith('image/')) return 'image';
  if (mimeType.startsWith('video/')) return 'video';
  if (mimeType.startsWith('audio/')) return 'audio';
  return 'other';
};

const urlToBase64 = async (url: string): Promise<string> => {
  const response = await fetch(url);
  const blob = await response.blob();
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1];
      resolve(base64);
    };
    reader.readAsDataURL(blob);
  });
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
             const base64 = (reader.result as string).split(',')[1];
             resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

const AssetCard: React.FC<{
  asset: Asset;
  isSelected: boolean;
  onSelect: (assetName: string) => void;
}> = ({asset, isSelected, onSelect}) => {
  const renderPreview = () => {
      if (asset.metadata?.mimetype?.startsWith('image/')) {
          return <img src={asset.publicURL} alt={asset.name} className="w-full h-full object-cover" loading="lazy" />;
      } else if (asset.metadata?.mimetype?.startsWith('video/')) {
          return <video src={asset.publicURL} muted loop className="w-full h-full object-cover" />;
      } else {
          return <div className="flex flex-col items-center justify-center h-full text-gray-400"><FileImageIcon className="w-10 h-10" /></div>;
      }
  };

  return (
    <div
      onClick={() => onSelect(asset.name)}
      className={`relative group aspect-square bg-white rounded-lg overflow-hidden cursor-pointer border-2 shadow-sm hover:shadow-md ${
        isSelected ? 'border-indigo-600 ring-2 ring-indigo-100' : 'border-gray-200 hover:border-gray-300'
      } transition-all duration-200`}>
      {renderPreview()}
      <div className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm p-2 border-t border-gray-100">
        <p className="text-gray-900 text-xs truncate font-medium" title={asset.name}>{asset.name}</p>
      </div>
      {isSelected && (
        <div className="absolute inset-0 bg-indigo-600/10 flex items-center justify-center">
            <div className="bg-white rounded-full p-1 shadow-sm"><SparklesIcon className="w-4 h-4 text-indigo-600"/></div>
        </div>
      )}
    </div>
  );
};

const DynamicAssetCard: React.FC<{
  asset: DynamicAsset;
  isSelected: boolean;
  onSelect: (assetId: number | string) => void;
}> = ({asset, isSelected, onSelect}) => {
  const url = asset.asset_urls?.primary;
  
  const getIcon = () => {
      switch(asset.element_type) {
          case 'character': return <UserIcon className="w-3 h-3"/>;
          case 'setting': return <MapPinIcon className="w-3 h-3"/>;
          case 'product': return <CubeIcon className="w-3 h-3"/>;
          case 'storyboard': return <PresentationIcon className="w-3 h-3"/>;
          default: return <FileImageIcon className="w-3 h-3"/>;
      }
  };

  if (!url) {
      return (
        <div onClick={() => onSelect(asset.id)} className={`relative group aspect-square bg-gray-50 rounded-lg overflow-hidden cursor-pointer border-2 border-dashed border-gray-300 flex items-center justify-center ${isSelected ? 'border-indigo-600 ring-2 ring-indigo-100' : ''}`}>
            <div className="text-center p-2">
                 <div className="flex justify-center mb-1 text-gray-400">{getIcon()}</div>
                 <p className="text-[10px] text-gray-400">No Image</p>
                 <p className="text-xs text-gray-500 font-medium truncate w-full">{asset.name_identifier}</p>
            </div>
        </div>
      );
  }

  return (
    <div
      onClick={() => onSelect(asset.id)}
      className={`relative group aspect-square bg-white rounded-lg overflow-hidden cursor-pointer border-2 shadow-sm hover:shadow-md ${
        isSelected ? 'border-indigo-600 ring-2 ring-indigo-100' : 'border-gray-200 hover:border-gray-300'
      } transition-all duration-200`}>
      <img src={url} alt={asset.name_identifier} className="w-full h-full object-cover" loading="lazy" />
      <div className="absolute top-2 left-2 bg-white/90 px-1.5 py-0.5 rounded text-[10px] font-bold uppercase text-gray-700 shadow-sm flex items-center gap-1">
          {getIcon()} {asset.element_type}
      </div>
      <div className="absolute bottom-0 left-0 right-0 bg-white/90 backdrop-blur-sm p-3 border-t border-gray-100">
        <p className="text-gray-900 text-sm truncate font-black" title={asset.name_identifier}>{asset.name_identifier.split('-')[0]}</p>
        <p className="text-[9px] text-gray-500 uppercase tracking-wider">{asset.asset_data?.role || 'Asset'}</p>
      </div>
       {isSelected && (
        <div className="absolute inset-0 bg-indigo-600/10 flex items-center justify-center">
            <div className="bg-white rounded-full p-1 shadow-sm"><SparklesIcon className="w-4 h-4 text-indigo-600"/></div>
        </div>
      )}
    </div>
  );
};

interface AssetStudioProps {
  onAssetsSelected: (assets: Asset[]) => void;
}

const AssetStudio: React.FC<AssetStudioProps> = ({onAssetsSelected}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('library');
  
  const [assets, setAssets] = useState<Asset[]>([]);
  const [selectedStorageAssets, setSelectedStorageAssets] = useState<Set<string>>(new Set());
  
  const [dynamicAssets, setDynamicAssets] = useState<DynamicAsset[]>([]);
  const [selectedDynamicAssets, setSelectedDynamicAssets] = useState<Set<number | string>>(new Set());

  // Inspector State
  const [inspectedAssetId, setInspectedAssetId] = useState<number | string | null>(null);
  const [isEditingInspector, setIsEditingInspector] = useState(false);
  
  // Variant Management
  const variantInputRef = useRef<HTMLInputElement>(null);
  const variantRefImageRef = useRef<HTMLInputElement>(null);
  const [isUploadingVariant, setIsUploadingVariant] = useState(false);
  
  // New Look Generator State
  const [variantPrompt, setVariantPrompt] = useState('');
  const [variantRefFile, setVariantRefFile] = useState<File | null>(null);
  const [isGeneratingVariant, setIsGeneratingVariant] = useState(false);
  
  const [editedJson, setEditedJson] = useState('');
  const [editedName, setEditedName] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<Filter>('all');
  const [libraryFilter, setLibraryFilter] = useState<string>('all');
  
  // Upload State
  const [isUploading, setIsUploading] = useState(false);
  const [showSmartUpload, setShowSmartUpload] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Smart Upload Form
  const [smartUploadType, setSmartUploadType] = useState('character');
  const [smartUploadName, setSmartUploadName] = useState('');
  const [smartUploadPrompt, setSmartUploadPrompt] = useState('');
  const [smartUploadFile, setSmartUploadFile] = useState<File | null>(null);

  // --- AI Generator State ---
  const [showGenerator, setShowGenerator] = useState(false);
  const [genStep, setGenStep] = useState(1); 
  const [genType, setGenType] = useState<'character'|'setting'|'product'>('character');
  const [genConcept, setGenConcept] = useState('');
  const [genProfile, setGenProfile] = useState<any>(null); 
  const [genImage, setGenImage] = useState<string | null>(null); 
  const [isGeneratingProfile, setIsGeneratingProfile] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
        if (viewMode === 'storage') {
            if (!supabase.storage) throw new Error('Supabase client is not configured.');
            const {data: files, error: listError} = await supabase.storage.from(BUCKET_NAME).list(FOLDER_NAME, {limit: 100, offset: 0, sortBy: {column: 'created_at', order: 'desc'}});
            if (listError) throw listError;
            if (files) {
                const assetsWithUrls = files.filter((file) => file.name !== '.emptyFolderPlaceholder').map((file) => {
                    const {data} = supabase.storage.from(BUCKET_NAME).getPublicUrl(`${FOLDER_NAME}/${file.name}`);
                    return {...file, publicURL: data.publicUrl};
                });
                setAssets(assetsWithUrls);
            }
        } else {
            // LIBRARY MODE: Unified Fetch
            const [libAssets, charAssets, locAssets] = await Promise.all([
                fetchDynamicAssets(libraryFilter),
                (libraryFilter === 'all' || libraryFilter === 'character') ? fetchCharacters() : Promise.resolve([]),
                (libraryFilter === 'all' || libraryFilter === 'setting') ? fetchLocations() : Promise.resolve([])
            ]);
            
            const mappedChars = (charAssets || []).map((c: any) => ({
                id: c.character_id || c.id,
                element_type: 'character',
                name_identifier: c.name || c.alias,
                created_at: c.created_at,
                asset_urls: { primary: c.image_url },
                asset_data: { description: c.description, role: c.role, ...c.character_jsonb }
            }));

            const mappedLocs = (locAssets || []).map((l: any) => ({
                id: `loc-${l.id}`,
                element_type: 'setting',
                name_identifier: l.name,
                created_at: l.created_at,
                asset_urls: { primary: l.image_urls?.primary },
                asset_data: { city: l.city, category: l.category, prompt: l.prompt }
            }));

            // Filter standard library for types that don't have dedicated tables yet
            const filteredLib = libAssets.filter(a => a.element_type !== 'character' && a.element_type !== 'setting');

            // Sort combined list by created_at desc
            const combined = [...filteredLib, ...mappedChars, ...mappedLocs].sort((a, b) => 
                new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
            );
            
            setDynamicAssets(combined as DynamicAsset[]);
        }

    } catch (err) {
      console.error('Error fetching assets:', err);
      const message = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to load assets: ${message}`);
    } finally {
      setIsLoading(false);
    }
  }, [viewMode, libraryFilter]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleUploadClick = () => {
      if (viewMode === 'storage') fileInputRef.current?.click();
      else setShowSmartUpload(true);
  };

  const handleSmartUpload = async () => {
      if (!smartUploadFile || !smartUploadName) { alert("File and name required."); return; }
      setIsUploading(true);
      try {
          const folder = `godrej/${smartUploadType}s`;
          const fileName = `${smartUploadType}_${Date.now()}_${smartUploadFile.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
          const url = await uploadBlob(smartUploadFile, fileName, folder);
          if (url) {
              await saveDynamicAsset(smartUploadType, smartUploadName, url, { description: smartUploadPrompt, source: 'smart_upload' });
              setShowSmartUpload(false);
              setSmartUploadFile(null);
              setSmartUploadName('');
              setSmartUploadPrompt('');
              fetchData();
          }
      } catch (e) { console.error(e); alert("Upload failed."); } finally { setIsUploading(false); }
  }

  const handleRawFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const fileName = `${crypto.randomUUID()}_${file.name.replace(/\s+/g, '_').replace(/[^a-zA-Z0-9._-]/g, '')}`;
      const {error: uploadError} = await supabase.storage.from(BUCKET_NAME).upload(`${FOLDER_NAME}/${fileName}`, file);
      if (uploadError) throw uploadError;
      await fetchData();
    } catch (err) { console.error(err); setError('Upload failed'); } finally { setIsUploading(false); if (fileInputRef.current) fileInputRef.current.value = ''; }
  };

  const toggleSelection = (id: string | number) => {
      if (viewMode === 'storage') {
          const name = id as string;
          setSelectedStorageAssets((prev) => {
            const newSelection = new Set(prev);
            if (newSelection.has(name)) newSelection.delete(name);
            else newSelection.add(name);
            return newSelection;
          });
      } else {
          const dynamicId = id;
          if (inspectedAssetId === dynamicId) {
             setInspectedAssetId(null);
          } else {
             setInspectedAssetId(dynamicId);
             const asset = dynamicAssets.find(a => a.id === dynamicId);
             if (asset) {
                 setEditedName(asset.name_identifier);
                 setEditedJson(JSON.stringify(asset.asset_data || {}, null, 2));
                 setVariantPrompt(''); 
                 setVariantRefFile(null);
             }
          }
          setSelectedDynamicAssets((prev) => {
            const newSelection = new Set(prev);
            if (newSelection.has(dynamicId)) newSelection.delete(dynamicId);
            else newSelection.add(dynamicId);
            return newSelection;
          });
      }
  };
  
  const handleAnalyzeAsset = async () => {
    if (!inspectedAssetId) return;
    const asset = dynamicAssets.find(a => a.id === inspectedAssetId);
    if (!asset || !asset.asset_urls?.primary) return;
    
    // Safety check: Don't edit mapped items
    if (typeof asset.id === 'string') {
        alert("This is a managed Hub asset. Please edit it in the dedicated Character or Location Lab.");
        return;
    }

    setIsAnalyzing(true);
    try {
        const base64 = await urlToBase64(asset.asset_urls.primary);
        const result = await analyzeImage(base64);
        const newData = { ...asset.asset_data || {}, ai_description: result.description, ai_tags: result.tags };
        setEditedJson(JSON.stringify(newData, null, 2));
        setIsEditingInspector(true);
        await updateDynamicAsset(inspectedAssetId as number, { asset_data: newData });
        setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { ...a, asset_data: newData } : a));
    } catch (e) { console.error(e); alert("Analysis failed."); } finally { setIsAnalyzing(false); }
  };
  
  const handleGenerateVariant = async () => {
    if (!inspectedAssetId || !variantPrompt.trim()) return;
    const asset = dynamicAssets.find(a => a.id === inspectedAssetId);
    if (!asset || !asset.asset_urls?.primary) return;
    
    if (typeof asset.id === 'string') {
        alert("Managed assets use dedicated Labs for look generation.");
        return;
    }

    setIsGeneratingVariant(true);
    try {
        const base64 = await urlToBase64(asset.asset_urls.primary);
        
        let refBase64: string | undefined = undefined;
        if (variantRefFile) {
            refBase64 = await fileToBase64(variantRefFile);
        }

        const result = await editImage(base64, variantPrompt, refBase64);
        
        // Convert to blob and upload
        const byteCharacters = atob(result.base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: result.mimeType });
        
        const fileName = `${asset.element_type}_variant_${Date.now()}.png`;
        const url = await uploadBlob(blob, fileName, `godrej/${asset.element_type}s`);
        
        if (url) {
            const currentUrls = asset.asset_urls || { primary: '' };
            const currentVariants = currentUrls.variants || [];
            const newUrls = {
                ...currentUrls,
                variants: [...currentVariants, url]
            };
            
            await updateDynamicAsset(inspectedAssetId as number, { asset_urls: newUrls });
            
            setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { 
                ...a, 
                asset_urls: newUrls
            } : a));
            
            setVariantPrompt('');
            setVariantRefFile(null);
        }
    } catch (e) {
        console.error(e);
        alert("Variant generation failed.");
    } finally {
        setIsGeneratingVariant(false);
    }
  };
  
  const handleSaveInspectorChanges = async () => {
      if (!inspectedAssetId) return;
      if (typeof inspectedAssetId === 'string') {
          alert("Managed assets cannot be edited here.");
          return;
      }
      setIsSavingEdit(true);
      try {
          let parsedJson = {};
          try { parsedJson = JSON.parse(editedJson); } catch(e) { alert("Invalid JSON format."); setIsSavingEdit(false); return; }
          await updateDynamicAsset(inspectedAssetId as number, { name_identifier: editedName, asset_data: parsedJson });
          setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { ...a, name_identifier: editedName, asset_data: parsedJson } : a));
          setIsEditingInspector(false);
      } catch (e) { console.error(e); alert("Failed to save changes."); } finally { setIsSavingEdit(false); }
  };
  
  const handleDeleteAsset = async () => {
      if (!inspectedAssetId) return;
      if (typeof inspectedAssetId === 'string') {
          alert("Managed hub assets must be deleted in their respective center.");
          return;
      }
      if (!confirm("Are you sure you want to delete this asset?")) return;
      setIsSavingEdit(true);
      try {
          await deleteDynamicAsset(inspectedAssetId as number);
          setDynamicAssets(prev => prev.filter(a => a.id !== inspectedAssetId));
          setInspectedAssetId(null);
          setSelectedDynamicAssets(prev => { const newSet = new Set(prev); newSet.delete(inspectedAssetId); return newSet; });
      } catch (e) { console.error(e); alert("Failed to delete."); } finally { setIsSavingEdit(false); }
  };

  const handleVariantUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !inspectedAssetId) return;
    if (typeof inspectedAssetId === 'string') { alert("Managed assets use dedicated Labs."); return; }
    
    const asset = dynamicAssets.find(a => a.id === inspectedAssetId);
    if (!asset) return;

    setIsUploadingVariant(true);
    try {
      const fileName = `${asset.element_type}_variant_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
      const folder = `godrej/${asset.element_type}s`;
      const url = await uploadBlob(file, fileName, folder);
      
      if (url) {
        const currentUrls = asset.asset_urls || { primary: '' };
        const currentVariants = currentUrls.variants || [];
        const newUrls = {
            ...currentUrls,
            variants: [...currentVariants, url]
        };

        await updateDynamicAsset(inspectedAssetId as number, { asset_urls: newUrls });
        setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { ...a, asset_urls: newUrls } : a));
      }
    } catch (err) {
      console.error(err);
      alert("Failed to upload variant.");
    } finally {
      setIsUploadingVariant(false);
      if (variantInputRef.current) variantInputRef.current.value = '';
    }
  };

  const handleMakePrimary = async (variantUrl: string) => {
      if (!inspectedAssetId || typeof inspectedAssetId === 'string') return;
      const asset = dynamicAssets.find(a => a.id === inspectedAssetId);
      if (!asset || !asset.asset_urls) return;

      const oldPrimary = asset.asset_urls.primary;
      const newVariants = (asset.asset_urls.variants || []).filter(v => v !== variantUrl);
      if (oldPrimary) newVariants.push(oldPrimary);

      const newUrls = {
          ...asset.asset_urls,
          primary: variantUrl,
          variants: newVariants
      };

      try {
           await updateDynamicAsset(inspectedAssetId as number, { asset_urls: newUrls });
           setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { ...a, asset_urls: newUrls } : a));
      } catch (e) {
          console.error(e);
      }
  };

  const handleDeleteVariant = async (variantUrl: string) => {
       if (!inspectedAssetId || typeof inspectedAssetId === 'string') return;
      const asset = dynamicAssets.find(a => a.id === inspectedAssetId);
      if (!asset || !asset.asset_urls) return;
      
      if (!confirm("Remove this variant?")) return;

      const newVariants = (asset.asset_urls.variants || []).filter(v => v !== variantUrl);
      const newUrls = {
          ...asset.asset_urls,
          variants: newVariants
      };

       try {
           await updateDynamicAsset(inspectedAssetId as number, { asset_urls: newUrls });
           setDynamicAssets(prev => prev.map(a => a.id === inspectedAssetId ? { ...a, asset_urls: newUrls } : a));
      } catch (e) {
          console.error(e);
      }
  }

  const handleUseAssets = () => {
    let finalAssets: Asset[] = [];
    if (viewMode === 'storage') {
        finalAssets = assets.filter((asset) => selectedStorageAssets.has(asset.name));
    } else {
        const selected = dynamicAssets.filter(da => selectedDynamicAssets.has(da.id));
        finalAssets = selected.map(da => ({
            id: da.id.toString(), name: da.name_identifier, publicURL: da.asset_urls?.primary || '', created_at: da.created_at, updated_at: da.created_at, last_accessed_at: da.created_at,
            metadata: { mimetype: 'image/png', size: 0, eTag: '', cacheControl: '', lastModified: '', contentLength: 0, httpStatusCode: 200 }
        }));
    }
    onAssetsSelected(finalAssets.filter(a => !!a.publicURL));
  };

  // --- Generator Functions ---
  const handleGenerateProfile = async () => {
      if (!genConcept.trim()) return;
      setIsGeneratingProfile(true);
      try {
          const profile = await generateAssetProfile(genConcept, genType);
          setGenProfile(profile);
          setGenStep(2);
      } catch(e) { console.error(e); alert("Failed to generate profile."); } finally { setIsGeneratingProfile(false); }
  };

  const handleGenerateAssetImage = async () => {
      if (!genProfile?.visual_prompt) return;
      setIsGeneratingImage(true);
      try {
          const result = await generateImagenImage(genProfile.visual_prompt, '1:1');
          setGenImage(result.base64);
          setGenStep(3);
      } catch(e: any) { console.error(e); alert(`Image generation failed: ${e.message}`); } finally { setIsGeneratingImage(false); }
  };

  const handleSaveGeneratedAsset = async () => {
      if (!genImage || !genProfile) return;
      setIsUploading(true);
      try {
           const byteCharacters = atob(genImage);
           const byteNumbers = new Array(byteCharacters.length);
           for (let i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
           const byteArray = new Uint8Array(byteNumbers);
           const blob = new Blob([byteArray], { type: 'image/jpeg' });
           
           const name = genProfile.name || `${genType}_${Date.now()}`;
           const fileName = `${genType}_${Date.now()}.jpeg`;
           const folder = `godrej/${genType}s`;
           
           const url = await uploadBlob(blob, fileName, folder);
           if (url) {
               await saveDynamicAsset(genType, name, url, { ...genProfile, source: 'ai_generator' });
               setShowGenerator(false);
               setGenStep(1);
               setGenConcept('');
               setGenProfile(null);
               setGenImage(null);
               fetchData();
           }
      } catch (e) { console.error(e); alert("Save failed."); } finally { setIsUploading(false); }
  }

  const handleEnhancePrompt = async () => {
      if (!genConcept.trim()) return;
      setIsEnhancingPrompt(true);
      try {
          const enhanced = await enhanceVisualPrompt(genConcept);
          setGenConcept(enhanced);
      } catch(e) {
          console.error(e);
      } finally {
          setIsEnhancingPrompt(false);
      }
  };

  const activeAsset = dynamicAssets.find(a => a.id === inspectedAssetId);

  return (
    <div className="w-full h-full flex flex-col gap-4 bg-gray-50 p-6 relative overflow-hidden">
      <header className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Asset Studio</h2>
          <p className="text-gray-500">Manage your creative assets and smart library.</p>
        </div>
        
        <div className="bg-white border border-gray-200 p-1 rounded-lg flex items-center shadow-sm">
             <button onClick={() => { setViewMode('library'); setInspectedAssetId(null); }} className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${viewMode === 'library' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Smart Library</button>
             <button onClick={() => { setViewMode('storage'); setInspectedAssetId(null); }} className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${viewMode === 'storage' ? 'bg-indigo-100 text-indigo-700' : 'text-gray-600 hover:bg-gray-50'}`}>Raw Files</button>
        </div>

        <div className="flex gap-2">
            <button onClick={() => setShowGenerator(true)} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-semibold rounded-lg transition-colors shadow-sm">
                <MagicWandIcon className="w-5 h-5" /> Generate with AI
            </button>
            <button onClick={handleUploadClick} disabled={isUploading} className="flex items-center gap-2 px-5 py-2.5 bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 font-semibold rounded-lg transition-colors disabled:bg-gray-100 shadow-sm">
                <UploadCloudIcon className="w-5 h-5" /> Upload
            </button>
            <input type="file" ref={fileInputRef} onChange={handleRawFileUpload} className="hidden" />
        </div>
      </header>

      {/* Filters */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 border-b border-gray-200">
         {viewMode === 'storage' ? (
             <>
                <button onClick={() => setFilter('all')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${filter === 'all' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>All Files</button>
                <button onClick={() => setFilter('image')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${filter === 'image' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>Images</button>
             </>
         ) : (
             <>
                <button onClick={() => setLibraryFilter('all')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${libraryFilter === 'all' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>All Assets</button>
                <button onClick={() => setLibraryFilter('character')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${libraryFilter === 'character' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>Characters</button>
                <button onClick={() => setLibraryFilter('setting')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${libraryFilter === 'setting' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>Locations</button>
                <button onClick={() => setLibraryFilter('product')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${libraryFilter === 'product' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>Products</button>
                <button onClick={() => setLibraryFilter('storyboard')} className={`px-3 py-1.5 text-xs font-medium rounded-md border ${libraryFilter === 'storyboard' ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-600 border-gray-300'}`}>Storyboards</button>
             </>
         )}
      </div>

      <div className="flex-grow flex gap-4 overflow-hidden relative">
          {/* Main Grid */}
          <div className="flex-grow overflow-y-auto pr-2 pb-20">
            {isLoading ? (
              <div className="flex items-center justify-center h-64"><div className="w-12 h-12 border-4 border-t-transparent border-indigo-600 rounded-full animate-spin"></div></div>
            ) : (
                viewMode === 'storage' ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {assets.filter(a => filter === 'all' || getAssetType(a.metadata?.mimetype) === filter).map(asset => (
                            <AssetCard key={asset.id} asset={asset} isSelected={selectedStorageAssets.has(asset.name)} onSelect={toggleSelection} />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {dynamicAssets.map(asset => (
                            <DynamicAssetCard key={asset.id} asset={asset} isSelected={selectedDynamicAssets.has(asset.id)} onSelect={toggleSelection} />
                        ))}
                    </div>
                )
            )}
          </div>
          
          {/* Inspector Panel */}
          {activeAsset && viewMode === 'library' && (
              <div className="w-[320px] bg-white border-l border-gray-200 shadow-xl overflow-y-auto p-4 flex flex-col gap-4 absolute right-0 top-0 bottom-0 z-10">
                  <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                      <h3 className="font-bold text-gray-800">Asset Inspector</h3>
                      <button onClick={() => setInspectedAssetId(null)} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-5 h-5"/></button>
                  </div>
                  
                  <div className="space-y-4">
                      <div className="aspect-square rounded-lg overflow-hidden bg-gray-100 border border-gray-200">
                          <img src={activeAsset.asset_urls?.primary} className="w-full h-full object-contain" />
                      </div>
                      
                      {/* Variants Section */}
                      <div className="border-t border-gray-100 pt-3">
                          <div className="flex justify-between items-center mb-2">
                              <span className="text-xs font-bold text-gray-500 uppercase">Variants / Looks</span>
                              <div className="flex gap-2">
                                  <button 
                                      onClick={() => variantInputRef.current?.click()} 
                                      className="text-xs font-medium text-gray-500 flex items-center gap-1 hover:bg-gray-100 px-2 py-0.5 rounded transition-colors"
                                      disabled={isUploadingVariant || typeof activeAsset.id === 'string'}
                                      title="Upload Manual Variant"
                                  >
                                      <UploadCloudIcon className="w-3 h-3"/>
                                  </button>
                              </div>
                              <input ref={variantInputRef} type="file" hidden onChange={handleVariantUpload} accept="image/*" />
                          </div>
                          
                          {/* Variant Grid */}
                          <div className="grid grid-cols-3 gap-2 mb-4">
                              {activeAsset.asset_urls?.variants?.map((v, i) => (
                                  <div key={i} className="relative group aspect-square rounded overflow-hidden border border-gray-200 bg-gray-50">
                                      <img src={v} className="w-full h-full object-cover" />
                                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center gap-1 transition-opacity">
                                          <button onClick={(e) => { e.stopPropagation(); handleMakePrimary(v); }} title="Make Primary" className="bg-white/20 hover:bg-white/40 p-1 rounded"><ArrowPathIcon className="w-3 h-3 text-white"/></button>
                                          <button onClick={(e) => { e.stopPropagation(); handleDeleteVariant(v); }} title="Delete" className="bg-white/20 hover:bg-white/40 p-1 rounded"><TrashIcon className="w-3 h-3 text-white"/></button>
                                      </div>
                                  </div>
                              ))}
                              {(!activeAsset.asset_urls?.variants || activeAsset.asset_urls.variants.length === 0) && (
                                  <p className="col-span-3 text-[10px] text-gray-400 italic text-center py-2">No variants uploaded.</p>
                              )}
                          </div>

                          {/* New Look Generator */}
                          {typeof activeAsset.id === 'number' && (
                              <div className="bg-indigo-50/50 rounded-lg p-3 border border-indigo-100">
                                  <label className="text-xs font-bold text-indigo-800 uppercase mb-2 block flex items-center gap-1"><MagicWandIcon className="w-3 h-3"/> Generate New Look</label>
                                  <textarea 
                                      className="w-full border border-indigo-200 rounded p-2 text-xs mb-2 focus:ring-1 focus:ring-indigo-500 outline-none"
                                      placeholder="e.g. Change outfit to a red suit, standing in a forest..."
                                      rows={3}
                                      value={variantPrompt}
                                      onChange={(e) => setVariantPrompt(e.target.value)}
                                  />
                                  <div className="flex gap-2 items-center mb-2">
                                       <input 
                                          type="file" 
                                          ref={variantRefImageRef} 
                                          hidden 
                                          accept="image/*" 
                                          onChange={(e) => setVariantRefFile(e.target.files?.[0] || null)} 
                                       />
                                       <button 
                                          onClick={() => variantRefImageRef.current?.click()}
                                          className={`flex-1 text-xs py-1.5 px-2 rounded border border-indigo-200 flex items-center justify-center gap-1 truncate ${variantRefFile ? 'bg-indigo-100 text-indigo-700 font-medium' : 'bg-white text-gray-500 hover:bg-gray-50'}`}
                                          title="Optional Reference Image"
                                       >
                                          <PhotoIcon className="w-3 h-3"/> {variantRefFile ? variantRefFile.name : "Ref Image (Opt)"}
                                       </button>
                                       {variantRefFile && <button onClick={() => setVariantRefFile(null)} className="text-gray-400 hover:text-gray-600"><XMarkIcon className="w-3 h-3"/></button>}
                                  </div>
                                  <button 
                                      onClick={handleGenerateVariant}
                                      disabled={isGeneratingVariant || !variantPrompt.trim()}
                                      className="w-full bg-indigo-600 text-white py-2 rounded text-xs font-bold shadow-sm hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
                                  >
                                      {isGeneratingVariant ? 'Generating...' : 'Generate Look'}
                                  </button>
                              </div>
                          )}
                      </div>
                      
                      <div className="h-[1px] bg-gray-100 my-2"></div>
                      
                      <button onClick={handleAnalyzeAsset} disabled={isAnalyzing} className="w-full bg-white text-indigo-600 py-2 rounded text-sm font-bold flex items-center justify-center gap-2 border border-indigo-200 hover:bg-indigo-50 transition-colors">
                         {isAnalyzing ? 'Analyzing...' : <><LightBulbIcon className="w-4 h-4" /> Update AI Tags</>}
                      </button>
                      <div className="space-y-2">
                          <label className="text-xs font-bold text-gray-500 uppercase">Name</label>
                          {isEditingInspector ? <input className="w-full border border-gray-300 rounded px-2 py-1 text-sm" value={editedName} onChange={(e) => setEditedName(e.target.value)} /> : <p className="text-sm font-medium text-gray-900">{activeAsset.name_identifier}</p>}
                      </div>
                      <div className="space-y-2">
                           <label className="text-xs font-bold text-gray-500 uppercase flex justify-between items-center">Metadata {!isEditingInspector && typeof activeAsset.id === 'number' && <button onClick={() => setIsEditingInspector(true)} className="text-indigo-600"><PencilSquareIcon className="w-4 h-4"/></button>}</label>
                           {isEditingInspector ? <textarea className="w-full h-40 border border-gray-300 rounded p-2 text-xs font-mono" value={editedJson} onChange={(e) => setEditedJson(e.target.value)} /> : <pre className="w-full h-40 bg-gray-50 border border-gray-200 rounded p-2 text-xs font-mono overflow-auto">{JSON.stringify(activeAsset.asset_data, null, 2)}</pre>}
                      </div>
                      {isEditingInspector ? (
                          <div className="flex gap-2">
                              <button onClick={handleSaveInspectorChanges} disabled={isSavingEdit} className="flex-1 bg-green-600 text-white py-2 rounded text-sm font-bold">Save</button>
                              <button onClick={() => setIsEditingInspector(false)} className="flex-1 bg-gray-200 text-gray-700 py-2 rounded text-sm font-bold">Cancel</button>
                          </div>
                      ) : (
                          <button onClick={handleDeleteAsset} className="w-full bg-red-50 text-red-600 hover:bg-red-100 py-2 rounded text-sm font-bold flex items-center justify-center gap-2 border border-red-200"><TrashIcon className="w-4 h-4" /> Delete</button>
                      )}
                  </div>
              </div>
          )}
      </div>

      {/* Selection Footer */}
      {(selectedStorageAssets.size > 0 || selectedDynamicAssets.size > 0) && (
        <footer className="mt-auto sticky bottom-4 bg-white/90 backdrop-blur-md border border-gray-200 p-3 rounded-xl shadow-lg z-20 flex justify-between items-center">
            <p className="font-medium text-sm text-gray-700">{selectedStorageAssets.size + selectedDynamicAssets.size} asset(s) selected</p>
            <div className="flex gap-2">
              <button onClick={() => {setSelectedStorageAssets(new Set()); setSelectedDynamicAssets(new Set()); setInspectedAssetId(null);}} className="px-4 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-semibold rounded-lg text-sm">Clear</button>
              <button onClick={handleUseAssets} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-sm shadow-md">Use Selected</button>
            </div>
        </footer>
      )}

      {/* Smart Upload Modal */}
      <Modal isOpen={showSmartUpload} onClose={() => setShowSmartUpload(false)} title="Upload Smart Asset">
          <div className="space-y-4">
              <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1">Asset Type</label>
                  <select value={smartUploadType} onChange={(e) => setSmartUploadType(e.target.value)} className="w-full border border-gray-300 rounded p-2">
                      <option value="character">Character</option>
                      <option value="setting">Location/Setting</option>
                      <option value="product">Product</option>
                      <option value="storyboard">Storyboard</option>
                  </select>
              </div>
              <div><label className="block text-sm font-bold text-gray-700 mb-1">Name</label><input type="text" value={smartUploadName} onChange={(e) => setSmartUploadName(e.target.value)} className="w-full border border-gray-300 rounded p-2" /></div>
              <div><label className="block text-sm font-bold text-gray-700 mb-1">Description</label><textarea value={smartUploadPrompt} onChange={(e) => setSmartUploadPrompt(e.target.value)} className="w-full border border-gray-300 rounded p-2 h-20" /></div>
              <div><label className="block text-sm font-bold text-gray-700 mb-1">File</label><input type="file" onChange={(e) => setSmartUploadFile(e.target.files?.[0] || null)} className="w-full border border-gray-300 rounded p-2" /></div>
              <button onClick={handleSmartUpload} disabled={isUploading} className="w-full bg-indigo-600 text-white py-2 rounded font-bold">{isUploading ? 'Uploading...' : 'Upload & Save'}</button>
          </div>
      </Modal>

      {/* AI Asset Generator Modal (Imagen 4.0) */}
      <Modal isOpen={showGenerator} onClose={() => setShowGenerator(false)} title="Generate Asset with AI">
          <div className="flex flex-col h-[500px]">
              {/* Stepper */}
              <div className="flex items-center justify-between mb-6 px-4">
                  <div className={`flex flex-col items-center ${genStep >= 1 ? 'text-indigo-600' : 'text-gray-400'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold mb-1 ${genStep >= 1 ? 'bg-indigo-100' : 'bg-gray-100'}`}>1</div>
                      <span className="text-xs font-bold">Concept</span>
                  </div>
                  <div className={`h-0.5 flex-grow mx-2 ${genStep >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
                  <div className={`flex flex-col items-center ${genStep >= 2 ? 'text-indigo-600' : 'text-gray-400'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold mb-1 ${genStep >= 2 ? 'bg-indigo-100' : 'bg-gray-100'}`}>2</div>
                      <span className="text-xs font-bold">Profile</span>
                  </div>
                  <div className={`h-0.5 flex-grow mx-2 ${genStep >= 3 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
                  <div className={`flex flex-col items-center ${genStep >= 3 ? 'text-indigo-600' : 'text-gray-400'}`}>
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold mb-1 ${genStep >= 3 ? 'bg-indigo-100' : 'bg-gray-100'}`}>3</div>
                      <span className="text-xs font-bold">Image</span>
                  </div>
              </div>
              
              <div className="flex-grow overflow-y-auto px-4 py-2">
                  {genStep === 1 && (
                      <div className="space-y-4">
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">Asset Type</label>
                              <div className="grid grid-cols-3 gap-3">
                                  {['character', 'setting', 'product'].map((t: any) => (
                                      <button key={t} onClick={() => setGenType(t)} className={`p-3 rounded-lg border text-center capitalize ${genType === t ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-bold' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}>
                                          {t === 'setting' ? 'Location' : t}
                                      </button>
                                  ))}
                              </div>
                          </div>
                          <div>
                              <div className="flex justify-between items-center mb-2">
                                  <label className="block text-sm font-bold text-gray-700">Concept / Idea</label>
                                  <button onClick={handleEnhancePrompt} disabled={isEnhancingPrompt} className="text-[10px] text-indigo-600 bg-indigo-50 px-2 py-1 rounded hover:bg-indigo-100 transition-colors flex items-center gap-1 font-bold">
                                      {isEnhancingPrompt ? 'Enhancing...' : <><MagicWandIcon className="w-3 h-3"/> AI Enhance</>}
                                  </button>
                              </div>
                              <textarea 
                                  className="w-full h-32 border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                  placeholder={genType === 'setting' ? "Describe the location... (e.g. Modern minimalist kitchen with morning sunlight)" : `Describe your ${genType}...`}
                                  value={genConcept}
                                  onChange={(e) => setGenConcept(e.target.value)}
                              />
                          </div>
                          <button onClick={handleGenerateProfile} disabled={isGeneratingProfile || !genConcept.trim()} className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold shadow-md hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
                              {isGeneratingProfile ? 'Brainstorming Profile...' : <><SparklesIcon className="w-5 h-5"/> Generate Profile</>}
                          </button>
                      </div>
                  )}

                  {genStep === 2 && genProfile && (
                      <div className="space-y-4">
                          <p className="text-sm text-gray-600">Review and edit the AI-generated profile before creating the image.</p>
                          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 space-y-3">
                              <div><span className="text-xs font-bold text-gray-500 uppercase">Name</span><p className="font-bold">{genProfile.name}</p></div>
                              {genProfile.backstory && <div><span className="text-xs font-bold text-gray-500 uppercase">Backstory</span><p className="text-sm">{genProfile.backstory}</p></div>}
                              {genProfile.details && <div><span className="text-xs font-bold text-gray-500 uppercase">Details</span><p className="text-sm">{genProfile.details.join(', ')}</p></div>}
                          </div>
                          <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">Visual Prompt (Editable)</label>
                              <textarea 
                                  className="w-full h-32 border border-gray-300 rounded-lg p-3 text-sm"
                                  value={genProfile.visual_prompt}
                                  onChange={(e) => setGenProfile({...genProfile, visual_prompt: e.target.value})}
                              />
                          </div>
                          <div className="flex gap-3">
                              <button onClick={() => setGenStep(1)} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-bold">Back</button>
                              <button onClick={handleGenerateAssetImage} disabled={isGeneratingImage} className="flex-[2] bg-indigo-600 text-white py-3 rounded-lg font-bold shadow-md hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
                                  {isGeneratingImage ? 'Generating Image...' : <><MagicWandIcon className="w-5 h-5"/> Generate Image (Imagen 4.0)</>}
                              </button>
                          </div>
                      </div>
                  )}

                  {genStep === 3 && genImage && (
                      <div className="space-y-4 h-full flex flex-col">
                          <div className="flex-grow bg-gray-100 rounded-lg overflow-hidden border border-gray-200 relative group">
                              <img src={`data:image/jpeg;base64,${genImage}`} className="w-full h-full object-contain" />
                          </div>
                          <div className="flex gap-3 mt-auto">
                              <button onClick={() => setGenStep(2)} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-bold">Back</button>
                              <button onClick={handleSaveGeneratedAsset} disabled={isUploading} className="flex-[2] bg-green-600 text-white py-3 rounded-lg font-bold shadow-md hover:bg-green-700 disabled:opacity-50">
                                  {isUploading ? 'Saving...' : 'Save to Library'}
                              </button>
                          </div>
                      </div>
                  )}
              </div>
          </div>
      </Modal>
    </div>
  );
};

export default AssetStudio;
