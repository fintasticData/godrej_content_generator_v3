
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { Influencer, BrandIdentity, Product, AspectRatio } from '../types';
import { brainstormDarlingTrends, generateImage } from '../services/geminiService';
import { fetchBrands, fetchProducts, uploadBlob, updateCharacter, supabase } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    SparklesIcon, 
    BoltIcon,
    ArrowRightIcon,
    CheckCircleIcon,
    GlobeAltIcon,
    ShoppingBagIcon,
    FireIcon,
    PhotoIcon,
    Square2StackIcon,
    MagicWandIcon
} from './icons';

interface DarlingTrendsetterProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

interface TrendConcept {
    style_name: string;
    product_used: string;
    description: string;
    visual_prompt: string;
    generatedUrl?: string;
}

const DarlingTrendsetter: React.FC<DarlingTrendsetterProps> = ({ character, onClose, onSuccess }) => {
    const [trendVibe, setTrendVibe] = useState('');
    const [isIdeating, setIsIdeating] = useState(false);
    const [concepts, setConcepts] = useState<TrendConcept[]>([]);
    const [isGeneratingVisual, setIsGeneratingVisual] = useState<string | null>(null);
    const [isBulkGenerating, setIsBulkGenerating] = useState(false);
    const [isSaving, setIsSaving] = useState<string | null>(null);

    // Brand Context
    const [darlingBrand, setDarlingBrand] = useState<BrandIdentity | null>(null);
    const [darlingProducts, setDarlingProducts] = useState<Product[]>([]);
    const [useBrandDNA, setUseBrandDNA] = useState(true);

    useEffect(() => {
        const loadContext = async () => {
            // 1. Find Darling Brand - Prioritize specific ID
            const allBrands = await fetchBrands();
            let darling = allBrands?.find(b => b.id === '39498288-b88f-4357-ba4b-5a771425e5ad');
            
            if (!darling) {
                darling = allBrands?.find(b => b.brand_name.toLowerCase().includes('darling'));
            }

            if (darling) {
                setDarlingBrand(darling);
                // 2. Fetch Products
                const prods = await fetchProducts(darling.id);
                setDarlingProducts(prods || []);
            }
        };
        loadContext();
    }, []);

    const parseBrandData = (brand: BrandIdentity | null) => {
        if (!brand || !brand.brand_data) return null;
        try {
            return typeof brand.brand_data === 'string' 
                ? JSON.parse(brand.brand_data) 
                : brand.brand_data;
        } catch { return null; }
    };

    const urlToBase64 = async (url: string): Promise<string> => {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(blob);
        });
    };

    const handleIdeate = async () => {
        if (!trendVibe.trim()) return;
        setIsIdeating(true);
        try {
            let brandVoice = "Empowering, Beautiful, Unstoppable.";
            const brandData = parseBrandData(darlingBrand);

            if (useBrandDNA && brandData) {
                // Construct rich brand context
                const tone = brandData.tone_of_voice?.archetypes?.join(', ') || "Trendsetting";
                const pillars = brandData.brand_pillars?.map((p: any) => p.name).join(', ') || "";
                const slogan = brandData.core_identity?.slogan || "";
                
                brandVoice = `Archetypes: ${tone}. Pillars: ${pillars}. Slogan: ${slogan}. Guidelines: Be honest, direct, genuine.`;
            }

            // List available product names for AI
            const productNames = darlingProducts.map(p => p.product_name);

            const results = await brainstormDarlingTrends(trendVibe, productNames, brandVoice);
            setConcepts(results);
        } catch (e) {
            console.error(e);
            alert("Failed to generate trends.");
        } finally {
            setIsIdeating(false);
        }
    };

    const handleVisualize = async (concept: TrendConcept, index: number) => {
        const charImg = character.image_url || character.image_urls_jsonb?.[0]?.url;
        if (!charImg) { alert("Character needs a base image."); return; }

        setIsGeneratingVisual(concept.style_name);
        try {
            const charB64 = await urlToBase64(charImg);
            
            let finalPrompt = `${concept.visual_prompt}. Photorealistic fashion photography.`;
            const brandData = parseBrandData(darlingBrand);

            if (useBrandDNA && brandData) {
                const vis = brandData.visual_identity;
                const gen = brandData.image_generation_guidelines;
                
                let brandDirectives = "";
                if (vis?.primary_color?.name) brandDirectives += ` Include distinct ${vis.primary_color.name} accents.`;
                if (gen?.lighting) brandDirectives += ` Lighting: ${gen.lighting}.`;
                if (gen?.composition) brandDirectives += ` Composition: ${gen.composition}.`;
                if (gen?.skin_texture) brandDirectives += ` Skin Texture: ${gen.skin_texture}.`;
                
                finalPrompt += ` BRAND MANDATORIES: ${brandDirectives} High-end commercial look.`;
            }

            // Nano Banana (Flash Image) is efficient for trend visualization
            const result = await generateImage(
                finalPrompt,
                AspectRatio.SQUARE, // Aspect Ratio
                { character: charB64 }
            );

            // Upload immediately
            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const fileName = `trend_${index}_${Date.now()}.png`;
            const url = await uploadBlob(blob, fileName, 'godrej/trends');

            if (url) {
                setConcepts(prev => prev.map((c, i) => i === index ? { ...c, generatedUrl: url } : c));
            }
        } catch (e) {
            console.error(e);
            // alert("Visual generation failed.");
        } finally {
            setIsGeneratingVisual(null);
        }
    };

    const handleGenerateAll = async () => {
        if (concepts.length === 0) return;
        setIsBulkGenerating(true);
        const charImg = character.image_url || character.image_urls_jsonb?.[0]?.url;
        
        if (!charImg) { 
            alert("Character needs a base image."); 
            setIsBulkGenerating(false);
            return; 
        }

        for (let i = 0; i < concepts.length; i++) {
            if (!concepts[i].generatedUrl) {
                await handleVisualize(concepts[i], i);
            }
        }
        setIsBulkGenerating(false);
    };

    const handleSave = async (concept: TrendConcept) => {
        if (!concept.generatedUrl) return;
        setIsSaving(concept.style_name);
        try {
            const pk = character.character_id || character.id;
            const { data: freshChar } = await supabase
                .from('dng1_characters')
                .select('image_urls_jsonb')
                .eq('character_id', pk)
                .single();

            const currentGallery = freshChar?.image_urls_jsonb || [];
            const newEntry = {
                url: concept.generatedUrl,
                type: 'trend_setter',
                description: `Darling Trend: ${concept.style_name}`,
                features: concept.description,
                metadata: {
                    style_name: concept.style_name,
                    product_used: concept.product_used,
                    visual_prompt: concept.visual_prompt,
                    vibe: trendVibe
                }
            };

            await updateCharacter(pk!, { image_urls_jsonb: [newEntry, ...currentGallery] });
            onSuccess();
            alert("Saved to gallery!");
        } catch (e) {
            console.error(e);
        } finally {
            setIsSaving(null);
        }
    };

    return (
        <div className="fixed inset-0 z-[160] bg-purple-900/90 backdrop-blur-xl flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-5xl h-[90vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden relative border-4 border-purple-500">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full z-20 transition-colors"><XMarkIcon className="w-6 h-6 text-gray-500"/></button>

                {/* LEFT: Context & Input */}
                <div className="w-[350px] bg-purple-50 p-8 flex flex-col border-r border-purple-100">
                    <div className="mb-8">
                        <h2 className="text-2xl font-black text-purple-900 uppercase tracking-tighter leading-none mb-2">Darling Trendsetter</h2>
                        <p className="text-xs font-bold text-purple-600 uppercase tracking-widest flex items-center gap-2">
                            <BoltIcon className="w-4 h-4"/> AI Trend Engine
                        </p>
                    </div>

                    <div className="space-y-6">
                        <div className="bg-white p-4 rounded-2xl shadow-sm border border-purple-100">
                            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                                <GlobeAltIcon className="w-3 h-3"/> Brand Context
                            </h4>
                            {darlingBrand ? (
                                <div className="space-y-3">
                                    <div>
                                        <p className="text-sm font-bold text-gray-900">{darlingBrand.brand_name}</p>
                                        <p className="text-xs text-gray-500 mt-1">{darlingProducts.length} Products Active</p>
                                    </div>
                                    <div 
                                        className={`flex items-center gap-3 p-2 rounded-xl cursor-pointer border transition-colors ${useBrandDNA ? 'bg-purple-100 border-purple-200' : 'bg-gray-50 border-gray-100'}`}
                                        onClick={() => setUseBrandDNA(!useBrandDNA)}
                                    >
                                        <div className={`w-8 h-5 rounded-full p-1 transition-colors ${useBrandDNA ? 'bg-purple-600' : 'bg-gray-300'}`}>
                                            <div className={`w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${useBrandDNA ? 'translate-x-3' : 'translate-x-0'}`}></div>
                                        </div>
                                        <span className={`text-[10px] font-black uppercase tracking-wide ${useBrandDNA ? 'text-purple-700' : 'text-gray-400'}`}>Inject Brand DNA</span>
                                    </div>
                                    {useBrandDNA && (
                                        <div className="text-[9px] text-purple-600 leading-tight bg-white p-2 rounded-lg border border-purple-50">
                                            <span className="font-bold">Active:</span> #FindYourBeautiful, Unstoppable Spirit, Authentic Tone.
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <p className="text-xs text-red-400 italic">"Darling" brand not found in DB.</p>
                            )}
                        </div>

                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-purple-900 uppercase tracking-widest">Trend Theme / Vibe</label>
                            <textarea 
                                className="w-full h-32 bg-white border border-purple-200 rounded-xl p-4 text-sm font-medium focus:ring-4 focus:ring-purple-200 outline-none resize-none shadow-sm"
                                placeholder="e.g. Summer Festival, Corporate Power, Afro-Punk Future..."
                                value={trendVibe}
                                onChange={(e) => setTrendVibe(e.target.value)}
                            />
                        </div>

                        <button 
                            onClick={handleIdeate}
                            disabled={isIdeating || !darlingBrand}
                            className="w-full py-4 bg-purple-600 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-purple-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                            {isIdeating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4"/>}
                            {isIdeating ? 'Analyzing Trends...' : 'Generate Concepts'}
                        </button>
                    </div>
                </div>

                {/* RIGHT: Results */}
                <div className="flex-1 overflow-y-auto p-10 bg-white">
                    {concepts.length > 0 ? (
                        <div className="space-y-8">
                            <div className="flex justify-between items-end">
                                <h3 className="text-xl font-black text-gray-900 uppercase tracking-tight flex items-center gap-2">
                                    <FireIcon className="w-6 h-6 text-orange-500"/> Trending Concepts
                                </h3>
                                <button 
                                    onClick={handleGenerateAll} 
                                    disabled={isBulkGenerating}
                                    className="px-5 py-2 bg-indigo-50 text-indigo-700 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center gap-2 border border-indigo-100"
                                >
                                    {isBulkGenerating ? <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <Square2StackIcon className="w-3 h-3"/>}
                                    {isBulkGenerating ? 'Processing Batch...' : 'Visualize All'}
                                </button>
                            </div>
                            
                            <div className="grid grid-cols-1 gap-6">
                                {concepts.map((concept, idx) => (
                                    <div key={idx} className="flex gap-6 p-6 rounded-3xl border border-gray-100 hover:border-purple-200 shadow-sm hover:shadow-lg transition-all bg-gray-50">
                                        <div className="w-48 shrink-0 flex flex-col gap-3">
                                            {concept.generatedUrl ? (
                                                <div className="aspect-square rounded-2xl overflow-hidden shadow-md">
                                                    <img src={concept.generatedUrl} className="w-full h-full object-cover" />
                                                </div>
                                            ) : (
                                                <div className="aspect-square rounded-2xl bg-gray-200 flex items-center justify-center text-gray-400">
                                                    {isGeneratingVisual === concept.style_name ? <div className="w-6 h-6 border-2 border-gray-400 border-t-transparent rounded-full animate-spin"></div> : <PhotoIcon className="w-12 h-12 opacity-20"/>}
                                                </div>
                                            )}
                                            {concept.generatedUrl ? (
                                                <button 
                                                    onClick={() => handleSave(concept)}
                                                    disabled={isSaving === concept.style_name}
                                                    className="w-full py-2 bg-green-500 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-md hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
                                                >
                                                    {isSaving === concept.style_name ? 'Saving...' : <><CheckCircleIcon className="w-3 h-3"/> Save Look</>}
                                                </button>
                                            ) : (
                                                <button 
                                                    onClick={() => handleVisualize(concept, idx)}
                                                    disabled={isGeneratingVisual === concept.style_name || isBulkGenerating}
                                                    className="w-full py-2 bg-purple-600 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest shadow-md hover:bg-purple-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
                                                >
                                                    {isGeneratingVisual === concept.style_name ? 'Rendering...' : 'Visualize'}
                                                </button>
                                            )}
                                        </div>
                                        <div className="flex-1">
                                            <div className="flex justify-between items-start mb-2">
                                                <h4 className="text-xl font-bold text-gray-900">{concept.style_name}</h4>
                                                <span className="bg-purple-100 text-purple-700 text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest flex items-center gap-1">
                                                    <ShoppingBagIcon className="w-3 h-3"/> {concept.product_used}
                                                </span>
                                            </div>
                                            <p className="text-sm text-gray-600 mb-4 leading-relaxed">{concept.description}</p>
                                            <div className="bg-white p-3 rounded-xl border border-gray-200 relative group">
                                                <p className="text-[10px] text-gray-400 font-mono line-clamp-2">AI Prompt: {concept.visual_prompt}</p>
                                                {useBrandDNA && <div className="absolute top-2 right-2 text-[8px] font-bold text-white bg-purple-600 px-2 py-0.5 rounded-full opacity-50 group-hover:opacity-100 transition-opacity">Brand DNA Injected</div>}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                            <BoltIcon className="w-24 h-24 text-gray-300 mb-4"/>
                            <h3 className="text-xl font-bold text-gray-400">Waiting for Inspiration</h3>
                            <p className="text-sm text-gray-400 mt-2 max-w-xs">Enter a vibe on the left to start the Darling Trend Engine.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DarlingTrendsetter;
