
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { supabase, uploadBlob, fetchProducts, fetchBrands, createProduct, updateProduct, deleteProduct, createBrand } from '../services/supabaseClient';
import { generateImage, brainstormBrand, researchBrandWithGoogle } from '../services/geminiService';
import { Product, BrandIdentity, AspectRatio } from '../types';
import { 
    PlusIcon, 
    SparklesIcon, 
    CubeIcon, 
    LinkIcon, 
    PencilSquareIcon, 
    TrashIcon, 
    UploadCloudIcon, 
    CheckCircleIcon, 
    SearchIcon,
    MagicWandIcon,
    XMarkIcon,
    PhotoIcon,
    SaveIcon,
    BoltIcon,
    ArrowRightIcon,
    ShoppingBagIcon,
    ChevronRightIcon,
    GlobeAltIcon,
    MapPinIcon
} from './icons';
import Modal from './Modal';

// --- Helper: Parse JSON Data ---
const parseBrandData = (data: any) => {
    if (!data) return {};
    if (typeof data === 'string') {
        try { return JSON.parse(data); } catch { return {}; }
    }
    if (Array.isArray(data)) return data[0] || {};
    return data;
};

// --- Helper: Get Product Image ---
const getProductImageUrl = (product: Product): string | null => {
    if (!product.image) return null;
    if (typeof product.image === 'string') return product.image;
    return product.image.primary || product.image.url || null;
};

// --- Brand Card Component ---
const BrandCard: React.FC<{ brand: BrandIdentity, onClick: () => void }> = ({ brand, onClick }) => {
    const data = parseBrandData(brand.brand_data);
    const purpose = data.brand_essence?.purpose || data.core_identity?.purpose || "No purpose defined.";
    
    return (
        <div 
            onClick={onClick}
            className="group bg-white rounded-3xl border border-gray-100 p-6 shadow-sm hover:shadow-2xl hover:border-[#9063CD] hover:-translate-y-1 transition-all cursor-pointer relative overflow-hidden h-[320px] flex flex-col"
        >
            {/* Header / Logo */}
            <div className="flex items-start justify-between mb-4">
                <div className="w-16 h-16 rounded-2xl bg-gray-50 border border-gray-100 p-2 flex items-center justify-center overflow-hidden">
                    {brand.brand_image_url ? (
                        <img src={brand.brand_image_url} className="w-full h-full object-contain" alt={brand.brand_name} />
                    ) : (
                        <CubeIcon className="w-8 h-8 text-gray-300" />
                    )}
                </div>
                {data.origin?.country && (
                    <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded flex items-center gap-1">
                        <MapPinIcon className="w-3 h-3"/> {data.origin.country}
                    </span>
                )}
            </div>

            {/* Content */}
            <div className="flex-1">
                <h3 className="text-2xl font-black text-gray-900 tracking-tight mb-2 leading-none">{brand.brand_name}</h3>
                <p className="text-xs text-gray-500 font-medium line-clamp-3 leading-relaxed">{purpose}</p>
            </div>

            {/* Footer Stats */}
            <div className="pt-4 border-t border-gray-50 flex items-center justify-between text-gray-400">
                <div className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest">
                    <ShoppingBagIcon className="w-3 h-3"/> Portfolio
                </div>
                <div className="w-8 h-8 rounded-full bg-gray-50 flex items-center justify-center group-hover:bg-[#9063CD] group-hover:text-white transition-colors">
                    <ArrowRightIcon className="w-4 h-4"/>
                </div>
            </div>
        </div>
    );
};

const BrandCenter: React.FC = () => {
    // --- Global State ---
    const [brands, setBrands] = useState<BrandIdentity[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [selectedBrand, setSelectedBrand] = useState<BrandIdentity | null>(null);
    
    // --- Workspace State ---
    const [activeTab, setActiveTab] = useState<'identity' | 'products'>('identity');
    const [brandProducts, setBrandProducts] = useState<Product[]>([]);
    const [isSaving, setIsSaving] = useState(false);
    
    // --- Identity Editor State ---
    const [identityJson, setIdentityJson] = useState<string>('');
    const [isRawMode, setIsRawMode] = useState(false);
    
    // --- AI Research State ---
    const [showResearchModal, setShowResearchModal] = useState(false);
    const [researchQuery, setResearchQuery] = useState('');
    const [isResearching, setIsResearching] = useState(false);

    // --- Product Creation State ---
    const [showCreateProductModal, setShowCreateProductModal] = useState(false);
    const [newProductName, setNewProductName] = useState('');
    
    // --- New Brand Creation ---
    const [showCreateBrandModal, setShowCreateBrandModal] = useState(false);
    const [newBrandName, setNewBrandName] = useState('');
    const [newBrandImage, setNewBrandImage] = useState<File | null>(null);
    const [newBrandImagePreview, setNewBrandImagePreview] = useState<string | null>(null);

    const fileInputRef = useRef<HTMLInputElement>(null);
    const brandFileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        loadBrands();
    }, []);

    useEffect(() => {
        if (selectedBrand) {
            loadBrandDetails(selectedBrand);
        }
    }, [selectedBrand]);

    const loadBrands = async () => {
        setIsLoading(true);
        const data = await fetchBrands();
        setBrands(data || []);
        setIsLoading(false);
    };

    const loadBrandDetails = async (brand: BrandIdentity) => {
        // Load Products
        const products = await fetchProducts(brand.id);
        setBrandProducts(products || []);
        
        // Setup JSON Editor
        let data = brand.brand_data;
        try {
            if (typeof data === 'string') data = JSON.parse(data);
        } catch { data = {}; }
        setIdentityJson(JSON.stringify(data, null, 2));
    };

    const handleCreateBrand = async () => {
        if (!newBrandName.trim()) return;
        setIsSaving(true);
        try {
            let logoUrl = null;
            if (newBrandImage) {
                // Ensure safe filename
                const safeName = newBrandName.replace(/[^a-z0-9]/gi, '_').toLowerCase();
                const fileName = `brand_logo_${safeName}_${Date.now()}.png`;
                logoUrl = await uploadBlob(newBrandImage, fileName, 'godrej/brand_logos');
            }

            const result = await createBrand({ 
                brand_name: newBrandName,
                brand_data: { 
                    brand_essence: { purpose: "New Brand" },
                    origin: { country: "Global" }
                },
                brand_image_url: logoUrl || undefined
            });

            if (result) {
                setBrands(prev => [result, ...prev]);
                setShowCreateBrandModal(false);
                setNewBrandName('');
                setNewBrandImage(null);
                setNewBrandImagePreview(null);
                setSelectedBrand(result); // Auto-open
            }
        } catch(e) { console.error(e); alert("Failed to create brand"); }
        finally { setIsSaving(false); }
    };

    const handleSaveIdentity = async () => {
        if (!selectedBrand) return;
        setIsSaving(true);
        try {
            let parsed = {};
            try { parsed = JSON.parse(identityJson); } catch (e) { alert("Invalid JSON"); setIsSaving(false); return; }
            
            const { error } = await supabase.from('dng1_brand_identity').update({
                brand_data: parsed,
                brand_name: selectedBrand.brand_name // In case name editing is added later
            }).eq('id', selectedBrand.id);
            
            if (error) throw error;
            
            // Update local state
            setBrands(prev => prev.map(b => b.id === selectedBrand.id ? { ...b, brand_data: parsed } : b));
            setSelectedBrand({ ...selectedBrand, brand_data: parsed });
            alert("Brand Identity Updated");
        } catch (e) { console.error(e); alert("Save failed"); }
        finally { setIsSaving(false); }
    };

    const handleResearchBrand = async () => {
        if (!researchQuery.trim()) return;
        setIsResearching(true);
        try {
            const researchData = await researchBrandWithGoogle(researchQuery);
            
            // Merge with existing or replace? Let's merge smart.
            let current = {};
            try { current = JSON.parse(identityJson); } catch {}
            
            const merged = { ...current, ...researchData };
            setIdentityJson(JSON.stringify(merged, null, 2));
            
            setShowResearchModal(false);
            setResearchQuery('');
        } catch (e) { console.error(e); alert("Research failed"); }
        finally { setIsResearching(false); }
    };

    const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !selectedBrand) return;
        setIsSaving(true);
        try {
            const url = await uploadBlob(file, `brand_logo_${selectedBrand.id}_${Date.now()}.png`, 'godrej/brand_logos');
            if (url) {
                await supabase.from('dng1_brand_identity').update({ brand_image_url: url }).eq('id', selectedBrand.id);
                setSelectedBrand({ ...selectedBrand, brand_image_url: url });
                setBrands(prev => prev.map(b => b.id === selectedBrand.id ? { ...b, brand_image_url: url } : b));
            }
        } catch (e) { console.error(e); } finally { setIsSaving(false); }
    };

    const handleCreateProduct = async () => {
        if (!selectedBrand || !newProductName.trim()) return;
        setIsSaving(true);
        try {
            await createProduct({
                brand_id: selectedBrand.id,
                product_name: newProductName,
                product_insight: `New product for ${selectedBrand.brand_name}`,
                product_data: {}
            });
            await loadBrandDetails(selectedBrand); // Refresh products
            setShowCreateProductModal(false);
            setNewProductName('');
        } catch(e) { console.error(e); } finally { setIsSaving(false); }
    };

    // --- RENDERERS ---

    const renderIdentityEditor = () => {
        if (isRawMode) {
            return (
                <textarea 
                    className="w-full h-[600px] bg-gray-900 text-green-400 font-mono text-sm p-6 rounded-2xl outline-none resize-none shadow-inner"
                    value={identityJson}
                    onChange={(e) => setIdentityJson(e.target.value)}
                />
            );
        }

        let data: any = {};
        try { data = JSON.parse(identityJson); } catch {}

        // Helper to update nested JSON safely
        const updateField = (path: string[], value: any) => {
            const newData = { ...data };
            let current = newData;
            for (let i = 0; i < path.length - 1; i++) {
                if (!current[path[i]]) current[path[i]] = {};
                current = current[path[i]];
            }
            current[path[path.length - 1]] = value;
            setIdentityJson(JSON.stringify(newData, null, 2));
        };

        return (
            <div className="space-y-8 animate-fade-in-up pb-20">
                {/* 1. Essence Section */}
                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                    <h4 className="text-sm font-black text-gray-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                        <SparklesIcon className="w-4 h-4 text-[#9063CD]"/> Brand Essence
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Persona / Archetype</label>
                            <input 
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-bold text-gray-800 focus:ring-2 focus:ring-[#9063CD] outline-none transition-all" 
                                value={data.brand_essence?.persona || ''} 
                                onChange={(e) => updateField(['brand_essence', 'persona'], e.target.value)}
                                placeholder="e.g. The Caring Expert"
                            />
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Purpose / Mission</label>
                            <input 
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-bold text-gray-800 focus:ring-2 focus:ring-[#9063CD] outline-none transition-all" 
                                value={data.brand_essence?.purpose || ''} 
                                onChange={(e) => updateField(['brand_essence', 'purpose'], e.target.value)}
                                placeholder="e.g. To empower families..."
                            />
                        </div>
                        <div className="col-span-full">
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Core Values (Comma Separated)</label>
                            <input 
                                className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-medium text-gray-800 focus:ring-2 focus:ring-[#9063CD] outline-none transition-all" 
                                value={data.brand_essence?.core_values?.join(', ') || ''} 
                                onChange={(e) => updateField(['brand_essence', 'core_values'], e.target.value.split(',').map((s: string) => s.trim()))}
                                placeholder="Safety, Trust, Innovation"
                            />
                        </div>
                    </div>
                </div>

                {/* 2. Visual Identity Section */}
                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                    <h4 className="text-sm font-black text-gray-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                        <PhotoIcon className="w-4 h-4 text-indigo-500"/> Visual Identity
                    </h4>
                    <div className="grid grid-cols-1 gap-6">
                        <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Logo Description (For AI)</label>
                            <textarea 
                                className="w-full h-24 p-4 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium text-gray-800 focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                                value={data.visual_identity?.logo_description || ''}
                                onChange={(e) => updateField(['visual_identity', 'logo_description'], e.target.value)}
                                placeholder="Describe the logo visual for AI generation..."
                            />
                        </div>
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Typography</label>
                                <input 
                                    className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-medium"
                                    value={data.visual_identity?.typography || ''}
                                    onChange={(e) => updateField(['visual_identity', 'typography'], e.target.value)}
                                />
                            </div>
                            <div>
                                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Primary Color (Hex)</label>
                                <div className="flex items-center gap-2">
                                    <div className="w-12 h-12 rounded-xl border border-gray-200 shadow-sm shrink-0" style={{ backgroundColor: data.visual_identity?.color_palette?.primary?.hex || '#ffffff' }}></div>
                                    <input 
                                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-mono"
                                        value={data.visual_identity?.color_palette?.primary?.hex || ''}
                                        onChange={(e) => updateField(['visual_identity', 'color_palette', 'primary', 'hex'], e.target.value)}
                                        placeholder="#000000"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* 3. Market & Strategy */}
                <div className="bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                    <h4 className="text-sm font-black text-gray-900 uppercase tracking-widest mb-6 flex items-center gap-2">
                        <GlobeAltIcon className="w-4 h-4 text-blue-500"/> Market Strategy
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Target Audience</label>
                            <textarea 
                                className="w-full h-32 p-4 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium resize-none outline-none"
                                value={data.market_positioning?.target_audience || ''}
                                onChange={(e) => updateField(['market_positioning', 'target_audience'], e.target.value)}
                            />
                        </div>
                        <div>
                            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Unique Selling Proposition (USP)</label>
                            <textarea 
                                className="w-full h-32 p-4 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium resize-none outline-none"
                                value={data.market_positioning?.usp || ''}
                                onChange={(e) => updateField(['market_positioning', 'usp'], e.target.value)}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    const renderProductList = () => {
        return (
            <div className="space-y-6 animate-fade-in-up pb-20">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Add New Card */}
                    <div 
                        onClick={() => setShowCreateProductModal(true)}
                        className="bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center gap-4 p-8 cursor-pointer hover:border-[#9063CD] hover:bg-purple-50 transition-all group min-h-[250px]"
                    >
                        <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                            <PlusIcon className="w-8 h-8 text-gray-300 group-hover:text-[#9063CD]"/>
                        </div>
                        <span className="text-xs font-black text-gray-400 uppercase tracking-widest group-hover:text-[#9063CD]">Add New SKU</span>
                    </div>

                    {/* Product Cards */}
                    {brandProducts.map(prod => {
                        const imgUrl = getProductImageUrl(prod);
                        return (
                            <div key={prod.id} className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden flex flex-col h-[250px] relative group hover:shadow-xl hover:border-gray-200 transition-all">
                                <div className="h-40 bg-gray-50 relative overflow-hidden">
                                    {imgUrl ? (
                                        <img src={imgUrl} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                                    ) : (
                                        <div className="w-full h-full flex items-center justify-center"><CubeIcon className="w-12 h-12 text-gray-200 opacity-50"/></div>
                                    )}
                                    <div className="absolute top-2 right-2 bg-white/80 backdrop-blur rounded-lg p-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <ArrowRightIcon className="w-4 h-4 text-gray-600"/>
                                    </div>
                                </div>
                                <div className="p-5 flex-1 flex flex-col justify-center">
                                    <h4 className="font-bold text-gray-900 text-lg leading-tight truncate">{prod.product_name}</h4>
                                    <p className="text-[10px] text-gray-400 uppercase tracking-widest mt-1 truncate">{prod.product_insight || 'No description'}</p>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    };

    return (
        <div className="w-full h-full bg-gray-50 flex overflow-hidden relative font-sans text-gray-900">
            {/* LEFT: Brand List (Master) */}
            <div className={`${selectedBrand ? 'w-[350px] border-r border-gray-200 bg-white' : 'w-full bg-gray-50'} flex flex-col transition-all duration-300 ease-in-out`}>
                <div className="p-6 border-b border-gray-100 bg-white flex justify-between items-center sticky top-0 z-10 shrink-0">
                    <h2 className="text-xl font-black uppercase tracking-tight">Brand Center</h2>
                    <button onClick={() => setShowCreateBrandModal(true)} className="p-2 bg-black text-white rounded-xl shadow-lg hover:scale-105 transition-transform"><PlusIcon className="w-5 h-5"/></button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6">
                    {isLoading ? (
                        <div className="flex justify-center p-12"><div className="w-8 h-8 border-4 border-[#9063CD] border-t-transparent rounded-full animate-spin"></div></div>
                    ) : (
                        <div className={selectedBrand ? "space-y-4" : "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"}>
                            {brands.map(brand => 
                                selectedBrand ? (
                                    // List Item View
                                    <div 
                                        key={brand.id}
                                        onClick={() => setSelectedBrand(brand)}
                                        className={`flex items-center gap-4 p-3 rounded-2xl cursor-pointer transition-all border ${selectedBrand.id === brand.id ? 'bg-[#9063CD]/5 border-[#9063CD] ring-1 ring-[#9063CD]/20' : 'bg-white border-gray-100 hover:border-gray-200'}`}
                                    >
                                        <div className="w-12 h-12 rounded-xl bg-gray-50 shrink-0 overflow-hidden border border-gray-100 p-1 flex items-center justify-center">
                                            {brand.brand_image_url ? <img src={brand.brand_image_url} className="w-full h-full object-contain"/> : <CubeIcon className="w-5 h-5 text-gray-300"/>}
                                        </div>
                                        <div className="min-w-0">
                                            <h4 className="font-bold text-sm text-gray-900 truncate">{brand.brand_name}</h4>
                                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider truncate">View Portfolio</p>
                                        </div>
                                        <ChevronRightIcon className={`w-4 h-4 ml-auto text-gray-400 ${selectedBrand.id === brand.id ? 'text-[#9063CD]' : ''}`}/>
                                    </div>
                                ) : (
                                    // Card View
                                    <BrandCard key={brand.id} brand={brand} onClick={() => setSelectedBrand(brand)} />
                                )
                            )}
                        </div>
                    )}
                </div>
            </div>

            {/* RIGHT: Detail Workspace */}
            {selectedBrand && (
                <div className="flex-1 flex flex-col bg-white overflow-hidden animate-slide-in-right z-20">
                    {/* Workspace Header */}
                    <header className="px-8 py-6 border-b border-gray-100 bg-white flex items-start justify-between shrink-0">
                        <div className="flex items-center gap-6">
                            <div className="w-20 h-20 rounded-[1.5rem] bg-white border border-gray-100 shadow-sm p-3 flex items-center justify-center relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                                {selectedBrand.brand_image_url ? (
                                    <img src={selectedBrand.brand_image_url} className="w-full h-full object-contain" />
                                ) : (
                                    <CubeIcon className="w-8 h-8 text-gray-200" />
                                )}
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 rounded-[1.5rem] flex items-center justify-center transition-opacity">
                                    <PencilSquareIcon className="w-5 h-5 text-white"/>
                                </div>
                                <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleLogoUpload} />
                            </div>
                            <div>
                                <h1 className="text-4xl font-black text-gray-900 tracking-tighter uppercase leading-none">{selectedBrand.brand_name}</h1>
                                <p className="text-sm font-medium text-gray-500 mt-2 flex items-center gap-2">
                                    <GlobeAltIcon className="w-4 h-4"/> Global Identity Manager
                                </p>
                            </div>
                        </div>
                        <button onClick={() => setSelectedBrand(null)} className="p-3 hover:bg-gray-50 rounded-full text-gray-400 transition-colors">
                            <XMarkIcon className="w-6 h-6"/>
                        </button>
                    </header>

                    {/* Tabs */}
                    <div className="px-8 flex gap-8 border-b border-gray-100 shrink-0">
                        <button onClick={() => setActiveTab('identity')} className={`py-4 text-xs font-black uppercase tracking-widest relative ${activeTab === 'identity' ? 'text-[#9063CD]' : 'text-gray-400 hover:text-gray-600'}`}>
                            Brand Identity
                            {activeTab === 'identity' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#9063CD]"></div>}
                        </button>
                        <button onClick={() => setActiveTab('products')} className={`py-4 text-xs font-black uppercase tracking-widest relative ${activeTab === 'products' ? 'text-[#9063CD]' : 'text-gray-400 hover:text-gray-600'}`}>
                            Product Portfolio ({brandProducts.length})
                            {activeTab === 'products' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#9063CD]"></div>}
                        </button>
                    </div>

                    {/* Content Area */}
                    <div className="flex-1 overflow-y-auto p-8 bg-gray-50/30 relative">
                        {activeTab === 'identity' ? renderIdentityEditor() : renderProductList()}
                    </div>

                    {/* Footer Actions (Identity Only) */}
                    {activeTab === 'identity' && (
                        <div className="p-6 border-t border-gray-100 bg-white flex items-center justify-between shrink-0">
                            <div className="flex gap-4">
                                <button onClick={() => setShowResearchModal(true)} className="flex items-center gap-2 px-5 py-3 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-xl font-bold text-xs uppercase tracking-widest transition-colors">
                                    <SparklesIcon className="w-4 h-4"/> Research
                                </button>
                                <button onClick={() => setIsRawMode(!isRawMode)} className="flex items-center gap-2 px-5 py-3 bg-gray-50 text-gray-600 hover:bg-gray-100 rounded-xl font-bold text-xs uppercase tracking-widest transition-colors">
                                    {isRawMode ? 'Visual Editor' : 'Raw JSON'}
                                </button>
                            </div>
                            <button onClick={handleSaveIdentity} disabled={isSaving} className="flex items-center gap-3 px-8 py-4 bg-black text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-gray-800 transition-all disabled:opacity-50">
                                {isSaving ? 'Saving...' : 'Save Identity'} <SaveIcon className="w-4 h-4"/>
                            </button>
                        </div>
                    )}
                </div>
            )}

            {/* Modals */}
            <Modal isOpen={showResearchModal} onClose={() => setShowResearchModal(false)} title="AI Brand Research">
                <div className="space-y-6 p-2">
                    <p className="text-sm text-gray-500">
                        Use <strong>Google Search Grounding</strong> to discover brand details from the web.
                        Enter the brand name or a URL.
                    </p>
                    <textarea 
                        className="w-full h-32 bg-gray-50 border border-gray-200 rounded-xl p-4 font-medium text-gray-900 focus:ring-2 focus:ring-[#9063CD] outline-none resize-none"
                        placeholder="e.g. Darling Hair Africa official website..."
                        value={researchQuery}
                        onChange={(e) => setResearchQuery(e.target.value)}
                    />
                    <button onClick={handleResearchBrand} disabled={isResearching} className="w-full bg-[#9063CD] text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg flex items-center justify-center gap-2">
                        {isResearching ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4"/>}
                        {isResearching ? 'Researching...' : 'Auto-Fill Identity'}
                    </button>
                </div>
            </Modal>

            <Modal isOpen={showCreateProductModal} onClose={() => setShowCreateProductModal(false)} title="Add New Product">
                <div className="space-y-6 p-2">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Product Name</label>
                        <input className="w-full border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none focus:ring-2 focus:ring-[#9063CD]" value={newProductName} onChange={(e) => setNewProductName(e.target.value)} placeholder="e.g. Moisture Lock Shampoo" />
                    </div>
                    <button onClick={handleCreateProduct} disabled={!newProductName || isSaving} className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg">
                        {isSaving ? 'Creating...' : 'Create SKU'}
                    </button>
                </div>
            </Modal>

            <Modal isOpen={showCreateBrandModal} onClose={() => setShowCreateBrandModal(false)} title="Create New Brand">
                <div className="space-y-6 p-2">
                    <div className="flex flex-col items-center gap-4 mb-4">
                        <div 
                            onClick={() => brandFileInputRef.current?.click()}
                            className="w-24 h-24 rounded-2xl bg-gray-50 border-2 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-[#9063CD] hover:bg-purple-50 transition-all overflow-hidden relative group"
                        >
                            {newBrandImagePreview ? (
                                <img src={newBrandImagePreview} className="w-full h-full object-contain" />
                            ) : (
                                <div className="text-center">
                                    <UploadCloudIcon className="w-6 h-6 text-gray-400 mx-auto mb-1"/>
                                    <span className="text-[10px] text-gray-400 font-bold uppercase">Logo</span>
                                </div>
                            )}
                            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <PencilSquareIcon className="w-5 h-5 text-white"/>
                            </div>
                        </div>
                        <input 
                            type="file" 
                            ref={brandFileInputRef} 
                            hidden 
                            accept="image/*" 
                            onChange={(e) => {
                                const file = e.target.files?.[0];
                                if(file) {
                                    setNewBrandImage(file);
                                    setNewBrandImagePreview(URL.createObjectURL(file));
                                }
                            }} 
                        />
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Brand Name</label>
                        <input className="w-full border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none focus:ring-2 focus:ring-[#9063CD]" value={newBrandName} onChange={(e) => setNewBrandName(e.target.value)} placeholder="e.g. Renew Skin" />
                    </div>
                    <button onClick={handleCreateBrand} disabled={!newBrandName || isSaving} className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg">
                        {isSaving ? 'Creating...' : 'Launch Brand'}
                    </button>
                </div>
            </Modal>
        </div>
    );
};

export default BrandCenter;
