
// ... existing imports
import { Video } from '@google/genai';
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { generateImage, generateVideo, generateInsights, editImage, stitchProject, constructStitchPayload, enhanceSceneDescription, generateTransitionPrompt } from '../services/geminiService';
import { uploadBlob, supabase, fetchDynamicAssets } from '../services/supabaseClient';
import {
  AspectRatio,
  GenerationMode,
  Resolution,
  StudioScene,
  VeoModel,
  Asset,
  DynamicAsset
} from '../types';
import {
  FilmIcon,
  SparklesIcon,
  ChatBubbleIcon,
  TrashIcon,
  PencilSquareIcon,
  PlayIcon,
  FolderIcon,
  ArrowRightIcon,
  PlusIcon,
  BoltIcon,
  ClapperboardIcon,
  CheckCircleIcon,
  LinkIcon,
  LayersIcon,
  UploadCloudIcon,
  PhotoIcon,
  MagicWandIcon,
  AlertTriangleIcon,
  MicrophoneIcon,
  MapPinIcon,
  CubeIcon,
  UserIcon,
  XMarkIcon,
  EyeIcon
} from './icons';
import ChatAssistant from './ChatAssistant';
import Modal from './Modal';
import AssetStudio from './AssetStudio';

// ... (Keep existing helper functions urlToBase64, blobToBase64, constants) ...
const urlToBase64 = async (url: string): Promise<string> => {
  const response = await fetch(url);
  const blob = await response.blob();
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1];
      resolve(base64);
    };
    reader.readAsDataURL(blob);
  });
};

const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
          resolve(reader.result.split(',')[1]);
      } else {
          reject(new Error("Failed to convert blob to base64"));
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

const CAMERA_ANGLES = ["Wide Shot", "Medium Shot", "Close Up", "Extreme Close Up", "Low Angle", "Drone View"];
const LIGHTING_STYLES = ["Golden Hour", "Cinematic Studio", "Neon Cyberpunk", "Natural Daylight", "Moody Noir"];

const CAMERA_MOVEMENTS = {
  "Dolly Moves": [
    { label: "Slow Dolly In", desc: "Camera moves slowly forward toward the subject." },
    { label: "Slow Dolly Out", desc: "Camera moves slowly backwards away from the subject." },
    { label: "Fast Dolly In", desc: "Camera moves rapidly forward toward the subject's face, creating an urgent motion." },
    { label: "Vertigo Effect (Zolly)", desc: "Camera moves backward while zooming in, causing the background to expand." }
  ],
  "Infinite Scale": [
    { label: "Extreme Macro Zoom", desc: "Zoom transition from a face to a micro view of the eye." },
    { label: "Cosmic Hyper Zoom", desc: "Fast zoom transition from space down to street level." }
  ],
  "Character-Mounted": [
    { label: "Over the Shoulder", desc: "Camera mounted behind subject A framing subject B." },
    { label: "Fisheye/Peephole", desc: "Extreme wide-angle distortion with a circular frame." }
  ],
  "Environmental": [
    { label: "Reveal from Behind", desc: "Camera slides laterally from behind a pillar to reveal the scene." },
    { label: "Through Shot", desc: "Camera moves through an opening (like a window) into a room." }
  ],
  "Focus & Lens": [
    { label: "Reveal from Blur", desc: "Start completely out of focus and slowly pull focus until sharp." },
    { label: "Rack Focus", desc: "Focus shifts from a foreground object to a background subject." }
  ],
  "Tripod Moves": [
    { label: "Tilt Up", desc: "Camera pans vertically up from legs to head." },
    { label: "Tilt Down", desc: "Camera pans vertically down from head to feet." }
  ],
  "Slider (Lateral)": [
    { label: "Truck Left", desc: "Camera moves sideways on a track to the left." },
    { label: "Truck Right", desc: "Camera moves sideways on a track to the right." }
  ],
  "Orbital": [
    { label: "Orbit 180", desc: "Camera moves in a half-circle around the subject." },
    { label: "Fast 360 Spin", desc: "Camera spins rapidly 360 degrees around the subject." },
    { label: "Cinematic Arc", desc: "Camera moves in a wide curve to reveal a side profile." }
  ],
  "Vertical (Crane)": [
    { label: "Pedestal Up", desc: "Camera rises vertically straight up from waist to eye level." },
    { label: "Crane Up Reveal", desc: "Camera lifts high into the air." },
    { label: "Crane Down", desc: "Camera descends slowly toward the subject." }
  ],
  "Optical Zoom": [
    { label: "Optical Zoom In", desc: "Lens magnifies subject while the camera stays stationary." },
    { label: "Crash Zoom", desc: "Rapid zoom directly into the subject's eyes." }
  ],
  "Drone Aerial": [
    { label: "Drone Fly Over", desc: "High altitude flight moving forward over a landscape." },
    { label: "Epic Drone Reveal", desc: "Rising and tilting down to reveal the scene." },
    { label: "Drone Orbit", desc: "Massive sweeping circle around a large structure." },
    { label: "Top Down", desc: "Camera pointing straight down with a slow twist." },
    { label: "FPV Dive", desc: "Aggressive diving motion down a feature." }
  ],
  "Stylized": [
    { label: "Handheld", desc: "Shaky, natural movement for a documentary feel." },
    { label: "Whip Pan", desc: "Camera whips violently to the side with extreme directional motion blur." },
    { label: "Dutch Angle", desc: "Tilted sideways on the Z-axis for a disorienting effect." }
  ],
  "Tracking": [
    { label: "Leading Shot", desc: "Camera moves backward matching the subject's speed." },
    { label: "Following Shot", desc: "Camera follows behind the subject matching their speed." },
    { label: "POV Walk", desc: "Camera moving forward with a bobbing motion to simulate walking." }
  ],
  "Time Manipulation": [
    { label: "Hyperlapse", desc: "Fast motion with light trails and accelerated time." },
    { label: "Bullet Time", desc: "Ultra slow motion with a camera orbit around a frozen action." }
  ],
  "Extreme": [
    { label: "Barrel Roll", desc: "Camera spins 360 degrees clockwise while moving forward." },
    { label: "Worm's Eye", desc: "Low angle tracking along the ground looking up." }
  ]
};

const DEFAULT_WATERMARK = "https://nrxakqdgbomnfftvoaqy.supabase.co/storage/v1/object/public/RetailData/godrej/icons/Darlin_Purple.JPG";

const IngredientChip: React.FC<{ 
    type: 'character' | 'setting' | 'product', 
    data?: { url: string, name: string }, 
    onClick: () => void,
    onRemove?: () => void
}> = ({ type, data, onClick, onRemove }) => {
    // Type-specific styling
    const styles = {
        character: { bg: 'bg-purple-50', border: 'border-purple-200', iconColor: 'text-purple-500', label: 'Actor' },
        setting: { bg: 'bg-blue-50', border: 'border-blue-200', iconColor: 'text-blue-500', label: 'Location' },
        product: { bg: 'bg-orange-50', border: 'border-orange-200', iconColor: 'text-orange-500', label: 'Product' }
    }[type];

    if (data) {
        return (
            <div className={`relative group flex items-center gap-2 pr-2 pl-1 py-1 rounded-full border bg-white shadow-sm hover:shadow-md transition-all cursor-pointer ${styles.border}`} onClick={onClick}>
                <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-100 shrink-0">
                    <img src={data.url} className="w-full h-full object-cover" alt={data.name} />
                </div>
                <div className="flex flex-col min-w-0 max-w-[80px]">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">{styles.label}</span>
                    <span className="text-[10px] font-bold text-gray-900 truncate">{data.name.split(' ')[0]}</span>
                </div>
                {onRemove && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); onRemove(); }}
                        className="ml-1 p-1 hover:bg-red-50 rounded-full text-gray-300 hover:text-red-500 transition-colors"
                    >
                        <XMarkIcon className="w-3 h-3"/>
                    </button>
                )}
            </div>
        );
    }

    // Empty State (Add Button)
    return (
        <button 
            onClick={onClick}
            className={`flex flex-col items-center justify-center w-10 h-10 rounded-full border-2 border-dashed ${styles.border} ${styles.bg} hover:brightness-95 transition-all group`}
            title={`Add ${styles.label}`}
        >
            {type === 'character' && <UserIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'setting' && <MapPinIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'product' && <CubeIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-sm border border-gray-100">
                <PlusIcon className="w-2 h-2 text-gray-500"/>
            </div>
        </button>
    );
};

interface CreativeStudioProps {
  adId?: string | null;
  onNewProject?: () => void;
  setBreadcrumb?: (name: string | null) => void;
  onBackToLibrary?: () => void;
  onOpenWizard?: (adId: string) => void;
}

type StageView = 'start' | 'end' | 'video' | 'dual';

// ... (Rest of component setup) ...

const CreativeStudio: React.FC<CreativeStudioProps> = ({ adId, onNewProject, setBreadcrumb, onBackToLibrary, onOpenWizard }) => {
  // ... (State hooks) ...
  const [adTitle, setAdTitle] = useState('New Campaign');
  const [finalVideoUrl, setFinalVideoUrl] = useState<string | null>(null);
  const [currentAdId, setCurrentAdId] = useState<string | null>(null);
  const [projectCast, setProjectCast] = useState<DynamicAsset[]>([]);

  // ... (Layout/Asset/Scene State hooks) ...
  const [activeRightTab, setActiveRightTab] = useState<'inspector' | 'chat'>('inspector');
  const [activeSceneId, setActiveSceneId] = useState<string | null>(null);
  const [stageView, setStageView] = useState<StageView>('dual');
  const [viewingMaster, setViewingMaster] = useState(false);
  
  const [showAssetBrowser, setShowAssetBrowser] = useState(false);
  const [pickingAssetFor, setPickingAssetFor] = useState<{ frame: 'start' | 'end' | 'global' | 'watermark', type: 'image' | 'character' | 'setting' | 'product' | 'watermark' } | null>(null);
  
  const [scenes, setScenes] = useState<StudioScene[]>([]);
  const [deleteConfirmation, setDeleteConfirmation] = useState<{isOpen: boolean, sceneId: string | null}>({isOpen: false, sceneId: null});

  const [isStitching, setIsStitching] = useState(false);
  const [isPolling, setIsPolling] = useState(false);
  const [notification, setNotification] = useState<{message: string, type: 'success' | 'error' | 'info'} | null>(null);
  const [isGeneratingFrame, setIsGeneratingFrame] = useState(false);
  const [showPayloadModal, setShowPayloadModal] = useState(false);
  const [productionPayload, setProductionPayload] = useState<any>(null);
  const [prodWatermark, setProdWatermark] = useState<string>(DEFAULT_WATERMARK);
  const [prodResolution, setProdResolution] = useState<'wide'|'tall'>('wide');

  const [showEditImageModal, setShowEditImageModal] = useState(false);
  const [editImagePrompt, setEditImagePrompt] = useState('');
  const [isEditingImage, setIsEditingImage] = useState(false);
  const [isEnhancingPrompt, setIsEnhancingPrompt] = useState(false);
  const [enhancingTarget, setEnhancingTarget] = useState<{sceneId: string, type: 'start' | 'end'} | null>(null);
  const [activeEditTarget, setActiveEditTarget] = useState<{sceneId: string, type: 'start' | 'end'} | null>(null);
  
  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const startFrameInputRef = useRef<HTMLInputElement>(null);
  const endFrameInputRef = useRef<HTMLInputElement>(null);
  const watermarkUploadRef = useRef<HTMLInputElement>(null);

  // ... (Effects) ...
  useEffect(() => {
    if (adId) {
        if (adId === 'new') handleNewProject();
        else loadProject(adId);
    } else {
        handleNewProject();
    }
  }, [adId]);

  useEffect(() => {
      if (setBreadcrumb) setBreadcrumb(adTitle);
  }, [adTitle]);

  useEffect(() => {
      if (showPayloadModal) {
          const width = prodResolution === 'wide' ? 1920 : 1080;
          const height = prodResolution === 'wide' ? 1080 : 1920;
          const payload = constructStitchPayload(currentAdId || 'draft', adTitle, scenes, prodWatermark, width, height);
          setProductionPayload(payload);
      }
  }, [showPayloadModal, prodWatermark, prodResolution, scenes, adTitle, currentAdId]);

  useEffect(() => {
      if (!activeSceneId && scenes.length > 0) {
          setActiveSceneId(scenes[0].id);
      }
  }, [scenes.length]);

  useEffect(() => {
      if (activeSceneId) {
          const scene = scenes.find(s => s.id === activeSceneId);
          if (scene) {
              if (scene.videoUrl) setStageView('dual');
              else setStageView('dual'); 
          }
      }
  }, [activeSceneId]);

  useEffect(() => {
      if (notification) {
          const timer = setTimeout(() => setNotification(null), 5000);
          return () => clearTimeout(timer);
      }
  }, [notification]);

  useEffect(() => {
    let interval: any;
    if (isPolling && currentAdId && currentAdId !== 'new') {
        interval = setInterval(async () => {
            const { data } = await supabase.from('dng1_ads').select('video_url').eq('id', currentAdId).single();
            if (data?.video_url) {
                setFinalVideoUrl(data.video_url);
                setIsPolling(false);
                setNotification({ message: "Production Complete! Video is ready.", type: 'success' });
            } else {
                console.log("Polling for final video...");
            }
        }, 10000);
    }
    return () => clearInterval(interval);
  }, [isPolling, currentAdId]);

  // ... (Load/Update logic) ...
  const loadProject = async (id: string) => {
    try {
        const { data: adData, error: adError } = await supabase
            .from('dng1_ads')
            .select('*')
            .eq('id', id)
            .single();
        
        if (adError || !adData) throw new Error("Could not load project");

        setCurrentAdId(adData.id);
        setAdTitle(adData.ad_title);
        setFinalVideoUrl(adData.video_url || null);

        const cast = await fetchDynamicAssets('character');
        setProjectCast(cast);
        
        const { data: sceneData } = await supabase
            .from('dng1_ad_scenes')
            .select('*')
            .eq('ad_id', id)
            .order('scene_number', { ascending: true });

        if (sceneData) {
            setScenes(sceneData.map(s => {
                let parsedData: any = {};
                try {
                    parsedData = typeof s.scene_data === 'string' ? JSON.parse(s.scene_data) : s.scene_data;
                } catch(e) {
                    console.error("Failed to parse scene_data", e);
                }

                const audioSpec = parsedData?.audio_spec || {};

                return {
                    id: crypto.randomUUID(),
                    dbId: s.id,
                    order: s.scene_number,
                    prompt: s.description,
                    startPrompt: parsedData?.frames?.start?.prompt || parsedData?.prompt,
                    endPrompt: parsedData?.frames?.end?.prompt,
                    startFrame: s.scene_image_url,
                    endFrame: parsedData?.end_frame_url,
                    videoUrl: parsedData?.video_url,
                    status: parsedData?.video_url ? 'done' : (s.scene_image_url ? 'done' : 'idle'),
                    duration: parsedData?.duration || 8,
                    assignedCharacterId: parsedData?.assigned_character_id,
                    assignedCharacterUrl: parsedData?.assigned_character_url || undefined,
                    insights: parsedData?.insights || [],
                    feedback: s.feedback,
                    audio_spec: audioSpec,
                    composition: parsedData?.composition,
                    startComposition: parsedData?.startComposition,
                    endComposition: parsedData?.endComposition
                };
            }));
        }
    } catch (e) { console.error(e); }
  };

  const handleNewProject = () => {
    setCurrentAdId("new"); 
    setAdTitle("New Campaign");
    setScenes([
        { id: crypto.randomUUID(), order: 1, prompt: "Establishing shot of the modern office environment...", status: 'idle', duration: 4 },
        { id: crypto.randomUUID(), order: 2, prompt: "Close up of the character smiling confidently...", status: 'idle', duration: 4 },
        { id: crypto.randomUUID(), order: 3, prompt: "Product interaction shot, high quality lighting...", status: 'idle', duration: 4 }
    ]);
  };

  const handlePrepareProduction = () => {
      if (scenes.length === 0) {
          alert("No scenes available to stitch.");
          return;
      }
      if (scenes.some(s => s.status !== 'done' && !s.videoUrl)) {
          alert("All scenes must be finalized (rendered as video) before stitching.");
          return;
      }
      setShowPayloadModal(true);
  };

  const confirmStitchProduction = async () => {
      setIsStitching(true);
      setShowPayloadModal(false);
      try {
          if (!currentAdId || currentAdId === 'new') throw new Error("Please save project first.");
          const width = prodResolution === 'wide' ? 1920 : 1080;
          const height = prodResolution === 'wide' ? 1080 : 1920;
          await stitchProject(currentAdId, adTitle, scenes, prodWatermark, width, height);
          
          setNotification({ message: "Production started. Auto-refreshing in progress...", type: 'info' });
          setIsPolling(true);
      } catch (e: any) {
          console.error("Stitching error:", e);
          setNotification({ message: `Production failed: ${e.message}`, type: 'error' });
      } finally {
          setIsStitching(false);
      }
  };

  // ... (Move/Delete/Add Scene logic - Keep as is) ...
  const moveScene = (idx: number, direction: 'up' | 'down') => {
      const newScenes = [...scenes];
      const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (targetIdx < 0 || targetIdx >= newScenes.length) return;
      const temp = newScenes[idx];
      newScenes[idx] = newScenes[targetIdx];
      newScenes[targetIdx] = temp;
      const ordered = newScenes.map((s, i) => ({ ...s, order: i + 1 }));
      setScenes(ordered);
  };

  const handleDeleteClick = (id: string) => { setDeleteConfirmation({isOpen: true, sceneId: id}); }

  const confirmDeleteScene = async () => {
      if (!deleteConfirmation.sceneId) return;
      const id = deleteConfirmation.sceneId;
      const sceneToDelete = scenes.find(s => s.id === id);
      setScenes(prev => prev.filter(s => s.id !== id).map((s, i) => ({ ...s, order: i + 1 })));
      if (activeSceneId === id) setActiveSceneId(null);
      setDeleteConfirmation({isOpen: false, sceneId: null});
      if (sceneToDelete?.dbId) {
          try { await supabase.from('dng1_ad_scenes').delete().eq('id', sceneToDelete.dbId); } catch (e) { console.error("Failed to delete scene from DB", e); }
      }
  };

  const activeScene = useMemo(() => scenes.find(s => s.id === activeSceneId), [scenes, activeSceneId]);
  const previousSceneAvailable = useMemo(() => {
      if (!activeScene) return false;
      const idx = scenes.findIndex(s => s.id === activeScene.id);
      return idx > 0;
  }, [activeScene, scenes]);

  const handleLinkPreviousScene = async () => {
      if (!activeSceneId) return;
      const idx = scenes.findIndex(s => s.id === activeSceneId);
      if (idx <= 0) return;
      const prevScene = scenes[idx - 1];
      const frameToCopy = prevScene.endFrame || prevScene.startFrame; // Use startFrame if endFrame is missing (e.g. single frame scene)
      
      if (frameToCopy) {
          await updateSceneFrame(activeSceneId, 'start', frameToCopy);
      } else {
          alert("Previous scene has no visual frame to link.");
      }
  };

  const handleViewMaster = () => { setViewingMaster(true); };

  const handleAddScene = () => {
      const newOrder = scenes.length + 1;
      const lastScene = scenes[scenes.length - 1];
      // Fallback: If no endFrame, use startFrame to ensure continuity
      const linkedStartFrame = lastScene?.endFrame || lastScene?.startFrame;
      const newScene: StudioScene = {
          id: crypto.randomUUID(),
          order: newOrder,
          prompt: "Describe the action...",
          status: linkedStartFrame ? 'done' : 'idle',
          duration: 4,
          startPrompt: "",
          endPrompt: "",
          startFrame: linkedStartFrame
      };
      setScenes([...scenes, newScene]);
      setActiveSceneId(newScene.id);
      setViewingMaster(false);
  };

  const handleSceneSelect = (id: string) => { setActiveSceneId(id); setViewingMaster(false); };

  const handleEnhancePrompt = async () => {
      if (!activeScene) return;
      setIsEnhancingPrompt(true);
      try {
          // Pass the Mzansi directive context here implicitly via the service which we updated
          const enhanced = await enhanceSceneDescription(activeScene.prompt);
          setScenes(prev => prev.map(s => s.id === activeScene.id ? { ...s, prompt: enhanced } : s));
      } catch (e) { console.error(e); } finally { setIsEnhancingPrompt(false); }
  };

  const addTagToPrompt = (tag: string) => {
      if (!activeScene) return;
      const current = activeScene.prompt || "";
      const separator = current.trim().length > 0 && !current.trim().endsWith('.') ? '. ' : ' ';
      setScenes(prev => prev.map(s => s.id === activeScene.id ? { ...s, prompt: `${current}${separator}${tag}` } : s));
  };

  const appendCameraMove = (move: string) => {
      if (!activeScene) return;
      const current = activeScene.prompt || "";
      const separator = current.trim().length > 0 && !current.trim().endsWith('.') ? '. ' : ' ';
      setScenes(prev => prev.map(s => s.id === activeScene.id ? { ...s, prompt: `${current}${separator}Camera Movement: ${move}` } : s));
  };

  // --- NEW: Visual Analysis Trigger ---
  const handleAnalyzeTransition = async () => {
      if (!activeSceneId) return;
      const scene = scenes.find(s => s.id === activeSceneId);
      if (!scene || !scene.startFrame) { alert("Start frame required for visual analysis."); return; }

      setNotification({ message: "AI is watching the frames to describe motion...", type: 'info' });
      setIsEnhancingPrompt(true); // Reuse this loading state

      try {
           const startBase64 = await urlToBase64(scene.startFrame);
           let endBase64 = null;
           if (scene.endFrame) {
               endBase64 = await urlToBase64(scene.endFrame);
           }

           const transitionPrompt = await generateTransitionPrompt(startBase64, endBase64, scene.prompt || "");
           
           // Update state
           setScenes(prev => prev.map(s => s.id === activeSceneId ? { ...s, prompt: transitionPrompt } : s));
           
           setNotification({ message: "Scene description updated with Visual Transition Analysis!", type: 'success' });
      } catch (e) {
          console.error(e);
          setNotification({ message: "Analysis failed.", type: 'error' });
      } finally {
          setIsEnhancingPrompt(false);
      }
  };

  // ... (Frame Management Logic - Keep as is) ...
  const updateSceneFrame = async (sceneId: string, type: 'start' | 'end', url: string) => {
      const scene = scenes.find(s => s.id === sceneId);
      if (!scene) return;
      if (type === 'start') {
          setScenes(prev => prev.map(s => s.id === sceneId ? { ...s, startFrame: url } : s));
          if (scene.dbId) await supabase.from('dng1_ad_scenes').update({ scene_image_url: url }).eq('id', scene.dbId);
          setStageView('dual'); 
      } else {
          setScenes(prev => {
              const idx = prev.findIndex(s => s.id === sceneId);
              if (idx === -1) return prev;
              const newScenes = [...prev];
              newScenes[idx] = { ...newScenes[idx], endFrame: url };
              if (idx < newScenes.length - 1) { newScenes[idx + 1] = { ...newScenes[idx + 1], startFrame: url }; }
              return newScenes;
          });
          if (scene.dbId) {
              const { data: currentScene } = await supabase.from('dng1_ad_scenes').select('scene_data').eq('id', scene.dbId).single();
              const newData = { ...currentScene?.scene_data, end_frame_url: url };
              await supabase.from('dng1_ad_scenes').update({ scene_data: newData }).eq('id', scene.dbId);
              const idx = scenes.findIndex(s => s.id === sceneId);
              if (idx !== -1 && idx < scenes.length - 1) {
                  const nextScene = scenes[idx + 1];
                  if (nextScene.dbId) { await supabase.from('dng1_ad_scenes').update({ scene_image_url: url }).eq('id', nextScene.dbId); }
              }
          }
          setStageView('dual'); 
      }
  };

  const handleGenerateFrame = async (sceneId: string, type: 'start' | 'end') => {
      const scene = scenes.find(s => s.id === sceneId);
      let promptText = scene?.prompt;
      if (type === 'start' && scene?.startPrompt) promptText = scene.startPrompt;
      if (type === 'end' && scene?.endPrompt) promptText = scene.endPrompt;
      if (!scene || !promptText?.trim()) { alert("Please provide an action prompt first."); return; }
      setIsGeneratingFrame(true);
      try {
          let finalPrompt = promptText;
          if (!finalPrompt.toLowerCase().includes("style")) { finalPrompt = `${finalPrompt}. Cinematic lighting, 8k resolution, highly detailed, photorealistic.`; }
          const references: any = {};
          const comp = (type === 'start' ? scene.startComposition : scene.endComposition) || scene.composition;
          if (comp?.characters && comp.characters.length > 0) {
              const charBase64s = [];
              const charNames = [];
              for (const char of comp.characters) {
                  if (char.url) {
                      const b64 = await urlToBase64(char.url);
                      if (b64) charBase64s.push(b64);
                      charNames.push(char.name);
                  }
              }
              if (charBase64s.length > 0) { references.characters = charBase64s; finalPrompt += ` Featuring characters: ${charNames.join(' and ')}. Maintain their identity exactly.`; }
          } else if (scene.assignedCharacterUrl) {
              references.character = await urlToBase64(scene.assignedCharacterUrl);
              finalPrompt += " The character in the image must match the reference provided exactly.";
          }
          if (comp?.location?.url) { references.setting = await urlToBase64(comp.location.url); finalPrompt += ` Setting: ${comp.location.name}.`; }
          if (comp?.product?.url) { references.product = await urlToBase64(comp.product.url); finalPrompt += ` Product: ${comp.product.name}.`; }
          const result = await generateImage(finalPrompt, AspectRatio.LANDSCAPE, references);
          const blob = await (await fetch(`data:${result.mimeType};base64,${result.base64}`)).blob();
          const fileName = `gen_frame_${sceneId}_${type}_${Date.now()}.png`;
          const url = await uploadBlob(blob, fileName, 'godrej/generated');
          if (url) { await updateSceneFrame(sceneId, type, url); }
      } catch (e) { console.error(e); alert("Image generation failed."); } finally { setIsGeneratingFrame(false); }
  };

  const handleEnhanceFramePrompt = async (sceneId: string, type: 'start' | 'end') => {
      const scene = scenes.find(s => s.id === sceneId);
      const currentText = type === 'start' ? (scene?.startPrompt || scene?.prompt) : (scene?.endPrompt || scene?.prompt);
      if (!scene || !currentText) return;
      setEnhancingTarget({ sceneId, type });
      try {
          const enhanced = await enhanceSceneDescription(currentText);
          setScenes(prev => prev.map(s => {
              if (s.id !== sceneId) return s;
              if (type === 'start') return { ...s, startPrompt: enhanced };
              return { ...s, endPrompt: enhanced };
          }));
      } catch (e) { console.error(e); alert("Enhancement failed."); } finally { setEnhancingTarget(null); }
  };

  const handleApplyMagicEdit = async () => {
    if (!activeEditTarget || !editImagePrompt.trim()) return;
    const scene = scenes.find(s => s.id === activeEditTarget.sceneId);
    if (!scene) return;
    const imageUrl = activeEditTarget.type === 'start' ? scene.startFrame : scene.endFrame;
    if (!imageUrl) { alert("No image to edit."); return; }
    setIsEditingImage(true);
    try {
        const base64 = await urlToBase64(imageUrl);
        const result = await editImage(base64, editImagePrompt);
        const byteCharacters = atob(result.base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) byteNumbers[i] = byteCharacters.charCodeAt(i);
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: result.mimeType });
        const fileName = `edit_${activeEditTarget.sceneId}_${activeEditTarget.type}_${Date.now()}.png`;
        const url = await uploadBlob(blob, fileName, 'godrej/generated');
        if (url) { await updateSceneFrame(activeEditTarget.sceneId, activeEditTarget.type, url); }
        setShowEditImageModal(false);
        setEditImagePrompt('');
    } catch (e: any) { console.error("Edit failed", e); setNotification({ message: `Edit failed: ${e.message}`, type: 'error' }); } finally { setIsEditingImage(false); }
  };

  // --- UPDATED VIDEO GENERATION HANDLER WITH VISUAL ANALYSIS ---
  const handleGenerateSceneVideo = async (sceneId: string) => {
      const scene = scenes.find(s => s.id === sceneId);
      if(!scene || !scene.startFrame) { alert("A starting storyboard image is required to generate video."); return; }
      
      setScenes(prev => prev.map(s => s.id === sceneId ? { ...s, status: 'generating_video' } : s));
      
      const model = VeoModel.VEO_FAST;
      
      try {
           const startResponse = await fetch(scene.startFrame);
           const startBlob = await startResponse.blob();
           const startBase64 = await blobToBase64(startBlob);
           const startFile = new File([startBlob], "start", {type: startBlob.type}); 

           let endBase64 = null, endFile = null;
           
           if (scene.endFrame) {
               const endResponse = await fetch(scene.endFrame);
               const endBlob = await endResponse.blob();
               endBase64 = await blobToBase64(endBlob);
               endFile = new File([endBlob], "end", {type: endBlob.type}); 
           }

           // --- USE EXISTING DESCRIPTION (Populated by "Vision Analyze") ---
           const promptToUseBase = scene.prompt || "A scene description.";
           
           // Construct Final Prompt
           const dialoguePart = scene.audio_spec?.dialogue ? ` Dialogue: "${scene.audio_spec.dialogue}"` : "";
           const sfxPart = scene.audio_spec?.sfx ? ` Audio: ${scene.audio_spec.sfx}` : "";
           const culturalContext = " Audio Direction: South African (Mzansi) accent voiceover, local house/amapiano beat undertone.";
           
           const promptToUse = `${promptToUseBase} ${culturalContext}${dialoguePart}${sfxPart}`;

           // Log the prompt for debugging/history
           const logEntryBase = {
                timestamp: new Date().toISOString(),
                model: model,
                prompt: promptToUse, 
                action: 'generate_video'
           };

           // Call Veo
           const { blob, response: apiResponse } = await generateVideo({
               prompt: promptToUse, 
               model: model, 
               aspectRatio: AspectRatio.LANDSCAPE, 
               resolution: Resolution.P720, 
               mode: GenerationMode.FRAMES_TO_VIDEO,
               startFrame: { file: startFile, base64: startBase64 },
               endFrame: endFile ? { file: endFile, base64: endBase64 } : null,
               referenceImages: [], styleImage: null, inputVideo: null, inputVideoObject: null, isLooping: false
           });

           const publicVideoUrl = await uploadBlob(blob, `v_${sceneId}_${Date.now()}.mp4`, 'godrej/generated_videos');
           
           if (publicVideoUrl) {
               if (scene.dbId) {
                   // Success path - Log success
                   const { data: currentScene } = await supabase.from('dng1_ad_scenes').select('scene_data, logs').eq('id', scene.dbId).single();
                   const newData = { ...currentScene?.scene_data, video_url: publicVideoUrl };
                   
                   const newLog = {
                       ...logEntryBase,
                       status: 'success',
                       video_url: publicVideoUrl,
                       api_response: apiResponse
                   };
                   const currentLogs = Array.isArray(currentScene?.logs) ? currentScene.logs : [];
                   const updatedLogs = [...currentLogs, newLog];

                   await supabase.from('dng1_ad_scenes').update({ 
                       scene_data: newData,
                       logs: updatedLogs
                   }).eq('id', scene.dbId);
               }
               setScenes(prev => prev.map(s => s.id === sceneId ? { ...s, status: 'done', videoUrl: publicVideoUrl } : s));
               setStageView('video');
               setNotification({ message: 'Motion render complete!', type: 'success' });
           }
      } catch (e: any) { 
          console.error("Video Generation Error:", e); 
          
          let errorMessage = e.message || "Video generation failed.";
          if (e.raiReasons) {
              errorMessage = `Content Blocked: ${e.message}`;
          }

          setNotification({ message: errorMessage, type: 'error' });
          setScenes(prev => prev.map(s => s.id === sceneId ? { ...s, status: 'error' } : s)); 

          // Log Error to DB
          if (scene.dbId) {
              const { data: currentScene } = await supabase.from('dng1_ad_scenes').select('logs').eq('id', scene.dbId).single();
              const newLog = {
                  timestamp: new Date().toISOString(),
                  model: model,
                  prompt: scene.prompt, 
                  action: 'generate_video',
                  status: 'error',
                  error_message: e.message,
                  rai_reasons: e.raiReasons || null, 
                  details: e.details || null
              };
              const currentLogs = Array.isArray(currentScene?.logs) ? currentScene.logs : [];
              const updatedLogs = [...currentLogs, newLog];
              
              await supabase.from('dng1_ad_scenes').update({ logs: updatedLogs }).eq('id', scene.dbId);
          }
      }
  };

  // ... (Rest of component logic, identical to previous) ...
  const processFrameUpload = async (file: File, type: 'start' | 'end') => {
      if (!activeSceneId) return;
      const scene = scenes.find(s => s.id === activeSceneId);
      if (!scene) return;
      try {
          const url = await uploadBlob(file, `fr_${activeSceneId}_${type}_${Date.now()}.png`, 'godrej/generated');
          if (url) { await updateSceneFrame(activeSceneId, type, url); }
      } catch (e) { alert("Upload failed."); }
  };

  const handleWatermarkUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
        const url = await uploadBlob(file, `watermark_${Date.now()}.png`, 'godrej/assets');
        if (url) { setProdWatermark(url); }
    } catch (err) { console.error(err); alert("Failed to upload watermark"); }
  };

  const handleSelectAssetForFrame = async (assets: Asset[]) => {
      if (!assets || assets.length === 0) return;
      const asset = assets[0];
      const { frame, type } = pickingAssetFor || {};
      
      if (type === 'watermark') {
          setProdWatermark(asset.publicURL);
      } else if (type === 'image') {
          if (activeSceneId && (frame === 'start' || frame === 'end')) {
              await updateSceneFrame(activeSceneId, frame, asset.publicURL);
          }
      } else if (activeSceneId && (frame === 'start' || frame === 'end') && (type === 'character' || type === 'setting' || type === 'product')) {
          const scene = scenes.find(s => s.id === activeSceneId);
          if (scene) {
              const compKey = frame === 'start' ? 'startComposition' : 'endComposition';
              const currentComp = scene[compKey] || { characters: [] };
              let newComp = { ...currentComp };

              if (type === 'character') {
                  if (!newComp.characters.some((c:any) => c.id === asset.id)) {
                      newComp.characters = [...(newComp.characters || []), { id: asset.id, url: asset.publicURL, name: asset.name, type: 'character' }];
                  }
              } else if (type === 'setting') {
                  newComp.location = { id: asset.id, url: asset.publicURL, name: asset.name, type: 'setting' };
              } else if (type === 'product') {
                  newComp.product = { id: asset.id, url: asset.publicURL, name: asset.name, type: 'product' };
              }
              setScenes(prev => prev.map(s => s.id === activeSceneId ? { ...s, [compKey]: newComp } : s));
              if (scene.dbId) {
                  const { data: currentScene } = await supabase.from('dng1_ad_scenes').select('scene_data').eq('id', scene.dbId).single();
                  const newData = { ...currentScene?.scene_data, [compKey]: newComp };
                  await supabase.from('dng1_ad_scenes').update({ scene_data: newData }).eq('id', scene.dbId);
              }
          }
      }
      setShowAssetBrowser(false);
      setPickingAssetFor(null);
  };

  const handleRemoveAssetFromComp = async (frame: 'start' | 'end', assetId: string, type: 'character'|'setting'|'product') => {
      if (!activeSceneId) return;
      const scene = scenes.find(s => s.id === activeSceneId);
      if (!scene) return;
      const compKey = frame === 'start' ? 'startComposition' : 'endComposition';
      const currentComp = scene[compKey] || { characters: [] };
      let newComp = { ...currentComp };
      if (type === 'character') { newComp.characters = newComp.characters.filter((c:any) => c.id !== assetId); } 
      else if (type === 'setting') { newComp.location = undefined; } 
      else if (type === 'product') { newComp.product = undefined; }
      setScenes(prev => prev.map(s => s.id === activeSceneId ? { ...s, [compKey]: newComp } : s));
      if (scene.dbId) {
          const { data: currentScene } = await supabase.from('dng1_ad_scenes').select('scene_data').eq('id', scene.dbId).single();
          const newData = { ...currentScene?.scene_data, [compKey]: newComp };
          await supabase.from('dng1_ad_scenes').update({ scene_data: newData }).eq('id', scene.dbId);
      }
  };

  const handleDropFrame = async (e: React.DragEvent<HTMLDivElement>, type: 'start' | 'end') => {
      e.preventDefault();
      if (!activeSceneId) return;
      const url = e.dataTransfer.getData("text/plain");
      if (url && (url.startsWith('http') || url.startsWith('data:'))) {
          await updateSceneFrame(activeSceneId, type, url);
      }
  };

  const IngredientChip: React.FC<{ 
    type: 'character' | 'setting' | 'product', 
    data?: { url: string, name: string }, 
    onClick: () => void,
    onRemove?: () => void
  }> = ({ type, data, onClick, onRemove }) => {
    // Type-specific styling
    const styles = {
        character: { bg: 'bg-purple-50', border: 'border-purple-200', iconColor: 'text-purple-500', label: 'Actor' },
        setting: { bg: 'bg-blue-50', border: 'border-blue-200', iconColor: 'text-blue-500', label: 'Location' },
        product: { bg: 'bg-orange-50', border: 'border-orange-200', iconColor: 'text-orange-500', label: 'Product' }
    }[type];

    if (data) {
        return (
            <div className={`relative group flex items-center gap-2 pr-2 pl-1 py-1 rounded-full border bg-white shadow-sm hover:shadow-md transition-all cursor-pointer ${styles.border}`} onClick={onClick}>
                <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-100 shrink-0">
                    <img src={data.url} className="w-full h-full object-cover" alt={data.name} />
                </div>
                <div className="flex flex-col min-w-0 max-w-[80px]">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">{styles.label}</span>
                    <span className="text-[10px] font-bold text-gray-900 truncate">{data.name.split(' ')[0]}</span>
                </div>
                {onRemove && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); onRemove(); }}
                        className="ml-1 p-1 hover:bg-red-50 rounded-full text-gray-300 hover:text-red-500 transition-colors"
                    >
                        <XMarkIcon className="w-3 h-3"/>
                    </button>
                )}
            </div>
        );
    }

    // Empty State (Add Button)
    return (
        <button 
            onClick={onClick}
            className={`flex flex-col items-center justify-center w-10 h-10 rounded-full border-2 border-dashed ${styles.border} ${styles.bg} hover:brightness-95 transition-all group`}
            title={`Add ${styles.label}`}
        >
            {type === 'character' && <UserIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'setting' && <MapPinIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'product' && <CubeIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-sm border border-gray-100">
                <PlusIcon className="w-2 h-2 text-gray-500"/>
            </div>
        </button>
    );
  };

  const FrameContainer = ({ label, image, onGenerate, onUpload, onSelect, onEdit, isLoading, onDrop, frameType, composition }: any) => (
      <div className="flex flex-col w-full h-full relative group">
          <div className="flex justify-between items-end mb-2 px-1">
               <span className="text-[10px] font-black text-gray-900 uppercase tracking-widest bg-white/50 backdrop-blur px-2 py-1 rounded-md shadow-sm border border-gray-100">
                   {label} Ingredients
               </span>
               <div className="flex gap-1">
                    {composition?.characters?.map((char: any) => (
                        <IngredientChip key={char.id} type="character" data={char} onClick={() => {}} onRemove={() => handleRemoveAssetFromComp(frameType, char.id, 'character')} />
                    ))}
                    <IngredientChip type="character" onClick={() => { setPickingAssetFor({ frame: frameType, type: 'character' }); setShowAssetBrowser(true); }} />
                    <IngredientChip type="setting" data={composition?.location} onClick={() => { setPickingAssetFor({ frame: frameType, type: 'setting' }); setShowAssetBrowser(true); }} onRemove={() => handleRemoveAssetFromComp(frameType, '', 'setting')} />
                    <IngredientChip type="product" data={composition?.product} onClick={() => { setPickingAssetFor({ frame: frameType, type: 'product' }); setShowAssetBrowser(true); }} onRemove={() => handleRemoveAssetFromComp(frameType, '', 'product')} />
               </div>
          </div>
          <div className="flex-1 bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden relative aspect-video transition-all hover:border-[#9063CD] hover:ring-2 hover:ring-[#9063CD]/20 group/frame" onDragOver={(e) => e.preventDefault()} onDrop={onDrop}>
              {image ? ( <img src={image} className="w-full h-full object-cover" /> ) : ( <div className="w-full h-full flex flex-col items-center justify-center text-gray-300 bg-gray-50 pattern-checkered-gray-200/50"><ClapperboardIcon className="w-8 h-8 opacity-20 mb-2"/><span className="text-[10px] font-bold uppercase tracking-widest">Empty Frame</span><span className="text-[9px] text-gray-400 mt-1 opacity-0 group-hover/frame:opacity-100 transition-opacity">Drop image here</span></div> )}
              <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-white/90 backdrop-blur-md p-1.5 rounded-xl shadow-lg border border-gray-100 opacity-0 group-hover/frame:opacity-100 transition-all duration-300 translate-y-2 group-hover/frame:translate-y-0">
                  <button onClick={onGenerate} disabled={isLoading} className="flex items-center gap-2 px-4 py-2 bg-[#9063CD] text-white rounded-lg font-bold text-[10px] uppercase tracking-wider hover:bg-purple-700 transition-colors shadow-sm">{isLoading ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-3 h-3"/>} Fuse & Generate</button>
                  <div className="w-px h-4 bg-gray-300 mx-1"></div>
                  {image && ( <button onClick={onEdit} className="p-2 hover:bg-indigo-50 text-indigo-600 rounded-lg transition-colors" title="Magic Edit"><PencilSquareIcon className="w-4 h-4"/></button> )}
                  <button onClick={onSelect} className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg transition-colors" title="Select from Library"><FolderIcon className="w-4 h-4"/></button>
                  <button onClick={onUpload} className="p-2 hover:bg-gray-100 text-gray-600 rounded-lg transition-colors" title="Upload File"><UploadCloudIcon className="w-4 h-4"/></button>
              </div>
          </div>
      </div>
  );

  return (
    <div className="w-full h-full flex flex-col bg-gray-50 text-gray-900 overflow-hidden relative font-sans">
        {notification && (
            <div className={`fixed top-20 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-full shadow-xl text-sm font-bold flex items-center gap-3 animate-fade-in-up ${notification.type === 'error' ? 'bg-red-600 text-white' : 'bg-black text-white'}`}>
                {notification.type === 'info' && <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>}
                {notification.message}
            </div>
        )}

        {isStitching && (
            <div className="absolute inset-0 z-[100] bg-white/90 backdrop-blur-md flex flex-col items-center justify-center p-8 animate-fade-in-up">
               <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-gray-200 flex flex-col items-center max-w-sm text-center">
                    <div className="relative w-24 h-24 mb-6"><div className="absolute inset-0 border-4 border-gray-100 rounded-full"></div><div className="absolute inset-0 border-4 border-[#9063CD] border-t-transparent rounded-full animate-spin"></div><div className="absolute inset-0 flex items-center justify-center"><SparklesIcon className="w-8 h-8 text-[#9063CD] animate-pulse" /></div></div>
                    <h3 className="text-xl font-black text-gray-900 mb-2">Stitching Final Master</h3>
                    <p className="text-sm text-gray-500 font-medium leading-relaxed">Transmitting production assets to the render engine...</p>
               </div>
            </div>
        )}

        <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-20 shadow-sm">
             <div className="flex items-center gap-4">
                 <button onClick={onBackToLibrary} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><FolderIcon className="w-5 h-5"/></button>
                 <div className="flex flex-col">
                     <h1 className="font-black text-gray-900 text-lg tracking-tight uppercase">{adTitle}</h1>
                     {currentAdId && currentAdId !== 'new' && <span className="text-[9px] text-gray-400 font-mono tracking-widest">{currentAdId}</span>}
                 </div>
                 <span className="bg-gray-100 text-gray-500 text-[10px] px-2 py-0.5 rounded uppercase tracking-wider font-bold border border-gray-200 self-center">Workspace</span>
             </div>
             <div className="flex items-center gap-3">
                 <button onClick={() => { setActiveRightTab(activeRightTab === 'chat' ? 'inspector' : 'chat'); }} className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all border ${activeRightTab === 'chat' ? 'bg-[#9063CD] text-white border-[#9063CD] shadow-md' : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'}`}><ChatBubbleIcon className="w-3 h-3" /> AiDi Assist</button>
                 <button onClick={handlePrepareProduction} disabled={isStitching || scenes.length === 0} className={`px-5 py-2 rounded-full font-bold flex items-center gap-2 text-xs shadow-lg transition-all hover:scale-105 ${isStitching ? 'bg-indigo-50 text-indigo-600 border border-indigo-100 animate-pulse' : 'bg-black text-white hover:bg-gray-800'}`}>{isStitching ? <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <BoltIcon className="w-3 h-3" />}{isStitching ? 'Mastering...' : 'Produce Master'}</button>
             </div>
        </header>

        {/* --- Main Workspace Layout --- */}
        <div className="flex-1 flex overflow-hidden">
            <div className="w-80 bg-white border-r border-gray-200 flex flex-col shrink-0 z-10 animate-slide-in-left h-full">
                {finalVideoUrl && (
                    <div className="p-5 border-b border-gray-100 flex flex-col gap-3 bg-gray-50/50">
                        <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-2"><SparklesIcon className="w-3 h-3"/> Final Master</span>
                        <div onClick={handleViewMaster} className={`aspect-video rounded-xl overflow-hidden bg-black relative group shadow-md cursor-pointer border-2 transition-all ${viewingMaster ? 'border-[#9063CD] ring-2 ring-[#9063CD]/20' : 'border-transparent hover:border-gray-300'}`}><video src={finalVideoUrl} className="w-full h-full object-cover" /><div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/40 transition-colors backdrop-blur-[1px]"><PlayIcon className="w-8 h-8 text-white opacity-80 group-hover:opacity-100 drop-shadow-md"/></div></div>
                    </div>
                )}
                <div className="flex-1 flex flex-col min-h-0">
                    <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-white sticky top-0 z-10 shadow-sm"><span className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><LayersIcon className="w-3 h-3"/> Sequence</span><button onClick={handleAddScene} className="text-[10px] font-black text-[#9063CD] hover:text-purple-700 bg-purple-50 px-2 py-1 rounded-md transition-colors flex items-center gap-1 hover:bg-purple-100"><PlusIcon className="w-3 h-3"/> Add</button></div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                        {scenes.map((scene, idx) => (
                            <div key={scene.id} onClick={() => handleSceneSelect(scene.id)} draggable={!!scene.startFrame} onDragStart={(e) => { if (scene.startFrame) { e.dataTransfer.setData("text/plain", scene.startFrame); e.dataTransfer.effectAllowed = "copy"; } }} className={`flex flex-col gap-3 p-4 rounded-xl border transition-all cursor-pointer group relative hover:shadow-lg ${activeSceneId === scene.id ? 'bg-indigo-50 border-[#9063CD] ring-1 ring-[#9063CD]/20' : 'bg-white border-gray-200 hover:border-gray-300'}`}>
                                <div className="w-full aspect-video bg-gray-100 rounded-lg overflow-hidden shrink-0 relative border border-gray-100 shadow-sm pointer-events-none">{scene.startFrame ? ( <img src={scene.startFrame} className="w-full h-full object-cover" /> ) : ( <div className="w-full h-full flex items-center justify-center"><ClapperboardIcon className="w-8 h-8 text-gray-300"/></div> )}<div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] font-black px-2 py-0.5 rounded backdrop-blur-md">SCENE {idx + 1}</div></div>
                                <div className="w-full flex flex-col gap-2"><p className="text-xs text-gray-700 font-medium line-clamp-3 leading-snug">{scene.prompt || "New Scene"}</p><div className="flex items-center gap-2">{scene.status === 'done' && <span className="text-[9px] font-bold text-green-600 bg-green-50 px-1.5 py-0.5 rounded">READY</span>}{scene.videoUrl && <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded flex items-center gap-1"><FilmIcon className="w-2 h-2"/> RENDERED</span>}</div></div>
                                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1 bg-white/90 rounded-lg p-1 shadow-sm border border-gray-100"><button onClick={(e) => { e.stopPropagation(); moveScene(idx, 'up'); }} className="p-1 text-gray-400 hover:text-indigo-600"><ArrowRightIcon className="w-3 h-3 -rotate-90"/></button><button onClick={(e) => { e.stopPropagation(); moveScene(idx, 'down'); }} className="p-1 text-gray-400 hover:text-indigo-600"><ArrowRightIcon className="w-3 h-3 rotate-90"/></button><button onClick={(e) => { e.stopPropagation(); handleDeleteClick(scene.id); }} className="p-1 text-gray-400 hover:text-red-600"><TrashIcon className="w-3 h-3"/></button></div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div className="flex-1 flex flex-col min-w-0 relative bg-gray-50 overflow-hidden">
                <div className="flex-1 overflow-y-auto p-8 relative scroll-smooth">
                    <div className="flex flex-col items-center min-h-full justify-center">
                    {viewingMaster && finalVideoUrl ? (
                        <div className="flex flex-col gap-4 w-full max-w-5xl h-full justify-center animate-fade-in-up">
                            <div className="flex justify-center mb-2"><span className="bg-black text-white px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-widest shadow-lg flex items-center gap-2 border border-gray-800"><SparklesIcon className="w-3 h-3 text-[#9063CD] animate-pulse"/> Final Production Master</span></div>
                            <div className="relative w-full aspect-video bg-black rounded-2xl shadow-2xl overflow-hidden border border-gray-800 ring-4 ring-black/5"><video src={finalVideoUrl} controls autoPlay className="w-full h-full object-contain" /></div>
                        </div>
                    ) : activeScene ? (
                        <div className="flex flex-col gap-6 w-full max-w-7xl h-full justify-center">
                            <div className="flex justify-center"><div className="bg-white rounded-full p-1 border border-gray-200 shadow-sm flex gap-1"><button onClick={() => setStageView('dual')} className={`px-5 py-2 rounded-full text-xs font-bold transition-all bg-black text-white shadow-md`}>Motion Board</button></div></div>
                            <div className="flex flex-col gap-8 w-full animate-fade-in-up pb-10">
                                <div className="grid grid-cols-[1fr_auto_1fr] gap-8 items-start">
                                    <div className="flex flex-col gap-4"><div className="aspect-video w-full"><FrameContainer label="Keyframe A (Start)" image={activeScene.startFrame} frameType="start" composition={activeScene.startComposition || activeScene.composition} onGenerate={() => handleGenerateFrame(activeScene.id, 'start')} onUpload={() => startFrameInputRef.current?.click()} onSelect={() => { setPickingAssetFor({ frame: 'start', type: 'image' }); setShowAssetBrowser(true); }} onEdit={() => { setActiveEditTarget({ sceneId: activeScene.id, type: 'start' }); setEditImagePrompt(''); setShowEditImageModal(true); }} isLoading={isGeneratingFrame} onDrop={(e: any) => handleDropFrame(e, 'start')}/></div><div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group"><div className="flex justify-between items-center mb-2"><h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Start Specs</h4><button onClick={() => handleEnhanceFramePrompt(activeScene.id, 'start')} disabled={enhancingTarget?.type === 'start'} className="text-[9px] font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded hover:bg-indigo-100 transition-colors flex items-center gap-1 opacity-0 group-hover:opacity-100">{enhancingTarget?.type === 'start' ? <div className="w-2 h-2 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div> : <MagicWandIcon className="w-2 h-2" />} AI Enhance</button></div><textarea className="w-full bg-transparent text-xs text-gray-600 leading-relaxed outline-none resize-none h-24 focus:ring-2 focus:ring-indigo-100 rounded-md p-1 -m-1 transition-all" value={activeScene.startPrompt || activeScene.prompt || ''} onChange={(e) => setScenes(prev => prev.map(s => s.id === activeScene.id ? { ...s, startPrompt: e.target.value } : s))} placeholder="Describe the start frame..." /></div></div>
                                    <div className="flex flex-col items-center justify-center pt-24 gap-6 shrink-0"><div className="bg-white p-3 rounded-xl border border-gray-200 shadow-sm flex flex-col items-center gap-2"><span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">Duration</span><span className="text-lg font-bold text-gray-900">{activeScene.duration || 4}s</span></div><ArrowRightIcon className="w-8 h-8 text-[#9063CD]"/>{activeScene.videoUrl && ( <span className="text-[9px] font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full border border-green-100 flex items-center gap-1 whitespace-nowrap"><CheckCircleIcon className="w-3 h-3"/> Rendered</span> )}</div>
                                    <div className="flex flex-col gap-4"><div className="aspect-video w-full"><FrameContainer label="Keyframe B (End)" image={activeScene.endFrame} frameType="end" composition={activeScene.endComposition || activeScene.composition} onGenerate={() => handleGenerateFrame(activeScene.id, 'end')} onUpload={() => endFrameInputRef.current?.click()} onSelect={() => { setPickingAssetFor({ frame: 'end', type: 'image' }); setShowAssetBrowser(true); }} onEdit={() => { setActiveEditTarget({ sceneId: activeScene.id, type: 'end' }); setEditImagePrompt(''); setShowEditImageModal(true); }} isLoading={isGeneratingFrame} onDrop={(e: any) => handleDropFrame(e, 'end')}/></div><div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative group"><div className="flex justify-between items-center mb-2"><h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">End Specs</h4><button onClick={() => handleEnhanceFramePrompt(activeScene.id, 'end')} disabled={enhancingTarget?.type === 'end'} className="text-[9px] font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded hover:bg-indigo-100 transition-colors flex items-center gap-1 opacity-0 group-hover:opacity-100">{enhancingTarget?.type === 'end' ? <div className="w-2 h-2 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin"></div> : <MagicWandIcon className="w-2 h-2" />} AI Enhance</button></div><textarea className="w-full bg-transparent text-xs text-gray-600 leading-relaxed outline-none resize-none h-24 focus:ring-2 focus:ring-indigo-100 rounded-md p-1 -m-1 transition-all" value={activeScene.endPrompt || (activeScene.prompt ? activeScene.prompt + " (end state)" : "")} onChange={(e) => setScenes(prev => prev.map(s => s.id === activeScene.id ? { ...s, endPrompt: e.target.value } : s))} placeholder="Describe the end frame..." /></div></div>
                                </div>
                                {activeScene.videoUrl ? ( <div className="mt-8 border-t border-gray-200 pt-8"><div className="flex items-center justify-center gap-2 mb-6"><FilmIcon className="w-5 h-5 text-[#9063CD]" /><h3 className="font-bold text-gray-900 text-lg">Motion Render Preview</h3></div><div className="w-full max-w-4xl mx-auto aspect-video bg-black rounded-2xl overflow-hidden shadow-2xl border border-gray-200 ring-4 ring-black/5 relative group"><video ref={videoRef} controls src={activeScene.videoUrl} className="w-full h-full object-contain" /></div></div> ) : ( <div className="mt-8 border-t border-gray-200 pt-8 flex justify-center">{activeScene.startFrame && ( <button onClick={() => handleGenerateSceneVideo(activeScene.id)} disabled={activeScene.status === 'generating_video' || !activeScene.startFrame} className={`px-8 py-4 rounded-full font-bold text-sm shadow-xl flex items-center gap-2 transition-all ${activeScene.status === 'generating_video' ? 'bg-indigo-50 text-indigo-600 animate-pulse border border-indigo-200' : 'bg-indigo-600 text-white hover:scale-105'}`}>{activeScene.status === 'generating_video' ? 'Rendering Motion...' : <><FilmIcon className="w-4 h-4"/> Generate Motion Render</>}</button> )}</div> )}
                            </div>
                            <input type="file" ref={startFrameInputRef} hidden accept="image/*" onChange={(e) => { const f = e.target.files?.[0]; if(f) processFrameUpload(f, 'start'); }} />
                            <input type="file" ref={endFrameInputRef} hidden accept="image/*" onChange={(e) => { const f = e.target.files?.[0]; if(f) processFrameUpload(f, 'end'); }} />
                        </div>
                    ) : (
                         <div className="text-gray-400 font-medium text-sm flex flex-col items-center gap-4 pt-32"><LayersIcon className="w-12 h-12 opacity-20"/> Select a scene from the sequence on the left.</div>
                    )}
                    </div>
                </div>
            </div>

            <div className={`w-96 bg-white border-l border-gray-200 shrink-0 flex flex-col z-20 shadow-2xl transition-all duration-300 ${!activeSceneId && activeRightTab !== 'chat' ? 'translate-x-full hidden' : ''}`}>
                 {activeRightTab === 'chat' ? (
                     <div className="h-full bg-white text-gray-900"><ChatAssistant onSaveGeneratedAsset={async (b, f, fo, c) => { const url = await uploadBlob(b, f, fo); if (url && c === 'character') { const newCast = await fetchDynamicAssets('character'); setProjectCast(newCast); } }} /></div>
                 ) : (
                     activeScene ? (
                         <div className="flex-col h-full overflow-y-auto no-scrollbar pb-10 bg-white">
                             <div className="p-5 border-b border-gray-100 bg-gray-50/50"><h3 className="font-black text-gray-900 text-sm uppercase tracking-wider">Director's Log</h3><p className="text-[10px] text-gray-400 font-mono mt-1">SCENE_ID: {activeScene.id.slice(0,6)}</p></div>
                             <div className="p-6 space-y-8">
                                 <div className="space-y-3">
                                     <div className="flex justify-between items-center">
                                         <label className="text-[10px] font-black text-[#9063CD] uppercase tracking-widest flex items-center gap-2">
                                             <PencilSquareIcon className="w-3 h-3"/> Scene Description
                                         </label>
                                         <div className="flex gap-2">
                                             <button onClick={handleAnalyzeTransition} disabled={isEnhancingPrompt} className="text-[9px] font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded-md hover:bg-blue-100 transition-colors flex items-center gap-1 border border-blue-200">
                                                 {isEnhancingPrompt ? <div className="w-2 h-2 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div> : <EyeIcon className="w-3 h-3" />} 
                                                 Vision Analyze
                                             </button>
                                             <button onClick={handleEnhancePrompt} disabled={isEnhancingPrompt} className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md hover:bg-indigo-100 transition-colors flex items-center gap-1 border border-indigo-200">
                                                 {isEnhancingPrompt ? <div className="w-2 h-2 border border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <MagicWandIcon className="w-3 h-3" />} 
                                                 Enhance
                                             </button>
                                         </div>
                                     </div>
                                     <textarea className="w-full h-32 bg-white border border-gray-200 rounded-xl p-4 text-sm text-gray-700 focus:border-[#9063CD] focus:ring-4 focus:ring-purple-50 outline-none leading-relaxed resize-none shadow-inner transition-all" value={activeScene.prompt} onChange={(e) => setScenes(prev => prev.map(s => { if (s.id !== activeScene.id) return s; return { ...s, prompt: e.target.value }; }))} />
                                 </div>
                                 <div className="space-y-3"><label className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-2"><MicrophoneIcon className="w-3 h-3"/> Dialogue & Audio</label><textarea className="w-full h-24 bg-white border border-gray-200 rounded-xl p-4 text-sm text-gray-700 focus:border-blue-500 focus:ring-4 focus:ring-blue-50 outline-none leading-relaxed resize-none shadow-inner transition-all" placeholder="Dialogue or Voiceover text..." value={activeScene.audio_spec?.dialogue || ''} onChange={(e) => setScenes(prev => prev.map(s => { if (s.id !== activeScene.id) return s; return { ...s, audio_spec: { ...s.audio_spec, dialogue: e.target.value } }; }))} /></div>
                                 <div className="space-y-3"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Camera & Lighting</label><div className="flex flex-wrap gap-2">{CAMERA_ANGLES.map(tag => ( <button key={tag} onClick={() => addTagToPrompt(tag)} className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors shadow-sm">{tag}</button> ))}{LIGHTING_STYLES.map(tag => ( <button key={tag} onClick={() => addTagToPrompt(tag)} className="px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-[10px] font-bold text-gray-500 hover:bg-gray-50 hover:text-gray-900 transition-colors shadow-sm">{tag}</button> ))}</div></div>
                                 <div className="space-y-3"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Dynamic Camera Moves</label><select className="w-full p-2 bg-white border border-gray-200 rounded-lg text-xs font-medium text-gray-700 focus:ring-2 focus:ring-indigo-100 outline-none" onChange={(e) => { if (e.target.value) { appendCameraMove(e.target.value); e.target.value = ""; } }}><option value="">+ Add Camera Movement...</option>{Object.entries(CAMERA_MOVEMENTS).map(([category, moves]) => ( <optgroup label={category} key={category}>{moves.map(move => ( <option key={move.label} value={`${move.label}: ${move.desc}`}>{move.label}</option> ))}</optgroup> ))}</select></div>
                                 <div className="space-y-4 pt-6 border-t border-gray-100"><div className="flex justify-between items-center"><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><ArrowRightIcon className="w-3 h-3"/> Motion Status</label></div><div className="grid grid-cols-2 gap-4"><div className="p-3 bg-gray-50 rounded-lg border border-gray-100 text-center"><p className="text-[9px] font-bold text-gray-400 uppercase">Keyframe A</p>{activeScene.startFrame ? <CheckCircleIcon className="w-4 h-4 text-green-500 mx-auto mt-1"/> : <span className="text-xs text-red-400 font-bold">-</span>}</div><div className="p-3 bg-gray-50 rounded-lg border border-gray-100 text-center"><p className="text-[9px] font-bold text-gray-400 uppercase">Keyframe B</p>{activeScene.endFrame ? <CheckCircleIcon className="w-4 h-4 text-green-500 mx-auto mt-1"/> : <span className="text-xs text-orange-400 font-bold">Optional</span>}</div></div>{previousSceneAvailable && ( <button onClick={handleLinkPreviousScene} className="w-full py-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-[9px] font-bold uppercase tracking-wide flex items-center justify-center gap-2 transition-colors border border-indigo-100" title="Copy End Frame from Previous Scene"><LinkIcon className="w-3 h-3"/> Link Previous End Frame</button> )}</div>
                                 <div className="pt-4"><button onClick={() => handleGenerateSceneVideo(activeScene.id)} disabled={activeScene.status === 'generating_video' || !activeScene.startFrame} className={`w-full py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg ${activeScene.status === 'generating_video' ? 'bg-indigo-50 text-indigo-400 border border-indigo-100 animate-pulse' : 'bg-black text-white hover:scale-[1.02]'}`}>{activeScene.status === 'generating_video' ? 'Rendering Motion...' : <><FilmIcon className="w-4 h-4"/> Render Action Sequence</>}</button></div>
                             </div>
                         </div>
                     ) : (
                         <div className="h-full flex flex-col items-center justify-center text-gray-400 bg-white"><div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4"><ClapperboardIcon className="w-6 h-6 opacity-20" /></div><p className="text-xs font-medium">Select a scene to edit.</p></div>
                     )
                 )}
            </div>
        </div>
        <Modal isOpen={showAssetBrowser} onClose={() => setShowAssetBrowser(false)} title="Select Asset"><div className="h-[75vh] -m-6"><AssetStudio onAssetsSelected={(a) => handleSelectAssetForFrame(a)} /></div></Modal>
        <Modal isOpen={showEditImageModal} onClose={() => setShowEditImageModal(false)} title="Magic Edit"><div className="space-y-6 p-2"><p className="text-sm text-gray-500 font-medium leading-relaxed">Describe what you want to change in the scene. The AI will preserve the rest of the composition.</p><textarea className="w-full h-32 border border-gray-200 rounded-2xl p-4 text-sm focus:ring-4 focus:ring-purple-50 focus:border-[#9063CD] outline-none transition-all shadow-inner bg-gray-50" placeholder="e.g. Change the background to a futuristic city, add a blue tint..." value={editImagePrompt} onChange={(e) => setEditImagePrompt(e.target.value)} /><button onClick={handleApplyMagicEdit} disabled={isEditingImage || !editImagePrompt.trim()} className="w-full bg-[#9063CD] text-white py-3 rounded-xl font-bold shadow-lg hover:bg-purple-700 transition-all uppercase tracking-wider text-xs disabled:opacity-50 flex items-center justify-center gap-2">{isEditingImage ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <MagicWandIcon className="w-4 h-4"/>} {isEditingImage ? 'Applying Magic...' : 'Apply Magic Edit'}</button></div></Modal>
        {deleteConfirmation.isOpen && ( <div className="fixed inset-0 z-[100] flex items-center justify-center bg-gray-900/50 backdrop-blur-sm animate-fade-in-up"><div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl border border-gray-100 transform transition-all scale-100"><div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-4 mx-auto"><AlertTriangleIcon className="w-6 h-6 text-red-500" /></div><h3 className="text-xl font-bold text-center text-gray-900 mb-2">Delete Scene?</h3><p className="text-sm text-gray-500 text-center mb-6 leading-relaxed">This will remove the scene from your sequence.</p><div className="flex gap-3"><button onClick={() => setDeleteConfirmation({isOpen: false, sceneId: null})} className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-sm transition-colors">Cancel</button><button onClick={confirmDeleteScene} className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-sm shadow-lg transition-colors">Delete</button></div></div></div> )}
        <Modal isOpen={showPayloadModal} onClose={() => setShowPayloadModal(false)} title="Production Payload Review"><div className="flex flex-col h-[80vh] max-w-6xl"><div className="p-6 bg-gray-50 border-b border-gray-200 grid grid-cols-1 md:grid-cols-2 gap-8 items-start"><div className="flex flex-col gap-8"><div className="space-y-3"><label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Brand Watermark</label><div className="flex items-center gap-4 bg-white p-3 rounded-xl border border-gray-100 shadow-sm">{prodWatermark ? ( <div className="w-16 h-16 rounded-lg border border-gray-200 bg-white p-1 overflow-hidden shadow-sm relative group cursor-pointer shrink-0" onClick={() => { setPickingAssetFor({ frame: 'watermark', type: 'watermark' }); setShowAssetBrowser(true); }}><img src={prodWatermark} className="w-full h-full object-contain" /><div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"><PencilSquareIcon className="w-4 h-4 text-white"/></div></div> ) : ( <div className="w-16 h-16 rounded-lg border-2 border-dashed border-gray-300 flex flex-col items-center justify-center text-gray-400 gap-1 cursor-pointer hover:border-gray-400 hover:text-gray-500 shrink-0" onClick={() => { setPickingAssetFor({ frame: 'watermark', type: 'watermark' }); setShowAssetBrowser(true); }}><PlusIcon className="w-6 h-6" /></div> )}<div className="flex flex-col gap-2"><div className="flex gap-2 items-center"><button onClick={() => { setPickingAssetFor({ frame: 'watermark', type: 'watermark' }); setShowAssetBrowser(true); }} className="text-xs font-bold text-[#9063CD] hover:underline flex items-center gap-1">Select <PhotoIcon className="w-3 h-3"/></button><span className="text-gray-300">|</span><button onClick={() => watermarkUploadRef.current?.click()} className="text-xs font-bold text-gray-600 hover:text-gray-900 flex items-center gap-1">Upload <UploadCloudIcon className="w-3 h-3"/></button><input type="file" ref={watermarkUploadRef} hidden accept="image/*" onChange={handleWatermarkUpload} /></div>{prodWatermark && ( <button onClick={() => setProdWatermark('')} className="text-[10px] font-bold text-red-400 hover:text-red-600 flex items-center gap-1 self-start">Remove Watermark <TrashIcon className="w-3 h-3"/></button> )}<span className="text-[10px] text-gray-400">Position: Bottom Right</span></div></div></div><div className="space-y-3"><label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Master Format</label><div className="flex gap-3"><button onClick={() => setProdResolution('wide')} className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-3 transition-all ${prodResolution === 'wide' ? 'bg-black text-white border-black shadow-md' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}><div className="w-6 h-4 border-2 border-current rounded-sm"></div><div className="text-left"><span className="block text-[10px] font-bold uppercase">Wide (16:9)</span><span className="block text-[9px] opacity-70">1920 x 1080</span></div></button><button onClick={() => setProdResolution('tall')} className={`flex-1 py-3 px-4 rounded-xl border flex items-center justify-center gap-3 transition-all ${prodResolution === 'tall' ? 'bg-black text-white border-black shadow-md' : 'bg-white text-gray-500 border-gray-200 hover:bg-gray-50'}`}><div className="h-6 w-4 border-2 border-current rounded-sm"></div><div className="text-left"><span className="block text-[10px] font-bold uppercase">Tall (9:16)</span><span className="block text-[9px] opacity-70">1080 x 1920</span></div></button></div></div></div><div className="h-full flex flex-col"><label className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Production Context</label><div className="flex-1 bg-blue-50/50 p-6 rounded-2xl border border-blue-100 flex flex-col justify-center"><h4 className="font-bold text-blue-900 mb-2">Ready to Stitch?</h4><p className="text-sm text-blue-800/80 leading-relaxed">Review the JSON payload below. This configuration defines the exact sequence, timing, and assets that will be sent to the remote rendering engine to compile your final master video file.</p><div className="mt-4 pt-4 border-t border-blue-100 flex gap-4 text-xs font-medium text-blue-700"><span>• {scenes.length} Scenes</span><span>• ~{scenes.reduce((acc, s) => acc + (s.duration || 8), 0)}s Duration</span><span>• {prodResolution === 'wide' ? 'Landscape' : 'Portrait'}</span></div></div></div></div><div className="flex-1 overflow-auto p-6 bg-gray-900 text-green-400 font-mono text-xs border-t border-gray-200 shadow-inner"><pre>{JSON.stringify(productionPayload, null, 2)}</pre></div><div className="p-4 border-t border-gray-200 bg-white flex justify-end gap-3 shrink-0 rounded-b-2xl"><button onClick={() => setShowPayloadModal(false)} className="px-6 py-3 rounded-xl font-bold text-gray-600 hover:bg-gray-100 transition-colors text-sm">Cancel</button><button onClick={confirmStitchProduction} className="px-6 py-3 bg-black text-white rounded-xl font-bold hover:bg-gray-800 transition-colors shadow-lg text-sm flex items-center gap-2">{isStitching ? <div className="w-4 h-4 border-2 border-gray-400 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4"/>} Confirm & Transmit</button></div></div></Modal>
        <Modal isOpen={showAssetBrowser} onClose={() => setShowAssetBrowser(false)} title="Select Asset"><div className="h-[75vh] -m-6"><AssetStudio onAssetsSelected={(a) => handleSelectAssetForFrame(a)} /></div></Modal>
    </div>
  );
};

export default CreativeStudio;
