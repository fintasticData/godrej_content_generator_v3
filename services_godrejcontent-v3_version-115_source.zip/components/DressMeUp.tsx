/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState } from 'react';
import { Influencer, CharacterItem, AspectRatio } from '../types';
import { researchFashionTrends, generateFashionItem, editImage, refineFashionTrends } from '../services/geminiService';
import { uploadBlob, updateCharacter, supabase } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    SparklesIcon, 
    GlobeAltIcon, 
    ShoppingBagIcon, 
    UserIcon,
    MagicWandIcon,
    CheckCircleIcon,
    ArrowRightIcon,
    MapPinIcon,
    CalendarIcon,
    ChatBubbleIcon,
    Square2StackIcon
} from './icons';

interface DressMeUpProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

const urlToBase64 = async (url: string): Promise<string> => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(blob);
        });
    } catch (e) {
        console.error("Base64 error", e);
        return "";
    }
};

const DressMeUp: React.FC<DressMeUpProps> = ({ character, onClose, onSuccess }) => {
    // Phase 1: Consultation & Research
    const [occasion, setOccasion] = useState('');
    const [location, setLocation] = useState('');
    const [isResearching, setIsResearching] = useState(false);
    
    // Phase 1.5: Draft Refinement (The Bulk Creator Loop)
    const [draftTrends, setDraftTrends] = useState<{name: string, description: string, type: string}[]>([]);
    const [feedback, setFeedback] = useState('');
    const [isRefining, setIsRefining] = useState(false);

    // Phase 2: Inventory & The Wheel
    const [trends, setTrends] = useState<{name: string, description: string, type: string, url?: string}[]>([]);
    const [isFabricating, setIsFabricating] = useState(false);
    const [selectedTrendIndices, setSelectedTrendIndices] = useState<Set<number>>(new Set());
    
    // Phase 3: Visualization
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [isFitting, setIsFitting] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    // Helpers
    const getBaseImage = () => {
        if (character.image_url && character.image_url.startsWith('http')) return character.image_url;
        if (character.image_urls_jsonb && character.image_urls_jsonb.length > 0) return character.image_urls_jsonb[0].url;
        return "";
    };

    // Initial Research (Generates Drafts)
    const handleResearch = async () => {
        if (!occasion || !location) return;
        setIsResearching(true);
        setDraftTrends([]);
        setTrends([]); 
        setPreviewImage(null);

        try {
            // 1. Search Grounding for Concepts
            const items = await researchFashionTrends(occasion, location);
            setDraftTrends(items);
        } catch (e) {
            console.error(e);
            alert("Trend research failed.");
        } finally {
            setIsResearching(false);
        }
    };

    // Refinement Loop
    const handleRefine = async () => {
        if (!feedback.trim() || draftTrends.length === 0) return;
        setIsRefining(true);
        try {
            const context = `${occasion} in ${location}`;
            const updatedItems = await refineFashionTrends(draftTrends, feedback, context);
            setDraftTrends(updatedItems);
            setFeedback('');
        } catch (e) {
            console.error(e);
            alert("Refinement failed.");
        } finally {
            setIsRefining(false);
        }
    };

    // Bulk Fabrication (Turn Drafts into Assets)
    const handleFabricateAll = async () => {
        if (draftTrends.length === 0) return;
        setIsFabricating(true);
        try {
            const fabricatedItems = await Promise.all(draftTrends.map(async (item: any) => {
                try {
                    const result = await generateFashionItem(item.description);
                    const blob = await (await fetch(`data:${result.mimeType};base64,${result.base64}`)).blob();
                    const url = await uploadBlob(blob, `trend_${item.type}_${Date.now()}.png`, 'godrej/wardrobe');
                    
                    if (url) {
                        // Save to character inventory immediately
                        const newItem: CharacterItem = {
                            id: crypto.randomUUID(),
                            type: item.type as any,
                            name: item.name,
                            image_url: url,
                            description: item.description,
                            created_at: new Date().toISOString()
                        };
                        
                        const pk = character.character_id || character.id;
                        if (pk) {
                            const { data: fresh } = await supabase.from('dng1_characters').select('character_items').eq('character_id', pk).single();
                            const current = fresh?.character_items || [];
                            await updateCharacter(pk, { character_items: [newItem, ...current] });
                        }
                        return { ...item, url };
                    }
                    return item;
                } catch(e) {
                    console.error("Fabrication failed for item", item.name, e);
                    return item;
                }
            }));
            
            setTrends(fabricatedItems.filter(t => t.url)); // Move to active list
            setDraftTrends([]); // Clear drafts
        } catch (e) {
            console.error(e);
            alert("Fabrication failed.");
        } finally {
            setIsFabricating(false);
        }
    };

    const toggleSelection = (index: number) => {
        setSelectedTrendIndices(prev => {
            const next = new Set(prev);
            if (next.has(index)) next.delete(index);
            else next.add(index);
            return next;
        });
    };

    const handleVisualize = async () => {
        if (selectedTrendIndices.size === 0) return;
        setIsFitting(true);
        try {
            const baseImg = getBaseImage();
            const charB64 = await urlToBase64(baseImg);
            
            // Combine descriptions of selected items
            const selectedItems = trends.filter((_, i) => selectedTrendIndices.has(i));
            const descriptions = selectedItems.map(t => t.description).join('. ');
            const prompt = `Wearing ${descriptions}. At ${location} for ${occasion}. Photorealistic, high fashion. Keep character identity exactly.`;
            
            // Use Edit Image (Nano Banana 2.5) for fast try-on
            const result = await editImage(charB64, prompt, undefined, AspectRatio.PORTRAIT, 'gemini-2.5-flash-image');
            setPreviewImage(result.base64);
        } catch(e) {
            console.error(e);
            alert("Virtual try-on failed.");
        } finally {
            setIsFitting(false);
        }
    };

    const handleSaveLook = async () => {
        if (!previewImage) return;
        setIsSaving(true);
        try {
            const binary = atob(previewImage);
            const array = [];
            for (let i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
            const blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
            
            const url = await uploadBlob(blob, `dressup_${Date.now()}.png`, 'godrej/characters');
            
            if (url) {
                const pk = character.character_id || character.id;
                const { data: fresh } = await supabase.from('dng1_characters').select('image_urls_jsonb').eq('character_id', pk).single();
                const current = fresh?.image_urls_jsonb || [];
                const newEntry = {
                    url,
                    type: 'dress_me_up',
                    description: `${occasion} at ${location}`,
                    metadata: { occasion, location }
                };
                await updateCharacter(pk!, { image_urls_jsonb: [newEntry, ...current] });
                onSuccess();
            }
        } catch(e) {
            console.error(e);
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[160] bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-6xl h-[90vh] rounded-[3rem] shadow-2xl flex overflow-hidden relative">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full z-50 transition-colors"><XMarkIcon className="w-6 h-6"/></button>

                {/* LEFT: Consultant AI & Bulk Creator */}
                <div className="w-[400px] bg-gray-50 border-r border-gray-200 flex flex-col p-8 z-20 overflow-y-auto">
                    <div className="mb-6">
                        <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter leading-none mb-2">Trend Studio</h2>
                        <p className="text-xs font-bold text-pink-600 uppercase tracking-widest flex items-center gap-2">
                            <GlobeAltIcon className="w-4 h-4"/> AI Trend Scout & Bulk Creator
                        </p>
                    </div>

                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 space-y-4">
                            <div>
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2"><CalendarIcon className="w-3 h-3"/> Occasion</label>
                                <input 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-bold text-sm outline-none focus:ring-2 focus:ring-pink-500"
                                    placeholder="e.g. Cannes Film Festival"
                                    value={occasion}
                                    onChange={(e) => setOccasion(e.target.value)}
                                />
                            </div>
                            <div>
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2"><MapPinIcon className="w-3 h-3"/> Location</label>
                                <input 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-bold text-sm outline-none focus:ring-2 focus:ring-pink-500"
                                    placeholder="e.g. French Riviera"
                                    value={location}
                                    onChange={(e) => setLocation(e.target.value)}
                                />
                            </div>
                            <button 
                                onClick={handleResearch} 
                                disabled={isResearching || !occasion || !location}
                                className="w-full py-4 bg-black text-white rounded-xl font-black uppercase tracking-widest text-xs shadow-lg hover:bg-gray-800 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                            >
                                {isResearching ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4 text-pink-400"/>}
                                {isResearching ? 'Scouting Trends...' : 'Draft Concepts'}
                            </button>
                        </div>

                        {/* Draft Refinement Area */}
                        {draftTrends.length > 0 && (
                            <div className="bg-pink-50 p-6 rounded-3xl border border-pink-100 animate-fade-in-up">
                                <h4 className="text-sm font-black text-pink-800 uppercase tracking-tight mb-4 flex justify-between items-center">
                                    Proposed Collection <span className="bg-white text-pink-600 text-[10px] px-2 py-0.5 rounded-full">Draft</span>
                                </h4>
                                <div className="space-y-2 mb-4">
                                    {draftTrends.map((t, i) => (
                                        <div key={i} className="bg-white p-3 rounded-xl border border-pink-100 flex items-start gap-3">
                                            <div className="w-8 h-8 bg-pink-100 rounded-lg flex items-center justify-center text-pink-500 shrink-0 font-bold text-xs">{i+1}</div>
                                            <div>
                                                <p className="text-xs font-bold text-pink-900">{t.name}</p>
                                                <p className="text-[10px] text-gray-500 line-clamp-2">{t.description}</p>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                                
                                <div className="flex gap-2 mb-4">
                                    <input 
                                        className="flex-1 p-2 rounded-lg border border-pink-200 text-xs focus:ring-2 focus:ring-pink-400 outline-none"
                                        placeholder="Feedback? e.g. Make them red"
                                        value={feedback}
                                        onChange={(e) => setFeedback(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && handleRefine()}
                                        disabled={isRefining}
                                    />
                                    <button onClick={handleRefine} disabled={isRefining || !feedback} className="bg-white p-2 rounded-lg text-pink-600 hover:text-pink-800 border border-pink-200">
                                        {isRefining ? <div className="w-4 h-4 border-2 border-pink-300 border-t-pink-600 rounded-full animate-spin"></div> : <ChatBubbleIcon className="w-4 h-4"/>}
                                    </button>
                                </div>

                                <button 
                                    onClick={handleFabricateAll} 
                                    disabled={isFabricating}
                                    className="w-full py-3 bg-pink-600 text-white rounded-xl font-bold uppercase tracking-widest text-[10px] shadow-md hover:bg-pink-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                                >
                                    {isFabricating ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <Square2StackIcon className="w-3 h-3"/>}
                                    {isFabricating ? 'Fabricating Assets...' : 'Fabricate Collection'}
                                </button>
                            </div>
                        )}

                        {/* Active Inventory */}
                        {trends.length > 0 && (
                            <div className="border-t border-gray-200 pt-6">
                                <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Ready for Fitting</h4>
                                <div className="space-y-2">
                                    {trends.map((t, i) => (
                                        <div key={i} onClick={() => toggleSelection(i)} className={`flex items-center gap-3 p-2 rounded-xl border cursor-pointer transition-colors ${selectedTrendIndices.has(i) ? 'bg-indigo-50 border-indigo-300 shadow-sm' : 'bg-white border-gray-200 hover:border-gray-300'}`}>
                                            {t.url ? <img src={t.url} className="w-10 h-10 rounded-lg object-cover bg-gray-100"/> : <ShoppingBagIcon className="w-8 h-8 text-gray-300"/>}
                                            <span className="text-xs font-bold text-gray-700 truncate flex-1">{t.name}</span>
                                            {selectedTrendIndices.has(i) && <CheckCircleIcon className="w-4 h-4 text-indigo-500"/>}
                                        </div>
                                    ))}
                                </div>
                                <button 
                                    onClick={handleVisualize} 
                                    disabled={selectedTrendIndices.size === 0 || isFitting}
                                    className="w-full mt-4 py-3 bg-indigo-600 text-white rounded-xl font-bold uppercase tracking-widest text-[10px] shadow-md hover:bg-indigo-700 disabled:opacity-50 transition-all"
                                >
                                    {isFitting ? 'Fitting Room...' : 'Visualize Look'}
                                </button>
                            </div>
                        )}
                    </div>
                </div>

                {/* RIGHT: The Wheel of Style */}
                <div className="flex-1 bg-gradient-to-br from-gray-100 to-gray-200 relative flex items-center justify-center overflow-hidden">
                    
                    {/* Center Character */}
                    <div className="absolute z-10 w-64 h-96 rounded-[3rem] overflow-hidden shadow-2xl border-4 border-white">
                        {previewImage ? (
                            <img src={`data:image/png;base64,${previewImage}`} className="w-full h-full object-cover animate-fade-in-up" />
                        ) : (
                            <img src={getBaseImage()} className="w-full h-full object-cover" />
                        )}
                        
                        {/* Save Overlay */}
                        {previewImage && !isSaving && (
                            <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
                                <button onClick={handleSaveLook} className="bg-green-500 text-white px-6 py-3 rounded-full font-bold uppercase tracking-widest text-xs shadow-xl hover:bg-green-600 transition-transform hover:scale-105 flex items-center gap-2">
                                    <CheckCircleIcon className="w-4 h-4"/> Save to Gallery
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Orbiting Items (Only shown after fabrication) */}
                    <div className="absolute inset-0 pointer-events-none">
                        {trends.map((item, index) => {
                            if (!item.url) return null;
                            
                            // Calculate position on circle
                            const total = trends.length;
                            const radius = 300; // px
                            const angle = (index / total) * 2 * Math.PI - (Math.PI / 2); // Start top
                            const x = 50 + (Math.cos(angle) * 35); // %
                            const y = 50 + (Math.sin(angle) * 35); // %

                            const isSelected = selectedTrendIndices.has(index);

                            return (
                                <div 
                                    key={index}
                                    className={`absolute w-32 h-32 -ml-16 -mt-16 rounded-3xl border-4 shadow-xl overflow-hidden cursor-pointer pointer-events-auto transition-all duration-500 group ${isSelected ? 'border-pink-500 scale-110 z-20' : 'border-white hover:border-pink-200 hover:scale-105'}`}
                                    style={{ left: `${x}%`, top: `${y}%` }}
                                    onClick={() => toggleSelection(index)}
                                >
                                    <img src={item.url} className="w-full h-full object-cover bg-white" />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end justify-center p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span className="text-[9px] font-bold text-white text-center leading-tight">{item.name}</span>
                                    </div>
                                    {isSelected && <div className="absolute top-2 right-2 bg-indigo-500 text-white p-1 rounded-full"><CheckCircleIcon className="w-3 h-3"/></div>}
                                </div>
                            );
                        })}
                    </div>

                    {/* Loading State Overlay for Fabrication */}
                    {isFabricating && (
                        <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-30 flex flex-col items-center justify-center">
                            <div className="w-16 h-16 border-4 border-pink-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                            <h3 className="text-xl font-black text-pink-900 uppercase tracking-tighter">Fabricating Collection</h3>
                            <p className="text-sm text-pink-600 font-medium">Nano Banana is generating inventory...</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DressMeUp;