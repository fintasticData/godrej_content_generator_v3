
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { supabase, uploadBlob, fetchCharacters, updateCharacter, createCharacter, deleteCharacter, fetchContentItems, createContentItem, ensureSceneForContentItem, upsertSchedule, fetchLocations } from '../services/supabaseClient';
import { brainstormInfluencer, generateImagenImage, editImage, brainstormContentIdeas, generateCharacterBio, enhanceVisualPrompt, generateProductBlurb } from '../services/geminiService';
import { AspectRatio, Influencer, BrandIdentity, CharacterItem, Location } from '../types';
import { 
    PlusIcon, 
    SparklesIcon, 
    UserIcon, 
    LinkIcon, 
    PencilSquareIcon, 
    TrashIcon, 
    UploadCloudIcon, 
    CheckCircleIcon, 
    SearchIcon, 
    MagicWandIcon,
    ArrowPathIcon,
    XMarkIcon,
    PhotoIcon,
    SaveIcon,
    MegaphoneIcon,
    BoltIcon,
    ClockIcon,
    EyeIcon,
    LayersIcon,
    RocketIcon,
    FileImageIcon,
    CubeIcon,
    MenuIcon,
    MapPinIcon,
    CalendarIcon,
    FilmIcon,
    CameraIcon,
    ChevronRightIcon,
    ChevronDownIcon,
    ScissorsIcon,
    ArrowRightIcon,
    CalendarDaysIcon,
    BookOpenIcon,
    FrameIcon,
    ShoppingBagIcon,
    FireIcon,
    GlobeAltIcon,
    MapIcon,
    Square2StackIcon
} from './icons';
import Modal from './Modal';
import QuickClipCreator from './QuickClipCreator';
import ContentEngine from './ContentEngine';
import HairstyleMapper from './HairstyleMapper';
import DarlingStylist from './DarlingStylist';
import DarlingTrendsetter from './DarlingTrendsetter';
import LocationScout from './LocationScout';
import LookbookGenerator from './LookbookGenerator';
import OutfitCreator from './OutfitCreator';
import CharacterLabGuide from './CharacterLabGuide';
import DressMeUp from './DressMeUp';
import CampaignStylist from './CampaignStylist'; // Import New Component
import { GoogleGenAI, Type } from "@google/genai";
import MarkdownRenderer from './MarkdownRenderer';

const DEFAULT_AVATAR = "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=400&h=500&fit=crop";

const RATIO_OPTIONS = [
    { id: AspectRatio.SQUARE, label: '1:1', desc: 'Post' },
    { id: AspectRatio.PORTRAIT, label: '9:16', desc: 'Reel' },
    { id: AspectRatio.LANDSCAPE, label: '16:9', desc: 'Wide' }
];

const CHARACTER_ROLES = [
    "Brand Ambassador",
    "Influencer",
    "Actor",
    "Sportsperson",
    "Animated Character",
    "Mascot",
    "Virtual Persona"
];

// ... (Helper functions urlToBase64, fileToBase64 remain the same) ...
const urlToBase64 = async (url: string): Promise<string> => {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(blob);
    });
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
             const base64 = (reader.result as string).split(',')[1];
             resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

// ... (InfluencerOnboarding component remains the same) ...
const InfluencerOnboarding: React.FC<{ onClose: () => void, onSuccess: () => void }> = ({ onClose, onSuccess }) => {
    // Form State
    const [name, setName] = useState('');
    const [alias, setAlias] = useState('');
    const [role, setRole] = useState('Influencer');
    const [bio, setBio] = useState('');
    const [visualPrompt, setVisualPrompt] = useState('');
    const [baseImage, setBaseImage] = useState<string | null>(null);
    
    // AI State
    const [architectConcept, setArchitectConcept] = useState('');
    const [isArchitecting, setIsArchitecting] = useState(false);
    const [isPainting, setIsPainting] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    
    // Catalogue State
    const [catalogueImages, setCatalogueImages] = useState<{url: string, label: string}[]>([]);
    const [isGeneratingCatalogue, setIsGeneratingCatalogue] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleArchitect = async () => {
        if (!architectConcept.trim()) return;
        setIsArchitecting(true);
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Create a detailed influencer persona based on this concept: "${architectConcept}".
                Return a JSON object with:
                - name: A creative real name.
                - alias: A catchy social media handle/alias.
                - role: One of [Influencer, Brand Ambassador, Virtual Persona, Model].
                - bio: A professional 2-sentence biography.
                - visual_prompt: A highly detailed, photorealistic image generation prompt describing their face, hair, style, and lighting.`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING },
                            alias: { type: Type.STRING },
                            role: { type: Type.STRING },
                            bio: { type: Type.STRING },
                            visual_prompt: { type: Type.STRING },
                        }
                    }
                }
            });
            
            const data = JSON.parse(response.text || '{}');
            setName(data.name || '');
            setAlias(data.alias || '');
            setRole(data.role || 'Influencer');
            setBio(data.bio || '');
            setVisualPrompt(data.visual_prompt || '');
        } catch (e) {
            console.error(e);
            alert("Architect failed to design persona.");
        } finally {
            setIsArchitecting(false);
        }
    };

    const handleGenerateBaseImage = async () => {
        if (!visualPrompt.trim()) return;
        setIsPainting(true);
        try {
            const result = await generateImagenImage(visualPrompt, '1:1');
            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const fileName = `base_avatar_${Date.now()}.png`;
            const url = await uploadBlob(blob, fileName, 'godrej/characters');
            if (url) setBaseImage(url);
        } catch (e) { console.error(e); alert("Failed to generate base image."); } finally { setIsPainting(false); }
    };

    const handleGenerateCatalogue = async () => {
        if (!baseImage) return;
        setIsGeneratingCatalogue(true);
        try {
            const base64 = await urlToBase64(baseImage);
            const concepts = [
                { label: 'Street Style', prompt: 'Change outfit to trendy street fashion, urban city background.' },
                { label: 'Red Carpet', prompt: 'Change outfit to elegant evening wear, red carpet background.' },
                { label: 'Casual', prompt: 'Change outfit to comfortable casual wear, home interior background.' },
                { label: 'Fitness', prompt: 'Change outfit to activewear, gym background.' }
            ];
            const promises = concepts.map(async (concept) => {
                const result = await editImage(base64, concept.prompt, undefined, AspectRatio.SQUARE, 'gemini-2.5-flash-image');
                const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
                const fileName = `cat_${concept.label.replace(/\s/g,'')}_${Date.now()}.png`;
                const url = await uploadBlob(blob, fileName, 'godrej/characters');
                return url ? { url, label: concept.label } : null;
            });
            const results = await Promise.all(promises);
            setCatalogueImages(prev => [...prev, ...results.filter((r): r is {url: string, label: string} => !!r)]);
        } catch (e) { console.error(e); } finally { setIsGeneratingCatalogue(false); }
    };

    const handleUploadImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        setIsPainting(true);
        try {
            const fileName = `base_upload_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9]/g, '')}`;
            const url = await uploadBlob(file, fileName, 'godrej/characters');
            if (url) setBaseImage(url);
        } catch(e) { console.error(e); } finally { setIsPainting(false); }
    };

    const handleRemoveCatalogueImage = (url: string) => {
        setCatalogueImages(prev => prev.filter(img => img.url !== url));
    };

    const handleSave = async () => {
        if (!name || !baseImage) { alert("Name and Base Image required."); return; }
        setIsSaving(true);
        try {
            const gallery = [
                { url: baseImage, type: 'primary', description: 'Base Avatar' },
                ...catalogueImages.map(img => ({ url: img.url, type: 'catalogue_look', description: img.label }))
            ];
            await createCharacter({
                name, alias, role, description: bio, image_url: baseImage, status: 'active',
                character_jsonb: { visual_markers: { primary_image: baseImage, visual_prompt: visualPrompt }, vibe_keywords: architectConcept.split(' ') },
                image_urls_jsonb: gallery
            });
            onSuccess(); onClose();
        } catch (e) { console.error(e); alert("Failed to save."); } finally { setIsSaving(false); }
    };

    return (
        <div className="fixed inset-0 z-[200] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-6xl rounded-[2.5rem] shadow-2xl flex overflow-hidden max-h-[90vh] border border-gray-100 relative">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors z-20"><XMarkIcon className="w-6 h-6"/></button>
                <div className="w-[350px] bg-gray-50 border-r border-gray-100 p-8 flex flex-col overflow-y-auto shrink-0">
                    <div className="mb-8"><div className="w-12 h-12 bg-gradient-to-br from-[#9063CD] to-indigo-600 rounded-2xl flex items-center justify-center text-white mb-4 shadow-lg"><SparklesIcon className="w-6 h-6"/></div><h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight leading-none">Persona Architect</h2><p className="text-sm text-gray-500 mt-2 font-medium">Use the AI Plugin to auto-generate a unique influencer profile.</p></div>
                    <div className="space-y-4"><label className="text-[10px] font-black text-indigo-500 uppercase tracking-widest block">Concept / Vibe</label><textarea className="w-full h-32 bg-white border border-gray-200 rounded-2xl p-4 text-sm font-medium focus:ring-4 focus:ring-indigo-100 outline-none resize-none shadow-sm transition-all" placeholder="e.g. A futuristic tech fashion blogger..." value={architectConcept} onChange={(e) => setArchitectConcept(e.target.value)} /><button onClick={handleArchitect} disabled={isArchitecting || !architectConcept} className="w-full py-4 bg-black text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-gray-800 disabled:opacity-50 transition-all flex items-center justify-center gap-2 shadow-xl">{isArchitecting ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4 text-yellow-400"/>}{isArchitecting ? 'Designing...' : 'Run Architect Plugin'}</button></div>
                </div>
                <div className="flex-1 p-10 overflow-y-auto bg-white flex flex-col">
                    <div className="flex-1"><h3 className="text-xl font-black text-gray-900 uppercase tracking-tight mb-8">Character Basics</h3><div className="grid grid-cols-2 gap-8 mb-8"><div className="space-y-6"><div><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Legal Name</label><input className="w-full p-4 bg-gray-50 border-transparent rounded-xl font-bold text-gray-900 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none transition-all" value={name} onChange={e => setName(e.target.value)} placeholder="Full Name" /></div><div><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Alias / Handle</label><input className="w-full p-4 bg-gray-50 border-transparent rounded-xl font-bold text-gray-900 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none transition-all" value={alias} onChange={e => setAlias(e.target.value)} placeholder="@username" /></div><div><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-2">Primary Role</label><select className="w-full p-4 bg-gray-50 border-transparent rounded-xl font-bold text-gray-900 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none transition-all appearance-none cursor-pointer" value={role} onChange={e => setRole(e.target.value)}>{CHARACTER_ROLES.map(r => <option key={r} value={r}>{r}</option>)}</select></div></div><div className="space-y-2"><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Identity Anchor (Base Image)</label><div className="aspect-[3/4] w-full bg-gray-50 rounded-[2rem] border-2 border-dashed border-gray-200 relative overflow-hidden group flex flex-col items-center justify-center hover:border-indigo-300 transition-all">{baseImage ? (<><img src={baseImage} className="w-full h-full object-cover" /><div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3"><button onClick={() => fileInputRef.current?.click()} className="p-3 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-md transition-colors"><UploadCloudIcon className="w-5 h-5"/></button><button onClick={handleGenerateBaseImage} className="p-3 bg-indigo-600 hover:bg-indigo-700 rounded-full text-white shadow-lg transition-colors"><MagicWandIcon className="w-5 h-5"/></button></div></>) : (<div className="text-center p-6 space-y-4"><div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm text-gray-300"><UserIcon className="w-8 h-8"/></div><div className="flex flex-col gap-2"><button onClick={() => fileInputRef.current?.click()} className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-xs font-bold text-gray-600 hover:bg-gray-50 transition-colors">Upload Photo</button><span className="text-[10px] text-gray-400 font-bold uppercase">OR</span><button onClick={handleGenerateBaseImage} disabled={!visualPrompt || isPainting} className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors disabled:opacity-50">{isPainting ? 'Painting...' : 'Generate from Prompt'}</button></div></div>)}<input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleUploadImage} /></div></div></div><div className="space-y-2 mb-8"><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Bio & Backstory</label><textarea className="w-full h-24 p-4 bg-gray-50 border-transparent rounded-xl text-sm font-medium text-gray-700 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none resize-none transition-all" value={bio} onChange={e => setBio(e.target.value)} placeholder="Character background..." /></div><div className="space-y-2 mb-8"><div className="flex justify-between items-center"><label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest block">Visual Prompt (AI Instructions)</label><button className="text-[9px] font-bold text-indigo-500 hover:text-indigo-700 flex items-center gap-1" onClick={() => setVisualPrompt(p => p + " 8k, photorealistic, cinematic lighting.")}><MagicWandIcon className="w-3 h-3"/> Enhance</button></div><textarea className="w-full h-20 p-4 bg-gray-50 border-transparent rounded-xl text-xs font-mono text-gray-600 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none resize-none transition-all" value={visualPrompt} onChange={e => setVisualPrompt(e.target.value)} placeholder="Detailed visual description for image generation..." /></div><div className="bg-indigo-50/50 p-6 rounded-3xl border border-indigo-100 mb-8"><div className="flex justify-between items-center mb-4"><h4 className="text-sm font-black text-indigo-900 uppercase tracking-tight flex items-center gap-2"><SparklesIcon className="w-4 h-4 text-[#9063CD]"/> Look Catalogue</h4><button onClick={handleGenerateCatalogue} disabled={!baseImage || isGeneratingCatalogue} className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center gap-2 shadow-sm">{isGeneratingCatalogue ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-3 h-3 text-yellow-300"/>} Generate 4 Looks (Nano)</button></div><div className="grid grid-cols-4 gap-4">{catalogueImages.map((img, idx) => (<div key={idx} className="relative group aspect-square rounded-2xl overflow-hidden bg-white shadow-sm border border-gray-100"><img src={img.url} className="w-full h-full object-cover" /><div className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-black/80 to-transparent"><p className="text-[9px] font-bold text-white uppercase text-center">{img.label}</p></div><button onClick={() => handleRemoveCatalogueImage(img.url)} className="absolute top-2 right-2 bg-white/20 hover:bg-red-500 hover:text-white text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-all"><XMarkIcon className="w-3 h-3"/></button></div>))}{catalogueImages.length === 0 && (<div className="col-span-4 py-8 text-center text-indigo-300/50 border-2 border-dashed border-indigo-100 rounded-2xl flex flex-col items-center justify-center"><PhotoIcon className="w-8 h-8 mb-2 opacity-50"/><p className="text-[10px] font-bold uppercase tracking-widest">No catalogue generated yet</p></div>)}</div></div></div><div className="flex justify-end pt-6 border-t border-gray-100 shrink-0"><button onClick={handleSave} disabled={isSaving} className="px-10 py-4 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-gray-800 transition-all flex items-center gap-2 disabled:opacity-50">{isSaving ? 'Onboarding...' : 'Confirm & Create Influencer'} <ArrowRightIcon className="w-4 h-4"/></button></div></div>
            </div>
        </div>
    );
};

// ... (ItemCasing component remains the same) ...
const ItemCasing: React.FC<{ 
    item: CharacterItem, 
    character: Influencer, 
    locations: Location[],
    onClose: () => void, 
    onDelete: (id: string) => void,
    onRefresh: () => void
}> = ({ item, character, locations, onClose, onDelete, onRefresh }) => {
    // Basic implementation to satisfy the error
    return (
        <div className="fixed inset-0 z-[200] bg-gray-900/80 backdrop-blur-md flex items-center justify-center p-4" onClick={onClose}>
            <div className="bg-white rounded-3xl p-6 max-w-4xl w-full max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                <div className="flex justify-between items-start mb-6">
                    <div>
                        <h3 className="text-2xl font-black text-gray-900">{item.name}</h3>
                        <p className="text-sm text-gray-500 font-medium uppercase tracking-wider">{item.type}</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full"><XMarkIcon className="w-6 h-6"/></button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="aspect-[3/4] bg-gray-100 rounded-2xl overflow-hidden">
                        <img src={item.image_url} className="w-full h-full object-cover" alt={item.name}/>
                    </div>
                    <div className="space-y-6">
                        <div>
                            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest block mb-2">Description</label>
                            <p className="text-sm text-gray-700 leading-relaxed">{item.description}</p>
                        </div>
                        <div className="pt-6 border-t border-gray-100">
                            <button onClick={() => onDelete(item.id)} className="w-full py-4 bg-red-50 text-red-600 rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-red-100 transition-colors flex items-center justify-center gap-2">
                                <TrashIcon className="w-4 h-4"/> Delete Item
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// CarouselModal update
const CarouselModal: React.FC<{
    images: { url: string; type?: string; description?: string, features?: string }[];
    initialIndex: number;
    onClose: () => void;
    onSetPrimary: (url: string) => void;
    onSetReference: (url: string) => void;
    onDelete: (url: string) => void;
}> = ({ images, initialIndex, onClose, onSetPrimary, onSetReference, onDelete }) => {
    const [currentIndex, setCurrentIndex] = useState(initialIndex);
    const currentImage = images[currentIndex];

    const handleNext = (e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentIndex((prev) => (prev + 1) % images.length);
    };

    const handlePrev = (e: React.MouseEvent) => {
        e.stopPropagation();
        setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    };

    return (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col justify-center items-center" onClick={onClose}>
            <button className="absolute top-6 right-6 p-2 text-white/50 hover:text-white transition-colors" onClick={onClose}>
                <XMarkIcon className="w-8 h-8"/>
            </button>
            
            <div className="flex-1 w-full flex items-center justify-between px-4">
                <button onClick={handlePrev} className="p-4 hover:bg-white/10 rounded-full text-white transition-colors"><ChevronRightIcon className="w-8 h-8 rotate-180"/></button>
                <div className="relative max-h-[80vh] max-w-[80vw] flex flex-col items-center gap-6" onClick={e => e.stopPropagation()}>
                    <div className="relative">
                        <img src={currentImage.url} className="max-h-[70vh] max-w-full object-contain rounded-lg shadow-2xl" />
                        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-4">
                            <button onClick={() => onSetPrimary(currentImage.url)} className="bg-white/10 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-full text-white text-xs font-bold uppercase tracking-widest border border-white/20 transition-all">Set Profile</button>
                            <button onClick={() => onSetReference(currentImage.url)} className="bg-white/10 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-full text-white text-xs font-bold uppercase tracking-widest border border-white/20 transition-all">Use as Anchor</button>
                            <button onClick={() => { onDelete(currentImage.url); onClose(); }} className="bg-red-500/80 hover:bg-red-600 backdrop-blur-md p-2 rounded-full text-white transition-all"><TrashIcon className="w-4 h-4"/></button>
                        </div>
                    </div>
                    {/* Metadata Panel */}
                    <div className="w-full max-w-2xl bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/10 text-white overflow-y-auto max-h-[20vh]">
                        <div className="flex items-center gap-3 mb-2">
                            <p className="text-white/50 text-xs font-mono">{currentIndex + 1} / {images.length}</p>
                            {currentImage.type && <span className="px-2 py-0.5 rounded bg-white/20 text-white/80 text-[9px] uppercase tracking-widest">{currentImage.type}</span>}
                        </div>
                        {currentImage.description && <p className="text-white font-medium text-sm mb-4">{currentImage.description}</p>}
                        
                        {currentImage.features && (
                            <div className="mt-4 pt-4 border-t border-white/10">
                                <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-300 mb-2">AI Analysis</h4>
                                <div className="text-xs text-white/80 prose prose-invert max-w-none">
                                    <MarkdownRenderer content={currentImage.features} className="text-white/80" />
                                </div>
                            </div>
                        )}
                    </div>
                </div>
                <button onClick={handleNext} className="p-4 hover:bg-white/10 rounded-full text-white transition-colors"><ChevronRightIcon className="w-8 h-8"/></button>
            </div>
        </div>
    );
};

const InfluencerCenter: React.FC = () => {
    // ... (Keep all existing InfluencerCenter main component logic) ...
    // ... existing state ...
    const [characters, setCharacters] = useState<Influencer[]>([]);
    const [brands, setBrands] = useState<BrandIdentity[]>([]);
    const [locations, setLocations] = useState<Location[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [activeFilter, setActiveFilter] = useState('all');
    
    // View/Edit State
    const [inspectedChar, setInspectedChar] = useState<Influencer | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [activeDrawerTab, setActiveDrawerTab] = useState<'bio' | 'wardrobe' | 'visual' | 'content'>('bio');
    
    // Showcase State
    const [inspectedItem, setInspectedItem] = useState<CharacterItem | null>(null);
    const [wardrobeFilter, setWardrobeFilter] = useState('all');

    // ... (Selection and Modals states) ...
    const [isSelectionMode, setIsSelectionMode] = useState(false);
    const [selectedCharIds, setSelectedCharIds] = useState<Set<string>>(new Set());
    const [showOutfitCreator, setShowOutfitCreator] = useState(false);
    const [showSingleOutfitCreator, setShowSingleOutfitCreator] = useState(false);

    // Engine States
    const [isGeneratingBio, setIsGeneratingBio] = useState(false);
    const [activeReferenceImage, setActiveReferenceImage] = useState<string>(''); 
    const [stylePrompt, setStylePrompt] = useState('');
    const [isGeneratingStyle, setIsGeneratingStyle] = useState(false);
    const [carouselIndex, setCarouselIndex] = useState<number | null>(null);
    const [showQuickClip, setShowQuickClip] = useState(false);
    const [showHairMapper, setShowHairMapper] = useState(false);
    const [showDarlingStylist, setShowDarlingStylist] = useState(false);
    const [showUserGuide, setShowUserGuide] = useState(false);
    // NEW: Trendsetter State
    const [showTrendsetter, setShowTrendsetter] = useState(false);
    // NEW: Location Scout State
    const [showLocationScout, setShowLocationScout] = useState(false);
    // NEW: Lookbook Generator State
    const [showLookbookGenerator, setShowLookbookGenerator] = useState(false);
    // NEW: Dress Me Up State
    const [showDressMeUp, setShowDressMeUp] = useState(false);
    // NEW: Campaign Stylist
    const [showCampaignStylist, setShowCampaignStylist] = useState(false);

    // Onboarding State
    const [showOnboarding, setShowOnboarding] = useState(false);

    // Video Selection Mode for Visual History
    const [videoSelectionMode, setVideoSelectionMode] = useState(false);
    const [selectedVideoSourceImages, setSelectedVideoSourceImages] = useState<string[]>([]);

    // Video Upload State
    const [isUploadingVideo, setIsUploadingVideo] = useState(false);
    const videoInputRef = useRef<HTMLInputElement>(null);

    const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !inspectedChar) return;

        setIsUploadingVideo(true);
        try {
            const fileName = `manual_video_${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '')}`;
            const url = await uploadBlob(file, fileName, 'godrej/generated_videos');
            
            if (url) {
                const pk = inspectedChar.character_id || inspectedChar.id;
                const currentVideos = inspectedChar.video_urls || [];
                const newVideo = {
                    url: url,
                    description: "Manual Upload",
                    created_at: new Date().toISOString()
                };
                
                // Optimistic update
                const updatedVideos = [newVideo, ...(Array.isArray(currentVideos) ? currentVideos : [])];
                setInspectedChar({ ...inspectedChar, video_urls: updatedVideos });
                
                await updateCharacter(pk!, { video_urls: updatedVideos });
                
                // Update parent list
                setCharacters(prev => prev.map(c => (c.character_id || c.id) === pk ? { ...c, video_urls: updatedVideos } : c));
            }
        } catch (e) {
            console.error("Upload failed", e);
            alert("Failed to upload video.");
        } finally {
            setIsUploadingVideo(false);
            if (videoInputRef.current) videoInputRef.current.value = '';
        }
    };

    useEffect(() => { 
        refreshCharacters(); 
        fetchBrands();
        loadLocations();
    }, []);

    useEffect(() => {
        if (inspectedChar) {
            setActiveReferenceImage(getCharacterImage(inspectedChar));
        }
    }, [inspectedChar?.character_id, inspectedChar?.id]);

    const loadLocations = async () => {
        const data = await fetchLocations();
        setLocations(data || []);
    };

    const fetchBrands = async () => {
        const { data } = await supabase.from('dng1_brand_identity').select('*');
        if(data) setBrands(data);
    };

    const refreshCharacters = async () => {
        setIsLoading(true);
        try {
            const data = await fetchCharacters();
            setCharacters(data || []);
            if (inspectedChar) {
                const pk = inspectedChar.character_id || inspectedChar.id;
                const fresh = data?.find(c => (c.character_id || c.id) === pk);
                if (fresh) setInspectedChar(fresh);
            }
        } catch (e) { console.error(e); } finally { setIsLoading(false); }
    };

    const getCharacterImage = (char: Influencer): string => {
        if (char.image_url && char.image_url.startsWith('http')) return char.image_url;
        if (char.image_urls_jsonb && char.image_urls_jsonb.length > 0) return char.image_urls_jsonb[0].url;
        const markers = (char.character_jsonb as any)?.visual_markers;
        const primary = markers?.primary_image;
        if (primary && typeof primary === 'string') return primary;
        return DEFAULT_AVATAR;
    };

    // ... existing handlers ...
    const handleSaveCharacter = async () => {
        if (!inspectedChar) return;
        setIsSaving(true);
        try {
            const { character_id, id, ...rest } = inspectedChar;
            const pk = character_id || id;
            if (pk === 'new' || !pk) await createCharacter(rest);
            else await updateCharacter(pk, rest);
            refreshCharacters();
        } catch (e) { console.error(e); } finally { setIsSaving(false); }
    };

    const handleMagicBio = async () => {
        if (!inspectedChar) return;
        setIsGeneratingBio(true);
        try {
            const bio = await generateCharacterBio(inspectedChar.name, inspectedChar.role);
            setInspectedChar({ ...inspectedChar, origin_story: bio });
        } catch (e) { console.error(e); } finally { setIsGeneratingBio(false); }
    };

    // ... rest of handlers ...
    const handleDeleteItem = async (itemId: string) => {
        if (!inspectedChar) return;
        
        const currentItems = Array.isArray(inspectedChar.character_items) ? inspectedChar.character_items : [];
        const updatedItems = currentItems.filter((i: any) => i.id !== itemId);
        
        const pk = inspectedChar.character_id || inspectedChar.id;
        if (pk) {
            await updateCharacter(pk, { character_items: updatedItems });
            setInspectedChar({ ...inspectedChar, character_items: updatedItems });
            setInspectedItem(null);
            refreshCharacters();
        }
    };

    const handleSetPrimaryImage = async (url: string) => {
        if (!inspectedChar) return;
        const pk = inspectedChar.character_id || inspectedChar.id;
        if (!pk) return;

        setInspectedChar(prev => prev ? ({ ...prev, image_url: url }) : null);
        await updateCharacter(pk, { image_url: url });
        setCharacters(prev => prev.map(c => (c.character_id || c.id) === pk ? { ...c, image_url: url } : c));
    };

    const handleDeleteGalleryImage = async (url: string) => {
        if (!inspectedChar) return;
        const pk = inspectedChar.character_id || inspectedChar.id;
        if (!pk) return;

        const currentGallery = inspectedChar.image_urls_jsonb || [];
        const newGallery = currentGallery.filter((img: any) => img.url !== url);

        setInspectedChar(prev => prev ? ({ ...prev, image_urls_jsonb: newGallery }) : null);
        await updateCharacter(pk, { image_urls_jsonb: newGallery });
    };

    const handleDeleteVideo = async (url: string) => {
        if (!inspectedChar) return;
        const pk = inspectedChar.character_id || inspectedChar.id;
        if (!pk) return;

        if (!confirm("Are you sure you want to delete this video?")) return;

        const currentVideos = inspectedChar.video_urls || [];
        const newVideos = currentVideos.filter((v: any) => v.url !== url);

        setInspectedChar(prev => prev ? ({ ...prev, video_urls: newVideos }) : null);
        await updateCharacter(pk, { video_urls: newVideos });
    };

    const toggleVideoSelection = (url: string) => {
        setSelectedVideoSourceImages(prev => {
            if (prev.includes(url)) return prev.filter(u => u !== url);
            if (prev.length >= 1) return prev; // Limit to 1 for source image in generator
            return [...prev, url];
        });
    };

    const filteredCharacters = characters.filter(c => {
        const matchesSearch = c.name?.toLowerCase().includes(searchQuery.toLowerCase()) || c.alias?.toLowerCase().includes(searchQuery.toLowerCase());
        let matchesType = activeFilter === 'all' || c.role?.toLowerCase().includes(activeFilter.toLowerCase());
        return matchesSearch && matchesType;
    });

    return (
        <div className="w-full h-full flex flex-col bg-gray-50 overflow-hidden relative font-sans">
            {/* Header */}
            <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-20 shadow-sm">
                <div><h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">Character <span className="text-[#9063CD]">Lab</span></h2></div>
                <div className="flex gap-3">
                    <button onClick={() => { setIsSelectionMode(!isSelectionMode); setSelectedCharIds(new Set()); }} className={`flex items-center gap-2 px-3 py-2 font-bold rounded-lg shadow-sm transition-all text-xs uppercase tracking-widest border ${isSelectionMode ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'}`}><FrameIcon className="w-4 h-4" /> {isSelectionMode ? 'Cancel' : 'Select'}</button>
                    <button onClick={() => setShowUserGuide(true)} className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-600 font-bold rounded-lg hover:bg-gray-200 transition-all text-xs uppercase tracking-widest"><BookOpenIcon className="w-4 h-4" /> Guide</button>
                    <button onClick={() => setShowOnboarding(true)} className="flex items-center gap-2 px-4 py-2 bg-black text-white font-bold rounded-lg shadow-md text-xs uppercase tracking-widest"><PlusIcon className="w-4 h-4" /> Add Talent</button>
                </div>
            </header>

            <div className="flex-1 flex overflow-hidden relative">
                {/* List Column */}
                <div className={`${inspectedChar ? 'w-80 border-r border-gray-200 bg-white' : 'w-full bg-gray-50'} flex flex-col transition-all duration-300 ease-in-out`}>
                    <div className="p-4 flex flex-col gap-3 sticky top-0 bg-inherit z-10">
                        <div className="relative">
                            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input type="text" placeholder="Search..." className="w-full pl-9 pr-4 py-2 bg-gray-100 border border-transparent rounded-xl text-sm font-medium focus:bg-white focus:border-gray-300 outline-none" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 pt-0">
                        {isLoading ? <div className="flex justify-center p-10"><div className="w-8 h-8 border-4 border-[#9063CD] border-t-transparent rounded-full animate-spin"></div></div> : (
                            inspectedChar ? (
                                <div className="space-y-2">
                                    {filteredCharacters.map(char => (
                                        <div key={char.character_id || char.id} onClick={() => setInspectedChar(char)} className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all hover:bg-gray-50 ${inspectedChar.character_id === char.character_id ? 'bg-indigo-50 border-indigo-100' : ''}`}>
                                            <img src={getCharacterImage(char)} className="w-10 h-10 rounded-full object-cover" />
                                            <div className="overflow-hidden"><h4 className="text-sm font-bold truncate">{char.alias || char.name}</h4><p className="text-[10px] text-gray-500 truncate">{char.role}</p></div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4 pb-20">
                                    {filteredCharacters.map(char => {
                                        const id = char.character_id || char.id || '';
                                        const thumb = getCharacterImage(char);
                                        return (
                                            <div key={id} onClick={() => setInspectedChar(char)} className="aspect-[3/4] group relative rounded-3xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] shadow-sm">
                                                <img src={thumb} className="w-full h-full object-cover absolute inset-0 transition-transform group-hover:scale-110" />
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                                                <div className="absolute bottom-4 left-4 right-4">
                                                    <span className="bg-[#9063CD] text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase">{char.role}</span>
                                                    <h3 className="text-white font-black uppercase text-lg mt-1 truncate">{char.alias || char.name}</h3>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )
                        )}
                    </div>
                </div>

                {/* Inspector Drawer */}
                {inspectedChar && (
                    <div className="flex-1 flex flex-col bg-white overflow-hidden animate-fade-in-up">
                        {/* Drawer Header ... */}
                        <header className="px-8 py-6 border-b border-gray-100 flex items-start justify-between bg-white shrink-0">
                            <div>
                                <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter leading-none">{inspectedChar.alias || inspectedChar.name || 'New Profile'}</h2>
                                <p className="text-xs font-bold text-[#9063CD] uppercase tracking-widest mt-2 flex items-center gap-2"><UserIcon className="w-3 h-3" /> {inspectedChar.role}</p>
                            </div>
                            <button onClick={() => setInspectedChar(null)} className="p-3 text-gray-400 hover:bg-gray-100 rounded-full transition-all"><XMarkIcon className="w-6 h-6"/></button>
                        </header>

                        <div className="px-8 border-b border-gray-100 flex gap-6 shrink-0 bg-white">
                            {['bio', 'wardrobe', 'visual', 'content'].map(tab => (
                                <button key={tab} onClick={() => setActiveDrawerTab(tab as any)} className={`py-4 text-xs font-black uppercase tracking-widest relative transition-colors ${activeDrawerTab === tab ? 'text-black' : 'text-gray-400 hover:text-gray-600'}`}>
                                    {tab}
                                    {activeDrawerTab === tab && <div className="absolute bottom-0 left-0 right-0 h-1 bg-[#9063CD] rounded-full"></div>}
                                </button>
                            ))}
                        </div>

                        <div className="flex-1 overflow-hidden bg-gray-50/50">
                            {activeDrawerTab === 'bio' && (
                                <div className="h-full overflow-y-auto p-8">
                                    <div className="max-w-4xl space-y-8 animate-fade-in-up">
                                        <div className="flex gap-10 items-start">
                                            <div className="w-48 h-64 rounded-3xl bg-gray-200 overflow-hidden shadow-2xl shrink-0 border-4 border-white">
                                                <img src={getCharacterImage(inspectedChar)} className="w-full h-full object-cover" />
                                            </div>
                                            <div className="flex-1 grid grid-cols-2 gap-6 pt-4">
                                                <div><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Legal Name</label><input className="w-full p-4 bg-white border border-gray-100 rounded-2xl font-bold shadow-sm" value={inspectedChar.name} onChange={(e) => setInspectedChar({...inspectedChar, name: e.target.value})} /></div>
                                                <div><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Display Alias</label><input className="w-full p-4 bg-white border border-gray-100 rounded-2xl font-bold shadow-sm" value={inspectedChar.alias} onChange={(e) => setInspectedChar({...inspectedChar, alias: e.target.value})} /></div>
                                                <div><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Role Selection</label><select className="w-full p-4 bg-white border border-gray-100 rounded-2xl font-bold shadow-sm appearance-none" value={inspectedChar.role} onChange={(e) => setInspectedChar({...inspectedChar, role: e.target.value})}>{CHARACTER_ROLES.map(r => <option key={r} value={r}>{r}</option>)}</select></div>
                                                <div><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-2">Affiliation</label><select className="w-full p-4 bg-white border border-gray-100 rounded-2xl font-bold shadow-sm appearance-none" value={inspectedChar.affiliation || ''} onChange={(e) => setInspectedChar({...inspectedChar, affiliation: e.target.value})}><option value="">Independent</option>{brands.map(b => <option key={b.id} value={b.brand_name}>{b.brand_name}</option>)}</select></div>
                                            </div>
                                        </div>
                                        <div className="space-y-4">
                                            <div className="flex justify-between items-end">
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">Character Backstory</label>
                                                <button onClick={handleMagicBio} disabled={isGeneratingBio} className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-3 py-1.5 rounded-lg hover:bg-indigo-100 transition-colors flex items-center gap-1 shadow-sm">
                                                    {isGeneratingBio ? 'Writing...' : <><MagicWandIcon className="w-3 h-3"/> Magic Write</>}
                                                </button>
                                            </div>
                                            <textarea className="w-full h-48 p-6 bg-white border border-gray-100 rounded-[2rem] leading-relaxed text-sm outline-none shadow-sm focus:ring-4 focus:ring-purple-50 transition-all" value={inspectedChar.origin_story} onChange={(e) => setInspectedChar({...inspectedChar, origin_story: e.target.value})} placeholder="Character backstory..." />
                                        </div>
                                    </div>
                                </div>
                            )}

                            {/* Wardrobe Tab remains same */}
                            {activeDrawerTab === 'wardrobe' && (
                                <div className="h-full flex flex-col p-8 overflow-hidden">
                                    <div className="flex justify-between items-center mb-8 shrink-0">
                                        <div className="flex gap-2 bg-white p-1 rounded-xl shadow-sm border border-gray-100">
                                            {['all', 'outfit', 'accessory', 'bag', 'watch', 'belt', 'prop'].map(f => (
                                                <button key={f} onClick={() => setWardrobeFilter(f)} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${wardrobeFilter === f ? 'bg-black text-white shadow-md' : 'text-gray-400 hover:text-gray-600'}`}>{f}</button>
                                            ))}
                                        </div>
                                        <button onClick={() => setShowSingleOutfitCreator(true)} className="px-6 py-2.5 bg-[#9063CD] text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg hover:bg-purple-700 transition-all flex items-center gap-2">
                                            <MagicWandIcon className="w-4 h-4" /> Architect New Item
                                        </button>
                                    </div>
                                    
                                    <div className="flex-1 overflow-y-auto no-scrollbar pb-10">
                                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
                                            {(() => {
                                                const rawItems = Array.isArray(inspectedChar.character_items) ? inspectedChar.character_items : [];
                                                const allItems = rawItems.filter((i: any) => wardrobeFilter === 'all' || i.type === wardrobeFilter);

                                                return allItems.map((item: any, idx: number) => (
                                                    <div 
                                                        key={item.id || idx} 
                                                        onClick={() => setInspectedItem(item)}
                                                        className={`group relative aspect-[3/4] rounded-3xl overflow-hidden bg-white shadow-sm border border-gray-100 hover:shadow-2xl hover:border-indigo-200 hover:-translate-y-1 transition-all cursor-pointer`}
                                                    >
                                                        <img src={item.image_url} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                                                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-5">
                                                            <span className="text-[8px] font-black text-white/70 uppercase tracking-widest mb-1">{item.type}</span>
                                                            <p className="text-white text-xs font-bold leading-tight line-clamp-2">{item.name}</p>
                                                            <div className="mt-3 flex items-center gap-2 text-white/50 text-[9px] font-bold uppercase tracking-widest border-t border-white/10 pt-3">
                                                                <EyeIcon className="w-3 h-3"/> {item.scened_visuals?.length || 0} Scene Usage
                                                            </div>
                                                        </div>
                                                    </div>
                                                ));
                                            })()}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeDrawerTab === 'visual' && (
                                <div className="h-full overflow-y-auto p-8 no-scrollbar">
                                    <div className="max-w-5xl mx-auto space-y-12 animate-fade-in-up pb-20">
                                        <div className="flex gap-10">
                                            <div className="w-1/3">
                                                <div className="bg-white p-6 rounded-[2.5rem] border border-indigo-100 shadow-xl sticky top-0">
                                                    <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-4 block flex items-center justify-center gap-2"><LinkIcon className="w-3 h-3"/> Identity Anchor</label>
                                                    <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-gray-50 border-4 border-white shadow-inner relative group">
                                                        <img src={activeReferenceImage || getCharacterImage(inspectedChar)} className="w-full h-full object-cover" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="flex-1 grid grid-cols-2 gap-4">
                                                
                                                {/* NEW: Campaign Stylist Plugin */}
                                                <div onClick={() => setShowCampaignStylist(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-purple-300 hover:-translate-y-1 transition-all group col-span-2 relative overflow-hidden">
                                                    <div className="absolute inset-0 bg-gradient-to-r from-purple-50 to-pink-50 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                                                    <div className="relative z-10 flex items-center gap-4">
                                                        <div className="p-3 bg-purple-100 rounded-xl text-purple-600 group-hover:bg-white group-hover:text-purple-600 transition-colors shadow-sm"><SparklesIcon className="w-6 h-6"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-sm uppercase tracking-widest">Campaign Stylist</h4><p className="text-[10px] font-bold text-gray-400 group-hover:text-purple-600">Product Analysis & Hair Trends</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-5 h-5 text-gray-300 group-hover:text-purple-500 relative z-10"/>
                                                </div>

                                                <div onClick={() => setShowDressMeUp(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-pink-300 hover:-translate-y-1 transition-all group relative overflow-hidden">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-pink-100 rounded-xl text-pink-600 group-hover:bg-white group-hover:text-pink-600 transition-colors shadow-sm"><ShoppingBagIcon className="w-6 h-6"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Dress Me Up</h4><p className="text-[9px] font-bold text-gray-400 group-hover:text-pink-600">Virtual Try-On</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-5 h-5 text-gray-300 group-hover:text-pink-500 relative z-10"/>
                                                </div>

                                                <div onClick={() => setShowHairMapper(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-pink-300 hover:-translate-y-1 transition-all group">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-pink-50 rounded-xl text-pink-500 group-hover:bg-pink-500 group-hover:text-white transition-colors"><ScissorsIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Hair Mapper</h4><p className="text-[9px] font-bold text-gray-400">Transfer Hairstyle</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-pink-500"/>
                                                </div>
                                                <div onClick={() => setShowDarlingStylist(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-[#9063CD] hover:-translate-y-1 transition-all group">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-purple-50 rounded-xl text-[#9063CD] group-hover:bg-[#9063CD] group-hover:text-white transition-colors"><UserIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Stylist Bot</h4><p className="text-[9px] font-bold text-gray-400">Consult Darling AI</p></div>
                                                    </div>
                                                    <SparklesIcon className="w-4 h-4 text-gray-300 group-hover:text-[#9063CD]"/>
                                                </div>
                                                <div onClick={() => setShowTrendsetter(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-indigo-500 hover:-translate-y-1 transition-all group col-span-2">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-indigo-50 rounded-xl text-indigo-500 group-hover:bg-indigo-500 group-hover:text-white transition-colors"><FireIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Darling Trendsetter</h4><p className="text-[9px] font-bold text-gray-400">Generate Branded Style Ideas</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-indigo-500"/>
                                                </div>
                                                
                                                {/* NEW: Location Scout */}
                                                <div onClick={() => setShowLocationScout(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-blue-400 hover:-translate-y-1 transition-all group">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-blue-50 rounded-xl text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-colors"><GlobeAltIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Location Scout</h4><p className="text-[9px] font-bold text-gray-400">Map & Teleport</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-blue-500"/>
                                                </div>

                                                {/* NEW: Lookbook Generator */}
                                                <div onClick={() => setShowLookbookGenerator(true)} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-emerald-400 hover:-translate-y-1 transition-all group">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-emerald-50 rounded-xl text-emerald-500 group-hover:bg-emerald-500 group-hover:text-white transition-colors"><Square2StackIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Lookbook Gen</h4><p className="text-[9px] font-bold text-gray-400">Consistency Pack</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-emerald-500"/>
                                                </div>

                                                <div onClick={() => { setVideoSelectionMode(true); setSelectedVideoSourceImages([]); }} className="bg-white p-6 rounded-[2rem] border border-gray-100 shadow-sm flex items-center justify-between cursor-pointer hover:border-blue-300 hover:-translate-y-1 transition-all group col-span-2">
                                                    <div className="flex items-center gap-4">
                                                        <div className="p-3 bg-blue-50 rounded-xl text-blue-500 group-hover:bg-blue-500 group-hover:text-white transition-colors"><FilmIcon className="w-5 h-5"/></div>
                                                        <div><h4 className="font-black text-gray-900 text-xs uppercase tracking-widest">Motion Studio</h4><p className="text-[9px] font-bold text-gray-400">Create 8s Clips from Gallery</p></div>
                                                    </div>
                                                    <ArrowRightIcon className="w-4 h-4 text-gray-300 group-hover:text-blue-500"/>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="space-y-6">
                                            <div className="flex justify-between items-center">
                                                <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-3">Visual History <span className="text-xs font-bold text-gray-400 bg-gray-100 px-3 py-1 rounded-full">{inspectedChar.image_urls_jsonb?.length || 0}</span></h3>
                                                {videoSelectionMode && (
                                                    <div className="flex gap-2">
                                                        <button onClick={() => { setVideoSelectionMode(false); setSelectedVideoSourceImages([]); }} className="px-4 py-2 rounded-lg text-gray-500 hover:bg-gray-100 text-xs font-bold">Cancel</button>
                                                        <button 
                                                            onClick={() => setShowQuickClip(true)} 
                                                            disabled={selectedVideoSourceImages.length === 0}
                                                            className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-indigo-700 disabled:opacity-50 transition-all shadow-md flex items-center gap-2"
                                                        >
                                                            <BoltIcon className="w-3 h-3"/> Generate Video ({selectedVideoSourceImages.length})
                                                        </button>
                                                    </div>
                                                )}
                                            </div>
                                            
                                            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                                                {(inspectedChar.image_urls_jsonb || []).map((item: any, i: number) => {
                                                    const isSelected = selectedVideoSourceImages.includes(item.url);
                                                    return (
                                                        <div 
                                                            key={i} 
                                                            className={`aspect-square bg-white rounded-2xl overflow-hidden cursor-pointer relative group border-4 transition-all ${
                                                                videoSelectionMode 
                                                                    ? (isSelected ? 'border-indigo-500 shadow-md transform scale-105' : 'border-gray-100 opacity-80 hover:opacity-100 hover:border-indigo-200')
                                                                    : (activeReferenceImage === item.url ? 'border-[#9063CD]' : 'border-white hover:border-gray-100 shadow-sm')
                                                            }`} 
                                                            onClick={() => {
                                                                if (videoSelectionMode) {
                                                                    toggleVideoSelection(item.url);
                                                                } else {
                                                                    setCarouselIndex(i);
                                                                }
                                                            }}
                                                        >
                                                            <img src={item.url} className="w-full h-full object-cover" />
                                                            {videoSelectionMode && (
                                                                <div className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-sm transition-transform">
                                                                    {isSelected ? <CheckCircleIcon className="w-4 h-4 text-indigo-500" /> : <div className="w-4 h-4 rounded-full border-2 border-gray-300" />}
                                                                </div>
                                                            )}
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </div>

                                        {/* Motion Gallery Section */}
                                        <div className="space-y-6 pt-8 border-t border-gray-100">
                                            <div className="flex justify-between items-center">
                                                <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter flex items-center gap-3">
                                                    Motion Gallery <span className="text-xs font-bold text-gray-400 bg-gray-100 px-3 py-1 rounded-full">{inspectedChar.video_urls?.length || 0}</span>
                                                </h3>
                                                <div className="flex gap-2">
                                                    <button 
                                                        onClick={() => videoInputRef.current?.click()}
                                                        disabled={isUploadingVideo}
                                                        className="px-4 py-2 bg-white border border-gray-200 text-gray-700 hover:bg-gray-50 rounded-lg text-xs font-bold uppercase tracking-widest shadow-sm flex items-center gap-2 transition-colors"
                                                    >
                                                        {isUploadingVideo ? 'Uploading...' : <><UploadCloudIcon className="w-3 h-3"/> Upload External</>}
                                                    </button>
                                                    <input type="file" ref={videoInputRef} hidden accept="video/*" onChange={handleVideoUpload} />
                                                </div>
                                            </div>
                                            
                                            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                                                {(inspectedChar.video_urls || []).map((vidItem: any, i: number) => {
                                                    const url = typeof vidItem === 'string' ? vidItem : vidItem.url;
                                                    const desc = typeof vidItem === 'string' ? "Legacy Clip" : (vidItem.description || "Quick Clip");
                                                    const date = typeof vidItem === 'string' ? new Date() : new Date(vidItem.created_at);

                                                    return (
                                                        <div key={i} className="group relative rounded-2xl overflow-hidden bg-black shadow-md border border-gray-100 flex flex-col">
                                                            <div className="relative aspect-video bg-gray-900">
                                                                <video 
                                                                    src={url} 
                                                                    controls 
                                                                    playsInline 
                                                                    preload="metadata"
                                                                    className="w-full h-full object-contain" 
                                                                />
                                                            </div>
                                                            <div className="p-3 bg-white flex-1 flex flex-col justify-between">
                                                                <div>
                                                                    <p className="text-xs font-bold text-gray-900 truncate" title={desc}>{desc}</p>
                                                                    <p className="text-[9px] text-gray-400">{date.toLocaleDateString()}</p>
                                                                </div>
                                                                <div className="mt-2 pt-2 border-t border-gray-100">
                                                                    <p className="text-[8px] text-gray-500 font-mono break-all bg-gray-50 p-1.5 rounded select-all" title={url}>
                                                                        URL: {url}
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <button 
                                                                onClick={() => handleDeleteVideo(url)}
                                                                className="absolute top-2 right-2 p-2 bg-black/50 hover:bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-all z-10"
                                                                title="Delete Video"
                                                            >
                                                                <TrashIcon className="w-4 h-4"/>
                                                            </button>
                                                        </div>
                                                    );
                                                })}
                                                {(!inspectedChar.video_urls || inspectedChar.video_urls.length === 0) && (
                                                    <div className="col-span-full py-12 flex flex-col items-center justify-center text-gray-300 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
                                                        <FilmIcon className="w-12 h-12 opacity-20 mb-2"/>
                                                        <p className="font-bold text-xs uppercase tracking-widest">No saved clips</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {activeDrawerTab === 'content' && <ContentEngine character={inspectedChar} onCharacterUpdate={(c) => setInspectedChar(c)} />}
                        </div>

                        <div className="p-6 border-t border-gray-100 bg-white flex justify-end shrink-0">
                            <button onClick={handleSaveCharacter} disabled={isSaving} className="px-10 py-4 bg-black text-white rounded-[1.5rem] font-black uppercase tracking-widest text-[10px] shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-3">
                                {isSaving ? 'Synchronizing...' : 'Save Production Data'} <SaveIcon className="w-4 h-4"/>
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Showcase Overlay */}
            {inspectedItem && inspectedChar && (
                <ItemCasing 
                    item={inspectedItem} 
                    character={inspectedChar} 
                    locations={locations}
                    onClose={() => setInspectedItem(null)} 
                    onDelete={handleDeleteItem} 
                    onRefresh={refreshCharacters}
                />
            )}

            {/* Carousel Modal */}
            {carouselIndex !== null && inspectedChar && (
                <CarouselModal 
                    images={inspectedChar.image_urls_jsonb || []}
                    initialIndex={carouselIndex}
                    onClose={() => setCarouselIndex(null)}
                    onSetPrimary={handleSetPrimaryImage}
                    onSetReference={(url) => setActiveReferenceImage(url)}
                    onDelete={handleDeleteGalleryImage}
                />
            )}

            {/* Restore QuickClipCreator */}
            {showQuickClip && inspectedChar && (
                <QuickClipCreator
                    onClose={() => setShowQuickClip(false)}
                    onSuccess={() => {
                        refreshCharacters();
                        setShowQuickClip(false);
                        setVideoSelectionMode(false);
                        setSelectedVideoSourceImages([]);
                    }}
                    initialCharacter={{
                        url: inspectedChar.image_url || inspectedChar.image_urls_jsonb?.[0]?.url || '',
                        id: inspectedChar.character_id || inspectedChar.id || '',
                        name: inspectedChar.name
                    }}
                    initialPrompt={""} 
                    initialStartFrame={selectedVideoSourceImages[0]}
                />
            )}

            {/* NEW: Influencer Onboarding Modal */}
            {showOnboarding && (
                <InfluencerOnboarding 
                    onClose={() => setShowOnboarding(false)}
                    onSuccess={refreshCharacters}
                />
            )}

            {/* Modals and toolkits */}
            {showHairMapper && inspectedChar && <HairstyleMapper character={inspectedChar} onClose={() => setShowHairMapper(false)} onSuccess={refreshCharacters} />}
            {showDarlingStylist && inspectedChar && <DarlingStylist character={inspectedChar} onClose={() => setShowDarlingStylist(false)} onSuccess={refreshCharacters} />}
            {showTrendsetter && inspectedChar && <DarlingTrendsetter character={inspectedChar} onClose={() => setShowTrendsetter(false)} onSuccess={refreshCharacters} />}
            
            {/* NEW Modals */}
            {showLocationScout && inspectedChar && <LocationScout character={inspectedChar} onClose={() => setShowLocationScout(false)} onSuccess={refreshCharacters} />}
            {showLookbookGenerator && inspectedChar && <LookbookGenerator character={inspectedChar} onClose={() => setShowLookbookGenerator(false)} onSuccess={refreshCharacters} />}
            {showDressMeUp && inspectedChar && <DressMeUp character={inspectedChar} onClose={() => setShowDressMeUp(false)} onSuccess={refreshCharacters} />}
            {showCampaignStylist && inspectedChar && <CampaignStylist character={inspectedChar} onClose={() => setShowCampaignStylist(false)} onSuccess={refreshCharacters} />}

            {showSingleOutfitCreator && inspectedChar && <OutfitCreator selectedCharacters={[inspectedChar]} onClose={() => setShowSingleOutfitCreator(false)} onSuccess={refreshCharacters} />}
            {showUserGuide && <CharacterLabGuide onClose={() => setShowUserGuide(false)} />}
        </div>
    );
};

export default InfluencerCenter;
