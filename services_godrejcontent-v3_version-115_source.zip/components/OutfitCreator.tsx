
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { Influencer, AspectRatio, CharacterItem } from '../types';
import { generateImage, brainstormItemRange } from '../services/geminiService';
import { uploadBlob, updateCharacter, supabase } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    SparklesIcon, 
    MagicWandIcon, 
    UserIcon, 
    CheckCircleIcon, 
    ArrowRightIcon, 
    PhotoIcon, 
    MapPinIcon, 
    ShoppingBagIcon, 
    BoltIcon, 
    CubeIcon, 
    Square2StackIcon, 
    PlusIcon, 
    LayoutGridIcon
} from './icons';

interface OutfitCreatorProps {
    selectedCharacters: Influencer[];
    onClose: () => void;
    onSuccess: () => void;
}

const ITEM_TYPES = [
    { id: 'outfit', label: 'Full Outfit', icon: <UserIcon className="w-4 h-4"/> },
    { id: 'accessory', label: 'Accessory', icon: <SparklesIcon className="w-4 h-4"/> },
    { id: 'bag', label: 'Bag / Carry', icon: <ShoppingBagIcon className="w-4 h-4"/> },
    { id: 'watch', label: 'Watch / Jewelry', icon: <SparklesIcon className="w-4 h-4"/> },
    { id: 'belt', label: 'Belt / Harness', icon: <MagicWandIcon className="w-4 h-4"/> },
    { id: 'prop', label: 'Prop / Item', icon: <MapPinIcon className="w-4 h-4"/> }
];

const RATIO_OPTIONS = [
    { id: AspectRatio.SQUARE, label: '1:1', desc: 'Social Post' },
    { id: AspectRatio.PORTRAIT, label: '9:16', desc: 'Reels / Shorts' },
    { id: AspectRatio.LANDSCAPE, label: '16:9', desc: 'Cinematic / Web' }
];

const OutfitCreator: React.FC<OutfitCreatorProps> = ({ selectedCharacters, onClose, onSuccess }) => {
    const [workflowStage, setWorkflowStage] = useState<'isolation' | 'usage'>('isolation');
    const [prompt, setPrompt] = useState('');
    const [location, setLocation] = useState('');
    const [selectedType, setSelectedType] = useState('outfit');
    const [selectedRatio, setSelectedRatio] = useState<AspectRatio>(AspectRatio.SQUARE);
    const [isGenerating, setIsGenerating] = useState(false);
    const [statusText, setStatusText] = useState('');
    const [selectedInventoryItem, setSelectedInventoryItem] = useState<CharacterItem | null>(null);

    // Progression State for Bulk Loop
    const [results, setResults] = useState<{url: string, name: string, type: string}[]>([]);
    const [bulkProgress, setBulkProgress] = useState<{current: number, total: number} | null>(null);

    // AI Advisor HUD
    const [showAdvisor, setShowAdvisor] = useState(false);
    const [advisorTopic, setAdvisorTopic] = useState('');
    const [isBrainstorming, setIsBrainstorming] = useState(false);
    const [suggestions, setSuggestions] = useState<any[]>([]);

    const urlToBase64 = async (url: string): Promise<string> => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            return new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
                reader.readAsDataURL(blob);
            });
        } catch (e) { 
            console.error("Base64 error for URL:", url, e);
            return ""; 
        }
    };

    const handleSummonAdvisor = async () => {
        if (!advisorTopic.trim()) return;
        setIsBrainstorming(true);
        try {
            const range = await brainstormItemRange(advisorTopic);
            setSuggestions(range);
        } catch(e) { console.error(e); } finally { setIsBrainstorming(false); }
    };

    // --- THE PRODUCTION LOOP ---
    const handleBulkCreationLoop = async () => {
        if (suggestions.length === 0) return;
        setIsGenerating(true);
        setResults([]);
        setBulkProgress({ current: 0, total: suggestions.length });

        try {
            for (let i = 0; i < suggestions.length; i++) {
                const item = suggestions[i];
                setBulkProgress({ current: i + 1, total: suggestions.length });
                setStatusText(`Rendering Item ${i+1}: ${item.name}...`);

                const finalPrompt = `PRODUCT ISOLATION MASTER: ${item.name}. STYLING INJECTION: ${item.styling_injection}. ${item.isolation_prompt}. Clean minimalist studio background. 8k commercial detail.`;
                
                const res = await generateImage(finalPrompt, AspectRatio.SQUARE);
                const blob = await (await fetch(`data:image/png;base64,${res.base64}`)).blob();
                const url = await uploadBlob(blob, `owned_${item.type}_${Date.now()}.png`, 'godrej/inventory');

                if (url) {
                    for (const char of selectedCharacters) {
                        const pk = char.character_id || char.id;
                        if (pk) {
                            const { data: fresh } = await supabase.from('dng1_characters').select('character_items').eq('character_id', pk).single();
                            const current = Array.isArray(fresh?.character_items) ? fresh.character_items : [];
                            const newItem: CharacterItem = {
                                id: crypto.randomUUID(),
                                type: item.type,
                                name: item.name,
                                image_url: url,
                                description: item.isolation_prompt,
                                created_at: new Date().toISOString(),
                                scened_visuals: []
                            };
                            await updateCharacter(pk, { character_items: [newItem, ...current] });
                        }
                    }
                    setResults(prev => [...prev, { url, name: item.name, type: item.type }]);
                }
            }
            onSuccess();
        } catch (e) {
            console.error("Bulk loop error", e);
        } finally {
            setIsGenerating(false);
            setBulkProgress(null);
            setStatusText('');
        }
    };

    const handleGenerateSingle = async () => {
        if (!prompt.trim()) {
            alert("Please enter a prompt.");
            return;
        }
        setIsGenerating(true);
        setResults([]);
        setStatusText('Starting generation pipeline...');

        try {
            if (workflowStage === 'isolation') {
                setStatusText('Rendering isolated asset...');
                const res = await generateImage(`PRODUCT ISOLATION. ${prompt}. High-end commercial render. White background.`, selectedRatio);
                const blob = await (await fetch(`data:image/png;base64,${res.base64}`)).blob();
                const url = await uploadBlob(blob, `item_${Date.now()}.png`, 'godrej/inventory');
                
                if (!url) throw new Error("Upload failed. Could not save image.");

                for (const char of selectedCharacters) {
                    const pk = char.character_id || char.id;
                    if (pk) {
                        // Safe fetch
                        const { data: fresh } = await supabase.from('dng1_characters').select('character_items').eq('character_id', pk).single();
                        
                        const current = Array.isArray(fresh?.character_items) ? fresh.character_items : [];
                        const newItem: CharacterItem = { 
                            id: crypto.randomUUID(), 
                            type: selectedType as any, 
                            name: prompt.substring(0,20), 
                            image_url: url, 
                            description: prompt, 
                            created_at: new Date().toISOString(),
                            scened_visuals: []
                        };
                        const { error } = await updateCharacter(pk, { character_items: [newItem, ...current] });
                        if (error) console.error("Failed to update character items", error);
                    }
                }
                setResults([{ url, name: prompt.substring(0,20), type: selectedType }]);
                setStatusText('Asset created and synced!');
            } else {
                // PHASE 2: USAGE / LIFESTYLE
                for (const char of selectedCharacters) {
                    setStatusText(`Architecting scene for ${char.name}...`);
                    
                    const charImageUrl = char.image_url || char.image_urls_jsonb?.[0]?.url;
                    if (!charImageUrl) {
                        console.warn(`Character ${char.name} has no reference image.`);
                        continue;
                    }

                    const charB64 = await urlToBase64(charImageUrl);
                    const itemB64 = selectedInventoryItem ? await urlToBase64(selectedInventoryItem.image_url) : undefined;
                    
                    const res = await generateImage(
                        `LIFESTYLE SCENE: ${prompt}. Location: ${location || 'Studio'}. Cinematic lighting. Professional fashion photography.`, 
                        selectedRatio, 
                        { character: charB64, product: itemB64 }
                    );

                    const blob = await (await fetch(`data:image/png;base64,${res.base64}`)).blob();
                    const url = await uploadBlob(blob, `usage_${Date.now()}.png`, 'godrej/usage');
                    
                    if (url) {
                        const pk = char.character_id || char.id;
                        if (pk) {
                            // PERSIST TO GALLERY: Phase 2 results should go into character gallery
                            const { data: freshChar } = await supabase.from('dng1_characters').select('image_urls_jsonb').eq('character_id', pk).single();
                            const currentGallery = freshChar?.image_urls_jsonb || [];
                            const newGalleryItem = { 
                                url, 
                                type: 'architect_engine_usage', 
                                description: `${prompt} at ${location || 'Studio'}` 
                            };
                            await updateCharacter(pk, { image_urls_jsonb: [newGalleryItem, ...currentGallery] });
                        }
                        setResults(prev => [...prev, { url, name: char.name, type: 'Lifestyle' }]);
                    }
                }
                setStatusText('Scene production complete!');
            }
            onSuccess();
        } catch (e: any) { 
            console.error("Generation error:", e);
            alert(`Production error: ${e.message || "Unknown error occurred"}`);
        } finally { 
            setIsGenerating(false); 
            setTimeout(() => setStatusText(''), 3000);
        }
    };

    return (
        <div className="fixed inset-0 z-[150] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className={`bg-white w-full ${showAdvisor ? 'max-w-7xl' : 'max-w-5xl'} rounded-[3rem] shadow-2xl flex max-h-[90vh] overflow-hidden border border-gray-200 transition-all duration-500`}>
                
                {/* Main Control Panel */}
                <div className="flex-1 flex flex-col min-w-0">
                    <header className="p-8 border-b border-gray-100 flex justify-between items-center bg-white shrink-0">
                        <div className="flex items-center gap-4">
                            <div className="bg-gradient-to-tr from-indigo-500 to-purple-600 p-3 rounded-2xl text-white shadow-lg"><MagicWandIcon className="w-6 h-6"/></div>
                            <div>
                                <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter">Architect Engine</h2>
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-[0.3em]">{workflowStage === 'isolation' ? 'Phase 1: Define Inventory' : 'Phase 2: Create Scene'}</p>
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={() => setShowAdvisor(!showAdvisor)} className={`px-5 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all border ${showAdvisor ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-indigo-600 border-indigo-100'}`}><SparklesIcon className="w-4 h-4"/> Collection Advisor</button>
                            <button onClick={onClose} className="p-3 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-6 h-6"/></button>
                        </div>
                    </header>

                    <div className="flex-1 overflow-y-auto p-8 bg-gray-50 space-y-8 no-scrollbar">
                        {/* Toggle Stage */}
                        <div className="flex bg-white p-2 rounded-[2rem] border border-gray-100 shadow-sm max-w-2xl mx-auto shrink-0">
                            <button onClick={() => { setWorkflowStage('isolation'); setSelectedInventoryItem(null); setPrompt(''); }} className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-[1.5rem] text-xs font-black uppercase tracking-widest transition-all ${workflowStage === 'isolation' ? 'bg-black text-white shadow-xl' : 'text-gray-400 hover:text-gray-600'}`}><CubeIcon className="w-4 h-4"/> 1. Define Items I Own</button>
                            <button onClick={() => setWorkflowStage('usage')} className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-[1.5rem] text-xs font-black uppercase tracking-widest transition-all ${workflowStage === 'usage' ? 'bg-black text-white shadow-xl' : 'text-gray-400 hover:text-gray-600'}`}><UserIcon className="w-4 h-4"/> 2. Show Me With My Stuff</button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-[1.5fr_1fr] gap-10 items-start max-w-6xl mx-auto">
                            {/* Input Console */}
                            <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-sm space-y-8">
                                <div className="space-y-4">
                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Select Category</label>
                                    <div className="grid grid-cols-3 gap-2">
                                        {ITEM_TYPES.map(t => (
                                            <button key={t.id} onClick={() => setSelectedType(t.id)} className={`flex items-center justify-center gap-2 p-3 rounded-xl text-[10px] font-bold uppercase transition-all border ${selectedType === t.id ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-gray-50 text-gray-500 border-transparent hover:bg-gray-100'}`}>{t.icon} {t.label}</button>
                                        ))}
                                    </div>
                                </div>

                                {workflowStage === 'usage' && (
                                    <div className="space-y-4">
                                        <label className="text-[10px] font-black text-[#9063CD] uppercase tracking-widest">Pick From Owned Inventory</label>
                                        <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar">
                                            {selectedCharacters[0]?.character_items?.map((item: any) => (
                                                <button 
                                                    key={item.id} 
                                                    onClick={() => setSelectedInventoryItem(item)} 
                                                    className={`relative w-20 h-20 rounded-2xl overflow-hidden shrink-0 border-2 transition-all ${selectedInventoryItem?.id === item.id ? 'border-[#9063CD] ring-4 ring-purple-100' : 'border-gray-100 opacity-60 hover:opacity-100'}`}
                                                >
                                                    <img src={item.image_url} className="w-full h-full object-cover" />
                                                </button>
                                            ))}
                                            <button onClick={() => setWorkflowStage('isolation')} className="w-20 h-20 rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-300 shrink-0 hover:bg-gray-100"><PlusIcon className="w-6 h-6"/><span className="text-[8px] font-bold mt-1 uppercase">New Asset</span></button>
                                        </div>
                                    </div>
                                )}

                                <div className="space-y-4">
                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{workflowStage === 'isolation' ? 'Product Specification' : 'Interaction Specification'}</label>
                                    <textarea className="w-full bg-gray-50 border border-gray-100 rounded-[2rem] p-6 text-sm font-medium focus:ring-4 focus:ring-indigo-100 outline-none h-40 resize-none shadow-inner" placeholder={workflowStage === 'isolation' ? "Describe the item detail..." : "Describe the interaction with the item..."} value={prompt} onChange={(e) => setPrompt(e.target.value)} />
                                </div>

                                <div className="flex gap-4">
                                    <div className="flex-1 relative">
                                        <MapPinIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
                                        <input className="w-full bg-gray-50 border border-gray-100 rounded-xl py-4 pl-12 text-xs font-bold outline-none" value={workflowStage === 'isolation' ? 'Studio Isolation (Auto)' : location} onChange={(e) => setLocation(e.target.value)} disabled={workflowStage === 'isolation'} placeholder="Set location (e.g. Cape Town)" />
                                    </div>
                                    <div className="flex bg-gray-100 p-1 rounded-xl">
                                        {RATIO_OPTIONS.map(opt => <button key={opt.id} onClick={() => setSelectedRatio(opt.id)} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase transition-all ${selectedRatio === opt.id ? 'bg-white shadow text-black' : 'text-gray-400 hover:text-gray-600'}`}>{opt.label}</button>)}
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <button onClick={handleGenerateSingle} disabled={isGenerating || !prompt.trim()} className="w-full py-6 bg-black text-white rounded-[2rem] font-black uppercase tracking-[0.3em] text-[10px] shadow-2xl hover:scale-105 transition-all flex items-center justify-center gap-3">
                                        {isGenerating ? <div className="w-5 h-5 border-4 border-white/30 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-5 h-5 text-yellow-400"/>}
                                        {isGenerating ? 'Rendering Shot...' : 'Render Production Master'}
                                    </button>
                                    {statusText && (
                                        <p className="text-[9px] font-bold text-indigo-500 text-center uppercase tracking-widest animate-pulse">{statusText}</p>
                                    )}
                                </div>
                            </div>

                            {/* Session Stream */}
                            <div className="space-y-6">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Session Production Feed</label>
                                <div className="grid grid-cols-1 gap-6">
                                    {results.length > 0 ? results.map((res, i) => (
                                        <div key={i} className="group relative aspect-[3/4] rounded-[3.5rem] overflow-hidden shadow-2xl border-8 border-white animate-fade-in-up bg-gray-100">
                                            <img src={res.url} className="w-full h-full object-cover" />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8">
                                                <span className="text-indigo-400 text-[9px] font-black uppercase tracking-[0.4em] mb-2">{res.type} Master</span>
                                                <p className="text-white text-xl font-black uppercase tracking-tighter leading-none">{res.name}</p>
                                                <div className="mt-4 flex items-center gap-2 text-green-400 text-[10px] font-black uppercase tracking-widest"><CheckCircleIcon className="w-4 h-4"/> Synced to Gallery</div>
                                            </div>
                                        </div>
                                    )) : (
                                        <div className="aspect-[3/4] bg-white rounded-[3.5rem] border-8 border-dashed border-gray-100 flex flex-col items-center justify-center text-gray-200 gap-4">
                                            <PhotoIcon className="w-20 h-20 opacity-10"/>
                                            <p className="text-xs font-black uppercase tracking-[0.2em]">Ready for Render</p>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* ADVISOR HUD (Right Rail) */}
                {showAdvisor && (
                    <div className="w-[450px] bg-gray-900 border-l border-gray-800 flex flex-col animate-slide-in-right z-20 overflow-hidden">
                        <header className="p-8 border-b border-gray-800 bg-black/50 shrink-0 flex justify-between items-center">
                            <div>
                                <h3 className="text-white font-black text-xl uppercase tracking-tight">Range Architect</h3>
                                <p className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.4em]">Sequential Loop Active</p>
                            </div>
                            <button onClick={() => setShowAdvisor(false)} className="text-gray-500 hover:text-white transition-colors"><XMarkIcon className="w-6 h-6"/></button>
                        </header>

                        <div className="flex-1 overflow-y-auto p-8 space-y-8 no-scrollbar">
                            <div className="space-y-4">
                                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Thematic Concept</label>
                                <div className="relative">
                                    <input 
                                        className="w-full bg-black/40 border border-gray-800 rounded-2xl py-4 px-6 text-sm text-white font-medium outline-none focus:border-[#9063CD] transition-all"
                                        placeholder="e.g. Minimalist Travel Collection..."
                                        value={advisorTopic}
                                        onChange={(e) => setAdvisorTopic(e.target.value)}
                                        onKeyDown={(e) => e.key === 'Enter' && handleSummonAdvisor()}
                                    />
                                    <button onClick={handleSummonAdvisor} className="absolute right-3 top-2.5 p-2 text-indigo-400 hover:bg-indigo-50/20 rounded-xl transition-all"><ArrowRightIcon className="w-5 h-5"/></button>
                                </div>
                            </div>

                            {isBrainstorming ? (
                                <div className="py-20 flex flex-col items-center gap-6 text-center">
                                    <div className="w-16 h-16 border-4 border-indigo-600/30 border-t-indigo-500 rounded-full animate-spin"></div>
                                    <p className="text-xs text-gray-400 font-bold uppercase tracking-[0.3em] animate-pulse">Designing Blueprint Collection...</p>
                                </div>
                            ) : suggestions.length > 0 ? (
                                <div className="space-y-6">
                                    <div className="flex justify-between items-end px-2">
                                        <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Production Queue</h4>
                                        <button 
                                            onClick={handleBulkCreationLoop} 
                                            disabled={isGenerating || workflowStage !== 'isolation'} 
                                            className="text-[10px] font-black text-green-400 hover:text-green-300 flex items-center gap-2 uppercase tracking-widest disabled:opacity-30 transition-all hover:scale-105"
                                        >
                                            <Square2StackIcon className="w-4 h-4"/> Execute Bulk Render
                                        </button>
                                    </div>
                                    <div className="space-y-4">
                                        {suggestions.map((s, idx) => (
                                            <div key={idx} className="bg-black/40 border border-gray-800 p-6 rounded-3xl group transition-all hover:border-indigo-500 shadow-lg">
                                                <div className="flex justify-between items-center mb-4">
                                                    <span className="text-[9px] font-black text-indigo-400 uppercase tracking-[0.3em]">{s.type}</span>
                                                    <div className="flex items-center gap-2 text-[9px] text-yellow-400 font-bold bg-yellow-400/10 px-3 py-1 rounded-full border border-yellow-400/20"><BoltIcon className="w-3 h-3"/> AI Styling: {s.styling_injection}</div>
                                                </div>
                                                <h4 className="text-lg font-black text-white mb-4 leading-tight uppercase tracking-tight">{s.name}</h4>
                                                <p className="text-[11px] text-gray-400 line-clamp-2 italic leading-relaxed mb-4">"{s.isolation_prompt}"</p>
                                                <div className="flex gap-2">
                                                    <button onClick={() => { setWorkflowStage('isolation'); setPrompt(s.isolation_prompt); setSelectedType(s.type); }} className="flex-1 py-2 rounded-lg bg-white/5 border border-white/10 text-[9px] font-black uppercase text-gray-400 hover:bg-white/10 transition-all">Select for Single</button>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ) : (
                                <div className="py-24 text-center opacity-40 grayscale">
                                    <LayoutGridIcon className="w-20 h-20 mx-auto text-gray-700 mb-6"/>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase tracking-[0.4em] max-w-[200px] mx-auto leading-relaxed">Enter a theme to generate a multi-item collection blueprint.</p>
                                </div>
                            )}
                        </div>

                        {bulkProgress && (
                            <div className="p-8 bg-black/80 backdrop-blur-xl border-t border-gray-800 animate-fade-in-up">
                                <div className="flex justify-between items-center mb-3">
                                    <span className="text-[10px] font-black text-green-400 uppercase tracking-widest flex items-center gap-2"><div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div> Render Loop In Progress</span>
                                    <span className="text-xs font-bold text-white">Item {bulkProgress.current} / {bulkProgress.total}</span>
                                </div>
                                <div className="h-2 w-full bg-gray-800 rounded-full overflow-hidden">
                                    <div className="h-full bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.5)] transition-all duration-700" style={{ width: `${(bulkProgress.current/bulkProgress.total)*100}%` }}></div>
                                </div>
                                <p className="text-[9px] text-gray-500 mt-3 font-bold uppercase tracking-widest text-center">Applying AI styling to current iteration...</p>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

export default OutfitCreator;
