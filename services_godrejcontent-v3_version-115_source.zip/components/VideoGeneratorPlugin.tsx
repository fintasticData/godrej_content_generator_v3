
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { uploadBlob } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    FilmIcon, 
    SparklesIcon, 
    ArrowRightIcon, 
    BoltIcon,
    CheckCircleIcon,
    AlertTriangleIcon
} from './icons';

interface VideoGeneratorPluginProps {
    isOpen: boolean;
    onClose: () => void;
    characterName: string;
    sourceImageUrl: string;
    onSuccess: (videoUrl: string) => void;
}

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result === 'string') resolve(reader.result.split(',')[1]);
            else reject(new Error("Failed to convert blob to base64"));
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
};

const VideoGeneratorPlugin: React.FC<VideoGeneratorPluginProps> = ({ 
    isOpen, 
    onClose, 
    characterName, 
    sourceImageUrl, 
    onSuccess 
}) => {
    const [prompt, setPrompt] = useState(`Cinematic slow motion shot of ${characterName}, photorealistic, 4k, high detail.`);
    const [isGenerating, setIsGenerating] = useState(false);
    const [progress, setProgress] = useState('');
    const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    // Reset state when opened with new image
    useEffect(() => {
        if (isOpen) {
            setGeneratedVideoUrl(null);
            setError(null);
            setProgress('');
            setIsGenerating(false);
            setPrompt(`Cinematic slow motion shot of ${characterName}, photorealistic, 4k, high detail.`);
        }
    }, [isOpen, characterName, sourceImageUrl]);

    const handleGenerate = async () => {
        if (!sourceImageUrl) {
            setError("No source image provided.");
            return;
        }
        if (!process.env.API_KEY) {
            setError("API Key missing.");
            return;
        }

        setIsGenerating(true);
        setError(null);
        setProgress('Initializing AI...');

        try {
            // 1. Initialize Client
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

            // 2. Fetch and Prepare Image
            setProgress('Preparing source asset...');
            const imgResp = await fetch(sourceImageUrl);
            if (!imgResp.ok) throw new Error(`Failed to load source image: ${imgResp.statusText}`);
            const imgBlob = await imgResp.blob();
            const base64Image = await blobToBase64(imgBlob);

            // 3. Call Veo API
            setProgress('Sending to Veo 3.1 (Fast)...');
            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: prompt,
                image: {
                    imageBytes: base64Image,
                    mimeType: imgBlob.type // e.g. 'image/png'
                },
                config: {
                    numberOfVideos: 1,
                    resolution: '720p',
                    aspectRatio: '9:16' // Vertical for social/character clips
                }
            });

            // 4. Poll for Completion
            setProgress('Rendering video...');
            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 5000)); // 5s poll
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }

            if (operation.error) {
                throw new Error(`Generation failed: ${operation.error.message}`);
            }

            // 5. Download Result
            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (!downloadLink) throw new Error("No video URI returned from API.");

            setProgress('Downloading media...');
            const videoResp = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
            if (!videoResp.ok) throw new Error("Failed to download generated video file.");
            
            const videoBlob = await videoResp.blob();

            // 6. Upload to Storage
            setProgress('Saving to gallery...');
            const fileName = `veo_clip_${Date.now()}_${Math.random().toString(36).substring(7)}.mp4`;
            const publicUrl = await uploadBlob(videoBlob, fileName, 'godrej/generated_videos');

            if (publicUrl) {
                setGeneratedVideoUrl(publicUrl);
                setProgress('Complete!');
            } else {
                throw new Error("Failed to upload video to cloud storage.");
            }

        } catch (e: any) {
            console.error("Video Plugin Error:", e);
            setError(e.message || "An unknown error occurred.");
        } finally {
            setIsGenerating(false);
        }
    };

    const handleSaveAndClose = () => {
        if (generatedVideoUrl) {
            onSuccess(generatedVideoUrl);
            onClose();
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-fade-in-up">
                
                {/* Header */}
                <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-white">
                    <div className="flex items-center gap-3">
                        <div className="bg-indigo-50 p-2 rounded-xl text-indigo-600"><FilmIcon className="w-5 h-5"/></div>
                        <div>
                            <h3 className="font-black text-gray-900 text-lg uppercase tracking-tight">Motion Generator</h3>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Veo 3.1 Plugin</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-5 h-5"/></button>
                </div>

                {/* Content */}
                <div className="p-8 bg-gray-50 flex gap-8">
                    {/* Left: Source */}
                    <div className="w-1/3 flex flex-col gap-4">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Source Image</label>
                        <div className="aspect-[9/16] rounded-2xl overflow-hidden bg-gray-200 border-2 border-white shadow-md relative">
                            {sourceImageUrl ? (
                                <img src={sourceImageUrl} className="w-full h-full object-cover" alt="Source" />
                            ) : (
                                <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">No Image</div>
                            )}
                        </div>
                    </div>

                    {/* Right: Controls & Output */}
                    <div className="flex-1 flex flex-col gap-6">
                        {!generatedVideoUrl ? (
                            <>
                                <div>
                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Prompt</label>
                                    <textarea 
                                        className="w-full h-32 bg-white border border-gray-200 rounded-xl p-4 text-sm font-medium focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                        placeholder="Describe the motion..."
                                    />
                                </div>

                                {error && (
                                    <div className="bg-red-50 text-red-600 p-3 rounded-lg text-xs font-bold flex items-center gap-2">
                                        <AlertTriangleIcon className="w-4 h-4"/> {error}
                                    </div>
                                )}

                                <div className="mt-auto">
                                    <button 
                                        onClick={handleGenerate} 
                                        disabled={isGenerating || !sourceImageUrl}
                                        className="w-full py-4 bg-indigo-600 text-white rounded-xl font-black uppercase tracking-widest text-xs shadow-lg hover:bg-indigo-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                                    >
                                        {isGenerating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4"/>}
                                        {isGenerating ? progress : 'Generate Video'}
                                    </button>
                                </div>
                            </>
                        ) : (
                            <div className="flex flex-col h-full">
                                <div className="flex-1 bg-black rounded-2xl overflow-hidden relative shadow-lg mb-6 border border-gray-800">
                                    <video src={generatedVideoUrl} controls autoPlay loop className="w-full h-full object-contain" />
                                </div>
                                <div className="flex gap-3">
                                    <button onClick={() => setGeneratedVideoUrl(null)} className="flex-1 py-3 bg-gray-200 text-gray-700 rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-gray-300 transition-all">Discard</button>
                                    <button onClick={handleSaveAndClose} className="flex-[2] py-3 bg-green-600 text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-green-700 shadow-lg transition-all flex items-center justify-center gap-2">
                                        <CheckCircleIcon className="w-4 h-4"/> Save to Gallery
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default VideoGeneratorPlugin;
