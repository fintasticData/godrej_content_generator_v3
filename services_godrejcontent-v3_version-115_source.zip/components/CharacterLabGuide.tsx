
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { uploadBlob } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    SparklesIcon, 
    UserIcon, 
    MapPinIcon, 
    LinkIcon,
    CameraIcon,
    ScissorsIcon,
    MagicWandIcon,
    BoltIcon,
    CalendarDaysIcon,
    BookOpenIcon,
    AcademicCapIcon,
    PhotoIcon,
    UploadCloudIcon
} from './icons';

interface CharacterLabGuideProps {
    onClose: () => void;
}

const ImagePlaceholder: React.FC<{ label: string }> = ({ label }) => {
    const [image, setImage] = useState<string | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const inputRef = useRef<HTMLInputElement>(null);

    // Load persisted snapshot URL from local storage on mount
    useEffect(() => {
        const stored = localStorage.getItem('guide_snapshots');
        if (stored) {
            try {
                const snapshots = JSON.parse(stored);
                if (snapshots[label]) {
                    setImage(snapshots[label]);
                }
            } catch (e) {
                console.error("Failed to load guide snapshots", e);
            }
        }
    }, [label]);

    const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsUploading(true);
        try {
            // Create a consistent filename for the guide section
            const cleanLabel = label.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
            const fileName = `guide_snapshot_${cleanLabel}_${Date.now()}.png`;
            
            // Upload to 'godrej/guide' folder
            const url = await uploadBlob(file, fileName, 'godrej/guide');
            
            if (url) {
                setImage(url);
                // Persist mapping to localStorage so it survives reload
                const stored = localStorage.getItem('guide_snapshots');
                const snapshots = stored ? JSON.parse(stored) : {};
                snapshots[label] = url;
                localStorage.setItem('guide_snapshots', JSON.stringify(snapshots));
            }
        } catch (error) {
            console.error("Snapshot upload failed", error);
            alert("Failed to upload snapshot image.");
        } finally {
            setIsUploading(false);
            if (inputRef.current) inputRef.current.value = '';
        }
    };

    return (
        <div 
            onClick={() => !isUploading && inputRef.current?.click()}
            className={`w-full h-64 bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center text-gray-400 gap-2 mb-6 cursor-pointer hover:bg-gray-100 hover:border-gray-400 transition-all relative overflow-hidden group ${isUploading ? 'opacity-50 pointer-events-none' : ''}`}
        >
            {isUploading ? (
                <div className="flex flex-col items-center gap-2">
                    <div className="w-8 h-8 border-4 border-gray-300 border-t-indigo-600 rounded-full animate-spin"></div>
                    <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Uploading...</span>
                </div>
            ) : image ? (
                <>
                    <img src={image} alt={label} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-sm">
                        <span className="text-white text-xs font-bold uppercase tracking-widest flex items-center gap-2 bg-white/20 px-4 py-2 rounded-full backdrop-blur-md border border-white/30 hover:bg-white/30 transition-colors">
                            <CameraIcon className="w-4 h-4" /> Replace Snapshot
                        </span>
                    </div>
                </>
            ) : (
                <>
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                        <PhotoIcon className="w-8 h-8 opacity-30" />
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest text-center px-4 max-w-sm text-gray-500">{label}</span>
                    <span className="text-[10px] text-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity font-bold flex items-center gap-1">
                        <UploadCloudIcon className="w-3 h-3"/> Click to Upload
                    </span>
                </>
            )}
            <input type="file" ref={inputRef} hidden accept="image/*" onChange={handleUpload} />
        </div>
    );
};

const InfoTip: React.FC<{ title: string, text: string }> = ({ title, text }) => (
    <div className="bg-indigo-50 border-l-4 border-indigo-500 p-4 rounded-r-lg mb-6">
        <h4 className="text-xs font-bold text-indigo-800 uppercase tracking-widest mb-1">{title}</h4>
        <p className="text-sm text-indigo-700 leading-relaxed">{text}</p>
    </div>
);

const CharacterLabGuide: React.FC<CharacterLabGuideProps> = ({ onClose }) => {
    const [activeSection, setActiveSection] = useState('overview');

    const MenuButton: React.FC<{ id: string, label: string, icon: React.ReactNode }> = ({ id, label, icon }) => (
        <button 
            onClick={() => setActiveSection(id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all ${activeSection === id ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
        >
            {icon} {label}
        </button>
    );

    const renderContent = () => {
        switch(activeSection) {
            case 'overview': return (
                <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-4">Character Lab Overview</h2>
                    <p className="text-lg text-gray-600 leading-relaxed">
                        The <strong>Character Lab</strong> is your central hub for managing digital talent. Whether you're working with real influencers, brand ambassadors, or AI-generated personas, this module helps you maintain visual consistency, generate new content, and schedule posts.
                    </p>
                    <ImagePlaceholder label="Character Lab Dashboard Overview" />
                    
                    <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">Key Features</h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-indigo-200 transition-colors">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2"><UserIcon className="w-4 h-4 text-indigo-600"/> Talent Management</h4>
                            <p className="text-xs text-gray-500">Organize profiles, bios, and affiliations.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-indigo-200 transition-colors">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2"><MagicWandIcon className="w-4 h-4 text-indigo-600"/> Visual Studio</h4>
                            <p className="text-xs text-gray-500">Generate new looks, hairstyles, and outfits using AI.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-indigo-200 transition-colors">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2"><CalendarDaysIcon className="w-4 h-4 text-indigo-600"/> Content Engine</h4>
                            <p className="text-xs text-gray-500">Brainstorm ideas and schedule production.</p>
                        </div>
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 hover:border-indigo-200 transition-colors">
                            <h4 className="font-bold text-gray-800 flex items-center gap-2 mb-2"><BoltIcon className="w-4 h-4 text-indigo-600"/> Quick Clips</h4>
                            <p className="text-xs text-gray-500">Draft motion concepts for immediate preview.</p>
                        </div>
                    </div>

                    <div className="mt-8 p-6 bg-yellow-50 rounded-2xl border border-yellow-100 text-yellow-800">
                        <h4 className="font-bold uppercase tracking-widest text-xs mb-2 flex items-center gap-2">
                            <CameraIcon className="w-4 h-4"/> Production Boundary Note
                        </h4>
                        <p className="text-sm">
                            The Character Lab focuses on <strong>Asset Generation (Stills)</strong> and <strong>Draft Motion</strong>. 
                            <br/><br/>
                            For full cinematic video production, scenes must be moved to the <strong>Storyboard Generator</strong> and <strong>Creative Studio</strong>. This ensures high-fidelity rendering and scene-by-scene direction.
                        </p>
                    </div>
                </div>
            );
            case 'creation': return (
                <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-4">Creating Talent</h2>
                    <p className="text-gray-600">There are three ways to bring talent into the system.</p>

                    <div className="space-y-8 mt-6">
                        <div>
                            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2 mb-2"><UserIcon className="w-5 h-5 text-gray-400"/> 1. Manual Entry</h3>
                            <p className="text-sm text-gray-500 mb-2">Best for existing influencers or real people.</p>
                            <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                                <li>Click the <strong>Add</strong> button in the header.</li>
                                <li>Fill in Name, Role, and Affiliation.</li>
                                <li>Upload a primary photo to set the visual baseline.</li>
                            </ul>
                        </div>

                        <div>
                            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2 mb-2"><SparklesIcon className="w-5 h-5 text-indigo-500"/> 2. AI Architect</h3>
                            <p className="text-sm text-gray-500 mb-2">Create bespoke virtual personas from scratch.</p>
                            <ImagePlaceholder label="AI Architect Wizard Interface" />
                            <ol className="list-decimal pl-5 text-sm text-gray-600 space-y-1">
                                <li>Click <strong>AI Architect</strong>.</li>
                                <li>Describe the persona (e.g., "Afro-futurist tech blogger").</li>
                                <li>The AI generates a Bio, Visual Prompt, and Tier logic.</li>
                                <li>Confirm generation to create the visual asset via Imagen.</li>
                            </ol>
                        </div>

                        <div>
                            <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2 mb-2"><LinkIcon className="w-5 h-5 text-green-500"/> 3. Batch Creation</h3>
                            <p className="text-sm text-gray-500 mb-2">Rapidly generate diverse crowds or extras.</p>
                            <ul className="list-disc pl-5 text-sm text-gray-600 space-y-1">
                                <li>Click <strong>Batch</strong>.</li>
                                <li>Define a base prompt and brand context.</li>
                                <li>The system will generate multiple unique characters in sequence.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            );
            case 'identity': return (
                <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-4">Identity Management</h2>
                    <p className="text-gray-600">Consistency is key for AI characters. The Character Lab uses an <strong>Identity Anchor</strong> system.</p>

                    <InfoTip 
                        title="The Identity Anchor" 
                        text="Every character has one 'Primary Image' locked as the visual source of truth. All future generations (new outfits, hairstyles) use this anchor to ensure the face and body type remain consistent."
                    />

                    <ImagePlaceholder label="Visual Tab with Locked Anchor Example" />

                    <h3 className="text-xl font-bold text-gray-900 mt-8 mb-4">Managing the Bio</h3>
                    <p className="text-sm text-gray-600 mb-4">
                        In the <strong>Bio Tab</strong>, you can define the character's backstory. Use the <strong>Generate Bio</strong> button to let Gemini write a compelling origin story based on their Name and Role.
                    </p>
                </div>
            );
            case 'visual': return (
                <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-4">Visual Studio</h2>
                    <p className="text-gray-600">The <strong>Visual</strong> tab is where you expand a character's portfolio.</p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
                        <div>
                            <h3 className="font-bold text-gray-900 mb-2">Wardrobe Engine</h3>
                            <p className="text-xs text-gray-500 mb-3">Place your character in new scenarios.</p>
                            <ul className="list-disc pl-4 text-xs text-gray-600 space-y-2">
                                <li>Type a prompt (e.g., "Wearing a red gala dress in Paris").</li>
                                <li>The engine combines the Prompt with the Identity Anchor.</li>
                                <li>Result: Your exact character in the new context.</li>
                            </ul>
                        </div>
                        <div>
                            <h3 className="font-bold text-gray-900 mb-2">Hairstyle Mapper</h3>
                            <p className="text-xs text-gray-500 mb-3">Transfer precise hairstyles from reference photos.</p>
                            <ul className="list-disc pl-4 text-xs text-gray-600 space-y-2">
                                <li>Upload a photo of a specific hairstyle.</li>
                                <li>The AI extracts the hair and applies it to your character.</li>
                                <li>Perfect for product demos (e.g., Darling Hair).</li>
                            </ul>
                        </div>
                    </div>

                    <div className="mt-8">
                        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center gap-2"><ScissorsIcon className="w-5 h-5 text-pink-500"/> Darling Stylist</h3>
                        <p className="text-sm text-gray-600 mb-4">
                            An specialized chatbot trained on Darling Hair products. Chat with it to find the perfect look ("I need a wedding style"), and it will generate the visual representation instantly.
                        </p>
                        <ImagePlaceholder label="Darling Stylist Interface" />
                    </div>
                </div>
            );
            case 'content': return (
                <div className="space-y-6 animate-fade-in-up">
                    <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter mb-4">Content & Scheduling</h2>
                    <p className="text-gray-600">Plan and execute social media campaigns directly from the character profile.</p>

                    <div className="space-y-8 mt-6">
                        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                            <h3 className="text-lg font-bold text-gray-900 mb-2">1. Brainstorming</h3>
                            <p className="text-sm text-gray-600">
                                Use the <strong>AI Brainstorm</strong> button in the Content Engine tab. Enter a campaign theme (e.g., "Summer Confidence"), and the AI will generate 5-10 post ideas tailored to the character's persona.
                            </p>
                        </div>

                        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                            <h3 className="text-lg font-bold text-gray-900 mb-2">2. Generation</h3>
                            <p className="text-sm text-gray-600">
                                Click <strong>Run Engine</strong> on any draft idea. The system generates a visual asset (Image/Post) based on the brief.
                            </p>
                        </div>

                        <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                            <h3 className="text-lg font-bold text-gray-900 mb-2">3. Scheduling</h3>
                            <p className="text-sm text-gray-600">
                                Once an item is "Ready", click <strong>Schedule</strong>.
                                <br/>
                                You can also bulk-select images from the <strong>Visual Gallery</strong> and schedule them all at once using the floating action bar.
                            </p>
                            <ImagePlaceholder label="Scheduling and Action Bar" />
                        </div>
                    </div>
                </div>
            );
            default: return null;
        }
    };

    return (
        <div className="fixed inset-0 z-[150] bg-gray-900/60 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-5xl h-[85vh] rounded-3xl shadow-2xl flex overflow-hidden relative border border-gray-200">
                
                {/* Left Navigation */}
                <div className="w-64 bg-gray-50 border-r border-gray-200 p-6 flex flex-col shrink-0">
                    <div className="mb-8">
                        <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">User Guide</h3>
                        <h1 className="text-xl font-black text-gray-900">Character Lab</h1>
                    </div>
                    <div className="space-y-2">
                        <MenuButton id="overview" label="Overview" icon={<AcademicCapIcon className="w-4 h-4"/>} />
                        <MenuButton id="creation" label="Creating Talent" icon={<UserIcon className="w-4 h-4"/>} />
                        <MenuButton id="identity" label="Identity Logic" icon={<LinkIcon className="w-4 h-4"/>} />
                        <MenuButton id="visual" label="Visual Studio" icon={<MagicWandIcon className="w-4 h-4"/>} />
                        <MenuButton id="content" label="Content Engine" icon={<CalendarDaysIcon className="w-4 h-4"/>} />
                    </div>
                    <div className="mt-auto pt-6 border-t border-gray-200">
                        <p className="text-[10px] text-gray-400">v3.1 Documentation</p>
                    </div>
                </div>

                {/* Main Content */}
                <div className="flex-1 overflow-y-auto p-10 bg-white relative">
                    <button 
                        onClick={onClose}
                        className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full text-gray-500 transition-colors"
                    >
                        <XMarkIcon className="w-6 h-6"/>
                    </button>
                    {renderContent()}
                </div>

            </div>
        </div>
    );
};

export default CharacterLabGuide;
