
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import { GoogleGenAI } from '@google/genai';
import React, { useState } from 'react';
import { SparklesIcon } from './icons';

interface AdConceptGeneratorProps {
  onPromptGenerated: (prompt: string) => void;
}

const AdConceptGenerator: React.FC<AdConceptGeneratorProps> = ({ onPromptGenerated }) => {
  const [productUrl, setProductUrl] = useState('');
  const [productInfo, setProductInfo] = useState('');
  const [adStyle, setAdStyle] = useState('modern');
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedPrompt, setGeneratedPrompt] = useState('');

  const handleGenerate = async () => {
    if (!productInfo.trim() && !productUrl.trim()) {
      setError('Please provide product information or a URL.');
      return;
    }
    setIsGenerating(true);
    setError(null);
    setGeneratedPrompt('');

    try {
      // Create a new GoogleGenAI instance for text generation
      // fix: Use process.env.API_KEY exclusively as per guidelines.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const metaPrompt = `
        You are an expert advertising agent specializing in creating compelling video ad concepts for a text-to-video AI model.
        Your task is to generate a concise and visually descriptive prompt for the AI.

        **Ad Style:** ${adStyle}
        **Product Information:** ${productInfo}
        **Product URL (for context):** ${productUrl || 'Not provided'}

        Instructions:
        1. If a URL is provided, act as if you have analyzed its content to understand the product, its target audience, and brand voice.
        2. Synthesize all the provided information.
        3. Create a single, detailed paragraph that describes the visual scenes of a short video ad (5-10 seconds).
        4. The prompt must be evocative, focusing on actions, characters, setting, and mood. Do not use camera directions like "pan left" or "close-up". Describe what is seen.
        5. The output should ONLY be the prompt itself, without any introductory text, labels, or explanations.
      `;

      // fix: Use gemini-3-pro-preview for complex text generation as per guidelines.
      const response = await ai.models.generateContent({ model: 'gemini-3-pro-preview', contents: metaPrompt });
      
      const promptText = response.text;
      setGeneratedPrompt(promptText);
    } catch (e) {
      console.error('Error generating ad prompt:', e);
      setError(e instanceof Error ? e.message : 'An unknown error occurred.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleUsePrompt = () => {
    onPromptGenerated(generatedPrompt);
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-8 bg-white rounded-xl border border-gray-200 shadow-xl flex flex-col gap-6 mt-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">AI Ad Concept Generator</h2>
        <p className="text-gray-500">
          Let AI agents brainstorm the perfect video ad concept for your product.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label htmlFor="product-info" className="block text-sm font-medium text-gray-700 mb-2">
            Product / Service Information
          </label>
          <textarea
            id="product-info"
            value={productInfo}
            onChange={(e) => setProductInfo(e.target.value)}
            placeholder="e.g., A new line of eco-friendly, reusable coffee cups made from bamboo fiber. Target audience is environmentally conscious millennials."
            className="w-full h-32 bg-gray-50 border border-gray-300 rounded-lg p-3 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-colors"
          />
        </div>
        <div>
          <label htmlFor="product-url" className="block text-sm font-medium text-gray-700 mb-2">
            Product URL (Optional)
          </label>
          <input
            id="product-url"
            type="url"
            value={productUrl}
            onChange={(e) => setProductUrl(e.target.value)}
            placeholder="https://example.com/product"
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 text-gray-900 placeholder-gray-400 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-colors"
          />
          <label htmlFor="ad-style" className="block text-sm font-medium text-gray-700 mt-4 mb-2">
            Desired Ad Style
          </label>
          <select
            id="ad-style"
            value={adStyle}
            onChange={(e) => setAdStyle(e.target.value)}
            className="w-full bg-gray-50 border border-gray-300 rounded-lg p-3 appearance-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white text-gray-900"
          >
            <option value="modern">Modern & Sleek</option>
            <option value="cinematic">Cinematic & Dramatic</option>
            <option value="energetic">Energetic & Fast-Paced</option>
            <option value="quirky">Quirky & Humorous</option>
            <option value="nostalgic">Nostalgic & Vintage</option>
            <option value="luxurious">Luxurious & Elegant</option>
          </select>
        </div>
      </div>

      <button
        onClick={handleGenerate}
        disabled={isGenerating}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition-colors text-lg disabled:bg-gray-300 disabled:cursor-not-allowed shadow-md"
      >
        {isGenerating ? (
          <>
            <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin"></div>
            <span>Generating Concept...</span>
          </>
        ) : (
          <>
            <SparklesIcon className="w-5 h-5" />
            Generate Ad Concept
          </>
        )}
      </button>

      {error && <p className="text-red-600 text-center">{error}</p>}

      {generatedPrompt && (
        <div className="mt-4 p-4 bg-gray-50 border border-gray-200 rounded-lg shadow-inner">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Generated Video Prompt:</h3>
          <p className="text-gray-700 whitespace-pre-wrap font-mono text-sm leading-relaxed">{generatedPrompt}</p>
          <button
            onClick={handleUsePrompt}
            className="mt-4 px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-lg transition-colors shadow-sm"
          >
            Use this Prompt
          </button>
        </div>
      )}
    </div>
  );
};

export default AdConceptGenerator;
