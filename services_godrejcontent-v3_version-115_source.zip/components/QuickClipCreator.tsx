/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { generateImage, generateVideo, generateQuickClipIdea, editImage, enhanceSceneDescription, analyzeAssetAttributes } from '../services/geminiService';
import { uploadBlob, supabase, updateCharacter, fetchCharacters } from '../services/supabaseClient';
import { Asset, AspectRatio, VeoModel, Resolution, GenerationMode, Influencer } from '../types';
import { 
    XMarkIcon, 
    BoltIcon, 
    UserIcon, 
    MapPinIcon, 
    CubeIcon, 
    MagicWandIcon, 
    FilmIcon,
    CheckCircleIcon,
    SparklesIcon,
    PlusIcon,
    UploadCloudIcon,
    FramesModeIcon,
    TextModeIcon,
    ReferencesModeIcon,
    PhotoIcon,
    GlobeAltIcon,
    PencilSquareIcon,
    TrashIcon,
    ArrowPathIcon,
    MicrophoneIcon
} from './icons';
import AssetStudio from './AssetStudio';
import Modal from './Modal';

interface QuickClipCreatorProps {
    onClose: () => void;
    onSuccess: () => void;
    initialCharacter?: { url: string, id: string, name: string };
    initialPrompt?: string;
    initialStartFrame?: string;
    initialEndFrame?: string;
}

const urlToBase64 = async (url: string): Promise<string> => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const base64 = (reader.result as string).split(',')[1];
                resolve(base64);
            };
            reader.readAsDataURL(blob);
        });
    } catch(e) {
        console.warn("Base64 conv failed", e);
        return "";
    }
};

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            if (typeof reader.result === 'string') resolve(reader.result.split(',')[1]);
            else reject(new Error("Failed base64"));
        };
        reader.readAsDataURL(blob);
    });
};

const VIBE_PRESETS = [
    "Cinematic Slow Mo", "Neon Cyberpunk", "VHS Glitch", "Drone Flyover", "Warm Golden Hour", "Fast Paced Action", "Fashion Runway", "Macro Detail"
];

const QuickClipCreator: React.FC<QuickClipCreatorProps> = ({ onClose, onSuccess, initialCharacter, initialPrompt, initialStartFrame, initialEndFrame }) => {
    // Assets
    const [character, setCharacter] = useState<{url: string, id: string, name: string} | null>(null);
    const [location, setLocation] = useState<{url: string, id: string, name: string} | null>(null);
    const [product, setProduct] = useState<{url: string, id: string, name: string} | null>(null);
    
    // Config
    const [projectTitle, setProjectTitle] = useState('New Quick Clip');
    const [prompt, setPrompt] = useState('');
    const [audioPrompt, setAudioPrompt] = useState('Upbeat Mzansi House beat, local accent voiceover');
    const [startFrameUrl, setStartFrameUrl] = useState<string | null>(null);
    const [endFrameUrl, setEndFrameUrl] = useState<string | null>(null);
    const [videoUrl, setVideoUrl] = useState<string | null>(null);
    const [mode, setMode] = useState<GenerationMode>(GenerationMode.FRAMES_TO_VIDEO);
    const [aspectRatio, setAspectRatio] = useState<AspectRatio>(AspectRatio.PORTRAIT);
    const [useBrandDNA, setUseBrandDNA] = useState(true);
    
    // UI State
    const [isLoading, setIsLoading] = useState(false);
    const [isIdeating, setIsIdeating] = useState(false);
    const [isEnhancing, setIsEnhancing] = useState(false);
    const [status, setStatus] = useState('');
    const [showAssetPicker, setShowAssetPicker] = useState(false);
    const [pickerType, setPickerType] = useState<'character'|'setting'|'product'|null>(null);
    const [trendSources, setTrendSources] = useState<string[]>([]);
    const [showCharacterGallery, setShowCharacterGallery] = useState(false);
    
    // Visual History for Character
    const [characterGallery, setCharacterGallery] = useState<string[]>([]);
    
    // Editing State
    const [showEditModal, setShowEditModal] = useState(false);
    const [editPrompt, setEditPrompt] = useState('');
    const [isEditing, setIsEditing] = useState(false);
    
    const startFileInputRef = useRef<HTMLInputElement>(null);
    const endFileInputRef = useRef<HTMLInputElement>(null);

    // Initialize from props
    useEffect(() => {
        if (initialCharacter) {
            setCharacter(initialCharacter);
            loadCharacterGallery(initialCharacter.id);
        }
        if (initialPrompt) setPrompt(initialPrompt);
        if (initialStartFrame) {
            setStartFrameUrl(initialStartFrame);
            setMode(GenerationMode.FRAMES_TO_VIDEO);
        }
        if (initialEndFrame) setEndFrameUrl(initialEndFrame);
    }, [initialCharacter, initialPrompt, initialStartFrame, initialEndFrame]);

    const loadCharacterGallery = async (charId: string) => {
        try {
            const { data } = await supabase.from('dng1_characters').select('image_urls_jsonb').eq('character_id', charId).single();
            if (data?.image_urls_jsonb) {
                // Limit to recent 20 images
                setCharacterGallery(data.image_urls_jsonb.slice(0, 20).map((i: any) => i.url));
            }
        } catch(e) { console.error("Gallery load failed", e); }
    };

    const handleAssetSelect = (assets: Asset[]) => {
        if (assets.length === 0 || !pickerType) return;
        const asset = assets[0];
        const data = { url: asset.publicURL, id: asset.id, name: asset.name };
        
        if (pickerType === 'character') {
            setCharacter(data);
            loadCharacterGallery(data.id);
        }
        if (pickerType === 'setting') setLocation(data);
        if (pickerType === 'product') setProduct(data);
        
        setShowAssetPicker(false);
        setPickerType(null);
    };

    const handleCharacterGallerySelect = (url: string) => {
        if (!character) return;
        setCharacter({ ...character, url: url });
        setShowCharacterGallery(false);
    };

    const handleUploadFrame = async (e: React.ChangeEvent<HTMLInputElement>, type: 'start' | 'end') => {
        const file = e.target.files?.[0];
        if (!file) return;
        setIsLoading(true);
        setStatus(`Uploading ${type} frame...`);
        try {
            const url = await uploadBlob(file, `quick_${type}_${Date.now()}.png`, 'godrej/quick_clips');
            if (url) {
                if (type === 'start') setStartFrameUrl(url);
                else setEndFrameUrl(url);
            }
        } catch(e) { console.error(e); }
        finally { setIsLoading(false); setStatus(''); }
    };

    const handleGenerateIdea = async (type: 'creative' | 'trending') => {
        setIsIdeating(true);
        setTrendSources([]);
        try {
            const assets = {
                character: character?.name,
                location: location?.name,
                product: product?.name
            };
            const result = await generateQuickClipIdea(assets, type);
            
            // Apply Brand DNA automatically if enabled for idea generation
            let generatedPrompt = result.prompt;
            if (useBrandDNA) {
                generatedPrompt += " Brand: Darling Hair (Unstoppable, Bold, African Beauty).";
            }
            
            setPrompt(generatedPrompt);
            if (result.sources && result.sources.length > 0) {
                setTrendSources(result.sources);
            }
        } catch (e) {
            console.error(e);
            alert("Ideation failed.");
        } finally {
            setIsIdeating(false);
        }
    };

    const handleEnhanceIdea = async () => {
        if (!prompt) return;
        setIsEnhancing(true);
        try {
            const enhanced = await enhanceSceneDescription(prompt);
            setPrompt(enhanced);
        } catch(e) {
            console.error(e);
        } finally {
            setIsEnhancing(false);
        }
    };

    const handleGenerateComposition = async () => {
        if (!prompt.trim()) { alert("Please enter a scene prompt."); return; }
        setIsLoading(true);
        setStatus("Analyzing Assets & Compositing (Nano Banana Pro)...");
        
        try {
            // 1. Prepare Ingredients & Analyze them for visual consistency
            const refs: any = {};
            const ingredientDescriptions: string[] = [];

            if (character) { 
                const charB64 = await urlToBase64(character.url);
                if (charB64) {
                    refs.character = charB64; 
                    // Analyze character
                    setStatus(`Analyzing ${character.name}...`);
                    const charDesc = await analyzeAssetAttributes(charB64, 'character');
                    ingredientDescriptions.push(`CHARACTER VISUALS: ${charDesc}. (Use provided reference image for strict identity match).`);
                }
            }
            if (location) { 
                const locB64 = await urlToBase64(location.url);
                if (locB64) {
                    refs.setting = locB64;
                    setStatus(`Analyzing Location...`);
                    const locDesc = await analyzeAssetAttributes(locB64, 'setting');
                    ingredientDescriptions.push(`LOCATION VISUALS: ${locDesc}.`);
                }
            }
            if (product) { 
                const prodB64 = await urlToBase64(product.url);
                if (prodB64) {
                    refs.product = prodB64;
                    setStatus(`Analyzing Product...`);
                    const prodDesc = await analyzeAssetAttributes(prodB64, 'product');
                    ingredientDescriptions.push(`PRODUCT VISUALS: ${prodDesc}.`);
                }
            }

            setStatus("Rendering Start Frame...");

            // 2. Construct Robust Prompt
            let fullPrompt = `SCENE ACTION: ${prompt}. \n\nVISUAL CONTEXT:\n${ingredientDescriptions.join('\n')}. \n\nSTYLE: Photorealistic, Cinematic Lighting, 8k resolution.`;
            if (useBrandDNA) {
                fullPrompt += " \nBRAND VIBE: Authentic South African Mzansi aesthetic. Unstoppable confidence.";
            }
            
            // Use Nano Banana Pro (Gemini 3 Pro Image) for composition - respecting Aspect Ratio
            // Explicitly requesting gemini-3-pro-image-preview for high fidelity ref usage
            const result = await generateImage(fullPrompt, aspectRatio, refs, undefined, 'gemini-3-pro-image-preview');
            
            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const url = await uploadBlob(blob, `quick_comp_${Date.now()}.png`, 'godrej/quick_clips');
            
            if (url) setStartFrameUrl(url);
            
        } catch(e: any) {
            console.error(e);
            alert(`Composition failed: ${e.message}`);
        } finally {
            setIsLoading(false);
            setStatus('');
        }
    };

    const handleMagicEdit = async () => {
        if (!startFrameUrl || !editPrompt) return;
        setIsEditing(true);
        try {
            const b64 = await urlToBase64(startFrameUrl);
            const result = await editImage(b64, editPrompt, undefined, aspectRatio, 'gemini-2.5-flash-image');
            
            const blob = await (await fetch(`data:${result.mimeType};base64,${result.base64}`)).blob();
            const url = await uploadBlob(blob, `quick_edit_${Date.now()}.png`, 'godrej/quick_clips');
            if (url) setStartFrameUrl(url);
            
            setShowEditModal(false);
            setEditPrompt('');
        } catch(e: any) {
            console.error(e);
            alert(`Edit failed: ${e.message}`);
        } finally {
            setIsEditing(false);
        }
    };

    const handleGenerateVideo = async () => {
        if (!prompt) { alert("Prompt is required."); return; }
        
        // Validation per mode
        if (mode === GenerationMode.FRAMES_TO_VIDEO && (!startFrameUrl || !endFrameUrl)) {
            alert("Frames to Video requires both a Start and End frame.");
            return;
        }
        if (mode === GenerationMode.FRAMES_TO_VIDEO && (!startFrameUrl)) {
             alert("Start Frame required.");
             return;
        }
        if (mode === GenerationMode.REFERENCES_TO_VIDEO && (!character && !product && !location)) {
            alert("Ingredients mode requires at least one asset (Character, Location, or Product).");
            return;
        }

        setIsLoading(true);
        setStatus(`Generating 8s Video (${mode})...`);
        
        try {
            let startFile, startBase64;
            let endFile, endBase64;
            const refImages = [];

            // 1. Prepare Start Frame
            if (startFrameUrl && (mode === GenerationMode.FRAMES_TO_VIDEO)) {
                const resp = await fetch(startFrameUrl);
                const blob = await resp.blob();
                startBase64 = await blobToBase64(blob);
                startFile = new File([blob], "start", { type: blob.type });
            }

            // 2. Prepare End Frame
            if (endFrameUrl && mode === GenerationMode.FRAMES_TO_VIDEO) {
                const resp = await fetch(endFrameUrl);
                const blob = await resp.blob();
                endBase64 = await blobToBase64(blob);
                endFile = new File([blob], "end", { type: blob.type });
            }

            // 3. Prepare Ingredients
            if (mode === GenerationMode.REFERENCES_TO_VIDEO) {
                if (character) {
                    const resp = await fetch(character.url);
                    const blob = await resp.blob();
                    const b64 = await blobToBase64(blob);
                    refImages.push({ file: new File([blob], "char", { type: blob.type }), base64: b64 });
                }
                if (product) {
                    const resp = await fetch(product.url);
                    const blob = await resp.blob();
                    const b64 = await blobToBase64(blob);
                    refImages.push({ file: new File([blob], "prod", { type: blob.type }), base64: b64 });
                }
                if (location) {
                    const resp = await fetch(location.url);
                    const blob = await resp.blob();
                    const b64 = await blobToBase64(blob);
                    refImages.push({ file: new File([blob], "loc", { type: blob.type }), base64: b64 });
                }
            }

            // Inject Brand DNA and Context
            let finalPrompt = prompt;
            if (useBrandDNA) {
                finalPrompt += " Brand: Darling Hair (Unstoppable, Bold). Context: South African Mzansi vibe.";
            }
            if (audioPrompt) {
                finalPrompt += ` Audio Direction: ${audioPrompt}.`;
            }

            // Model Selection: Ingredients needs Veo 3.1 (Preview), others use Fast
            const modelToUse = mode === GenerationMode.REFERENCES_TO_VIDEO ? VeoModel.VEO : VeoModel.VEO_FAST;

            const result = await generateVideo({
               prompt: finalPrompt,
               model: modelToUse,
               aspectRatio: aspectRatio, // Using Selected Ratio
               resolution: Resolution.P720,
               mode: mode,
               startFrame: startFile ? { file: startFile, base64: startBase64 } : null,
               endFrame: endFile ? { file: endFile, base64: endBase64 } : null,
               referenceImages: refImages, 
               styleImage: null, inputVideo: null, inputVideoObject: null, isLooping: false
            });
            
            console.log('video received');

            const url = await uploadBlob(result.blob, `quick_vid_${Date.now()}.mp4`, 'godrej/generated_videos');
            if (url) {
                console.log('video saved');
                console.log('video url', url);
                setVideoUrl(url);
            } else {
                throw new Error("Failed to upload generated video.");
            }

        } catch(e: any) {
            console.error(e);
            alert(`Video generation failed: ${e.message}`);
        } finally {
            setIsLoading(false);
            setStatus('');
        }
    };

    const handleSaveToCharacter = async () => {
        if (!videoUrl || !character?.id) return;
        setIsLoading(true);
        setStatus("Saving to Character Gallery...");
        try {
            // Fetch latest to avoid race conditions
            const { data: currentChar } = await supabase.from('dng1_characters').select('video_urls').eq('character_id', character.id).single();
            const currentVideos = currentChar?.video_urls || [];
            
            const newVideo = {
                url: videoUrl,
                description: prompt || "Quick Clip",
                created_at: new Date().toISOString()
            };
            
            // Ensure we handle potential nulls from DB gracefully
            const updatedVideos = [newVideo, ...(Array.isArray(currentVideos) ? currentVideos : [])];

            const { error } = await updateCharacter(character.id, { video_urls: updatedVideos });
            
            if (error) throw error;
            
            onSuccess();
        } catch(e) {
            console.error("Save error:", e);
            alert("Save failed. Check console.");
        } finally {
            setIsLoading(false);
            setStatus('');
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-gray-900/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
            {/* Hidden inputs must be outside conditionals to be accessible for the overlay buttons */}
            <input type="file" ref={startFileInputRef} hidden accept="image/*" onChange={(e) => handleUploadFrame(e, 'start')} />
            <input type="file" ref={endFileInputRef} hidden accept="image/*" onChange={(e) => handleUploadFrame(e, 'end')} />

            <div className="bg-white w-full max-w-6xl rounded-[2rem] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden relative">
                {/* Header */}
                <div className="p-6 border-b border-gray-100 flex items-center justify-between shrink-0 bg-white z-10">
                    <div className="flex items-center gap-3">
                        <div className="bg-indigo-50 p-2 rounded-xl text-indigo-600"><BoltIcon className="w-6 h-6"/></div>
                        <div>
                            <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">Quick Clip Creator</h2>
                            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Veo 3.1 Studio (8s Gen)</p>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-6 h-6"/> Close</button>
                </div>

                <div className="flex-1 overflow-y-auto p-8 bg-gray-50 flex gap-8">
                    {/* LEFT: Controls */}
                    <div className="w-[400px] flex flex-col gap-6 shrink-0">
                        
                        {/* Mode Selector */}
                        <div className="bg-white p-2 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-1">
                            <label className="px-3 pt-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">Generation Mode</label>
                            <div className="grid grid-cols-2 gap-1">
                                <button onClick={() => setMode(GenerationMode.TEXT_TO_VIDEO)} className={`p-2 rounded-xl text-xs font-bold flex items-center gap-2 ${mode === GenerationMode.TEXT_TO_VIDEO ? 'bg-indigo-50 text-indigo-600 ring-1 ring-indigo-200' : 'hover:bg-gray-50 text-gray-600'}`}>
                                    <TextModeIcon className="w-4 h-4"/> Text to Video
                                </button>
                                <button onClick={() => setMode(GenerationMode.FRAMES_TO_VIDEO)} className={`p-2 rounded-xl text-xs font-bold flex items-center gap-2 ${mode === GenerationMode.FRAMES_TO_VIDEO ? 'bg-indigo-50 text-indigo-600 ring-1 ring-indigo-200' : 'hover:bg-gray-50 text-gray-600'}`}>
                                    <FramesModeIcon className="w-4 h-4"/> Frames to Video
                                </button>
                                <button onClick={() => setMode(GenerationMode.REFERENCES_TO_VIDEO)} className={`p-2 rounded-xl text-xs font-bold flex items-center gap-2 ${mode === GenerationMode.REFERENCES_TO_VIDEO ? 'bg-indigo-50 text-indigo-600 ring-1 ring-indigo-200' : 'hover:bg-gray-50 text-gray-600'}`}>
                                    <ReferencesModeIcon className="w-4 h-4"/> Ingredients
                                </button>
                                <button onClick={() => setMode(GenerationMode.FRAMES_TO_VIDEO)} className={`p-2 rounded-xl text-xs font-bold flex items-center gap-2 ${mode === GenerationMode.FRAMES_TO_VIDEO ? '' : 'hover:bg-gray-50 text-gray-600'}`}>
                                    <PhotoIcon className="w-4 h-4"/> Image to Video
                                </button>
                            </div>
                        </div>

                        {/* Aspect Ratio Selector */}
                        <div className="bg-white p-2 rounded-2xl shadow-sm border border-gray-100 flex flex-col gap-1">
                            <label className="px-3 pt-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">Aspect Ratio</label>
                            <div className="grid grid-cols-2 gap-1">
                                <button onClick={() => setAspectRatio(AspectRatio.PORTRAIT)} className={`p-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 border transition-all ${aspectRatio === AspectRatio.PORTRAIT ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50'}`}>
                                    <div className="w-3 h-5 border-2 border-current rounded-sm"></div>
                                    Portrait (9:16)
                                </button>
                                <button onClick={() => setAspectRatio(AspectRatio.LANDSCAPE)} className={`p-3 rounded-xl text-xs font-bold flex flex-col items-center justify-center gap-1 border transition-all ${aspectRatio === AspectRatio.LANDSCAPE ? 'bg-indigo-50 border-indigo-200 text-indigo-600' : 'bg-white border-gray-100 text-gray-500 hover:bg-gray-50'}`}>
                                    <div className="w-5 h-3 border-2 border-current rounded-sm"></div>
                                    Landscape (16:9)
                                </button>
                            </div>
                        </div>

                        {/* Ingredients Panel (Visible only for Ingredients/Composition) */}
                        <div className={`bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4 transition-all ${mode === GenerationMode.TEXT_TO_VIDEO ? 'opacity-50 pointer-events-none grayscale' : ''}`}>
                            <div className="space-y-3">
                                <label className="text-[10px] font-black text-indigo-600 uppercase tracking-widest flex items-center gap-2">
                                    <SparklesIcon className="w-3 h-3"/> Active Ingredients
                                </label>
                                <div className="grid grid-cols-3 gap-2">
                                    {/* Character Slot */}
                                    <div 
                                        onClick={() => { 
                                            // Special logic for character: if one is already selected, show gallery toggle
                                            if (character) setShowCharacterGallery(!showCharacterGallery);
                                            else { setPickerType('character'); setShowAssetPicker(true); }
                                        }} 
                                        className={`aspect-square rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 transition-all bg-gray-50 relative group ${character ? 'border-indigo-500' : 'border-gray-200'}`}
                                    >
                                        {character ? (
                                            <>
                                                <img src={character.url} className="w-full h-full object-cover rounded-lg"/>
                                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-lg transition-opacity">
                                                    <span className="text-[8px] font-bold text-white uppercase">Change</span>
                                                </div>
                                            </>
                                        ) : (
                                            <><UserIcon className="w-5 h-5 text-gray-300"/><span className="text-[8px] font-bold text-gray-400 uppercase mt-1">Actor</span></>
                                        )}
                                    </div>

                                    {/* Location Slot */}
                                    <div onClick={() => { setPickerType('setting'); setShowAssetPicker(true); }} className={`aspect-square rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 transition-all bg-gray-50 ${location ? 'border-indigo-500' : 'border-gray-200'}`}>
                                        {location ? <img src={location.url} className="w-full h-full object-cover rounded-lg"/> : <><MapPinIcon className="w-5 h-5 text-gray-300"/><span className="text-[8px] font-bold text-gray-400 uppercase mt-1">Loc</span></>}
                                    </div>

                                    {/* Product Slot */}
                                    <div onClick={() => { setPickerType('product'); setShowAssetPicker(true); }} className={`aspect-square rounded-xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 transition-all bg-gray-50 ${product ? 'border-indigo-500' : 'border-gray-200'}`}>
                                        {product ? <img src={product.url} className="w-full h-full object-cover rounded-lg"/> : <><CubeIcon className="w-5 h-5 text-gray-300"/><span className="text-[8px] font-bold text-gray-400 uppercase mt-1">Prod</span></>}
                                    </div>
                                </div>

                                {/* Character Visual History Strip */}
                                {character && showCharacterGallery && characterGallery.length > 0 && (
                                    <div className="mt-2 bg-gray-50 p-2 rounded-xl border border-gray-200">
                                        <p className="text-[8px] font-bold text-gray-400 uppercase mb-2">Visual History: {character.name}</p>
                                        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                                            {characterGallery.map((imgUrl, i) => (
                                                <button key={i} onClick={() => handleCharacterGallerySelect(imgUrl)} className="w-10 h-10 shrink-0 rounded-lg overflow-hidden border border-gray-200 hover:border-indigo-500 transition-all">
                                                    <img src={imgUrl} className="w-full h-full object-cover" />
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}

                                <p className="text-[10px] text-gray-400 leading-tight">
                                    {mode === GenerationMode.REFERENCES_TO_VIDEO 
                                     ? "Selected assets will be used as multimodal references for Veo 3.1." 
                                     : "Assets used for compositing the Start Frame."}
                                </p>
                            </div>
                        </div>

                        {/* Prompt Input */}
                        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4 flex-grow">
                            <div><label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Project Title</label><input className="w-full font-bold text-sm border-b border-gray-200 py-1 outline-none focus:border-indigo-500 bg-transparent" value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} /></div>
                            
                            <div className="flex justify-between items-center">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">Action Prompt</label>
                                <div className="flex gap-1">
                                    <button onClick={handleEnhanceIdea} disabled={isEnhancing} className="bg-yellow-50 text-yellow-600 hover:bg-yellow-100 px-2 py-1 rounded-md text-[9px] font-bold flex items-center gap-1 transition-colors border border-yellow-200">
                                        {isEnhancing ? '...' : <><SparklesIcon className="w-3 h-3"/> Enhance</>}
                                    </button>
                                    <button onClick={() => handleGenerateIdea('creative')} disabled={isIdeating} className="bg-purple-50 text-[#9063CD] hover:bg-purple-100 px-2 py-1 rounded-md text-[9px] font-bold flex items-center gap-1 transition-colors border border-purple-200">
                                        {isIdeating ? '...' : <><MagicWandIcon className="w-3 h-3"/> Idea</>}
                                    </button>
                                    <button onClick={() => handleGenerateIdea('trending')} disabled={isIdeating} className="bg-blue-50 text-blue-600 hover:bg-blue-100 px-2 py-1 rounded-md text-[9px] font-bold flex items-center gap-1 transition-colors border border-blue-200">
                                        {isIdeating ? '...' : <><GlobeAltIcon className="w-3 h-3"/> Trends</>}
                                    </button>
                                </div>
                            </div>
                            
                            <textarea className="w-full h-24 text-sm font-medium border border-gray-200 rounded-xl p-3 resize-none focus:ring-2 focus:ring-indigo-100 outline-none" placeholder="Describe the scene action..." value={prompt} onChange={(e) => setPrompt(e.target.value)} />
                            
                            {/* Audio Direction Input */}
                            <div>
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1 flex items-center gap-2"><MicrophoneIcon className="w-3 h-3"/> Voiceover / Audio</label>
                                <input 
                                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold text-gray-700 outline-none focus:ring-1 focus:ring-indigo-200"
                                    value={audioPrompt}
                                    onChange={(e) => setAudioPrompt(e.target.value)}
                                    placeholder="e.g. Energetic Afro-beat, female voiceover with Jozi accent"
                                />
                            </div>

                            {/* Brand DNA Toggle */}
                            <div 
                                className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer border transition-colors ${useBrandDNA ? 'bg-purple-50 border-purple-200' : 'bg-gray-50 border-gray-100'}`}
                                onClick={() => setUseBrandDNA(!useBrandDNA)}
                            >
                                <div className={`w-8 h-5 rounded-full p-1 transition-colors ${useBrandDNA ? 'bg-purple-600' : 'bg-gray-300'}`}>
                                    <div className={`w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${useBrandDNA ? 'translate-x-3' : 'translate-x-0'}`}></div>
                                </div>
                                <div className="flex flex-col">
                                    <span className={`text-[10px] font-black uppercase tracking-wide ${useBrandDNA ? 'text-purple-700' : 'text-gray-400'}`}>Inject Brand DNA</span>
                                    {useBrandDNA && <span className="text-[8px] text-purple-500 font-bold leading-tight">Darling Hair: Unstoppable, Bold, African Beauty.</span>}
                                </div>
                            </div>

                            {/* Vibe Mixer */}
                            <div className="flex gap-1 flex-wrap">
                                {VIBE_PRESETS.map(vibe => (
                                    <button key={vibe} onClick={() => setPrompt(p => p + (p ? '. ' : '') + vibe)} className="px-2 py-1 bg-gray-50 border border-gray-100 rounded-lg text-[9px] font-bold text-gray-500 hover:bg-indigo-50 hover:text-indigo-600 transition-colors">
                                        {vibe}
                                    </button>
                                ))}
                            </div>

                            {/* Actions based on Mode */}
                            <div className="flex flex-col gap-2 mt-2">
                                {(mode === GenerationMode.FRAMES_TO_VIDEO || mode === GenerationMode.REFERENCES_TO_VIDEO) && (
                                    <button 
                                        onClick={handleGenerateComposition} 
                                        disabled={isLoading || !prompt}
                                        className="w-full py-3 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-xl font-bold text-xs uppercase tracking-widest shadow-sm flex items-center justify-center gap-2 disabled:opacity-50"
                                    >
                                        {isLoading && !startFrameUrl ? 'Analyzing & Compositing...' : 'Composite Start Frame'} <MagicWandIcon className="w-4 h-4"/>
                                    </button>
                                )}
                                <button 
                                    onClick={handleGenerateVideo}
                                    disabled={isLoading}
                                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                                >
                                    {isLoading ? 'Generating Video...' : 'Generate 8s Video (Veo 3.1)'} <FilmIcon className="w-4 h-4"/>
                                </button>
                            </div>
                        </div>
                    </div>

                    {/* RIGHT: Visual Canvas */}
                    <div className="flex-1 flex flex-col gap-6">
                        
                        {/* Video Player / Main Stage */}
                        <div className={`flex-1 bg-black rounded-3xl overflow-hidden relative shadow-2xl flex items-center justify-center group border border-gray-800 min-h-[400px] ${aspectRatio === AspectRatio.PORTRAIT ? 'max-w-md mx-auto' : 'w-full'}`}>
                            {videoUrl ? (
                                <div className="relative w-full h-full group">
                                    <video key={videoUrl} src={videoUrl} controls autoPlay loop className="w-full h-full object-contain" />
                                    <div className="absolute top-4 right-4 z-20">
                                        <button onClick={() => setVideoUrl(null)} className="bg-black/50 hover:bg-red-600 text-white p-2 rounded-full backdrop-blur-md transition-colors shadow-lg" title="Clear Video / Reset">
                                            <TrashIcon className="w-5 h-5"/>
                                        </button>
                                    </div>
                                </div>
                            ) : startFrameUrl ? (
                                <div className="relative w-full h-full group">
                                    <img src={startFrameUrl} className="w-full h-full object-contain opacity-90" />
                                    {/* Overlay Controls */}
                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 backdrop-blur-sm">
                                         <button onClick={() => startFileInputRef.current?.click()} className="p-3 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-md transition-all shadow-lg" title="Replace Image">
                                             <UploadCloudIcon className="w-5 h-5"/>
                                         </button>
                                         <button onClick={() => { setShowEditModal(true); setEditPrompt(''); }} className="p-3 bg-indigo-600 hover:bg-indigo-700 rounded-full text-white shadow-lg transition-all" title="Magic Edit">
                                             <PencilSquareIcon className="w-5 h-5"/>
                                         </button>
                                    </div>
                                </div>
                            ) : (
                                <div className="text-center text-gray-600">
                                    <FilmIcon className="w-16 h-16 mx-auto mb-4 opacity-20"/>
                                    <p className="text-sm font-bold uppercase tracking-widest">Visual Preview</p>
                                    <p className="text-xs text-gray-700 mt-2">Mode: {mode}</p>
                                </div>
                            )}
                            
                            {/* Trend Sources Overlay */}
                            {trendSources.length > 0 && !videoUrl && !startFrameUrl && (
                                <div className="absolute bottom-4 left-4 right-4 bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/20">
                                    <p className="text-[9px] font-bold text-white uppercase tracking-widest mb-1 flex items-center gap-1"><GlobeAltIcon className="w-3 h-3"/> Trend Sources</p>
                                    <div className="flex gap-2 overflow-x-auto no-scrollbar">
                                        {trendSources.map((src, i) => (
                                            <a key={i} href={src} target="_blank" rel="noreferrer" className="text-[9px] text-blue-300 hover:text-white truncate max-w-[150px] block bg-black/30 px-2 py-0.5 rounded">{new URL(src).hostname}</a>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>

                        {/* Frames Strip (Contextual) */}
                        {mode === GenerationMode.FRAMES_TO_VIDEO && (
                            <div className="grid grid-cols-2 gap-4 h-40">
                                {/* Start Frame */}
                                <div className="bg-white rounded-2xl border border-gray-200 p-2 flex flex-col relative group overflow-hidden hover:border-indigo-400 transition-colors">
                                    <span className="text-[9px] font-black uppercase tracking-widest text-gray-400 absolute top-2 left-2 z-10 bg-white/80 px-2 rounded group-hover:text-indigo-600">Start Frame</span>
                                    {startFrameUrl ? (
                                        <div className="w-full h-full relative cursor-pointer" onClick={() => startFileInputRef.current?.click()}>
                                            <img src={startFrameUrl} className="w-full h-full object-cover rounded-xl" />
                                            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <ArrowPathIcon className="w-6 h-6 text-white" />
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="flex-1 flex items-center justify-center bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                                            <button onClick={() => startFileInputRef.current?.click()} className="text-gray-400 hover:text-indigo-600"><PlusIcon className="w-6 h-6"/></button>
                                        </div>
                                    )}
                                </div>

                                {/* End Frame */}
                                <div className="bg-white rounded-2xl border border-gray-200 p-2 flex flex-col relative group overflow-hidden hover:border-indigo-400 transition-colors">
                                    <span className="text-[9px] font-black uppercase tracking-widest text-gray-400 absolute top-2 left-2 z-10 bg-white/80 px-2 rounded group-hover:text-indigo-600">End Frame</span>
                                    {endFrameUrl ? (
                                        <div className="w-full h-full relative cursor-pointer" onClick={() => endFileInputRef.current?.click()}>
                                            <img src={endFrameUrl} className="w-full h-full object-cover rounded-xl" />
                                            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <ArrowPathIcon className="w-6 h-6 text-white" />
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="flex-1 flex items-center justify-center bg-gray-50 rounded-xl border-2 border-dashed border-gray-200">
                                            <button onClick={() => endFileInputRef.current?.click()} className="text-gray-400 hover:text-indigo-600"><PlusIcon className="w-6 h-6"/></button>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* Footer */}
                        <div className="flex justify-between items-center bg-white p-4 rounded-2xl border border-gray-100 shadow-sm shrink-0">
                            <div className="flex items-center gap-2 text-xs font-medium text-gray-500">
                                {isLoading && <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>}
                                {status || "Ready to create"}
                            </div>
                            <button 
                                onClick={handleSaveToCharacter} 
                                disabled={isLoading || (!videoUrl && !startFrameUrl) || !character} 
                                className="px-8 py-3 bg-green-600 text-white rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-green-700 disabled:opacity-50 shadow-lg flex items-center gap-2"
                            >
                                <CheckCircleIcon className="w-4 h-4"/> Save to Character
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Magic Edit Modal */}
            <Modal isOpen={showEditModal} onClose={() => setShowEditModal(false)} title="Magic Edit">
                <div className="space-y-4 p-2">
                    <p className="text-sm text-gray-500">Describe what you want to change in the start frame.</p>
                    <textarea 
                        className="w-full h-32 border border-gray-200 rounded-xl p-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                        value={editPrompt}
                        onChange={(e) => setEditPrompt(e.target.value)}
                        placeholder="e.g. Change background to a futuristic city, add a blue tint..."
                    />
                    <button 
                        onClick={handleMagicEdit}
                        disabled={isEditing || !editPrompt}
                        className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold text-xs uppercase tracking-widest flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg"
                    >
                        {isEditing ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <MagicWandIcon className="w-4 h-4"/>}
                        {isEditing ? 'Editing...' : 'Apply Edit'}
                    </button>
                </div>
            </Modal>

            {/* Asset Picker Modal */}
            <Modal isOpen={showAssetPicker} onClose={() => setShowAssetPicker(false)} title={`Select ${pickerType}`}>
                <div className="h-[60vh] -m-6">
                    <AssetStudio onAssetsSelected={handleAssetSelect} />
                </div>
            </Modal>
        </div>
    );
};

export default QuickClipCreator;