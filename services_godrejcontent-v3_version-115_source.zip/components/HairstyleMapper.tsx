/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Influencer, AspectRatio } from '../types';
import { mapHairstyle, editImage, analyzeHairReference } from '../services/geminiService';
import { uploadBlob, updateCharacter, fetchCharacters, supabase } from '../services/supabaseClient';
import MarkdownRenderer from './MarkdownRenderer';
import { 
    ScissorsIcon, 
    ArrowRightIcon, 
    CheckCircleIcon, 
    XMarkIcon, 
    UserIcon, 
    SparklesIcon, 
    ArrowPathIcon, 
    SaveIcon, 
    ChevronDownIcon, 
    AlertTriangleIcon, 
    TrashIcon, 
    PhotoIcon,
    MagicWandIcon,
    LayersIcon,
    CameraIcon,
    BoltIcon,
    EyeIcon,
    PlusIcon,
    Square2StackIcon
} from './icons';

interface HairstyleMapperProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

interface RefImage {
    id: string;
    file: File;
    preview: string;
}

const STYLE_PRESETS = [
    "High-End Fashion Editorial",
    "Soft Natural Daylight",
    "Cinematic Studio Lighting",
    "Vibrant Social Media Glow",
    "Moody Noir Shadow",
    "Clean Commercial 8k"
];

const RATIO_OPTIONS = [
    { id: AspectRatio.SQUARE, label: '1:1', desc: 'Post' },
    { id: AspectRatio.PORTRAIT, label: '9:16', desc: 'Reel' },
    { id: AspectRatio.LANDSCAPE, label: '16:9', desc: 'Web' }
];

const urlToBase64 = async (url: string): Promise<string> => {
    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to fetch image: ${response.statusText}`);
        const blob = await response.blob();
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => {
                if (typeof reader.result === 'string') {
                    resolve(reader.result.split(',')[1]);
                } else {
                    reject(new Error("Failed to read blob as string"));
                }
            };
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    } catch (e: any) {
        console.error("Base64 conversion failed", e);
        alert(`Failed to process image (CORS or Network error): ${e.message}. Please try a different image or check console.`);
        return "";
    }
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
             const base64 = (reader.result as string).split(',')[1];
             resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const HairstyleMapper: React.FC<HairstyleMapperProps> = ({ character: initialCharacter, onClose, onSuccess }) => {
    // Character State
    const [selectedChar, setSelectedChar] = useState<Influencer>(initialCharacter);
    const [allCharacters, setAllCharacters] = useState<Influencer[]>([]);
    
    // Active Source Image State (from character gallery)
    const [activeSourceImage, setActiveSourceImage] = useState<string>("");

    // Process State
    const [refImages, setRefImages] = useState<RefImage[]>([]);
    
    // Analysis State
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analyzedAttributes, setAnalyzedAttributes] = useState<string>("");
    
    // Advanced Controls
    const [matchPose, setMatchPose] = useState(false);
    const [retainOutfit, setRetainOutfit] = useState(true);
    const [retainBackground, setRetainBackground] = useState(false);
    const [selectedRatio, setSelectedRatio] = useState<AspectRatio>(AspectRatio.SQUARE);
    const [stylePreset, setStylePreset] = useState(STYLE_PRESETS[0]);
    
    // Result State
    const [previewBase64, setPreviewBase64] = useState<string | null>(null); 
    const [resultHistory, setResultHistory] = useState<string[]>([]);
    const [savedItems, setSavedItems] = useState<Set<string>>(new Set()); // Track saved base64 strings
    
    const [isProcessing, setIsProcessing] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [processingIndex, setProcessingIndex] = useState(0);
    
    // Styling State
    const [stylePrompt, setStylePrompt] = useState('');
    const [isStyling, setIsStyling] = useState(false);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Computed
    const unsavedCount = useMemo(() => resultHistory.filter(r => !savedItems.has(r)).length, [resultHistory, savedItems]);

    const getCharacterImage = (char: Influencer) => {
        if (char.image_url && char.image_url.startsWith('http')) return char.image_url;
        if (char.image_urls_jsonb && char.image_urls_jsonb.length > 0) return char.image_urls_jsonb[0].url;
        if (char.character_jsonb?.visual_markers?.primary_image) return char.character_jsonb.visual_markers.primary_image;
        return "";
    };

    useEffect(() => {
        const loadChars = async () => {
            const chars = await fetchCharacters();
            setAllCharacters(chars || []);
            
            // Re-sync selectedChar with fresh data including image_urls_jsonb
            if (selectedChar) {
                const fullChar = chars?.find(c => (c.character_id || c.id) === (selectedChar.character_id || selectedChar.id));
                if (fullChar) {
                    setSelectedChar(fullChar);
                }
            }
        };
        loadChars();
    }, []);

    useEffect(() => {
        if (selectedChar) {
            const primary = getCharacterImage(selectedChar);
            const isInGallery = selectedChar.image_urls_jsonb?.find(i => i.url === activeSourceImage);
            const isPrimary = activeSourceImage === selectedChar.image_url;
            
            if (!activeSourceImage || (!isInGallery && !isPrimary)) {
                setActiveSourceImage(primary);
            }
        }
    }, [selectedChar, activeSourceImage]);

    // Handle Paste Event
    useEffect(() => {
        const handlePaste = (e: ClipboardEvent) => {
            if (e.clipboardData && e.clipboardData.files.length > 0) {
                const newImages: RefImage[] = [];
                const files = e.clipboardData.files;
                for (let i = 0; i < files.length; i++) {
                    const file = files[i];
                    if (file.type.startsWith('image/')) {
                        newImages.push({
                            id: crypto.randomUUID(),
                            file: file,
                            preview: URL.createObjectURL(file)
                        });
                    }
                }
                if (newImages.length > 0) {
                    setRefImages(prev => [...prev, ...newImages]);
                    // Auto-analyze the first added image if none analyzed yet
                    if (!analyzedAttributes) {
                        analyzeFile(newImages[0].file);
                    }
                }
            }
        };

        window.addEventListener('paste', handlePaste);
        return () => window.removeEventListener('paste', handlePaste);
    }, [analyzedAttributes]);

    const handleCharacterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newId = e.target.value;
        if (unsavedCount > 0) {
            if (!confirm(`You have ${unsavedCount} unsaved looks. Switch anyway?`)) {
                e.target.value = selectedChar.character_id || selectedChar.id || '';
                return;
            }
        }
        
        const target = allCharacters.find(c => (c.character_id || c.id) === newId);
        if (target) {
            setSelectedChar(target);
            resetState();
        }
    };

    const handleCloseSafe = () => {
        if (unsavedCount > 0) {
            if (confirm(`You have ${unsavedCount} generated look(s) that are not saved. Close anyway?`)) {
                onClose();
            }
        } else {
            onClose();
        }
    };

    const analyzeFile = async (file: File) => {
        setIsAnalyzing(true);
        try {
            const b64 = await fileToBase64(file);
            const analysis = await analyzeHairReference(b64);
            setAnalyzedAttributes(analysis);
        } catch (err) {
            console.error("Analysis failed", err);
        } finally {
            setIsAnalyzing(false);
        }
    }

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = e.target.files;
        if (files && files.length > 0) {
            const newImages: RefImage[] = [];
            // Use for loop to ensure type safety for FileList
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                newImages.push({
                    id: crypto.randomUUID(),
                    file,
                    preview: URL.createObjectURL(file)
                });
            }
            
            setRefImages(prev => [...prev, ...newImages]);
            
            // Analyze the first one if nothing is analyzed
            if (!analyzedAttributes && newImages.length > 0) {
                analyzeFile(newImages[0].file);
            }
        }
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const removeRefImage = (id: string) => {
        setRefImages(prev => prev.filter(img => img.id !== id));
    };

    const handleMapHairstyle = async () => {
        if (refImages.length === 0) {
            alert("Please upload or paste hairstyle reference images.");
            return;
        }
        const charUrl = activeSourceImage;
        if (!charUrl) {
            alert("Select a base photo for the character (Identity Source).");
            return;
        }

        setIsProcessing(true);
        setResultHistory([]); 
        setSavedItems(new Set());
        
        try {
            const charB64 = await urlToBase64(charUrl);
            if (!charB64) {
                setIsProcessing(false);
                return; 
            }

            // Loop through all reference images
            for (let i = 0; i < refImages.length; i++) {
                setProcessingIndex(i + 1);
                const ref = refImages[i];
                const styleB64 = await fileToBase64(ref.file);
                
                try {
                    const result = await mapHairstyle(charB64, styleB64, undefined, {
                        matchPose,
                        aspectRatio: selectedRatio,
                        retainOutfit,
                        retainBackground,
                        stylePreset
                    });
                    
                    // Update state with result immediately
                    setResultHistory(prev => [result.base64, ...prev]);
                    setPreviewBase64(result.base64); // Show the latest one
                } catch (innerError) {
                    console.error("Individual mapping failed", innerError);
                    // Continue to next image
                }
            }

        } catch (e: any) {
            console.error("Mapping Error:", e);
            alert(`Mapping failed: ${e.message || "Unknown error"}. Check console for details.`);
        } finally {
            setIsProcessing(false);
            setProcessingIndex(0);
        }
    };

    const handleStyleResult = async () => {
        if (!previewBase64 || !stylePrompt.trim()) return;
        setIsStyling(true);
        try {
            const result = await editImage(previewBase64, stylePrompt, undefined, selectedRatio, 'gemini-2.5-flash-image');
            setPreviewBase64(result.base64);
            setResultHistory(prev => [result.base64, ...prev]); // Add styled version to history
            setStylePrompt('');
        } catch (e: any) {
            console.error(e);
            alert(`Styling failed: ${e.message}`);
        } finally {
            setIsStyling(false);
        }
    };

    const uploadAndSave = async (base64: string): Promise<boolean> => {
        if (savedItems.has(base64)) return true; // Already saved

        try {
            const binary = atob(base64);
            const array = [];
            for (let i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
            const blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
            
            const pk = selectedChar.character_id || selectedChar.id;
            const fileName = `hair_mapped_${pk}_${Date.now()}_${Math.random().toString(36).substring(7)}.png`;
            const publicUrl = await uploadBlob(blob, fileName, 'godrej/characters');
            
            if (publicUrl) {
                // Fetch fresh char to avoid race conditions
                const { data: freshChar } = await supabase
                    .from('dng1_characters')
                    .select('image_urls_jsonb')
                    .eq('character_id', pk)
                    .single();

                const currentGallery = freshChar?.image_urls_jsonb || [];
                const newGallery = [{ 
                    url: publicUrl, 
                    type: 'hairstyle_map', 
                    description: `AI Hairstyle: ${stylePreset}`,
                    features: analyzedAttributes, 
                    metadata: {
                        stylePreset,
                        ratio: selectedRatio
                    }
                }, ...currentGallery];
                
                await updateCharacter(pk!, { image_urls_jsonb: newGallery });
                setSavedItems(prev => new Set(prev).add(base64));
                return true;
            }
            return false;
        } catch (e) {
            console.error("Save error", e);
            return false;
        }
    };

    const handleSaveResult = async () => {
        if (!previewBase64) return;
        setIsSaving(true);
        const success = await uploadAndSave(previewBase64);
        setIsSaving(false);
        if (success) {
            alert("Saved to character gallery!");
            onSuccess(); // Trigger parent refresh
        } else {
            alert("Failed to save image.");
        }
    };

    const handleSaveAll = async () => {
        if (resultHistory.length === 0) return;
        setIsSaving(true);
        
        let savedCount = 0;
        const unsaved = resultHistory.filter(b64 => !savedItems.has(b64));
        
        // Process in parallel with concurrency limit could be better, but sequential is safer for order
        for (const b64 of unsaved) {
            const success = await uploadAndSave(b64);
            if (success) savedCount++;
        }
        
        setIsSaving(false);
        if (savedCount > 0) {
            alert(`Successfully saved ${savedCount} new images to gallery!`);
            onSuccess();
        } else if (unsaved.length === 0) {
            alert("All images are already saved.");
        } else {
            alert("Failed to save images. Please check console/network.");
        }
    };

    const resetState = () => {
        if (unsavedCount > 0) {
            if (!confirm(`Clear all ${unsavedCount} unsaved results?`)) return;
        }
        setRefImages([]);
        setPreviewBase64(null);
        setResultHistory([]);
        setSavedItems(new Set());
        setStylePrompt('');
        setAnalyzedAttributes("");
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const Toggle = ({ active, onToggle, label, sublabel }: any) => (
        <div className="flex items-center gap-3 bg-white p-3 rounded-xl border border-gray-100 shadow-sm flex-1 hover:border-pink-200 transition-colors">
            <div className="flex-1">
                <span className="text-[10px] font-black text-gray-900 uppercase tracking-wide block">{label}</span>
                <span className="text-[8px] text-gray-400 block leading-tight">{sublabel}</span>
            </div>
            <div 
                className={`w-10 h-6 rounded-full p-1 cursor-pointer transition-colors ${active ? 'bg-pink-500' : 'bg-gray-200'}`}
                onClick={onToggle}
            >
                <div className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${active ? 'translate-x-4' : 'translate-x-0'}`}></div>
            </div>
        </div>
    );

    return (
        <div className="fixed inset-0 z-[100] bg-gray-900/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-6xl rounded-[2.5rem] shadow-2xl flex flex-col max-h-[90vh] overflow-hidden relative border border-gray-200">
                <header className="p-6 border-b border-gray-100 flex items-center justify-between bg-white z-10 shrink-0">
                    <div className="flex items-center gap-3">
                        <div className="bg-pink-50 p-2 rounded-xl text-pink-600"><ScissorsIcon className="w-6 h-6"/></div>
                        <div>
                            <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">Hairstyle Mapper</h2>
                            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Multi-Shot Batch Processor</p>
                        </div>
                    </div>
                    <button onClick={handleCloseSafe} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-6 h-6"/></button>
                </header>

                <div className="flex-1 overflow-y-auto p-8 bg-gray-50">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8 h-full items-start">
                        
                        {/* 1. Character Source */}
                        <div className="flex flex-col gap-4 items-center">
                            <div className="w-full">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Target Character</label>
                                <div className="relative">
                                    <select 
                                        className="w-full bg-white border border-gray-200 rounded-xl py-3 pl-4 pr-10 text-sm font-bold text-gray-800 appearance-none outline-none focus:ring-2 focus:ring-pink-500 transition-shadow cursor-pointer"
                                        value={selectedChar.character_id || selectedChar.id}
                                        onChange={handleCharacterChange}
                                        disabled={isProcessing || isSaving}
                                    >
                                        {allCharacters.map(c => <option key={c.character_id || c.id} value={c.character_id || c.id}>{c.name}</option>)}
                                    </select>
                                    <ChevronDownIcon className="w-4 h-4 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"/>
                                </div>
                            </div>

                            <div className="aspect-[3/4] w-full rounded-3xl overflow-hidden bg-white shadow-md border-4 border-white relative group shrink-0">
                                {activeSourceImage ? <img src={activeSourceImage} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-gray-100 text-gray-300"><UserIcon className="w-12 h-12"/></div>}
                                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 bg-black/60 text-white text-[9px] font-bold px-2 py-1 rounded backdrop-blur-md whitespace-nowrap">Identity Source</div>
                            </div>

                            {/* Base Photo Thumbnails */}
                            <div className="w-full">
                                <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wider mb-2">Select Base Photo</p>
                                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
                                    <button 
                                        onClick={() => setActiveSourceImage(getCharacterImage(selectedChar))}
                                        className={`relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${activeSourceImage === getCharacterImage(selectedChar) ? 'border-pink-500 ring-2 ring-pink-500/20' : 'border-transparent hover:border-gray-200'}`}
                                        title="Primary Image"
                                    >
                                        <img src={getCharacterImage(selectedChar)} className="w-full h-full object-cover" />
                                    </button>
                                    {selectedChar.image_urls_jsonb?.map((img, idx) => (
                                        <button 
                                            key={idx}
                                            onClick={() => setActiveSourceImage(img.url)}
                                            className={`relative w-14 h-14 rounded-xl overflow-hidden shrink-0 border-2 transition-all ${activeSourceImage === img.url ? 'border-pink-500 ring-2 ring-pink-500/20' : 'border-transparent hover:border-gray-200'}`}
                                        >
                                            <img src={img.url} className="w-full h-full object-cover" />
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* 2. Advanced Controls Column */}
                        <div className="flex flex-col gap-6">
                            <div className="space-y-4">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><LayersIcon className="w-3 h-3"/> Continuity Controls</label>
                                <div className="flex flex-col gap-2">
                                    <Toggle active={matchPose} onToggle={() => setMatchPose(!matchPose)} label="Match Reference Pose" sublabel="Copy hairstyle's body angle" />
                                    <Toggle active={retainOutfit} onToggle={() => setRetainOutfit(!retainOutfit)} label="Retain My Model's Outfit" sublabel="Don't use hair source clothes" />
                                    <Toggle active={retainBackground} onToggle={() => setRetainBackground(!retainBackground)} label="Retain My Background" sublabel="Keep original environment" />
                                </div>
                            </div>

                            <div className="space-y-4">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2"><PhotoIcon className="w-3 h-3"/> Format & Style</label>
                                <div className="grid grid-cols-3 gap-2">
                                    {RATIO_OPTIONS.map(opt => (
                                        <button 
                                            key={opt.id} 
                                            onClick={() => setSelectedRatio(opt.id)}
                                            className={`flex flex-col items-center justify-center p-2 rounded-xl border transition-all ${selectedRatio === opt.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-white text-gray-500 border-gray-100 hover:border-gray-200'}`}
                                        >
                                            <div className={`border-2 border-current rounded-sm mb-1 ${opt.id === AspectRatio.SQUARE ? 'w-4 h-4' : opt.id === AspectRatio.PORTRAIT ? 'w-3 h-5' : 'w-5 h-3'}`}></div>
                                            <span className="text-[8px] font-black uppercase tracking-tighter">{opt.label}</span>
                                        </button>
                                    ))}
                                </div>
                                <div className="relative">
                                    <select 
                                        className="w-full bg-white border border-gray-100 rounded-xl py-3 px-4 text-[10px] font-black uppercase tracking-widest appearance-none outline-none shadow-sm cursor-pointer hover:bg-gray-50 transition-colors"
                                        value={stylePreset}
                                        onChange={(e) => setStylePreset(e.target.value)}
                                    >
                                        {STYLE_PRESETS.map(s => <option key={s} value={s}>{s}</option>)}
                                    </select>
                                    <ChevronDownIcon className="w-3 h-3 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"/>
                                </div>
                            </div>
                        </div>

                        {/* 3. Reference Input & Analysis */}
                        <div className="flex flex-col gap-6 items-center">
                            <div className="w-full flex justify-between items-center">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Hairstyle Goals ({refImages.length})</label>
                                {isAnalyzing && <span className="text-[9px] font-bold text-pink-500 animate-pulse">Detecting Attributes...</span>}
                            </div>
                            
                            {/* Upload Area */}
                            <div 
                                className="w-full min-h-[200px] bg-white rounded-[2rem] border-2 border-dashed border-gray-300 flex flex-col p-4 transition-all hover:border-pink-400 hover:bg-pink-50 cursor-pointer relative"
                                onClick={() => !isProcessing && fileInputRef.current?.click()}
                            >
                                {refImages.length === 0 ? (
                                    <div className="flex-1 flex flex-col items-center justify-center text-center">
                                        <div className="w-12 h-12 bg-pink-100 rounded-full flex items-center justify-center mb-2"><ScissorsIcon className="w-6 h-6 text-pink-500"/></div>
                                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Paste or Upload Photos</p>
                                        <p className="text-[9px] text-gray-300 mt-1">Multi-select enabled</p>
                                    </div>
                                ) : (
                                    <div className="grid grid-cols-2 gap-2 overflow-y-auto max-h-[200px] pr-1">
                                        {refImages.map((img) => (
                                            <div key={img.id} className="relative aspect-square rounded-xl overflow-hidden group">
                                                <img src={img.preview} className="w-full h-full object-cover" />
                                                <button 
                                                    onClick={(e) => { e.stopPropagation(); removeRefImage(img.id); }}
                                                    className="absolute top-1 right-1 bg-white/80 hover:bg-red-500 hover:text-white p-1 rounded-full text-gray-500 transition-colors opacity-0 group-hover:opacity-100"
                                                >
                                                    <XMarkIcon className="w-3 h-3"/>
                                                </button>
                                            </div>
                                        ))}
                                        <div className="aspect-square rounded-xl border-2 border-dashed border-gray-200 flex items-center justify-center">
                                            <PlusIcon className="w-6 h-6 text-gray-300"/>
                                        </div>
                                    </div>
                                )}
                                <input type="file" ref={fileInputRef} hidden accept="image/*" multiple onChange={handleFileChange} />
                            </div>

                            {/* Analysis Tags Display */}
                            {analyzedAttributes && (
                                <div className="w-full bg-pink-50 border border-pink-100 rounded-2xl p-4 shadow-inner flex-1 max-h-[150px] overflow-hidden flex flex-col">
                                    <div className="flex items-center gap-2 mb-3 pb-2 border-b border-pink-100 shrink-0">
                                        <EyeIcon className="w-4 h-4 text-pink-600"/>
                                        <span className="text-[10px] font-black text-pink-700 uppercase tracking-wider">Detected Features</span>
                                    </div>
                                    <div className="overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-pink-200">
                                        <MarkdownRenderer content={analyzedAttributes} />
                                    </div>
                                </div>
                            )}

                            <button 
                                onClick={handleMapHairstyle} 
                                disabled={refImages.length === 0 || isProcessing || isSaving || isAnalyzing}
                                className="w-full py-4 bg-gradient-to-r from-pink-500 to-indigo-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:scale-105 transition-all disabled:opacity-50 disabled:scale-100 flex items-center justify-center gap-2 mt-auto"
                            >
                                {isProcessing ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4"/>}
                                {isProcessing ? `Processing ${processingIndex}/${refImages.length}...` : 'Mix & Render All'}
                            </button>
                        </div>

                        {/* 4. Result & Refinement */}
                        <div className="flex flex-col gap-4 items-center h-full">
                            <label className="text-[10px] font-black text-[#9063CD] uppercase tracking-widest self-start flex justify-between w-full">
                                <span>Final Creations</span>
                                {resultHistory.length > 0 && <span className="bg-purple-100 text-purple-600 px-2 rounded">{resultHistory.length}</span>}
                            </label>
                            
                            {/* Main Preview (Active) */}
                            <div className={`w-full rounded-[2.5rem] overflow-hidden bg-white shadow-2xl border-4 border-pink-100 relative group transition-all shrink-0 ${selectedRatio === AspectRatio.PORTRAIT ? 'aspect-[9/16]' : selectedRatio === AspectRatio.LANDSCAPE ? 'aspect-[16/9]' : 'aspect-square'}`}>
                                {previewBase64 ? <img src={`data:image/png;base64,${previewBase64}`} className="w-full h-full object-cover" /> : (
                                    <div className="w-full h-full flex flex-col items-center justify-center bg-gray-50 text-gray-300 border-2 border-dashed border-gray-100">
                                        <SparklesIcon className="w-10 h-10 opacity-10 animate-pulse"/>
                                        {isProcessing && <div className="mt-4 text-xs font-bold text-pink-400 uppercase tracking-widest animate-pulse">Generating High-Fi...</div>}
                                    </div>
                                )}
                                {previewBase64 && savedItems.has(previewBase64) && (
                                    <div className="absolute inset-0 bg-black/40 flex flex-col items-center justify-center gap-2 backdrop-blur-sm">
                                        <div className="bg-green-500 text-white px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest flex items-center gap-2 shadow-xl animate-fade-in-up">
                                            <CheckCircleIcon className="w-4 h-4"/> Saved
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Result History Strip */}
                            {resultHistory.length > 1 && (
                                <div className="w-full overflow-x-auto pb-2 no-scrollbar flex gap-2 shrink-0 h-20">
                                    {resultHistory.map((b64, idx) => (
                                        <button 
                                            key={idx}
                                            onClick={() => setPreviewBase64(b64)}
                                            className={`aspect-square rounded-lg overflow-hidden border-2 shrink-0 relative ${previewBase64 === b64 ? 'border-pink-500 ring-1 ring-pink-300' : 'border-gray-200 hover:border-gray-400'}`}
                                        >
                                            <img src={`data:image/png;base64,${b64}`} className="w-full h-full object-cover" />
                                            {savedItems.has(b64) && (
                                                <div className="absolute top-1 right-1 bg-green-500 rounded-full p-0.5 border border-white">
                                                    <CheckCircleIcon className="w-3 h-3 text-white"/>
                                                </div>
                                            )}
                                        </button>
                                    ))}
                                </div>
                            )}

                            {previewBase64 && (
                                <div className="w-full space-y-3 animate-fade-in-up mt-auto">
                                    <div className="relative">
                                        <input 
                                            className="w-full bg-white border border-gray-200 rounded-xl py-3 pl-4 pr-10 text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-100" 
                                            placeholder="Tweaks? e.g. Change dress to red" 
                                            value={stylePrompt} 
                                            onChange={(e) => setStylePrompt(e.target.value)} 
                                            onKeyDown={(e) => e.key === 'Enter' && handleStyleResult()} 
                                        />
                                        <button onClick={handleStyleResult} disabled={isStyling} className="absolute right-2 top-2 p-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors shadow-md disabled:opacity-50">
                                            {isStyling ? <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <ArrowRightIcon className="w-3 h-3"/>}
                                        </button>
                                    </div>
                                    <div className="flex gap-2">
                                        {/* Save Button changes based on state */}
                                        <button 
                                            onClick={handleSaveResult} 
                                            disabled={isSaving || savedItems.has(previewBase64)} 
                                            className={`flex-1 py-4 rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl flex items-center justify-center gap-2 transition-all disabled:opacity-50 ${savedItems.has(previewBase64) ? 'bg-green-50 text-green-600 border border-green-200' : 'bg-black text-white hover:bg-gray-800'}`}
                                        >
                                            {isSaving ? 'Syncing...' : (savedItems.has(previewBase64) ? <><CheckCircleIcon className="w-4 h-4"/> Saved</> : <><SaveIcon className="w-4 h-4"/> Save Current</>)}
                                        </button>
                                        
                                        {/* Save All - Only show if unsaved items exist */}
                                        {unsavedCount > 0 && (
                                            <button 
                                                onClick={handleSaveAll} 
                                                disabled={isSaving}
                                                className="px-4 py-4 bg-purple-100 text-purple-700 rounded-2xl hover:bg-purple-200 transition-colors text-[10px] font-black uppercase tracking-wider"
                                                title={`Save ${unsavedCount} unsaved items`}
                                            >
                                                Save All ({unsavedCount})
                                            </button>
                                        )}

                                        <button onClick={resetState} className="p-4 bg-red-50 text-red-400 rounded-2xl hover:bg-red-100 transition-colors" title="Reset All"><TrashIcon className="w-5 h-5"/></button>
                                    </div>
                                </div>
                            )}
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default HairstyleMapper;