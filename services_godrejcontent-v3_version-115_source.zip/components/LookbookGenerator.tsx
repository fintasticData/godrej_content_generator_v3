
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { Influencer, AspectRatio, BrandIdentity } from '../types';
import { editImage, brainstormLookbook } from '../services/geminiService';
import { uploadBlob, updateCharacter, supabase, fetchBrands } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    CameraIcon, 
    BoltIcon,
    UserIcon,
    SparklesIcon,
    GlobeAltIcon
} from './icons';

interface LookbookGeneratorProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

const DEFAULT_AVATAR = "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=400&h=500&fit=crop";

const urlToBase64 = async (url: string): Promise<string> => {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(blob);
    });
};

const LookbookGenerator: React.FC<LookbookGeneratorProps> = ({ character, onClose, onSuccess }) => {
    const [isGenerating, setIsGenerating] = useState(false);
    const [isBrainstorming, setIsBrainstorming] = useState(false);
    const [generatedLooks, setGeneratedLooks] = useState<string[]>([]);
    
    const [theme, setTheme] = useState('');
    const [looks, setLooks] = useState([
        { name: "Urban Street", prompt: "Walking down a busy city street, trendy streetwear fashion, candid shot." },
        { name: "Gala Event", prompt: "Red carpet event, elegant evening gown, camera flashes, high glamour." },
        { name: "Casual Coffee", prompt: "Sitting in a cozy cafe, drinking coffee, casual sweater, relaxed vibe." },
        { name: "Business Pro", prompt: "Modern office setting, business suit, confident pose, professional headshot." }
    ]);

    // Brand State
    const [darlingBrand, setDarlingBrand] = useState<BrandIdentity | null>(null);
    const [useBrandDNA, setUseBrandDNA] = useState(true);

    useEffect(() => {
        const loadBrand = async () => {
            const allBrands = await fetchBrands();
            let darling = allBrands?.find(b => b.id === '39498288-b88f-4357-ba4b-5a771425e5ad');
            if (!darling) darling = allBrands?.find(b => b.brand_name.toLowerCase().includes('darling'));
            if (darling) setDarlingBrand(darling);
        };
        loadBrand();
    }, []);

    const parseBrandData = (brand: BrandIdentity | null) => {
        if (!brand || !brand.brand_data) return null;
        try {
            return typeof brand.brand_data === 'string' 
                ? JSON.parse(brand.brand_data) 
                : brand.brand_data;
        } catch { return null; }
    };

    const handleBrainstorm = async () => {
        setIsBrainstorming(true);
        try {
            let context = `Character: ${character.name}. Role: ${character.role}. Bio: ${character.description || character.origin_story || ''}`;
            const brandData = parseBrandData(darlingBrand);

            if (useBrandDNA && brandData) {
                const slogan = brandData.core_identity?.slogan || "#FindYourBeautiful";
                const spirit = brandData.core_identity?.brand_story || "Unstoppable Spirit";
                context += ` BRAND ALIGNMENT: Theme matches '${slogan}' and '${spirit}'. Authentically African, Trendsetting.`;
            }

            const newLooks = await brainstormLookbook(context, theme);
            if (newLooks && newLooks.length === 4) {
                setLooks(newLooks);
            } else {
                alert("AI returned incomplete ideas. Using defaults.");
            }
        } catch(e) {
            console.error(e);
            alert("Brainstorming failed.");
        } finally {
            setIsBrainstorming(false);
        }
    };

    const updateLook = (index: number, field: 'name' | 'prompt', value: string) => {
        setLooks(prev => prev.map((l, i) => i === index ? { ...l, [field]: value } : l));
    };

    const handleGenerate = async () => {
        const charImg = character.image_url || character.image_urls_jsonb?.[0]?.url;
        if (!charImg) { alert("Character needs a base image."); return; }
        
        setIsGenerating(true);
        setGeneratedLooks([]);
        
        try {
            const charB64 = await urlToBase64(charImg);
            const pk = character.character_id || character.id;
            const { data: freshChar } = await supabase.from('dng1_characters').select('image_urls_jsonb').eq('character_id', pk).single();
            let currentGallery = freshChar?.image_urls_jsonb || [];

            // Prepare brand constraints
            let brandPromptSuffix = " Photorealistic 8k.";
            const brandData = parseBrandData(darlingBrand);
            if (useBrandDNA && brandData) {
                const vis = brandData.visual_identity;
                const gen = brandData.image_generation_guidelines;
                
                if (gen) {
                    if (gen.lighting) brandPromptSuffix += ` Lighting: ${gen.lighting}.`;
                    if (gen.skin_texture) brandPromptSuffix += ` Skin: ${gen.skin_texture}.`;
                    if (gen.composition) brandPromptSuffix += ` Composition: ${gen.composition}.`;
                }
                if (vis?.primary_color?.name) {
                    brandPromptSuffix += ` Palette Hint: ${vis.primary_color.name}.`;
                }
            }

            // Generate sequentially to update UI
            for (const look of looks) {
                const prompt = `Consistency Lookbook: ${look.prompt}. Keep character identity exactly.${brandPromptSuffix}`;
                const result = await editImage(charB64, prompt, undefined, AspectRatio.PORTRAIT, 'gemini-2.5-flash-image');
                
                const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
                const fileName = `lookbook_${look.name.replace(/\s/g,'')}_${Date.now()}.png`;
                const url = await uploadBlob(blob, fileName, 'godrej/characters');
                
                if (url) {
                    setGeneratedLooks(prev => [...prev, url]);
                    // Auto-save with metadata
                    const newEntry = { 
                        url, 
                        type: 'lookbook_auto', 
                        description: look.name,
                        features: look.prompt, // Save prompt as features for now
                        metadata: {
                            theme: theme,
                            prompt: look.prompt,
                            look_name: look.name,
                            brand_aligned: useBrandDNA
                        }
                    };
                    currentGallery = [newEntry, ...currentGallery];
                    await updateCharacter(pk!, { image_urls_jsonb: currentGallery });
                }
            }
            onSuccess();
        } catch (e) {
            console.error(e);
            alert("Lookbook generation interrupted.");
        } finally {
            setIsGenerating(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[160] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-5xl h-[80vh] rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden relative">
                <header className="p-8 border-b border-gray-100 flex justify-between items-center bg-white z-10 shrink-0">
                    <div>
                        <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Consistency Pack</h2>
                        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Nano Banana Loop</p>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-6 h-6"/></button>
                </header>

                <div className="flex-1 overflow-y-auto p-8 bg-gray-50">
                    <div className="grid grid-cols-4 gap-4 h-full">
                        {/* Control Card */}
                        <div className="col-span-4 md:col-span-1 bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex flex-col gap-6">
                            <div className="text-center">
                                <div className="w-20 h-20 rounded-full bg-gray-100 mx-auto mb-4 overflow-hidden border-4 border-white shadow-lg">
                                    <img src={character.image_url || DEFAULT_AVATAR} className="w-full h-full object-cover" />
                                </div>
                                <h3 className="font-bold text-gray-900">{character.name}</h3>
                            </div>
                            
                            {/* Brand DNA Switch */}
                            {darlingBrand && (
                                <div 
                                    className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer border transition-colors ${useBrandDNA ? 'bg-purple-50 border-purple-200' : 'bg-gray-50 border-gray-100'}`}
                                    onClick={() => setUseBrandDNA(!useBrandDNA)}
                                >
                                    <div className={`w-8 h-5 rounded-full p-1 transition-colors ${useBrandDNA ? 'bg-purple-600' : 'bg-gray-300'}`}>
                                        <div className={`w-3 h-3 bg-white rounded-full shadow-sm transition-transform ${useBrandDNA ? 'translate-x-3' : 'translate-x-0'}`}></div>
                                    </div>
                                    <div className="flex flex-col">
                                        <span className={`text-[10px] font-black uppercase tracking-wide ${useBrandDNA ? 'text-purple-700' : 'text-gray-400'}`}>Darling Brand DNA</span>
                                        {useBrandDNA && <span className="text-[8px] text-purple-500 font-bold">Identity Active</span>}
                                    </div>
                                </div>
                            )}

                            <div className="space-y-3 border-t border-gray-100 pt-4">
                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Collection Theme (Optional)</label>
                                <div className="flex gap-2">
                                    <input 
                                        className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                                        placeholder="e.g. Tokyo Street Style"
                                        value={theme}
                                        onChange={(e) => setTheme(e.target.value)}
                                    />
                                    <button 
                                        onClick={handleBrainstorm}
                                        disabled={isBrainstorming}
                                        className="bg-indigo-50 text-indigo-600 p-2 rounded-xl hover:bg-indigo-100 transition-colors"
                                        title="Auto-Generate Looks"
                                    >
                                        {isBrainstorming ? <div className="w-4 h-4 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4" />}
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-2 mt-2 max-h-[300px] overflow-y-auto pr-1 flex-1">
                                {looks.map((l, idx) => (
                                    <div key={idx} className="bg-gray-50 p-3 rounded-xl border border-gray-100 group hover:border-indigo-200 transition-colors">
                                        <div className="flex justify-between items-center mb-1">
                                            <input 
                                                className="bg-transparent text-[10px] font-black uppercase text-gray-700 w-full outline-none"
                                                value={l.name}
                                                onChange={(e) => updateLook(idx, 'name', e.target.value)}
                                            />
                                        </div>
                                        <textarea 
                                            className="w-full bg-transparent text-[9px] text-gray-500 resize-none outline-none h-10 leading-tight"
                                            value={l.prompt}
                                            onChange={(e) => updateLook(idx, 'prompt', e.target.value)}
                                        />
                                    </div>
                                ))}
                            </div>

                            <button 
                                onClick={handleGenerate} 
                                disabled={isGenerating} 
                                className="mt-auto w-full py-4 bg-black text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                            >
                                {isGenerating ? <div className="w-4 h-4 border-2 border-gray-500 border-t-white rounded-full animate-spin"></div> : <BoltIcon className="w-4 h-4 text-yellow-400"/>}
                                {isGenerating ? 'Rendering Pack...' : 'Generate 4 Looks'}
                            </button>
                        </div>

                        {/* Results Grid */}
                        <div className="col-span-4 md:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-4">
                            {looks.map((look, i) => (
                                <div key={i} className="aspect-[9/16] bg-white rounded-2xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center relative overflow-hidden group">
                                    {generatedLooks[i] ? (
                                        <>
                                            <img src={generatedLooks[i]} className="w-full h-full object-cover animate-fade-in-up" />
                                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 pt-10">
                                                <span className="text-white text-[10px] font-bold uppercase tracking-widest">{look.name}</span>
                                            </div>
                                            {useBrandDNA && <div className="absolute top-2 right-2 bg-purple-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-full shadow-sm">Branded</div>}
                                        </>
                                    ) : (
                                        <div className="text-center text-gray-300 p-4">
                                            <UserIcon className="w-8 h-8 mx-auto mb-2 opacity-20"/>
                                            <span className="text-[9px] font-bold uppercase tracking-widest block mb-2">{look.name}</span>
                                            {isGenerating && i === generatedLooks.length && <div className="mt-4 w-4 h-4 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto"></div>}
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LookbookGenerator;
