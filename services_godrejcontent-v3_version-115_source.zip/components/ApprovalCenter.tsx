
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect } from 'react';
import { fetchPendingApprovals, submitApproval } from '../services/supabaseClient';
import { SceneSchedule } from '../types';
import { 
    CheckCircleIcon, 
    XMarkIcon, 
    UserIcon, 
    CalendarIcon, 
    ClockIcon, 
    EyeIcon,
    AlertTriangleIcon,
    ChatBubbleIcon,
    ShareIcon,
    ArrowRightIcon
} from './icons';

interface ApprovalCenterProps {
    onClose: () => void;
}

const ApprovalCenter: React.FC<ApprovalCenterProps> = ({ onClose }) => {
    const [approvals, setApprovals] = useState<SceneSchedule[]>([]);
    const [selectedId, setSelectedId] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isProcessing, setIsProcessing] = useState(false);
    const [note, setNote] = useState('');

    useEffect(() => {
        loadApprovals();
    }, []);

    const loadApprovals = async () => {
        setIsLoading(true);
        const data = await fetchPendingApprovals();
        setApprovals(data || []);
        setIsLoading(false);
    };

    const handleDecision = async (scheduleId: string, role: 'approver1_status' | 'approver2_status' | 'approver3_status', decision: 'approved' | 'rejected') => {
        setIsProcessing(true);
        const success = await submitApproval(scheduleId, role, decision, note);
        if (success) {
            await loadApprovals();
            // If item is now fully approved (removed from pending list), clear selection if it was selected
            if (!approvals.find(a => a.schedule_id === scheduleId)) {
                setSelectedId(null);
            }
            setNote('');
        } else {
            alert("Failed to submit decision.");
        }
        setIsProcessing(false);
    };

    const selectedItem = approvals.find(a => a.schedule_id === selectedId);

    const ApprovalStep = ({ label, status, onApprove, onReject, isLead }: { label: string, status: string, onApprove: () => void, onReject: () => void, isLead?: boolean }) => {
        const isPending = status === 'pending';
        const isApproved = status === 'approved';
        const isRejected = status === 'rejected';

        return (
            <div className={`p-4 rounded-xl border flex items-center justify-between transition-all ${isPending ? 'bg-white border-gray-200' : isApproved ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${isApproved ? 'bg-green-500 text-white' : isRejected ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-500'}`}>
                        {isApproved ? <CheckCircleIcon className="w-4 h-4"/> : isRejected ? <XMarkIcon className="w-4 h-4"/> : label.charAt(0)}
                    </div>
                    <div>
                        <p className="text-xs font-bold text-gray-900 uppercase tracking-wide">{label}</p>
                        <p className={`text-[10px] font-medium uppercase tracking-wider ${isApproved ? 'text-green-600' : isRejected ? 'text-red-600' : 'text-gray-400'}`}>
                            {status}
                        </p>
                    </div>
                </div>
                {isPending && (
                    <div className="flex gap-2">
                        <button onClick={onReject} disabled={isProcessing} className="p-2 hover:bg-red-100 text-red-400 rounded-lg transition-colors" title="Reject"><XMarkIcon className="w-4 h-4"/></button>
                        <button onClick={onApprove} disabled={isProcessing} className="px-3 py-1.5 bg-black text-white rounded-lg text-[10px] font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors shadow-sm">Approve</button>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="fixed inset-0 z-[200] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-6xl h-[85vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden border border-gray-200 relative">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors z-20"><XMarkIcon className="w-6 h-6"/></button>

                {/* Left: Queue List */}
                <div className="w-[350px] bg-gray-50 border-r border-gray-200 flex flex-col">
                    <div className="p-8 border-b border-gray-200 bg-white">
                        <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter mb-2">Approval Queue</h2>
                        <div className="flex items-center gap-2 text-xs font-bold text-gray-500 uppercase tracking-widest">
                            <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></span>
                            {approvals.length} Pending Items
                        </div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {isLoading ? (
                            <div className="flex justify-center p-10"><div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div></div>
                        ) : approvals.length === 0 ? (
                            <div className="text-center py-20 text-gray-400">
                                <CheckCircleIcon className="w-16 h-16 mx-auto mb-4 opacity-20"/>
                                <p className="font-bold text-sm uppercase tracking-widest">All caught up!</p>
                            </div>
                        ) : (
                            approvals.map(item => {
                                const isSelected = selectedId === item.schedule_id;
                                return (
                                    <div 
                                        key={item.schedule_id} 
                                        onClick={() => setSelectedId(item.schedule_id)}
                                        className={`p-4 rounded-2xl cursor-pointer border transition-all hover:shadow-md ${isSelected ? 'bg-white border-indigo-500 ring-1 ring-indigo-200 shadow-md' : 'bg-white border-gray-200 hover:border-indigo-300'}`}
                                    >
                                        <div className="flex items-center gap-3 mb-3">
                                            <div className="w-10 h-10 rounded-full bg-gray-100 overflow-hidden border border-gray-200">
                                                {item.character?.image_url ? <img src={item.character.image_url} className="w-full h-full object-cover"/> : <UserIcon className="w-5 h-5 text-gray-400 m-2.5"/>}
                                            </div>
                                            <div className="overflow-hidden">
                                                <h4 className="font-bold text-gray-900 text-sm truncate">{item.character?.name || 'Unknown Talent'}</h4>
                                                <p className="text-[10px] text-gray-500 font-medium">{new Date(item.scheduled_for).toLocaleDateString()}</p>
                                            </div>
                                        </div>
                                        <div className="flex justify-between items-center text-[10px] font-bold text-gray-400 uppercase tracking-wider">
                                            <span className="bg-gray-50 px-2 py-1 rounded">{item.channel}</span>
                                            <span>{item.platform || 'Social'}</span>
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>

                {/* Right: Inspection & Action */}
                <div className="flex-1 bg-white flex flex-col overflow-y-auto">
                    {selectedItem ? (
                        <div className="flex-1 flex flex-col">
                            {/* Content Preview */}
                            <div className="flex-1 p-8 bg-gray-50 flex items-center justify-center relative group">
                                {selectedItem.scene?.scene_image_url ? (
                                    <img src={selectedItem.scene.scene_image_url} className="max-w-full max-h-[50vh] object-contain rounded-xl shadow-2xl" />
                                ) : (
                                    <div className="text-gray-300 text-center"><EyeIcon className="w-24 h-24 opacity-20 mb-4"/><p className="font-bold text-xs uppercase tracking-widest">No visual asset attached</p></div>
                                )}
                                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/80 text-white px-4 py-2 rounded-full backdrop-blur-md text-xs font-medium flex items-center gap-2 shadow-lg">
                                    <ClockIcon className="w-3 h-3"/> Scheduled for {new Date(selectedItem.scheduled_for).toLocaleString()}
                                </div>
                            </div>

                            {/* Action Panel */}
                            <div className="p-8 bg-white border-t border-gray-100">
                                <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12">
                                    <div className="space-y-6">
                                        <div>
                                            <h3 className="text-lg font-black text-gray-900 uppercase tracking-tight mb-2">Context & Copy</h3>
                                            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 text-sm text-gray-700 leading-relaxed font-medium">
                                                {selectedItem.scene?.description || "No caption provided."}
                                            </div>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block flex items-center gap-2"><ChatBubbleIcon className="w-3 h-3"/> Rejection Notes</label>
                                            <textarea 
                                                className="w-full h-24 bg-white border border-gray-200 rounded-xl p-3 text-sm focus:ring-2 focus:ring-red-100 outline-none resize-none"
                                                placeholder="Add notes if rejecting..."
                                                value={note}
                                                onChange={(e) => setNote(e.target.value)}
                                            />
                                        </div>
                                    </div>

                                    <div className="space-y-4">
                                        <h3 className="text-lg font-black text-gray-900 uppercase tracking-tight mb-4 flex items-center gap-2"><ShareIcon className="w-5 h-5"/> Workflow Status</h3>
                                        
                                        <ApprovalStep 
                                            label="Creative Lead" 
                                            status={selectedItem.approver1_status} 
                                            onApprove={() => handleDecision(selectedItem.schedule_id, 'approver1_status', 'approved')}
                                            onReject={() => handleDecision(selectedItem.schedule_id, 'approver1_status', 'rejected')}
                                        />
                                        <ApprovalStep 
                                            label="Brand Manager" 
                                            status={selectedItem.approver2_status} 
                                            onApprove={() => handleDecision(selectedItem.schedule_id, 'approver2_status', 'approved')}
                                            onReject={() => handleDecision(selectedItem.schedule_id, 'approver2_status', 'rejected')}
                                        />
                                        <ApprovalStep 
                                            label="Legal / Compliance" 
                                            status={selectedItem.approver3_status} 
                                            onApprove={() => handleDecision(selectedItem.schedule_id, 'approver3_status', 'approved')}
                                            onReject={() => handleDecision(selectedItem.schedule_id, 'approver3_status', 'rejected')}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="flex-1 flex flex-col items-center justify-center text-gray-300">
                            <AlertTriangleIcon className="w-24 h-24 opacity-10 mb-4"/>
                            <p className="font-bold text-sm uppercase tracking-widest">Select an item to review</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ApprovalCenter;
