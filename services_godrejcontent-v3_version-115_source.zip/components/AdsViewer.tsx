
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useMemo, useState, useEffect} from 'react';
import {supabase, duplicateAdProject} from '../services/supabaseClient';
import {Ad, GenerateVideoParams, ProjectAsset, AdScene} from '../types';
import {
    ClapperboardIcon, 
    SearchIcon, 
    PlusIcon, 
    DotsHorizontalIcon,
    PhotoIcon,
    FileImageIcon,
    TrashIcon,
    AlertTriangleIcon,
    Square2StackIcon,
    XMarkIcon,
    PlayIcon,
    CalendarIcon,
    UserIcon,
    FilmIcon,
    ArrowRightIcon,
    ChevronRightIcon,
    LayersIcon,
    MusicIcon,
    MegaphoneIcon,
    MagicWandIcon,
    BoltIcon,
    PresentationIcon,
    ListBulletIcon,
    LayoutGridIcon,
    MapPinIcon,
    CubeIcon,
    CheckCircleIcon
} from './icons';
import Modal from './Modal';
import PromptForm from './PromptForm';
import QuickClipCreator from './QuickClipCreator';

interface AdsViewerProps {
  onGenerate: (params: GenerateVideoParams) => void;
  onEdit: (adId: string) => void;
  onCreateNew?: () => void;
  onOpenWizard?: (adId: string) => void;
}

const ITEMS_PER_PAGE = 8;

const parseText = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, i) => {
        if (part.startsWith('**') && part.endsWith('**')) {
            return <strong key={i} className="font-bold text-gray-900">{part.slice(2, -2)}</strong>;
        }
        return part;
    });
};

const cleanMarkdown = (text: string) => {
    if (!text) return "";
    return text
        .replace(/\*\*(.*?)\*\*/g, '$1')
        .replace(/\*(.*?)\*/g, '$1')
        .replace(/^#+\s+/gm, '')
        .replace(/`/g, '')
        .replace(/\[(.*?)\]\(.*?\)/g, '$1')
        .trim();
};

const ProjectSlideshow: React.FC<{ images: string[] }> = ({ images }) => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        if (images.length <= 1) return;
        const timer = setInterval(() => {
            setIndex(prev => (prev + 1) % images.length);
        }, 3000); 
        return () => clearInterval(timer);
    }, [images.length]);

    if (images.length === 0) return (
        <div className="w-full h-full flex flex-col items-center justify-center text-gray-500 bg-gray-50">
            <FilmIcon className="w-12 h-12 opacity-20 mb-2"/>
            <span className="text-xs font-bold uppercase tracking-widest">No Media Generated</span>
        </div>
    );

    if (images.length === 1) return (
         <img src={images[0]} className="w-full h-full object-cover opacity-90" alt="Scene" />
    );

    return (
        <div className="w-full h-full relative bg-black group">
            {images.map((img, i) => (
                <div 
                    key={i}
                    className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${i === index ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
                >
                    <img src={img} className="w-full h-full object-contain" alt={`Scene ${i+1}`} />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                </div>
            ))}
            
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20">
                {images.map((_, i) => (
                    <div 
                        key={i} 
                        className={`h-1.5 rounded-full transition-all duration-500 shadow-sm ${i === index ? 'w-8 bg-white' : 'w-1.5 bg-white/40'}`} 
                    />
                ))}
            </div>
            
            <div className="absolute top-4 left-4 z-20 bg-black/40 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-widest border border-white/10 flex items-center gap-2">
                <PhotoIcon className="w-3 h-3"/> Storyboard Preview
            </div>
        </div>
    );
};

const ScriptDisplay: React.FC<{ text: string }> = ({ text }) => {
    if (!text) return null;
    const lines = text.split('\n');
    
    return (
        <div className="font-mono text-sm leading-relaxed text-gray-600 space-y-2 bg-white">
            {lines.map((line, i) => {
                let trimmed = line.trim();
                if (!trimmed) return <div key={i} className="h-2" />;
                if (trimmed === '•') return null; 

                if (trimmed.match(/^[-*_]{3,}$/)) {
                    return <hr key={i} className="my-6 border-gray-100" />;
                }

                if (trimmed.match(/^(#+\s*)?(\*\*)?SCENE\s*\d+/i) || trimmed.match(/^SCENE\s*\d+/i)) {
                    const cleanHeader = trimmed.replace(/^[#*]+/, '').replace(/[*:]+$/, '').trim().toUpperCase();
                    return (
                        <div key={i} className="pt-8 pb-3 border-b-2 border-gray-100 font-black text-gray-900 tracking-tighter text-xl uppercase flex items-center gap-2">
                            {cleanHeader}
                        </div>
                    );
                }

                if (trimmed.match(/^(CAPSULE STRUCTURE|VEO 3.1 AUDIO SPECS|VISUAL PROMPT SPECS)/i)) {
                    return (
                        <div key={i} className="mt-6 mb-2 flex items-center gap-2">
                            <div className="h-4 w-1 bg-[#9063CD] rounded-full"></div>
                            <span className="text-xs font-black text-gray-800 uppercase tracking-widest">{trimmed.replace(/[:*]+$/, '')}</span>
                        </div>
                    );
                }

                const metaMatch = trimmed.match(/^([•\-\*]*\s*)?(\*\*?[\w\s\(\)]+\*\*?)\s*:\s*(.*)$/);
                if (metaMatch) {
                    const keyRaw = metaMatch[2]; 
                    const value = metaMatch[3];
                    const keyClean = keyRaw.replace(/\*/g, '').trim();
                    
                    if (value.trim()) {
                        return (
                            <div key={i} className="flex flex-col sm:flex-row gap-2 sm:gap-4 items-start sm:items-baseline mb-2 p-2 bg-gray-50 rounded-lg border border-gray-100">
                                <span className="text-[#9063CD] font-black uppercase tracking-wider shrink-0 text-[10px] w-auto sm:w-24 text-left sm:text-right pt-0.5">{keyClean}</span>
                                <span className="text-gray-800 font-medium text-xs flex-1">{parseText(value)}</span>
                            </div>
                        );
                    }
                }

                if (trimmed.startsWith('>')) {
                    return (
                        <div key={i} className="pl-4 border-l-4 border-indigo-200 text-indigo-700 italic my-2 bg-indigo-50/30 p-3 rounded-r-lg text-xs leading-relaxed">
                            {parseText(trimmed.replace(/^>\s*/, ''))}
                        </div>
                    );
                }

                const numMatch = trimmed.match(/^(\d+)\.\s+(.*)/);
                if (numMatch) {
                    return (
                        <div key={i} className="flex gap-3 relative items-start mb-3 pl-2 group">
                            <span className="shrink-0 w-5 h-5 rounded-full bg-gray-100 text-[#9063CD] text-[10px] font-black flex items-center justify-center border border-gray-200 group-hover:bg-[#9063CD] group-hover:text-white transition-colors">{numMatch[1]}</span>
                            <span className="text-gray-700 text-xs leading-relaxed pt-0.5">{parseText(numMatch[2])}</span>
                        </div>
                    );
                }

                if (trimmed.match(/^[-*•]\s+/)) {
                    const content = trimmed.replace(/^[-*•]\s+/, '');
                    return (
                        <div key={i} className="flex gap-3 relative items-start mb-1 pl-2">
                            <span className="shrink-0 w-1.5 h-1.5 rounded-full bg-gray-300 mt-2"></span>
                            <span className="text-gray-600 text-xs">{parseText(content)}</span>
                        </div>
                    );
                }

                return <p key={i} className="text-gray-600 mb-2 text-xs leading-relaxed">{parseText(trimmed)}</p>;
            })}
        </div>
    );
};

const MovieCard: React.FC<{ 
    ad: Ad, 
    onClick: (ad: Ad) => void, 
    onDelete: (id: string, e: React.MouseEvent) => void,
    onClone: (id: string, e: React.MouseEvent) => void,
    onOpenWizard?: (id: string, e: React.MouseEvent) => void 
}> = ({ ad, onClick, onDelete, onClone, onOpenWizard }) => {
    const thumbnail = ad.storyboard_urls?.[0]?.url
      || ad.scenes?.[0]?.scene_image_url 
      || ad.ad_images_url?.[0]?.url 
      || null;

    const isStoryboard = !!ad.storyboard_urls?.[0]?.url;
    const sceneCount = ad.scenes?.length || 0;

    const previewImages = (ad.scenes || [])
        .map(s => s.scene_image_url)
        .filter(url => !!url)
        .slice(0, 6);

    const cleanConcept = cleanMarkdown(ad.concept || "No description provided.");

    return (
        <div 
          onClick={() => onClick(ad)}
          className="group bg-white rounded-xl border border-gray-200 hover:shadow-xl hover:border-indigo-300 transition-all cursor-pointer overflow-hidden relative flex flex-col h-full animate-fade-in-up"
        >
            <div className="aspect-video bg-gray-100 relative overflow-hidden">
                {thumbnail ? (
                    <img src={thumbnail} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" alt={ad.ad_title} />
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50">
                        {sceneCount > 0 ? <ClapperboardIcon className="w-8 h-8" /> : <FileImageIcon className="w-8 h-8 opacity-50"/>}
                    </div>
                )}
                <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-md uppercase tracking-wide">
                    {isStoryboard ? 'Storyboard' : (sceneCount > 0 ? 'Production' : 'Draft')}
                </div>
                
                {ad.final_video_url && (
                    <div className="absolute top-2 right-2 bg-indigo-600 text-white p-1 rounded-full shadow-lg z-10">
                        <PlayIcon className="w-3 h-3 fill-current"/>
                    </div>
                )}
                
                <div className="absolute bottom-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-all z-[50]">
                    {onOpenWizard && (
                        <button
                            onClick={(e) => onOpenWizard(ad.id, e)}
                            className="p-2 bg-white text-[#9063CD] border border-gray-200 rounded-lg shadow-md hover:bg-purple-50 hover:scale-110 transition-all"
                            title="View Storyboard"
                        >
                            <PresentationIcon className="w-4 h-4 pointer-events-none" />
                        </button>
                    )}
                    <button 
                        onClick={(e) => onClone(ad.id, e)}
                        className="p-2 bg-white text-indigo-600 border border-gray-200 rounded-lg shadow-md hover:bg-indigo-50 hover:scale-110 transition-all"
                        title="Remix & Clone Project"
                    >
                        <Square2StackIcon className="w-4 h-4 pointer-events-none" />
                    </button>
                    <button 
                        onClick={(e) => onDelete(ad.id, e)}
                        className="p-2 bg-red-600 text-white rounded-lg shadow-md hover:bg-red-700 hover:scale-110 transition-all"
                        title="Delete Project"
                    >
                        <TrashIcon className="w-4 h-4 pointer-events-none" />
                    </button>
                </div>
            </div>

            <div className="p-4 flex flex-col flex-grow">
                <h3 className="font-bold text-gray-900 group-hover:text-indigo-600 transition-colors line-clamp-1 mb-1">{ad.ad_title}</h3>
                <p className="text-xs text-gray-500 line-clamp-2 mb-3 flex-grow min-h-[2.5em]">{cleanConcept}</p>
                
                {previewImages.length > 0 && (
                    <div className="flex gap-1.5 mb-3 pt-2 border-t border-dashed border-gray-100 overflow-x-auto no-scrollbar">
                        {previewImages.map((img, i) => (
                            <div key={i} className="w-8 h-8 rounded-md overflow-hidden bg-gray-50 border border-gray-200 shrink-0">
                                <img src={img} className="w-full h-full object-cover" />
                            </div>
                        ))}
                    </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-gray-100 mt-auto">
                    <div className="flex items-center gap-2 text-xs text-gray-400">
                         {isStoryboard ? <PhotoIcon className="w-3 h-3"/> : <ClapperboardIcon className="w-3 h-3" />}
                         <span>{sceneCount} Scenes</span>
                    </div>
                    <button className="p-1 hover:bg-gray-100 rounded-full text-gray-400 hover:text-gray-600">
                        <DotsHorizontalIcon className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </div>
    );
};

const AdsViewer: React.FC<AdsViewerProps> = ({ onGenerate, onEdit, onCreateNew, onOpenWizard }) => {
  const [ads, setAds] = useState<Ad[]>([]);
  const [selectedAd, setSelectedAd] = useState<Ad | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);

  // Detail View State
  const [detailTab, setDetailTab] = useState<'concept' | 'cast' | 'scenes' | 'storyboard' | 'logs'>('concept');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentSceneForModal, setCurrentSceneForModal] = useState<AdScene | null>(null);
  const [isQuickClipModalOpen, setIsQuickClipModalOpen] = useState(false);
  
  // Custom Delete Modal State
  const [deleteConfirmation, setDeleteConfirmation] = useState<{isOpen: boolean, adId: string | null}>({isOpen: false, adId: null});
  const [isDeleting, setIsDeleting] = useState(false);
  
  // Cloning State
  const [isCloning, setIsCloning] = useState(false);

  const filterOptions = ["All", "Video Gallery", "Scenes", "Scripts", "Products", "Characters", "Settings"];

  // Reset pagination when filter changes
  useEffect(() => {
      setCurrentPage(1);
  }, [searchQuery, activeFilter]);

  const fetchAds = async () => {
      setIsLoading(true);
      setError(null);
      try {
        const {data, error: adsError} = await supabase
          .from('dng1_ads')
          .select(
            `
            id,
            ad_title,
            target_audience,
            concept,
            ad_images_url,
            storyboard_urls,
            video_url,
            status,
            created_at,
            characters,
            ad_data,
            scenes:dng1_ad_scenes (
              id,
              scene_number,
              description,
              scene_image_url,
              scene_data,
              logs
            )
          `,
          )
          .order('created_at', {ascending: false});

        if (adsError) throw adsError;
        
        const sortedData = (data as any[]).map(ad => {
          let normalizedAssets: ProjectAsset[] = [];
          if (ad.ad_images_url) {
              if (Array.isArray(ad.ad_images_url)) {
                  normalizedAssets = ad.ad_images_url;
              } else if (typeof ad.ad_images_url === 'string') {
                  try {
                      normalizedAssets = JSON.parse(ad.ad_images_url);
                  } catch (e) {
                      console.warn('Failed to parse assets for ad', ad.id);
                  }
              }
          }
          
          let normalizedStoryboards: {url: string, prompt: string}[] = [];
          if (ad.storyboard_urls) {
              if (Array.isArray(ad.storyboard_urls)) {
                  normalizedStoryboards = ad.storyboard_urls;
              } else if (typeof ad.storyboard_urls === 'string') {
                  try {
                      normalizedStoryboards = JSON.parse(ad.storyboard_urls);
                  } catch (e) {
                      console.warn('Failed to parse storyboards', ad.id);
                  }
              }
          }

          let normalizedCharacters: any[] = [];
          if (ad.characters) {
              if (Array.isArray(ad.characters)) {
                  normalizedCharacters = ad.characters;
              } else if (typeof ad.characters === 'string') {
                  try {
                      normalizedCharacters = JSON.parse(ad.characters);
                  } catch (e) {
                      console.warn('Failed to parse characters for ad', ad.id);
                  }
              }
          }

          let normalizedAdData: any = {};
          if (ad.ad_data) {
              if (typeof ad.ad_data === 'string') {
                  try { normalizedAdData = JSON.parse(ad.ad_data); } catch {}
              } else {
                  normalizedAdData = ad.ad_data;
              }
          }

          let cleanVideoUrl = null;
          if (ad.video_url && typeof ad.video_url === 'string') {
              cleanVideoUrl = ad.video_url.replace(/^"|"$/g, '');
          }

          return {
            ...ad,
            final_video_url: cleanVideoUrl,
            ad_images_url: normalizedAssets,
            storyboard_urls: normalizedStoryboards,
            characters: normalizedCharacters,
            ad_data: normalizedAdData,
            scenes: ad.scenes.sort((a: any, b: any) => a.scene_number - b.scene_number),
          };
        });

        setAds(sortedData as Ad[]);
      } catch (err) {
        console.error('Error fetching ads:', err);
        const message = err instanceof Error ? err.message : 'An unknown error occurred.';
        setError(`Failed to load library: ${message}`);
      } finally {
        setIsLoading(false);
      }
    };

  useEffect(() => {
    fetchAds();
  }, []);
  
  const handleGenerateFromScene = (params: GenerateVideoParams) => {
    onGenerate(params);
    setIsModalOpen(false);
    setCurrentSceneForModal(null);
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      setDeleteConfirmation({isOpen: true, adId: id});
  };

  const handleCloneClick = async (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      if (isCloning) return;
      
      setIsCloning(true);
      try {
          const newId = await duplicateAdProject(id);
          if (newId) {
              await fetchAds(); 
          } else {
              alert("Clone failed.");
          }
      } catch(e) {
          console.error(e);
          alert("Error cloning project.");
      } finally {
          setIsCloning(false);
      }
  };

  const handleResumeWizardClick = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      e.preventDefault();
      if (onOpenWizard) onOpenWizard(id);
  };

  const confirmDelete = async () => {
      const id = deleteConfirmation.adId;
      if (!id) return;
      
      setIsDeleting(true);
      try {
          const { data: scenes } = await supabase.from('dng1_ad_scenes').select('id').eq('ad_id', id);
          const sceneIds = scenes?.map(s => s.id) || [];
          if (sceneIds.length > 0) {
              await supabase.from('dng1_ad_scenes').delete().eq('ad_id', id);
          }
          const { error } = await supabase.from('dng1_ads').delete().eq('id', id);
          if (error) throw error;
          
          setAds(prev => prev.filter(ad => ad.id !== id));
          if (selectedAd?.id === id) setSelectedAd(null);
          setDeleteConfirmation({isOpen: false, adId: null});
      } catch (err: any) {
          console.error("Deep delete failed:", err);
          alert(`Failed to delete project: ${err.message}.`);
      } finally {
          setIsDeleting(false);
      }
  };

  const filteredAds = useMemo(() => {
    return ads.filter((ad) => {
        const matchesSearch = ad.ad_title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                              (ad.concept || '').toLowerCase().includes(searchQuery.toLowerCase());
        
        if (!matchesSearch) return false;

        if (activeFilter === 'All') return true;
        if (activeFilter === 'Video Gallery') return !!ad.final_video_url && ad.final_video_url.length > 0;
        if (activeFilter === 'Scenes') return (ad.scenes?.length || 0) > 0;
        if (activeFilter === 'Scripts') return (ad.scenes?.length || 0) === 0;

        const keyword = activeFilter.toLowerCase().slice(0, -1);
        const contentText = `${ad.ad_title} ${ad.concept || ''} ${ad.target_audience || ''}`.toLowerCase();
        return contentText.includes(keyword);
    });
  }, [ads, searchQuery, activeFilter]); 

  const totalPages = Math.ceil(filteredAds.length / ITEMS_PER_PAGE);
  const paginatedAds = filteredAds.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const FilterPill: React.FC<{ label: string, active: boolean, onClick: () => void }> = ({ label, active, onClick }) => (
      <button 
        onClick={onClick}
        className={`px-5 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap flex-shrink-0 border ${
            active 
            ? 'bg-black text-white border-black shadow-md transform scale-105' 
            : 'bg-white border-gray-200 text-gray-500 hover:border-gray-400 hover:text-gray-900'
        }`}
      >
          {label}
      </button>
  );

  const renderTabButton = (tabName: string, label: string, icon: React.ReactNode) => (
      <button 
          onClick={() => setDetailTab(tabName as any)} 
          className={`flex-1 pb-4 text-xs font-black uppercase tracking-widest transition-colors flex items-center justify-center gap-2 ${
              detailTab === tabName ? 'text-black border-b-2 border-black' : 'text-gray-400 hover:text-gray-600'
          }`}
      >
          {icon} {label}
      </button>
  );

  return (
    <div className="w-full h-full flex flex-col bg-gray-50 overflow-hidden relative">
        {isCloning && (
            <div className="absolute inset-0 z-[100] bg-white/80 backdrop-blur-sm flex flex-col items-center justify-center">
                <div className="bg-white p-8 rounded-2xl shadow-2xl border border-gray-100 flex flex-col items-center">
                    <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <h3 className="font-bold text-gray-900">Duplicating Project...</h3>
                    <p className="text-sm text-gray-500">Cloning scenes and re-casting characters.</p>
                </div>
            </div>
        )}

        <div className="px-6 py-6 bg-white border-b border-gray-200 flex flex-col gap-4 shrink-0 shadow-sm z-10">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <h2 className="text-2xl font-bold text-gray-900">Movie Library</h2>
                <div className="flex gap-4 items-center w-full md:w-auto">
                    <div className="relative flex-grow md:flex-grow-0 md:w-64">
                            <SearchIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
                            <input 
                            type="text" 
                            placeholder="Search projects..." 
                            className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            />
                    </div>
                    <button 
                        onClick={() => setIsQuickClipModalOpen(true)}
                        className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-bold text-sm shadow-md transition-colors whitespace-nowrap"
                    >
                        <BoltIcon className="w-4 h-4" /> Quick Clip
                    </button>
                    {onCreateNew && (
                        <button 
                            onClick={onCreateNew}
                            className="flex items-center gap-2 bg-[#9063CD] hover:bg-[#7b4ab9] text-white px-4 py-2 rounded-lg font-bold text-sm shadow-md transition-colors whitespace-nowrap"
                        >
                            <PlusIcon className="w-4 h-4" /> New Project
                        </button>
                    )}
                </div>
            </div>
            <div className="-mx-6 px-6 overflow-x-auto no-scrollbar pb-1">
                <div className="flex gap-3 w-max">
                    {filterOptions.map(opt => (
                        <FilterPill key={opt} label={opt} active={activeFilter === opt} onClick={() => setActiveFilter(opt)} />
                    ))}
                </div>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
            {isLoading ? (
                <div className="h-full flex items-center justify-center"><div className="w-8 h-8 border-4 border-t-transparent border-indigo-600 rounded-full animate-spin"></div></div>
            ) : error ? (
                <div className="text-center text-red-500 p-8">{error}</div>
            ) : filteredAds.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-400 pb-20">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <ClapperboardIcon className="w-8 h-8 opacity-20"/>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-1">No Projects Found</h3>
                    <p className="text-sm max-w-xs">Try adjusting your filters or create a new project to get started.</p>
                    {activeFilter !== 'All' && (
                        <button onClick={() => setActiveFilter('All')} className="mt-4 text-indigo-600 font-bold text-sm hover:underline">
                            Clear Filters
                        </button>
                    )}
                </div>
            ) : (
                <div className="flex flex-col h-full">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-6">
                        {paginatedAds.map(ad => (
                            <MovieCard 
                                key={ad.id} 
                                ad={ad} 
                                onClick={(ad) => setSelectedAd(ad)} 
                                onDelete={handleDeleteClick} 
                                onClone={handleCloneClick}
                                onOpenWizard={onOpenWizard}
                            />
                        ))}
                    </div>
                    {totalPages > 1 && (
                        <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-200">
                            <button 
                                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                                disabled={currentPage === 1}
                                className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1 transition-colors"
                            >
                                <ChevronRightIcon className="w-4 h-4 rotate-180" /> Previous
                            </button>
                            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">
                                Page {currentPage} of {totalPages}
                            </span>
                            <button 
                                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                                disabled={currentPage === totalPages}
                                className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1 transition-colors"
                            >
                                Next <ChevronRightIcon className="w-4 h-4" />
                            </button>
                        </div>
                    )}
                </div>
            )}
        </div>

        {/* --- Slide-Out Ad Detail Drawer --- */}
        {selectedAd && (
            <div className="absolute inset-0 z-50 flex justify-end bg-black/20 backdrop-blur-sm animate-fade-in-up" onClick={() => setSelectedAd(null)}>
                <div 
                    className="w-full max-w-5xl bg-white h-full shadow-2xl flex flex-col border-l border-gray-200 animate-slide-in-right" 
                    onClick={(e) => e.stopPropagation()}
                >
                    {/* Header */}
                    <div className="px-8 py-6 border-b border-gray-100 flex items-center justify-between bg-white shrink-0">
                        <div>
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">Project Details</span>
                            <h2 className="text-2xl font-black text-gray-900 leading-none uppercase tracking-tight">{selectedAd.ad_title}</h2>
                        </div>
                        <div className="flex gap-3 items-center">
                            {onOpenWizard && (
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onOpenWizard(selectedAd.id); }}
                                    className="bg-white border border-gray-200 text-gray-700 font-bold uppercase tracking-widest text-[10px] px-4 py-3 rounded-xl hover:bg-gray-50 transition-all flex items-center gap-2"
                                >
                                    <PresentationIcon className="w-3 h-3 text-[#9063CD]"/> View Storyboard
                                </button>
                            )}
                            <button 
                                onClick={(e) => { e.stopPropagation(); onEdit(selectedAd.id); }}
                                className="bg-black text-white font-black uppercase tracking-widest text-[10px] px-6 py-3 rounded-xl shadow-xl hover:bg-gray-800 transition-all flex items-center gap-2 hover:scale-[1.02]"
                            >
                                Enter Creative Studio <ArrowRightIcon className="w-3 h-3"/>
                            </button>
                            <button onClick={() => setSelectedAd(null)} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors">
                                <XMarkIcon className="w-6 h-6"/>
                            </button>
                        </div>
                    </div>

                    <div className="flex-1 overflow-y-auto no-scrollbar p-8 bg-gray-50/50">
                        <div className="space-y-8">
                            {/* Media Section (Highlight Area) */}
                            <div className="w-full aspect-video bg-black rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white ring-4 ring-gray-50 relative group">
                                {selectedAd.final_video_url ? (
                                    <video src={selectedAd.final_video_url} controls className="w-full h-full object-contain" poster={selectedAd.scenes?.[0]?.scene_image_url} />
                                ) : (
                                    <ProjectSlideshow images={selectedAd.scenes?.map(s => s.scene_image_url).filter(Boolean) as string[] || []} />
                                )}
                                {selectedAd.final_video_url && (
                                    <div className="absolute top-4 right-4 bg-[#9063CD] text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-md flex items-center gap-1">
                                        <PlayIcon className="w-3 h-3 fill-current"/> Final Master
                                    </div>
                                )}
                            </div>

                            {/* TABS */}
                            <div className="flex border-b border-gray-200">
                                {renderTabButton('concept', 'Creative Concept', <BoltIcon className="w-3 h-3"/>)}
                                {renderTabButton('cast', 'Assets & Cast', <UserIcon className="w-3 h-3"/>)}
                                {renderTabButton('scenes', 'Scene Breakdown', <ClapperboardIcon className="w-3 h-3"/>)}
                                {renderTabButton('storyboard', 'Storyboard Grid', <LayoutGridIcon className="w-3 h-3"/>)}
                                {renderTabButton('logs', 'Production Logs', <ListBulletIcon className="w-3 h-3"/>)}
                            </div>

                            {/* TAB CONTENT */}
                            <div className="animate-fade-in-up">
                                {detailTab === 'concept' && (
                                    <div className="space-y-6">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-sm">
                                                <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1 flex items-center gap-1"><UserIcon className="w-3 h-3"/> Target Audience</span>
                                                <p className="font-bold text-gray-900">{selectedAd.target_audience || 'General'}</p>
                                            </div>
                                            <div className="p-4 bg-white rounded-2xl border border-gray-200 shadow-sm">
                                                <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-1 flex items-center gap-1"><CalendarIcon className="w-3 h-3"/> Created</span>
                                                <p className="font-bold text-gray-900">{selectedAd.created_at ? new Date(selectedAd.created_at).toLocaleDateString() : 'N/A'}</p>
                                            </div>
                                        </div>
                                        
                                        <div>
                                            <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest border-b border-gray-100 pb-3 mb-4">Creative Concept</h3>
                                            {selectedAd.concept ? (
                                                <ScriptDisplay text={selectedAd.concept} />
                                            ) : (
                                                <p className="text-sm text-gray-400 italic">No concept description available.</p>
                                            )}
                                        </div>
                                    </div>
                                )}

                                {detailTab === 'cast' && (
                                    <div className="space-y-8">
                                        {/* 1. Characters */}
                                        <div>
                                            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2"><UserIcon className="w-3 h-3"/> Cast</h4>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                                {selectedAd.characters && selectedAd.characters.length > 0 ? (
                                                    selectedAd.characters.map((char: any, i: number) => (
                                                        <div key={i} className="flex flex-col items-center gap-3 p-4 bg-white rounded-2xl border border-gray-200 shadow-sm hover:border-[#9063CD] transition-all group">
                                                            <div className="w-16 h-16 rounded-full overflow-hidden bg-gray-50 border border-gray-100 shadow-inner">
                                                                {char.image_url ? <img src={char.image_url} alt={char.name} className="w-full h-full object-cover transition-transform group-hover:scale-110" /> : <div className="w-full h-full flex items-center justify-center text-gray-300"><UserIcon className="w-8 h-8"/></div>}
                                                            </div>
                                                            <div className="text-center w-full">
                                                                <p className="text-sm font-bold text-gray-900 truncate">{char.name}</p>
                                                                <p className="text-[9px] text-gray-500 uppercase font-bold tracking-wider">{char.role || 'Cast'}</p>
                                                            </div>
                                                        </div>
                                                    ))
                                                ) : (
                                                    <p className="text-sm text-gray-400 italic col-span-full">No cast assigned.</p>
                                                )}
                                            </div>
                                        </div>

                                        {/* 2. Locations */}
                                        <div>
                                            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2"><MapPinIcon className="w-3 h-3"/> Locations</h4>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                                {selectedAd.ad_data?.locations && selectedAd.ad_data.locations.length > 0 ? (
                                                    selectedAd.ad_data.locations.map((loc: any, i: number) => (
                                                        <div key={i} className="flex flex-col gap-3 p-4 bg-white rounded-2xl border border-gray-200 shadow-sm">
                                                            <div className="aspect-video rounded-lg overflow-hidden bg-gray-50 border border-gray-100">
                                                                {loc.imageUrl ? <img src={loc.imageUrl} alt={loc.name} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-gray-300"><MapPinIcon className="w-6 h-6"/></div>}
                                                            </div>
                                                            <div>
                                                                <p className="text-sm font-bold text-gray-900 truncate">{loc.name}</p>
                                                                <p className="text-[9px] text-gray-500 truncate">{loc.visual_style || 'Location'}</p>
                                                            </div>
                                                        </div>
                                                    ))
                                                ) : (
                                                    <p className="text-sm text-gray-400 italic col-span-full">No locations assigned.</p>
                                                )}
                                            </div>
                                        </div>

                                        {/* 3. Products */}
                                        <div>
                                            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 flex items-center gap-2"><CubeIcon className="w-3 h-3"/> Products</h4>
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                                {selectedAd.ad_data?.products && selectedAd.ad_data.products.length > 0 ? (
                                                    selectedAd.ad_data.products.map((prod: any, i: number) => {
                                                        const img = typeof prod.image === 'string' ? prod.image : prod.image?.primary;
                                                        return (
                                                            <div key={i} className="flex flex-col gap-3 p-4 bg-white rounded-2xl border border-gray-200 shadow-sm">
                                                                <div className="aspect-square rounded-lg overflow-hidden bg-gray-50 border border-gray-100 p-2">
                                                                    {img ? <img src={img} alt={prod.product_name} className="w-full h-full object-contain"/> : <div className="w-full h-full flex items-center justify-center text-gray-300"><CubeIcon className="w-6 h-6"/></div>}
                                                                </div>
                                                                <p className="text-sm font-bold text-gray-900 truncate">{prod.product_name}</p>
                                                            </div>
                                                        );
                                                    })
                                                ) : (
                                                    <p className="text-sm text-gray-400 italic col-span-full">No products assigned.</p>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {detailTab === 'scenes' && (
                                    <div className="space-y-6">
                                        {selectedAd.scenes && selectedAd.scenes.length > 0 ? (
                                            selectedAd.scenes.map((scene: any, i: number) => (
                                                <div key={i} className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden flex flex-col md:flex-row group hover:border-gray-300 transition-colors">
                                                    <div className="md:w-64 shrink-0 bg-gray-100 relative">
                                                        {scene.scene_image_url ? (
                                                            <img src={scene.scene_image_url} className="w-full h-full object-cover h-48 md:h-full" />
                                                        ) : (
                                                            <div className="w-full h-full flex items-center justify-center text-gray-300 h-48 md:h-full"><ClapperboardIcon className="w-10 h-10 opacity-20"/></div>
                                                        )}
                                                        <div className="absolute top-2 left-2 bg-black/60 text-white text-[9px] font-black px-2 py-1 rounded backdrop-blur-md uppercase tracking-widest">
                                                            Scene {scene.scene_number}
                                                        </div>
                                                    </div>
                                                    <div className="p-6 flex-1">
                                                        <h4 className="text-sm font-bold text-gray-900 mb-2 leading-snug">{scene.description.split('.')[0]}.</h4>
                                                        <div className="text-xs text-gray-600 leading-relaxed">
                                                            {scene.description}
                                                            {scene.scene_data && (
                                                                <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-1 gap-2">
                                                                    {scene.scene_data.audio_spec && (
                                                                        <div className="flex gap-3 items-start">
                                                                            <MusicIcon className="w-3 h-3 text-[#9063CD] mt-0.5 shrink-0"/>
                                                                            <div>
                                                                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider block">Audio</span>
                                                                                <p className="text-xs text-gray-700">
                                                                                    {scene.scene_data.audio_spec.dialogue || scene.scene_data.audio_spec.music || 'No audio spec.'}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                                    {scene.scene_data.transition && (
                                                                        <div className="flex gap-3 items-start">
                                                                            <LayersIcon className="w-3 h-3 text-indigo-500 mt-0.5 shrink-0"/>
                                                                            <div>
                                                                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider block">Transition</span>
                                                                                <p className="text-xs text-gray-700">
                                                                                    {scene.scene_data.transition.type}: {scene.scene_data.transition.description}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                </div>
                                            ))
                                        ) : (
                                            <div className="py-12 text-center text-gray-400">
                                                <ClapperboardIcon className="w-12 h-12 mx-auto mb-2 opacity-20"/>
                                                <p className="text-xs font-bold uppercase tracking-widest">No scenes generated yet</p>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {detailTab === 'storyboard' && (
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                        {(selectedAd.scenes || []).map((scene: any, i: number) => (
                                            <div key={i} className="flex flex-col gap-2">
                                                <div className="aspect-video bg-gray-100 rounded-xl overflow-hidden border border-gray-200 shadow-sm relative group">
                                                    {scene.scene_image_url ? (
                                                        <img src={scene.scene_image_url} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                                                    ) : (
                                                        <div className="w-full h-full flex items-center justify-center text-gray-300"><PhotoIcon className="w-8 h-8 opacity-20"/></div>
                                                    )}
                                                    <div className="absolute top-2 left-2 bg-black/60 text-white text-[9px] font-black px-2 py-0.5 rounded">
                                                        SC {scene.scene_number}
                                                    </div>
                                                </div>
                                                <p className="text-[10px] text-gray-600 font-medium line-clamp-2">{scene.description}</p>
                                            </div>
                                        ))}
                                        {(!selectedAd.scenes || selectedAd.scenes.length === 0) && (
                                            <div className="col-span-full py-12 text-center text-gray-400">
                                                <PresentationIcon className="w-12 h-12 mx-auto mb-2 opacity-20"/>
                                                <p className="text-xs font-bold uppercase tracking-widest">Storyboard is empty</p>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {detailTab === 'logs' && (
                                    <div className="bg-gray-900 rounded-2xl p-4 overflow-hidden shadow-inner font-mono text-xs">
                                        <div className="flex justify-between items-center mb-4 border-b border-gray-800 pb-2">
                                            <h4 className="text-gray-400 font-bold uppercase tracking-widest flex items-center gap-2">
                                                <BoltIcon className="w-3 h-3 text-green-500"/> Production Logs
                                            </h4>
                                            <span className="text-[10px] text-gray-600">LIVE FEED</span>
                                        </div>
                                        <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
                                            {(selectedAd.scenes || []).flatMap(s => (s.logs || []).map((l: any, idx: number) => ({ ...l, scene_number: s.scene_number, unique_id: `${s.id}-${idx}` })))
                                                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                                                .map((log: any) => (
                                                    <div key={log.unique_id} className="flex gap-4 items-start group">
                                                        <div className="text-gray-600 w-24 shrink-0">{new Date(log.timestamp).toLocaleTimeString()}</div>
                                                        <div className="flex-1">
                                                            <div className="flex items-center gap-2 mb-1">
                                                                <span className="text-indigo-400 font-bold">SCENE {log.scene_number}</span>
                                                                <span className={`uppercase text-[9px] px-1.5 py-0.5 rounded ${log.status === 'success' ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                                                                    {log.status}
                                                                </span>
                                                                <span className="text-gray-500">{log.action || 'Video Gen'}</span>
                                                            </div>
                                                            {log.prompt && (
                                                                <p className="text-gray-400 mb-1 leading-relaxed"><span className="text-gray-600">PROMPT:</span> {log.prompt}</p>
                                                            )}
                                                            {log.error_message && (
                                                                <p className="text-red-400 mb-1 bg-red-900/10 p-2 rounded border border-red-900/20">
                                                                    ERROR: {log.error_message}
                                                                    {log.rai_reasons && <span className="block mt-1 text-red-300">RAI: {log.rai_reasons.join(', ')}</span>}
                                                                </p>
                                                            )}
                                                            {log.api_response && (
                                                                <details className="mt-1">
                                                                    <summary className="cursor-pointer text-[10px] text-gray-500 hover:text-gray-300">View Raw API Response</summary>
                                                                    <pre className="mt-2 bg-black p-2 rounded border border-gray-800 text-gray-500 overflow-x-auto">
                                                                        {JSON.stringify(log.api_response, null, 2)}
                                                                    </pre>
                                                                </details>
                                                            )}
                                                        </div>
                                                    </div>
                                                ))
                                            }
                                            {(!selectedAd.scenes?.some(s => s.logs && s.logs.length > 0)) && (
                                                <p className="text-gray-600 italic text-center py-8">No generation logs available.</p>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Action Footer (Simplified - Delete Only) */}
                    <div className="p-6 border-t border-gray-200 bg-gray-50 shrink-0 flex justify-end">
                        <button 
                            onClick={(e) => handleDeleteClick(selectedAd.id, e)}
                            className="text-red-500 hover:text-red-700 font-bold text-xs flex items-center gap-2 px-4 py-2 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete Project"
                        >
                            <TrashIcon className="w-4 h-4"/> Delete Project
                        </button>
                    </div>
                </div>
            </div>
        )}

        {/* Generate Modal */}
        <Modal
            isOpen={isModalOpen}
            onClose={() => setIsModalOpen(false)}
            title={`Generate Video: Scene ${currentSceneForModal?.scene_number}`}
        >
            {currentSceneForModal && (
                <PromptForm 
                    onGenerate={handleGenerateFromScene} 
                    initialValues={{ prompt: currentSceneForModal.description || '' } as GenerateVideoParams}
                />
            )}
        </Modal>

        {/* Quick Clip Creator Modal (New) */}
        {isQuickClipModalOpen && (
            <QuickClipCreator 
                onClose={() => setIsQuickClipModalOpen(false)}
                onSuccess={() => {
                    setIsQuickClipModalOpen(false);
                    fetchAds();
                }}
            />
        )}

        {/* Custom Delete Confirmation Modal */}
        {deleteConfirmation.isOpen && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center bg-gray-900/50 backdrop-blur-sm animate-fade-in-up">
                <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl border border-gray-100 transform transition-all scale-100">
                    <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mb-4 mx-auto">
                        <AlertTriangleIcon className="w-6 h-6 text-red-500" />
                    </div>
                    <h3 className="text-xl font-bold text-center text-gray-900 mb-2">Delete Project?</h3>
                    <p className="text-sm text-gray-500 text-center mb-6 leading-relaxed">
                        This action is irreversible. It will permanently remove the project, all scenes, and generated assets.
                    </p>
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setDeleteConfirmation({isOpen: false, adId: null})}
                            className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-sm transition-colors"
                            disabled={isDeleting}
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={confirmDelete}
                            className="flex-1 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-sm shadow-lg transition-colors flex items-center justify-center gap-2"
                            disabled={isDeleting}
                        >
                            {isDeleting ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : "Delete Forever"}
                        </button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

export default AdsViewer;