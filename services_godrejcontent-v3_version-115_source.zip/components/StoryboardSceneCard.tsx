
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React from 'react';
import { 
    PhotoIcon, 
    MagicWandIcon, 
    EyeIcon, 
    PlusIcon, 
    LinkIcon, 
    TrashIcon, 
    XMarkIcon, 
    UserIcon, 
    MapPinIcon, 
    CubeIcon 
} from './icons';
import { SceneCard, CompositionAsset } from './StoryboardGenerator';

interface StoryboardSceneCardProps {
    scene: SceneCard;
    index: number;
    isLast: boolean;
    onGenerate: (id: string) => void;
    onUpdatePrompt: (id: string, value: string) => void;
    onToggleDebug: (id: string) => void;
    onSplit: (index: number) => void;
    onMerge: (index: number) => void;
    onDelete: (id: string) => void;
    onAddAsset: (sceneId: string, type: 'character' | 'setting' | 'product') => void;
    onRemoveAsset: (sceneId: string, type: 'character' | 'setting' | 'product', index?: number) => void;
}

export const IngredientChip: React.FC<{ 
    type: 'character' | 'setting' | 'product', 
    data?: CompositionAsset, 
    onClick: () => void,
    onRemove?: () => void,
    compact?: boolean
}> = ({ type, data, onClick, onRemove, compact }) => {
    const styles = {
        character: { bg: 'bg-purple-50', border: 'border-purple-200', iconColor: 'text-purple-500', label: 'Actor' },
        setting: { bg: 'bg-blue-50', border: 'border-blue-200', iconColor: 'text-blue-500', label: 'Location' },
        product: { bg: 'bg-orange-50', border: 'border-orange-200', iconColor: 'text-orange-500', label: 'Product' }
    }[type];

    if (data && data.name) {
        const displayName = typeof data.name === 'string' ? data.name.split(' ')[0] : 'Asset';
        return (
            <div className={`relative group flex items-center gap-2 pr-2 pl-1 py-1 rounded-full border bg-white shadow-sm hover:shadow-md transition-all cursor-pointer ${styles.border}`} onClick={onClick}>
                <div className="w-8 h-8 rounded-full overflow-hidden border border-gray-100 shrink-0">
                    {data.url ? (
                        <img src={data.url} className="w-full h-full object-cover" alt={displayName} />
                    ) : (
                        <div className={`w-full h-full flex items-center justify-center ${styles.bg}`}>
                            {type === 'character' ? <UserIcon className="w-4 h-4 text-gray-400"/> : <CubeIcon className="w-4 h-4 text-gray-400"/>}
                        </div>
                    )}
                </div>
                <div className="flex flex-col min-w-0 max-w-[80px]">
                    <span className="text-[8px] font-bold text-gray-400 uppercase tracking-wider">{styles.label}</span>
                    <span className="text-[10px] font-bold text-gray-900 truncate">{displayName}</span>
                </div>
                {onRemove && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); onRemove(); }}
                        className="ml-1 p-1 hover:bg-red-50 rounded-full text-gray-300 hover:text-red-500 transition-colors"
                    >
                        <XMarkIcon className="w-3 h-3"/>
                    </button>
                )}
            </div>
        );
    }

    return (
        <button 
            onClick={onClick}
            className={`flex flex-col items-center justify-center w-10 h-10 rounded-full border-2 border-dashed ${styles.border} ${styles.bg} hover:brightness-95 transition-all group`}
            title={`Add ${styles.label}`}
        >
            {type === 'character' && <UserIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'setting' && <MapPinIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            {type === 'product' && <CubeIcon className={`w-4 h-4 ${styles.iconColor}`} />}
            <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5 shadow-sm border border-gray-100">
                <PlusIcon className="w-2 h-2 text-gray-500"/>
            </div>
        </button>
    );
};

const StoryboardSceneCard: React.FC<StoryboardSceneCardProps> = ({ 
    scene, index, isLast, 
    onGenerate, onUpdatePrompt, onToggleDebug, 
    onSplit, onMerge, onDelete, 
    onAddAsset, onRemoveAsset 
}) => {
    return (
        <div className="bg-white rounded-[2.5rem] border border-gray-100 p-8 shadow-sm hover:shadow-xl transition-all group flex flex-col lg:flex-row gap-8 relative overflow-hidden">
            
            {/* Action Menu */}
            <div className="absolute top-6 right-6 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <button onClick={() => onToggleDebug(scene.id)} className="p-2 bg-gray-100 hover:bg-indigo-50 text-gray-400 hover:text-indigo-600 rounded-lg transition-colors"><EyeIcon className="w-4 h-4"/></button>
                <button onClick={() => onSplit(index)} className="p-2 bg-gray-100 hover:bg-indigo-50 text-gray-400 hover:text-indigo-600 rounded-lg transition-colors" title="Split Scene"><PlusIcon className="w-4 h-4"/></button>
                {!isLast && <button onClick={() => onMerge(index)} className="p-2 bg-gray-100 hover:bg-indigo-50 text-gray-400 hover:text-indigo-600 rounded-lg transition-colors" title="Merge Next"><LinkIcon className="w-4 h-4"/></button>}
                <button onClick={() => onDelete(scene.id)} className="p-2 bg-gray-100 hover:bg-red-50 text-gray-400 hover:text-red-600 rounded-lg transition-colors"><TrashIcon className="w-4 h-4"/></button>
            </div>

            {/* Left: Visual */}
            <div className="w-full lg:w-1/3 flex flex-col gap-4">
                <div className={`flex flex-col gap-3 ${scene.endImageUrl ? 'h-full' : ''}`}>
                    {/* Start Frame */}
                    <div className="aspect-video bg-gray-50 rounded-2xl overflow-hidden relative shadow-inner group/image border border-gray-200 shrink-0">
                        {scene.imageUrl ? (
                            <img src={scene.imageUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover/image:scale-105" />
                        ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center text-gray-300">
                                {scene.status === 'generating' ? <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-2"></div> : <PhotoIcon className="w-12 h-12 opacity-20 mb-2"/>}
                                <span className="text-[10px] font-bold uppercase tracking-widest">{scene.status === 'generating' ? 'Rendering...' : 'Start Frame'}</span>
                            </div>
                        )}
                        <div className="absolute top-3 left-3 bg-black/60 text-white text-[9px] font-black px-2 py-1 rounded-md backdrop-blur-md uppercase tracking-widest border border-white/10 flex items-center gap-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-green-400"></div> Scene {scene.scene_number} Start
                        </div>
                    </div>

                    {/* End Frame (Next Scene) */}
                    {scene.endImageUrl && (
                        <div className="aspect-video bg-gray-50 rounded-2xl overflow-hidden relative shadow-inner group/endimage border border-gray-200 shrink-0">
                            <img src={scene.endImageUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover/endimage:scale-105 opacity-90 hover:opacity-100" />
                            <div className="absolute top-3 left-3 bg-black/60 text-white text-[9px] font-black px-2 py-1 rounded-md backdrop-blur-md uppercase tracking-widest border border-white/10 flex items-center gap-1">
                                <div className="w-1.5 h-1.5 rounded-full bg-orange-400"></div> End Frame
                            </div>
                            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-0 group-hover/endimage:opacity-100 transition-opacity">
                                <span className="bg-black/50 text-white px-3 py-1 rounded-full text-[9px] font-bold uppercase backdrop-blur-md">Next Scene Start</span>
                            </div>
                        </div>
                    )}
                </div>

                <button 
                    onClick={() => onGenerate(scene.id)} 
                    disabled={scene.status === 'generating'} 
                    className="w-full py-4 bg-indigo-50 text-indigo-600 rounded-xl font-bold uppercase tracking-widest text-[10px] hover:bg-indigo-100 transition-all flex items-center justify-center gap-2 mt-auto"
                >
                    <MagicWandIcon className="w-3 h-3"/> {scene.imageUrl ? 'Regenerate Frame' : 'Generate Frame'}
                </button>
            </div>

            {/* Right: Director Controls */}
            <div className="flex-1 space-y-6">
                <div className="flex flex-col gap-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Action Description</label>
                    <textarea 
                        className="w-full bg-white text-lg font-medium text-gray-900 border-none outline-none resize-none p-0 focus:ring-0 placeholder-gray-300 h-24"
                        value={scene.editablePrompt || scene.visual_prompt_start}
                        onChange={(e) => onUpdatePrompt(scene.id, e.target.value)}
                        placeholder="Describe the scene action..."
                    />
                </div>

                {/* Composition Chips */}
                <div className="flex flex-wrap gap-2 mt-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
                    {/* Characters */}
                    {scene.composition?.characters?.map((char, i) => (
                        <IngredientChip 
                            key={i} 
                            type="character" 
                            data={char} 
                            onClick={() => {}} 
                            onRemove={() => onRemoveAsset(scene.id, 'character', i)} 
                        />
                    ))}
                    <IngredientChip type="character" onClick={() => onAddAsset(scene.id, 'character')} />
                    
                    {/* Location */}
                    <IngredientChip 
                        type="setting" 
                        data={scene.composition?.location} 
                        onClick={() => onAddAsset(scene.id, 'setting')} 
                        onRemove={() => onRemoveAsset(scene.id, 'setting')}
                    />
                    
                    {/* Product */}
                    <IngredientChip 
                        type="product" 
                        data={scene.composition?.product} 
                        onClick={() => onAddAsset(scene.id, 'product')} 
                        onRemove={() => onRemoveAsset(scene.id, 'product')}
                    />
                </div>

                {/* Debug View */}
                {scene.showDebug && (
                    <div className="mt-4 p-4 bg-gray-900 rounded-xl overflow-x-auto text-[10px] font-mono text-green-400">
                        <pre>{JSON.stringify({
                            scene_description: scene.description,
                            assigned_assets: {
                                characters: scene.composition?.characters?.map(c => c.name) || [],
                                location: scene.composition?.location?.name || 'None',
                                product: scene.composition?.product?.name || 'None'
                            },
                            generated_prompt: `${scene.editablePrompt || scene.visual_prompt_start}`
                        }, null, 2)}</pre>
                    </div>
                )}
            </div>
        </div>
    );
};

export default StoryboardSceneCard;
