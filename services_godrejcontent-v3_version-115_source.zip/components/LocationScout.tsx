
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { Influencer, AspectRatio } from '../types';
import { editImage } from '../services/geminiService';
import { uploadBlob, updateCharacter, supabase } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    MapIcon, 
    UploadCloudIcon, 
    SearchIcon, 
    MapPinIcon, 
    PhotoIcon, 
    GlobeAltIcon, 
    CheckCircleIcon 
} from './icons';

interface LocationScoutProps { 
    character: Influencer; 
    onClose: () => void; 
    onSuccess: () => void; 
}

// Helper functions for this component
const urlToBase64 = async (url: string): Promise<string> => {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(blob);
    });
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
             const base64 = (reader.result as string).split(',')[1];
             resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

const MAP_LOCATIONS = [
    { name: "Paris, Eiffel Tower", color: "bg-blue-100 text-blue-600" },
    { name: "New York, Times Square", color: "bg-indigo-100 text-indigo-600" },
    { name: "Tokyo, Shibuya Crossing", color: "bg-pink-100 text-pink-600" },
    { name: "Cape Town, Beach", color: "bg-orange-100 text-orange-600" },
    { name: "London, Big Ben", color: "bg-red-100 text-red-600" },
    { name: "Dubai, Skyline", color: "bg-amber-100 text-amber-600" }
];

const LocationScout: React.FC<LocationScoutProps> = ({ character, onClose, onSuccess }) => {
    const [tab, setTab] = useState<'map' | 'upload'>('map');
    const [locationName, setLocationName] = useState('');
    const [mapQuery, setMapQuery] = useState('');
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    
    // Processing
    const [isTeleporting, setIsTeleporting] = useState(false);
    const [generatedScene, setGeneratedScene] = useState<string | null>(null);

    const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setUploadedFile(file);
            setPreviewUrl(URL.createObjectURL(file));
            setLocationName(file.name.split('.')[0]);
        }
    };

    const handleTeleport = async () => {
        const charImg = character.image_url || character.image_urls_jsonb?.[0]?.url;
        if (!charImg) { alert("Character needs a base image."); return; }
        
        setIsTeleporting(true);
        try {
            const charB64 = await urlToBase64(charImg);
            let locationB64 = '';
            let locPrompt = '';

            if (tab === 'map') {
                if (!mapQuery && !locationName) { alert("Select or type a location."); setIsTeleporting(false); return; }
                locPrompt = mapQuery || locationName;
            } else {
                if (!uploadedFile) { alert("Upload a background."); setIsTeleporting(false); return; }
                locationB64 = await fileToBase64(uploadedFile);
            }

            // Using Nano Banana (2.5 Flash Image) for "Teleport" / Edit
            const finalPrompt = `Put character in ${locPrompt || locationName}. Photorealistic, cinematic lighting. Match background lighting.`;
            
            const result = await editImage(
                charB64, 
                finalPrompt, 
                locationB64 || undefined, 
                AspectRatio.SQUARE, 
                'gemini-2.5-flash-image'
            );

            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const fileName = `teleport_${character.name}_${Date.now()}.png`;
            const url = await uploadBlob(blob, fileName, 'godrej/locations');

            if (url) {
                setGeneratedScene(url);
                // Auto-save to gallery
                const pk = character.character_id || character.id;
                const { data: freshChar } = await supabase.from('dng1_characters').select('image_urls_jsonb').eq('character_id', pk).single();
                const newGallery = [{ url, type: 'location_teleport', description: `Location: ${locationName || locPrompt}` }, ...(freshChar?.image_urls_jsonb || [])];
                await updateCharacter(pk!, { image_urls_jsonb: newGallery });
                onSuccess();
            }

        } catch (e: any) {
            console.error(e);
            alert(`Teleport failed: ${e.message}`);
        } finally {
            setIsTeleporting(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[160] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-4xl h-[80vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden relative">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors z-20"><XMarkIcon className="w-6 h-6"/></button>
                
                {/* Left: Input */}
                <div className="w-1/2 bg-gray-50 p-8 flex flex-col border-r border-gray-200 overflow-y-auto">
                    <div className="mb-6">
                        <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight mb-2">Location Scout</h3>
                        <p className="text-xs text-gray-500 font-bold uppercase tracking-widest">Select Environment</p>
                    </div>

                    <div className="flex bg-white p-1 rounded-xl mb-6 shadow-sm">
                        <button onClick={() => setTab('map')} className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${tab === 'map' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}><MapIcon className="w-3 h-3 inline mr-2"/> Virtual Map</button>
                        <button onClick={() => setTab('upload')} className={`flex-1 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${tab === 'upload' ? 'bg-indigo-600 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'}`}><UploadCloudIcon className="w-3 h-3 inline mr-2"/> Upload Plate</button>
                    </div>

                    {tab === 'map' ? (
                        <div className="space-y-4">
                            <div className="relative">
                                <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400"/>
                                <input 
                                    className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-indigo-500 outline-none"
                                    placeholder="Type city or place (e.g. Lagos Market)"
                                    value={mapQuery}
                                    onChange={(e) => setMapQuery(e.target.value)}
                                />
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                {MAP_LOCATIONS.map(loc => (
                                    <button 
                                        key={loc.name}
                                        onClick={() => { setMapQuery(loc.name); setLocationName(loc.name); }}
                                        className={`p-3 rounded-xl text-[10px] font-bold uppercase tracking-wide text-left transition-all hover:scale-105 ${loc.color}`}
                                    >
                                        <MapPinIcon className="w-3 h-3 inline mr-1 mb-0.5"/> {loc.name}
                                    </button>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <div className="w-full aspect-video bg-white border-2 border-dashed border-gray-300 rounded-xl flex flex-col items-center justify-center text-gray-400 cursor-pointer hover:bg-gray-50 relative overflow-hidden group">
                                {previewUrl ? <img src={previewUrl} className="w-full h-full object-cover"/> : <><PhotoIcon className="w-8 h-8 mb-2"/><span className="text-xs font-bold">Click to Upload</span></>}
                                <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleUpload} accept="image/*" />
                            </div>
                            <input 
                                className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-bold outline-none"
                                placeholder="Location Name (Optional)"
                                value={locationName}
                                onChange={(e) => setLocationName(e.target.value)}
                            />
                        </div>
                    )}

                    <div className="mt-auto pt-6">
                        <button 
                            onClick={handleTeleport}
                            disabled={isTeleporting}
                            className="w-full py-4 bg-black text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                            {isTeleporting ? 'Teleporting...' : 'Map Character to Location'} <GlobeAltIcon className="w-4 h-4"/>
                        </button>
                    </div>
                </div>

                {/* Right: Result */}
                <div className="w-1/2 bg-gray-900 p-8 flex flex-col items-center justify-center relative">
                    {generatedScene ? (
                        <div className="relative w-full aspect-square rounded-3xl overflow-hidden shadow-2xl border-4 border-indigo-500 animate-fade-in-up">
                            <img src={generatedScene} className="w-full h-full object-cover" />
                            <div className="absolute bottom-4 left-4 bg-green-500 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest shadow-lg flex items-center gap-2">
                                <CheckCircleIcon className="w-3 h-3"/> Saved to Gallery
                            </div>
                        </div>
                    ) : (
                        <div className="text-center text-gray-600">
                            <GlobeAltIcon className="w-24 h-24 opacity-20 mx-auto mb-4"/>
                            <p className="text-sm font-bold uppercase tracking-widest">Waiting for Teleport</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default LocationScout;
