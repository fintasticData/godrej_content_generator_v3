
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { 
    fetchContentItems, 
    createContentItem, 
    updateContentItem,
    ensureSceneForContentItem, 
    upsertSchedule, 
    fetchSchedule, 
    updateApprovalStatus,
    updateContentItemStatus,
    supabase,
    uploadBlob
} from '../services/supabaseClient';
import { brainstormContentIdeas, generateImage } from '../services/geminiService';
import { ContentItem, ContentChannel, ContentType, SceneSchedule, Influencer, AspectRatio } from '../types';
import { 
    PlusIcon, 
    BoltIcon, 
    CalendarDaysIcon, 
    ClockIcon, 
    CheckCircleIcon, 
    XMarkIcon, 
    ArrowRightIcon, 
    AlertTriangleIcon, 
    EyeIcon, 
    SparklesIcon, 
    RocketIcon, 
    PhotoIcon, 
    FilmIcon, 
    LayoutGridIcon, 
    ListBulletIcon, 
    Square2StackIcon,
    PencilSquareIcon,
    SaveIcon
} from './icons';
import Modal from './Modal';
import QuickClipCreator from './QuickClipCreator';

interface ContentEngineProps {
    character: Influencer;
    onCharacterUpdate?: (updatedCharacter: Influencer) => void;
}

type ViewMode = 'list' | 'grid';

const urlToBase64 = async (url: string): Promise<string> => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(blob);
        });
    } catch { return ""; }
};

const ContentEngine: React.FC<ContentEngineProps> = ({ character, onCharacterUpdate }) => {
    const [activeTab, setActiveTab] = useState<ContentChannel>('social');
    const [viewMode, setViewMode] = useState<ViewMode>('grid');
    const [items, setItems] = useState<ContentItem[]>([]);
    const [schedules, setSchedules] = useState<SceneSchedule[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    
    // Selection State
    const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());

    // Create State
    const [showCreateModal, setShowCreateModal] = useState(false);
    const [newItemTheme, setNewItemTheme] = useState('');
    const [newItemType, setNewItemType] = useState<ContentType>('image');
    const [newItemBrief, setNewItemBrief] = useState('');
    
    // Brainstorm State
    const [showBrainstormModal, setShowBrainstormModal] = useState(false);
    const [brainstormTopic, setBrainstormTopic] = useState('');
    const [brainstormFormat, setBrainstormFormat] = useState<AspectRatio>(AspectRatio.SQUARE);
    const [isBrainstorming, setIsBrainstorming] = useState(false);
    const [brainstormCount, setBrainstormCount] = useState(5);

    // Bulk Run State
    const [isBulkRunning, setIsBulkRunning] = useState(false);

    // Schedule State
    const [showScheduleModal, setShowScheduleModal] = useState(false);
    const [showBulkScheduleModal, setShowBulkScheduleModal] = useState(false);
    const [scheduleItem, setScheduleItem] = useState<ContentItem | null>(null);
    const [scheduleDate, setScheduleDate] = useState('');
    const [schedulePlatform, setSchedulePlatform] = useState('Instagram');
    const [isScheduling, setIsScheduling] = useState(false);
    
    // Bulk Schedule Config
    const [bulkInterval, setBulkInterval] = useState(24); // Hours

    // Preview & Quick Clip State
    const [previewImage, setPreviewImage] = useState<string | null>(null);
    const [quickClipItem, setQuickClipItem] = useState<ContentItem | null>(null);

    // Editing State
    const [editingItemId, setEditingItemId] = useState<string | null>(null);
    const [editTheme, setEditTheme] = useState('');
    const [editBrief, setEditBrief] = useState('');
    const [isSavingEdit, setIsSavingEdit] = useState(false);

    useEffect(() => {
        loadData();
        setSelectedItemIds(new Set()); // Clear selection on tab change/load
    }, [character.character_id, character.id, activeTab]);

    const loadData = async () => {
        const id = character.character_id || character.id;
        if (!id) return;
        setIsLoading(true);
        const [iData, sData] = await Promise.all([
            fetchContentItems(id, activeTab),
            fetchSchedule(id)
        ]);
        setItems(iData);
        setSchedules(sData);
        setIsLoading(false);
    };

    const toggleSelection = (id: string, status: string) => {
        if (status !== 'ready') return; // Only allow selecting ready items
        setSelectedItemIds(prev => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });
    };

    const handleCreateItem = async () => {
        const id = character.character_id || character.id;
        if (!id || !newItemTheme) return;
        
        await createContentItem({
            character_id: id,
            channel: activeTab,
            content_type: newItemType,
            theme: newItemTheme,
            brief: newItemBrief,
            status: 'draft',
            meta_jsonb: {}
        });
        setShowCreateModal(false);
        setNewItemTheme('');
        setNewItemBrief('');
        loadData();
    };

    const handleBrainstorm = async () => {
        const id = character.character_id || character.id;
        if (!id || !brainstormTopic) return;

        setIsBrainstorming(true);
        try {
            const context = `Character: ${character.name} (${character.role}). Bio: ${character.description || character.origin_story}.`;
            const ideas = await brainstormContentIdeas(context, brainstormTopic, brainstormCount, activeTab);
            
            for (const idea of ideas) {
                await createContentItem({
                    character_id: id,
                    channel: activeTab,
                    content_type: activeTab === 'video_reels' ? 'reel' : 'image', // Intelligent default
                    theme: idea.caption ? idea.caption.substring(0, 50) + '...' : `Idea: ${idea.day}`,
                    brief: idea.visual_prompt || idea.caption,
                    status: 'draft',
                    meta_jsonb: { 
                        source: 'ai_brainstorm', 
                        day: idea.day,
                        video_prompt: idea.video_prompt,
                        aspect_ratio: brainstormFormat // Store selected aspect ratio
                    }
                });
            }
            
            setShowBrainstormModal(false);
            setBrainstormTopic('');
            loadData();
        } catch (e) {
            console.error(e);
            alert("Brainstorming failed. Try again.");
        } finally {
            setIsBrainstorming(false);
        }
    };

    const handleRunEngine = async (item: ContentItem) => {
        // Optimistic Update
        setItems(prev => prev.map(i => i.content_item_id === item.content_item_id ? { ...i, status: 'generating' as const } : i));
        
        try {
            // 1. Determine Model & Reference
            const promptText = `${item.brief || item.theme}. Style: Social Media Content, High Quality, Engaging.`;
            const isComplex = promptText.length > 150 || promptText.toLowerCase().includes('product') || promptText.toLowerCase().includes('detailed');
            
            // Force Nano Banana Pro if complex, otherwise Nano Banana
            const modelToUse = isComplex ? 'gemini-3-pro-image-preview' : 'gemini-2.5-flash-image';
            
            // Determine Aspect Ratio from Metadata or Fallback
            let ratio = AspectRatio.SQUARE;
            if (item.meta_jsonb?.aspect_ratio) {
                ratio = item.meta_jsonb.aspect_ratio as AspectRatio;
            } else {
                const isVertical = item.content_type === 'reel' || item.content_type === 'story';
                ratio = isVertical ? AspectRatio.PORTRAIT : AspectRatio.SQUARE;
            }

            // Prepare Character Reference (Identity Anchor)
            let charBase64 = '';
            const charImg = character.image_url || character.image_urls_jsonb?.[0]?.url;
            if (charImg) {
                charBase64 = await urlToBase64(charImg);
            }

            const prompt = `
                Subject: ${character.name}. 
                Action/Context: ${promptText}. 
                ${charBase64 ? "Maintain character identity exactly." : ""}
            `;

            // 2. Generate
            const result = await generateImage(
                prompt, 
                ratio, 
                charBase64 ? { character: charBase64 } : undefined, 
                undefined, 
                modelToUse
            );
            
            // 3. Upload Result
            const blob = await (await fetch(`data:${result.mimeType};base64,${result.base64}`)).blob();
            const fileName = `content_${item.content_item_id}_${Date.now()}.png`;
            const publicUrl = await uploadBlob(blob, fileName, 'godrej/content_engine');

            if (publicUrl) {
                // 4. Update Content Item DB
                const newMeta = { 
                    ...item.meta_jsonb, 
                    generated_assets: [publicUrl],
                    last_generated_at: new Date().toISOString(),
                    model_used: modelToUse
                };

                await supabase
                    .from('dng1_character_content_items')
                    .update({ 
                        status: 'ready', 
                        meta_jsonb: newMeta 
                    })
                    .eq('content_item_id', item.content_item_id);

                // 5. Update Character Gallery (Sync to Visual Tab)
                const charId = character.character_id || character.id;
                if (charId) {
                    const { data: charData } = await supabase
                        .from('dng1_characters')
                        .select('*')
                        .eq('character_id', charId)
                        .single();
                    
                    if (charData) {
                        const currentGallery = charData.image_urls_jsonb || [];
                        const newGalleryItem = { 
                            url: publicUrl, 
                            type: 'content_engine', 
                            description: item.theme 
                        };
                        const updatedGallery = [newGalleryItem, ...currentGallery];
                        
                        await supabase
                            .from('dng1_characters')
                            .update({ image_urls_jsonb: updatedGallery })
                            .eq('character_id', charId);
                    }
                }

                // 6. Update Local State
                setItems(prev => prev.map(i => i.content_item_id === item.content_item_id ? { 
                    ...i, 
                    status: 'ready',
                    meta_jsonb: newMeta
                } : i));
            } else {
                throw new Error("Upload failed");
            }

        } catch (e) {
            console.error("Content generation failed", e);
            setItems(prev => prev.map(i => i.content_item_id === item.content_item_id ? { ...i, status: 'failed' } : i));
        }
    };

    const startEditing = (item: ContentItem) => {
        setEditingItemId(item.content_item_id);
        setEditTheme(item.theme || '');
        setEditBrief(item.brief || '');
    };

    const cancelEditing = () => {
        setEditingItemId(null);
        setEditTheme('');
        setEditBrief('');
    };

    const saveEditing = async (item: ContentItem) => {
        if (!editTheme) return;
        setIsSavingEdit(true);
        try {
            await updateContentItem(item.content_item_id, {
                theme: editTheme,
                brief: editBrief
            });
            setItems(prev => prev.map(i => i.content_item_id === item.content_item_id ? { ...i, theme: editTheme, brief: editBrief } : i));
            setEditingItemId(null);
        } catch (e) {
            console.error(e);
            alert("Failed to save changes.");
        } finally {
            setIsSavingEdit(false);
        }
    };

    const handleBulkRun = async () => {
        const drafts = items.filter(i => i.status === 'draft');
        if (drafts.length === 0) return;

        setIsBulkRunning(true);
        setItems(prev => prev.map(i => i.status === 'draft' ? { ...i, status: 'generating' as const } : i));

        try {
            for (const item of drafts) {
                await handleRunEngine(item);
            }
        } catch (e) {
            console.error("Bulk run error", e);
        } finally {
            setIsBulkRunning(false);
        }
    };

    const openScheduleModal = (item: ContentItem) => {
        setScheduleItem(item);
        setScheduleDate('');
        setShowScheduleModal(true);
    };

    const handleSchedule = async () => {
        if (!scheduleItem || !scheduleDate) return;
        setIsScheduling(true);
        try {
            const sceneId = await ensureSceneForContentItem(scheduleItem, `Content - ${scheduleItem.theme}`);
            if (!sceneId) throw new Error("Could not create scene link");

            await upsertSchedule({
                scene_id: sceneId,
                character_id: scheduleItem.character_id,
                channel: scheduleItem.channel,
                platform: schedulePlatform,
                scheduled_for: new Date(scheduleDate).toISOString(),
                publish_status: 'pending_approval',
                requires_approval: true,
                approver1_status: 'pending',
                approver2_status: 'pending',
                approver3_status: 'pending'
            });

            await updateContentItemStatus(scheduleItem.content_item_id, 'scheduled');
            setShowScheduleModal(false);
            loadData();
        } catch (e) {
            console.error(e);
            alert("Scheduling failed");
        } finally {
            setIsScheduling(false);
        }
    };

    const handleBulkSchedule = async () => {
        if (!scheduleDate || selectedItemIds.size === 0) return;
        setIsScheduling(true);
        try {
            const ids = Array.from(selectedItemIds);
            let currentTime = new Date(scheduleDate).getTime();
            const intervalMs = bulkInterval * 60 * 60 * 1000;

            for (const id of ids) {
                const item = items.find(i => i.content_item_id === id);
                if (!item) continue;

                const sceneId = await ensureSceneForContentItem(item, `Content - ${item.theme}`);
                if (!sceneId) continue;

                await upsertSchedule({
                    scene_id: sceneId,
                    character_id: item.character_id,
                    channel: item.channel,
                    platform: schedulePlatform,
                    scheduled_for: new Date(currentTime).toISOString(),
                    publish_status: 'pending_approval',
                    requires_approval: true,
                    approver1_status: 'pending',
                    approver2_status: 'pending',
                    approver3_status: 'pending'
                });

                await updateContentItemStatus(item.content_item_id, 'scheduled');
                currentTime += intervalMs;
            }
            
            setShowBulkScheduleModal(false);
            setSelectedItemIds(new Set());
            loadData();
        } catch(e) {
            console.error(e);
            alert("Bulk scheduling failed partially or fully.");
        } finally {
            setIsScheduling(false);
        }
    }

    const handleApproval = async (scheduleId: string, approver: string, status: string) => {
        await updateApprovalStatus(scheduleId, approver, status);
        loadData();
    };

    const getScheduleForItem = (item: ContentItem) => {
        if (!item.meta_jsonb?.scene_id) return null;
        return schedules.find(s => s.scene_id === item.meta_jsonb!.scene_id);
    };

    const StatusPill: React.FC<{ status: string }> = ({ status }) => {
        const colors: any = {
            draft: 'bg-gray-100 text-gray-500',
            generating: 'bg-blue-50 text-blue-600 animate-pulse',
            ready: 'bg-green-50 text-green-600',
            scheduled: 'bg-purple-50 text-purple-600',
            pending_approval: 'bg-amber-50 text-amber-600',
            approved: 'bg-indigo-50 text-indigo-600',
            posted: 'bg-emerald-100 text-emerald-800',
            failed: 'bg-red-50 text-red-600'
        };
        return <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wide ${colors[status] || 'bg-gray-100'}`}>{status.replace('_', ' ')}</span>;
    };

    return (
        <div className="flex flex-col h-full bg-gray-50 relative">
            {/* Toolbar */}
            <div className="flex justify-between items-center p-6 bg-white border-b border-gray-200">
                <div className="flex bg-gray-100 p-1 rounded-xl">
                    {['social', 'campaign', 'portfolio', 'video_reels'].map(c => (
                        <button 
                            key={c}
                            onClick={() => setActiveTab(c as any)}
                            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${activeTab === c ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            {c.replace('_', ' ')}
                        </button>
                    ))}
                </div>
                <div className="flex items-center gap-2">
                    <div className="flex bg-gray-100 p-1 rounded-xl mr-2">
                        <button onClick={() => setViewMode('list')} className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-white shadow text-black' : 'text-gray-400 hover:text-gray-600'}`} title="List View"><ListBulletIcon className="w-4 h-4"/></button>
                        <button onClick={() => setViewMode('grid')} className={`p-2 rounded-lg transition-all ${viewMode === 'grid' ? 'bg-white shadow text-black' : 'text-gray-400 hover:text-gray-600'}`} title="Grid View"><LayoutGridIcon className="w-4 h-4"/></button>
                    </div>
                    <button onClick={() => setShowBrainstormModal(true)} className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold rounded-xl shadow-lg transition-all text-xs uppercase tracking-widest">
                        <SparklesIcon className="w-4 h-4"/> AI Brainstorm
                    </button>
                    <button onClick={() => setShowCreateModal(true)} className="flex items-center gap-2 px-5 py-2.5 bg-white border border-gray-200 text-gray-700 font-bold rounded-xl shadow-sm hover:bg-gray-50 transition-all text-xs uppercase tracking-widest">
                        <PlusIcon className="w-4 h-4"/> Add Idea
                    </button>
                </div>
            </div>

            {/* List Header / Bulk Action */}
            <div className="px-6 pt-4 flex justify-between items-center">
                <div className="flex items-center gap-3">
                    <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest">{activeTab} Backlog</h3>
                    {selectedItemIds.size > 0 && (
                        <button 
                            onClick={() => { setScheduleDate(''); setShowBulkScheduleModal(true); }}
                            className="text-xs font-bold text-white bg-black px-4 py-1.5 rounded-lg flex items-center gap-2 animate-fade-in-up"
                        >
                            <CalendarDaysIcon className="w-3 h-3"/> Schedule {selectedItemIds.size} Items
                        </button>
                    )}
                </div>
                
                {items.some(i => i.status === 'draft') && (
                    <button onClick={handleBulkRun} disabled={isBulkRunning} className="text-xs font-bold text-indigo-600 flex items-center gap-2 hover:bg-indigo-50 px-3 py-1 rounded-lg transition-colors">
                        {isBulkRunning ? <div className="w-3 h-3 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div> : <BoltIcon className="w-3 h-3"/>}
                        Run Engine for All Drafts ({items.filter(i => i.status === 'draft').length})
                    </button>
                )}
            </div>

            {/* Content List */}
            <div className="flex-1 overflow-y-auto p-6">
                {isLoading ? (
                    <div className="flex justify-center p-10"><div className="w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div></div>
                ) : items.length === 0 ? (
                    <div className="text-center text-gray-400 py-20 flex flex-col items-center">
                        <RocketIcon className="w-12 h-12 opacity-20 mb-4"/>
                        <p className="text-sm font-bold uppercase tracking-widest">No content planned for {activeTab}</p>
                        <button onClick={() => setShowBrainstormModal(true)} className="mt-4 text-indigo-600 font-bold text-xs hover:underline">Use AI to generate ideas</button>
                    </div>
                ) : (
                    viewMode === 'list' ? (
                        // LIST VIEW
                        <div className="space-y-4">
                            {items.map(item => {
                                const sched = getScheduleForItem(item);
                                const displayStatus = sched ? sched.publish_status : item.status;
                                const generatedImage = item.meta_jsonb?.generated_assets?.[0];
                                const isSelected = selectedItemIds.has(item.content_item_id);
                                const videoPrompt = item.meta_jsonb?.video_prompt;
                                const isEditing = editingItemId === item.content_item_id;

                                return (
                                    <div 
                                        key={item.content_item_id} 
                                        className={`bg-white p-6 rounded-2xl border shadow-sm flex flex-col gap-4 group transition-colors relative ${isSelected ? 'border-indigo-600 ring-1 ring-indigo-200 bg-indigo-50/20' : 'border-gray-100 hover:border-indigo-200'}`}
                                    >
                                        {item.status === 'ready' && (
                                            <div className="absolute top-4 left-4 z-20">
                                                <input 
                                                    type="checkbox" 
                                                    checked={isSelected} 
                                                    onChange={() => toggleSelection(item.content_item_id, item.status)}
                                                    className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer opacity-0 group-hover:opacity-100 checked:opacity-100 transition-opacity"
                                                />
                                            </div>
                                        )}

                                        <div className="flex flex-col md:flex-row gap-6 pl-6">
                                            {/* Preview Area */}
                                            <div className="w-full md:w-48 aspect-square shrink-0 bg-gray-50 rounded-xl overflow-hidden border border-gray-100 relative group/image">
                                                {generatedImage ? (
                                                    <>
                                                        <img src={generatedImage} className="w-full h-full object-cover transition-transform duration-700 hover:scale-105 cursor-pointer" onClick={() => setPreviewImage(generatedImage)} />
                                                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover/image:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                                            <button onClick={() => setPreviewImage(generatedImage)} className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white backdrop-blur-sm transition-colors" title="Preview"><EyeIcon className="w-4 h-4"/></button>
                                                            <button onClick={() => setQuickClipItem(item)} className="p-2 bg-indigo-600 hover:bg-indigo-700 rounded-full text-white shadow-lg transition-colors" title="Quick Clip"><BoltIcon className="w-4 h-4"/></button>
                                                        </div>
                                                    </>
                                                ) : (
                                                    <div className="w-full h-full flex flex-col items-center justify-center text-gray-300">
                                                        {item.status === 'generating' ? (
                                                            <>
                                                                <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-2"></div>
                                                                <span className="text-[9px] font-bold uppercase tracking-widest text-indigo-400">Rendering...</span>
                                                            </>
                                                        ) : (
                                                            <>
                                                                {item.content_type === 'video' || item.content_type === 'reel' ? <FilmIcon className="w-8 h-8 opacity-20"/> : <PhotoIcon className="w-8 h-8 opacity-20"/>}
                                                                <span className="text-[9px] font-bold uppercase tracking-widest mt-2 opacity-50">Pending</span>
                                                            </>
                                                        )}
                                                    </div>
                                                )}
                                                {item.content_type === 'video' || item.content_type === 'reel' ? (
                                                    <div className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full"><FilmIcon className="w-3 h-3"/></div>
                                                ) : null}
                                            </div>

                                            {/* Content Info */}
                                            <div className="flex-1 flex flex-col">
                                                <div className="flex justify-between items-start mb-2">
                                                    <div className="w-full">
                                                        <div className="flex items-center gap-3 mb-2">
                                                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded">{item.content_type}</span>
                                                            <StatusPill status={displayStatus} />
                                                            {item.meta_jsonb?.aspect_ratio && (
                                                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-gray-50 px-2 py-1 rounded">
                                                                    {item.meta_jsonb.aspect_ratio === AspectRatio.SQUARE ? '1:1' : item.meta_jsonb.aspect_ratio === AspectRatio.PORTRAIT ? '9:16' : '16:9'}
                                                                </span>
                                                            )}
                                                        </div>
                                                        {isEditing ? (
                                                            <input 
                                                                className="font-bold text-lg text-gray-900 leading-tight w-full bg-gray-50 border-b border-indigo-300 outline-none mb-2"
                                                                value={editTheme}
                                                                onChange={(e) => setEditTheme(e.target.value)}
                                                            />
                                                        ) : (
                                                            <div className="flex items-center gap-2 group/title">
                                                                <h4 className="font-bold text-lg text-gray-900 leading-tight">{item.theme}</h4>
                                                                {!generatedImage && <button onClick={() => startEditing(item)} className="text-gray-400 hover:text-indigo-600 opacity-0 group-hover/title:opacity-100 transition-opacity"><PencilSquareIcon className="w-4 h-4"/></button>}
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div className="flex gap-2 opacity-100 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity">
                                                        {isEditing ? (
                                                            <>
                                                                <button onClick={() => saveEditing(item)} disabled={isSavingEdit} className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100"><CheckCircleIcon className="w-4 h-4"/></button>
                                                                <button onClick={cancelEditing} className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100"><XMarkIcon className="w-4 h-4"/></button>
                                                            </>
                                                        ) : (
                                                            <>
                                                                {item.status === 'draft' || item.status === 'ready' || item.status === 'failed' ? (
                                                                    <button 
                                                                        onClick={() => handleRunEngine(item)} 
                                                                        className="px-4 py-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-100 rounded-lg text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all"
                                                                    >
                                                                        <BoltIcon className="w-4 h-4"/> {item.status === 'ready' ? 'Regenerate' : 'Run Engine'}
                                                                    </button>
                                                                ) : null}
                                                                {item.status === 'ready' && !sched && (
                                                                    <button onClick={() => openScheduleModal(item)} className="px-4 py-2 bg-black text-white hover:bg-gray-800 rounded-lg text-xs font-bold uppercase tracking-widest flex items-center gap-2 transition-all shadow-md">
                                                                        <CalendarDaysIcon className="w-4 h-4"/> Schedule
                                                                    </button>
                                                                )}
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                                
                                                {isEditing ? (
                                                    <textarea 
                                                        className="text-sm text-gray-600 leading-relaxed mb-2 w-full bg-gray-50 border border-gray-200 rounded-lg p-2 h-24 resize-none outline-none focus:ring-1 focus:ring-indigo-300"
                                                        value={editBrief}
                                                        onChange={(e) => setEditBrief(e.target.value)}
                                                    />
                                                ) : (
                                                    <p className="text-sm text-gray-600 leading-relaxed mb-2">{item.brief || "No brief provided."}</p>
                                                )}
                                                
                                                {videoPrompt && (
                                                    <div className="mt-2 p-2 bg-purple-50 rounded text-[9px] text-purple-700 border border-purple-100 flex items-center gap-2">
                                                        <FilmIcon className="w-3 h-3"/>
                                                        <span className="font-bold">Video Prompt Ready:</span> 
                                                        <span className="line-clamp-1 opacity-75">{videoPrompt.full_prompt || videoPrompt.action || "Generated"}</span>
                                                    </div>
                                                )}

                                                {sched && (
                                                    <div className="mt-auto pt-4 border-t border-gray-100 flex items-center gap-4 text-xs">
                                                        <span className="font-bold text-gray-400 uppercase tracking-wide">Approvals:</span>
                                                        {[1, 2, 3].map(n => {
                                                            const key = `approver${n}_status` as keyof SceneSchedule;
                                                            const val = sched[key];
                                                            return (
                                                                <div key={n} className="flex items-center gap-1">
                                                                    <div className={`w-2 h-2 rounded-full ${val === 'approved' ? 'bg-green-500' : val === 'rejected' ? 'bg-red-500' : 'bg-orange-300'}`}></div>
                                                                    <span className="font-medium text-gray-600">App {n}</span>
                                                                    {val === 'pending' && (
                                                                        <button onClick={() => handleApproval(sched.schedule_id, `approver${n}_status`, 'approved')} className="ml-1 text-[9px] text-green-600 hover:underline">OK</button>
                                                                    )}
                                                                </div>
                                                            );
                                                        })}
                                                        {sched.scheduled_for && (
                                                            <div className="ml-auto flex items-center gap-1 text-gray-500 font-bold">
                                                                <ClockIcon className="w-3 h-3"/> {new Date(sched.scheduled_for).toLocaleDateString()}
                                                            </div>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        // GRID VIEW (Kept simple for now)
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-20">
                            {items.map(item => {
                                const sched = getScheduleForItem(item);
                                const displayStatus = sched ? sched.publish_status : item.status;
                                const generatedImage = item.meta_jsonb?.generated_assets?.[0];
                                const isSelected = selectedItemIds.has(item.content_item_id);

                                return (
                                    <div 
                                        key={item.content_item_id} 
                                        className={`bg-white rounded-2xl border shadow-sm overflow-hidden flex flex-col group hover:shadow-lg transition-all h-full relative ${isSelected ? 'border-indigo-600 ring-2 ring-indigo-200' : 'border-gray-100 hover:border-indigo-200'}`}
                                    >
                                        {/* Simplified Grid Item */}
                                        {item.status === 'ready' && (
                                            <div className="absolute top-3 left-3 z-30">
                                                <input 
                                                    type="checkbox" 
                                                    checked={isSelected} 
                                                    onChange={() => toggleSelection(item.content_item_id, item.status)}
                                                    className="w-5 h-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer shadow-sm opacity-0 group-hover:opacity-100 checked:opacity-100 transition-opacity bg-white"
                                                />
                                            </div>
                                        )}
                                        <div className="aspect-square bg-gray-50 relative overflow-hidden group/image">
                                            {generatedImage ? (
                                                <>
                                                    <img src={generatedImage} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 cursor-pointer" onClick={() => setPreviewImage(generatedImage)} />
                                                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/image:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-[1px]">
                                                        <button onClick={() => setPreviewImage(generatedImage)} className="p-3 bg-white/20 text-white hover:bg-white/40 rounded-full shadow-lg hover:scale-110 transition-transform backdrop-blur-md"><EyeIcon className="w-5 h-5"/></button>
                                                        <button onClick={() => setQuickClipItem(item)} className="p-3 bg-indigo-600 text-white rounded-full shadow-lg hover:scale-110 transition-transform"><BoltIcon className="w-5 h-5"/></button>
                                                    </div>
                                                </>
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-300">
                                                    {item.status === 'generating' ? <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div> : <PhotoIcon className="w-12 h-12 opacity-20"/>}
                                                </div>
                                            )}
                                            {!isSelected && <div className="absolute top-2 left-2 flex gap-1 pointer-events-none group-hover:opacity-0 transition-opacity"><StatusPill status={displayStatus} /></div>}
                                        </div>
                                        <div className="p-4 flex flex-col flex-1">
                                            <h4 className="font-bold text-gray-900 text-sm line-clamp-2 mb-2 leading-tight">{item.theme}</h4>
                                            <p className="text-xs text-gray-500 line-clamp-3 mb-2 flex-1">{item.brief || "No brief provided."}</p>
                                            <div className="pt-3 border-t border-gray-100 mt-auto flex items-center justify-between text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                                                {item.meta_jsonb?.aspect_ratio && <span>{item.meta_jsonb.aspect_ratio === AspectRatio.SQUARE ? '1:1' : item.meta_jsonb.aspect_ratio === AspectRatio.PORTRAIT ? '9:16' : '16:9'}</span>}
                                                <span className="flex items-center gap-1">{sched ? <ClockIcon className="w-3 h-3"/> : 'Draft'}</span>
                                            </div>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )
                )}
            </div>

            {/* Brainstorm Modal Update */}
            <Modal isOpen={showBrainstormModal} onClose={() => setShowBrainstormModal(false)} title="AI Brainstorm">
                <div className="space-y-6 p-2">
                    <p className="text-sm text-gray-500">Generate multiple content ideas for the <strong>{activeTab}</strong> channel tailored to {character.name}.</p>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Campaign Theme / Context</label>
                        <textarea 
                            className="w-full border border-gray-200 rounded-xl p-4 h-32 resize-none outline-none focus:ring-2 focus:ring-indigo-500" 
                            value={brainstormTopic} 
                            onChange={(e) => setBrainstormTopic(e.target.value)} 
                            placeholder="e.g. Back to School confidence, Summer beach vibes, Product launch..." 
                        />
                    </div>
                    
                    {/* NEW: Format Selection */}
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Content Format</label>
                        <div className="grid grid-cols-3 gap-2">
                            <button 
                                onClick={() => setBrainstormFormat(AspectRatio.SQUARE)}
                                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${brainstormFormat === AspectRatio.SQUARE ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'}`}
                            >
                                <div className="w-4 h-4 border-2 border-current rounded-sm mb-1"></div>
                                <span className="text-[10px] font-bold uppercase">Insta Square</span>
                            </button>
                            <button 
                                onClick={() => setBrainstormFormat(AspectRatio.PORTRAIT)}
                                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${brainstormFormat === AspectRatio.PORTRAIT ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'}`}
                            >
                                <div className="w-3 h-5 border-2 border-current rounded-sm mb-1"></div>
                                <span className="text-[10px] font-bold uppercase">TikTok Portrait</span>
                            </button>
                            <button 
                                onClick={() => setBrainstormFormat(AspectRatio.LANDSCAPE)}
                                className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${brainstormFormat === AspectRatio.LANDSCAPE ? 'bg-indigo-50 border-indigo-500 text-indigo-700' : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'}`}
                            >
                                <div className="w-5 h-3 border-2 border-current rounded-sm mb-1"></div>
                                <span className="text-[10px] font-bold uppercase">YouTube Wide</span>
                            </button>
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Number of Ideas</label>
                        <select className="w-full border border-gray-200 rounded-xl p-3 font-bold bg-white" value={brainstormCount} onChange={(e) => setBrainstormCount(Number(e.target.value))}>
                            <option value={3}>3 Ideas</option>
                            <option value={5}>5 Ideas</option>
                            <option value={10}>10 Ideas</option>
                        </select>
                    </div>
                    <button 
                        onClick={handleBrainstorm} 
                        disabled={isBrainstorming || !brainstormTopic}
                        className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:from-purple-700 hover:to-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {isBrainstorming ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4"/>}
                        {isBrainstorming ? 'Brainstorming...' : 'Generate Content Plan'}
                    </button>
                </div>
            </Modal>

            {/* Other modals remain the same... */}
            {/* Create Item Modal */}
            <Modal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} title="New Content Item">
                <div className="space-y-6 p-2">
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Theme / Topic</label>
                        <input className="w-full border border-gray-200 rounded-xl p-3 font-bold" value={newItemTheme} onChange={(e) => setNewItemTheme(e.target.value)} placeholder="e.g. Summer Launch Post" />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Format</label>
                        <select className="w-full border border-gray-200 rounded-xl p-3 font-bold bg-white" value={newItemType} onChange={(e) => setNewItemType(e.target.value as ContentType)}>
                            <option value="image">Image Post</option>
                            <option value="carousel">Carousel</option>
                            <option value="video">Video</option>
                            <option value="reel">Reel / Short</option>
                            <option value="story">Story</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Creative Brief</label>
                        <textarea className="w-full border border-gray-200 rounded-xl p-3 h-32 resize-none" value={newItemBrief} onChange={(e) => setNewItemBrief(e.target.value)} placeholder="Describe visual style, setting, outfit..." />
                    </div>
                    <button onClick={handleCreateItem} disabled={!newItemTheme} className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-gray-800 disabled:opacity-50">Save to Backlog</button>
                </div>
            </Modal>

            {/* Schedule Modal */}
            <Modal isOpen={showScheduleModal} onClose={() => setShowScheduleModal(false)} title="Schedule Content">
                <div className="space-y-6 p-2">
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Platform</label>
                            <select className="w-full border border-gray-200 rounded-xl p-3 font-bold bg-white" value={schedulePlatform} onChange={(e) => setSchedulePlatform(e.target.value)}>
                                <option>Instagram</option>
                                <option>TikTok</option>
                                <option>YouTube</option>
                                <option>LinkedIn</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Publish Time</label>
                            <input type="datetime-local" className="w-full border border-gray-200 rounded-xl p-3 font-bold" value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)} />
                        </div>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-100">
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Approval Workflow</label>
                        <div className="flex gap-2 text-xs">
                            <span className="px-3 py-1 bg-white border border-gray-200 rounded-full text-gray-600">Creative Lead</span>
                            <span className="px-3 py-1 bg-white border border-gray-200 rounded-full text-gray-600">Brand Manager</span>
                            <span className="px-3 py-1 bg-white border border-gray-200 rounded-full text-gray-600">Legal</span>
                        </div>
                        <p className="text-[10px] text-gray-400 mt-2">Required by policy.</p>
                    </div>

                    <button onClick={handleSchedule} disabled={isScheduling} className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
                        {isScheduling ? 'Scheduling...' : 'Confirm Schedule'}
                    </button>
                </div>
            </Modal>

            {/* Bulk Schedule Modal */}
            <Modal isOpen={showBulkScheduleModal} onClose={() => setShowBulkScheduleModal(false)} title="Batch Schedule Content">
                <div className="space-y-6 p-2">
                    <p className="text-sm text-gray-500">
                        You are about to schedule <strong>{selectedItemIds.size} items</strong>.
                        They will be posted sequentially starting from the date below.
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Start Date & Time</label>
                            <input type="datetime-local" className="w-full border border-gray-200 rounded-xl p-3 font-bold" value={scheduleDate} onChange={(e) => setScheduleDate(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Interval (Hours)</label>
                            <input type="number" className="w-full border border-gray-200 rounded-xl p-3 font-bold" value={bulkInterval} onChange={(e) => setBulkInterval(Number(e.target.value))} min={1} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase tracking-widest mb-2">Platform</label>
                        <select className="w-full border border-gray-200 rounded-xl p-3 font-bold bg-white" value={schedulePlatform} onChange={(e) => setSchedulePlatform(e.target.value)}>
                            <option>Instagram</option>
                            <option>TikTok</option>
                            <option>YouTube</option>
                            <option>LinkedIn</option>
                        </select>
                    </div>
                    
                    <button onClick={handleBulkSchedule} disabled={isScheduling || !scheduleDate} className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-gray-800 disabled:opacity-50 flex items-center justify-center gap-2">
                        {isScheduling ? 'Processing Schedule...' : `Confirm Schedule (${selectedItemIds.size})`}
                    </button>
                </div>
            </Modal>

            {/* Lightbox Preview */}
            {previewImage && (
                <div 
                    className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in-up" 
                    onClick={() => setPreviewImage(null)}
                >
                    <button 
                        className="absolute top-6 right-6 p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors z-10" 
                        onClick={() => setPreviewImage(null)}
                    >
                        <XMarkIcon className="w-8 h-8"/>
                    </button>
                    <img 
                        src={previewImage} 
                        className="max-w-full max-h-full object-contain rounded-lg shadow-2xl pointer-events-auto" 
                        onClick={(e) => e.stopPropagation()} 
                    />
                </div>
            )}

            {/* Quick Clip Creator Modal */}
            {quickClipItem && (
                <QuickClipCreator 
                    onClose={() => setQuickClipItem(null)} 
                    onSuccess={() => setQuickClipItem(null)}
                    initialCharacter={{
                        url: character.image_url || character.image_urls_jsonb?.[0]?.url || '', 
                        id: character.character_id || character.id || '',
                        name: character.name
                    }}
                    initialPrompt={
                        quickClipItem.meta_jsonb?.video_prompt?.full_prompt || 
                        quickClipItem.brief || 
                        quickClipItem.theme
                    }
                />
            )}
        </div>
    );
};

export default ContentEngine;
