
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';
import { 
    PresentationIcon,
    MegaphoneIcon, 
    CubeIcon, 
    UserIcon,
    RocketIcon,
    ShoppingBagIcon
} from './icons';

interface DashboardProps {
    onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
    return (
        <div className="w-full h-full bg-gray-50 overflow-y-auto p-6 md:p-12 no-scrollbar">
            <div className="max-w-7xl mx-auto space-y-12 pb-20">
                {/* Header */}
                <div className="flex flex-col gap-2">
                    <h1 className="text-4xl font-black text-gray-900 tracking-tighter uppercase">
                        Creative <span className="text-[#9063CD]">Command</span> Center
                    </h1>
                    <p className="text-lg text-gray-500 font-medium max-w-2xl">
                        Architecting the future of beauty through AI & Global Insight.
                    </p>
                </div>

                {/* MAIN ACTIONS SECTION */}
                <div className="animate-fade-in-up" style={{animationDelay: '0.1s'}}>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        
                        {/* 1. Character Lab */}
                        <div 
                            onClick={() => onNavigate('influencers')}
                            className="bg-black p-10 rounded-[2.5rem] border border-gray-800 shadow-2xl hover:shadow-3xl hover:scale-[1.02] transition-all cursor-pointer group relative overflow-hidden h-[450px]"
                        >
                            <div className="absolute top-0 right-0 p-6 opacity-20 group-hover:opacity-30 transition-opacity">
                                <MegaphoneIcon className="w-64 h-64 text-white -mr-10 -mt-10" />
                            </div>
                            <div className="relative z-10 flex flex-col h-full justify-between gap-8">
                                <div>
                                    <div className="w-16 h-16 bg-white/10 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-white/20 backdrop-blur-sm">
                                        <MegaphoneIcon className="w-8 h-8 text-white" />
                                    </div>
                                    <h3 className="text-3xl font-black text-white uppercase tracking-tighter leading-none mb-4">Character<br/>Lab</h3>
                                    <p className="text-sm text-gray-400 font-medium leading-relaxed max-w-xs">
                                        Recruit and manage top global talent or architect bespoke AI virtual personas.
                                    </p>
                                </div>
                                <div className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-[#9063CD] bg-white/5 p-4 rounded-2xl border border-white/10 w-fit backdrop-blur-sm group-hover:bg-white/10 transition-colors">
                                    <UserIcon className="w-4 h-4" /> Source Talent
                                </div>
                            </div>
                        </div>

                        {/* 2. Storyboard Generator */}
                        <div 
                            onClick={() => onNavigate('storyboard')}
                            className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-xl hover:shadow-2xl hover:border-[#9063CD] hover:scale-[1.02] transition-all cursor-pointer group relative overflow-hidden h-[450px]"
                        >
                            <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                                <PresentationIcon className="w-64 h-64 text-[#9063CD] -mr-10 -mt-10" />
                            </div>
                            <div className="relative z-10 flex flex-col h-full justify-between gap-8">
                                <div>
                                    <div className="w-16 h-16 bg-purple-50 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-purple-100">
                                        <PresentationIcon className="w-8 h-8 text-[#9063CD]" />
                                    </div>
                                    <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tighter leading-none mb-4">Storyboard<br/>Generator</h3>
                                    <p className="text-sm text-gray-500 font-medium leading-relaxed max-w-xs">
                                        Turn high-level briefs into full storyboarded ad scripts and AI video concepts instantly using Veo 3.1.
                                    </p>
                                </div>
                                <div className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-[#9063CD] bg-purple-50 p-4 rounded-2xl border border-purple-100 w-fit group-hover:bg-[#9063CD] group-hover:text-white transition-colors">
                                    <RocketIcon className="w-4 h-4" /> Start Production
                                </div>
                            </div>
                        </div>

                        {/* 3. Product Portfolio */}
                        <div 
                            onClick={() => onNavigate('products')}
                            className="bg-white p-10 rounded-[2.5rem] border border-gray-100 shadow-xl hover:shadow-2xl hover:border-indigo-500 hover:scale-[1.02] transition-all cursor-pointer group relative overflow-hidden h-[450px]"
                        >
                            <div className="absolute top-0 right-0 p-6 opacity-5 group-hover:opacity-10 transition-opacity">
                                <ShoppingBagIcon className="w-64 h-64 text-indigo-900 -mr-10 -mt-10" />
                            </div>
                            <div className="relative z-10 flex flex-col h-full justify-between gap-8">
                                <div>
                                    <div className="w-16 h-16 bg-indigo-50 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform border border-indigo-100">
                                        <ShoppingBagIcon className="w-8 h-8 text-indigo-600" />
                                    </div>
                                    <h3 className="text-3xl font-black text-gray-900 uppercase tracking-tighter leading-none mb-4">Product<br/>Portfolio</h3>
                                    <p className="text-sm text-gray-500 font-medium leading-relaxed max-w-xs">
                                        Manage SKUs, visual identities, and generate AI product photography.
                                    </p>
                                </div>
                                <div className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-indigo-600 bg-indigo-50 p-4 rounded-2xl border border-indigo-100 w-fit group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                                    <CubeIcon className="w-4 h-4" /> Manage Products
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    );
};

export default Dashboard;
