
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useMemo } from 'react';
import { fetchCalendarEvents, createCalendarEvent, fetchAdsList, fetchGlobalSchedules, fetchPendingApprovals } from '../services/supabaseClient';
import { CalendarEvent } from '../types';
import { 
    CalendarDaysIcon, 
    PlusIcon, 
    ChevronRightIcon, 
    CheckCircleIcon, 
    ClockIcon,
    AlertTriangleIcon,
    ClapperboardIcon,
    MenuIcon,
    FilterIcon,
    RocketIcon,
    BoltIcon,
    ChevronDownIcon,
    EyeIcon,
    ShareIcon
} from './icons';
import Modal from './Modal';
import ApprovalCenter from './ApprovalCenter';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const ContentCalendar: React.FC = () => {
    const [viewMode, setViewMode] = useState<'list' | 'month'>('list');
    const [currentDate, setCurrentDate] = useState(new Date());
    const [events, setEvents] = useState<CalendarEvent[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [pendingCount, setPendingCount] = useState(0);
    
    // Sort State
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'start_at', direction: 'asc' });

    // Create Event State
    const [showModal, setShowModal] = useState(false);
    const [showApprovalCenter, setShowApprovalCenter] = useState(false);
    const [newEventTitle, setNewEventTitle] = useState('');
    const [newEventDate, setNewEventDate] = useState('');
    const [newEventType, setNewEventType] = useState<'job_run' | 'deadline' | 'review'>('deadline');
    const [selectedAdId, setSelectedAdId] = useState('');
    const [adsList, setAdsList] = useState<{id: string, ad_title: string}[]>([]);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        loadEvents();
        loadAds();
        checkPendingApprovals();
    }, [currentDate, viewMode]);

    const loadAds = async () => {
        const ads = await fetchAdsList();
        setAdsList(ads);
    };

    const checkPendingApprovals = async () => {
        const pending = await fetchPendingApprovals();
        setPendingCount(pending.length);
    };

    const loadEvents = async () => {
        setIsLoading(true);
        let start: Date, end: Date;

        if (viewMode === 'month') {
             // Month View: Strict month bounds
             const year = currentDate.getFullYear();
             const month = currentDate.getMonth();
             start = new Date(year, month, 1);
             end = new Date(year, month + 1, 0);
        } else {
             // Scheduler List: Wide range (Past 3 months to Next Year)
             start = new Date();
             start.setMonth(start.getMonth() - 3);
             end = new Date();
             end.setFullYear(end.getFullYear() + 1);
        }
        
        // Parallel Fetch: Standard Calendar Events + Social Schedule
        const [manualEvents, socialSchedule] = await Promise.all([
            fetchCalendarEvents(start, end),
            fetchGlobalSchedules(start, end)
        ]);

        // Transform Social Schedule into Calendar Events
        const socialEvents: CalendarEvent[] = (socialSchedule || []).map((s: any) => ({
            event_id: s.schedule_id,
            title: `${s.scene?.description || 'Social Post'} (${s.character?.name || 'Unknown'})`,
            event_type: 'launch', // Using 'launch' type for posts to show green icon
            status: s.publish_status || 'scheduled',
            start_at: s.scheduled_for,
            ad_id: s.ad_id,
            meta: { platform: s.platform, channel: s.channel },
            ad: { ad_title: s.character?.name || 'Social' } // Hack to show Character name in "Linked Project" column
        }));

        setEvents([...(manualEvents || []), ...socialEvents]);
        setIsLoading(false);
    };

    const handlePrevMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    };

    const handleCreateEvent = async () => {
        // Validation with Alerts
        if (!newEventTitle.trim()) {
            alert("Please enter an Event Title.");
            return;
        }
        if (!newEventDate) {
            alert("Please select a valid Date & Time (ensure day, month, year, and time are filled).");
            return;
        }

        setIsSaving(true);
        try {
            const result = await createCalendarEvent({
                title: newEventTitle,
                start_at: new Date(newEventDate).toISOString(),
                event_type: newEventType,
                status: 'scheduled',
                ad_id: selectedAdId || null
            });
            
            if (result) {
                setShowModal(false);
                setNewEventTitle('');
                setNewEventDate('');
                setSelectedAdId('');
                loadEvents();
            } else {
                throw new Error("Creation returned null");
            }
        } catch (e) {
            console.error(e);
            alert("Failed to create event. Please try again.");
        } finally {
            setIsSaving(false);
        }
    };

    // --- Sort Logic ---
    const requestSort = (key: string) => {
        let direction: 'asc' | 'desc' = 'asc';
        if (sortConfig.key === key && sortConfig.direction === 'asc') {
            direction = 'desc';
        }
        setSortConfig({ key, direction });
    };

    const sortedEvents = useMemo(() => {
        let sortableItems = [...events];
        if (sortConfig !== null) {
            sortableItems.sort((a, b) => {
                let aValue: any = a[sortConfig.key as keyof CalendarEvent];
                let bValue: any = b[sortConfig.key as keyof CalendarEvent];
                
                // Handle special keys
                if (sortConfig.key === 'ad_title') {
                    aValue = a.ad?.ad_title || '';
                    bValue = b.ad?.ad_title || '';
                }
                
                if (aValue < bValue) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }
                if (aValue > bValue) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableItems;
    }, [events, sortConfig]);

    // --- View Helpers ---

    const getTypeStyles = (type: string) => {
        switch(type) {
            case 'deadline': return { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', icon: <AlertTriangleIcon className="w-3 h-3"/>, label: 'Deadline' };
            case 'review': return { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200', icon: <EyeIcon className="w-3 h-3"/>, label: 'Review' };
            case 'job_run': return { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200', icon: <BoltIcon className="w-3 h-3"/>, label: 'Job Run' };
            case 'launch': return { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200', icon: <ShareIcon className="w-3 h-3"/>, label: 'Post' }; // Visual tweak for social posts
            default: return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-200', icon: <ClockIcon className="w-3 h-3"/>, label: 'Event' };
        }
    };

    const getStatusStyles = (status: string) => {
        switch(status) {
            case 'completed': 
            case 'approved': 
            case 'posted':
                return 'bg-green-100 text-green-800';
            case 'in_progress': 
            case 'pending_approval':
                return 'bg-blue-100 text-blue-800';
            case 'cancelled': 
            case 'failed':
                return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-600';
        }
    };

    // Calendar Grid Logic
    const getDaysInMonth = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDay = firstDay.getDay(); // 0 = Sun
        
        const days = [];
        for (let i = 0; i < startingDay; i++) days.push(null); // Padding
        for (let i = 1; i <= daysInMonth; i++) days.push(i);
        return days;
    };

    const getEventsForDay = (day: number) => {
        return events.filter(e => {
            const eventDate = new Date(e.start_at);
            return eventDate.getDate() === day && 
                   eventDate.getMonth() === currentDate.getMonth() &&
                   eventDate.getFullYear() === currentDate.getFullYear();
        });
    };

    // Icon helper for missing imports if any
    const SortIcon = ({ active, direction }: { active: boolean, direction: 'asc' | 'desc' }) => (
        <span className={`ml-1 inline-block transition-transform ${active && direction === 'desc' ? 'rotate-180' : ''}`}>
            <ChevronDownIcon className={`w-3 h-3 ${active ? 'text-indigo-600' : 'text-gray-300'}`} />
        </span>
    );

    return (
        <div className="w-full h-full flex flex-col bg-gray-50 overflow-hidden font-sans text-gray-900">
            {/* Header */}
            <header className="h-20 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0 shadow-sm z-10">
                <div className="flex items-center gap-6">
                    <div>
                        <h2 className="text-2xl font-black text-gray-900 tracking-tight uppercase">Production Schedule</h2>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                            {viewMode === 'list' ? 'Master Timeline' : 'Calendar View'}
                        </p>
                    </div>
                    
                    {viewMode === 'month' && (
                        <>
                            <div className="h-8 w-px bg-gray-200 mx-2"></div>
                            {/* Month Navigator (Only for Month Mode) */}
                            <div className="flex items-center bg-gray-50 rounded-xl p-1 border border-gray-100">
                                <button onClick={handlePrevMonth} className="p-2 hover:bg-white rounded-lg transition-all shadow-sm text-gray-500 hover:text-black"><ChevronRightIcon className="w-4 h-4 rotate-180"/></button>
                                <span className="px-4 font-black text-sm text-gray-800 uppercase tracking-wide w-40 text-center">{MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}</span>
                                <button onClick={handleNextMonth} className="p-2 hover:bg-white rounded-lg transition-all shadow-sm text-gray-500 hover:text-black"><ChevronRightIcon className="w-4 h-4"/></button>
                            </div>
                        </>
                    )}
                </div>

                <div className="flex items-center gap-3">
                    {/* Approval Queue Button */}
                    <button 
                        onClick={() => setShowApprovalCenter(true)} 
                        className="flex items-center gap-2 px-4 py-2 bg-orange-50 text-orange-600 font-bold rounded-lg border border-orange-200 hover:bg-orange-100 transition-all text-xs uppercase tracking-widest relative"
                    >
                        <CheckCircleIcon className="w-4 h-4"/> Approvals
                        {pendingCount > 0 && <span className="bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-[9px] absolute -top-2 -right-2 border-2 border-white">{pendingCount}</span>}
                    </button>

                    <div className="h-8 w-px bg-gray-200 mx-2"></div>

                    {/* View Toggle */}
                    <div className="bg-gray-100 p-1 rounded-xl flex gap-1">
                        <button 
                            onClick={() => setViewMode('list')}
                            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${viewMode === 'list' ? 'bg-white shadow-md text-black' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <MenuIcon className="w-4 h-4"/> List
                        </button>
                        <button 
                            onClick={() => setViewMode('month')}
                            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${viewMode === 'month' ? 'bg-white shadow-md text-black' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <CalendarDaysIcon className="w-4 h-4"/> Month
                        </button>
                    </div>

                    <button onClick={() => setShowModal(true)} className="flex items-center gap-2 px-6 py-2.5 bg-black text-white font-black rounded-xl shadow-lg transition-all hover:bg-gray-800 text-xs uppercase tracking-widest ml-4">
                        <PlusIcon className="w-4 h-4" /> New Event
                    </button>
                </div>
            </header>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden flex flex-col relative">
                {isLoading ? (
                    <div className="absolute inset-0 flex items-center justify-center bg-white/50 backdrop-blur-sm z-10">
                        <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                ) : null}

                {viewMode === 'list' && (
                    <div className="flex-1 overflow-y-auto p-8 no-scrollbar">
                        {/* Scheduler Table Grid */}
                        <div className="bg-white rounded-[1.5rem] border border-gray-200 shadow-sm overflow-hidden min-w-[800px]">
                            {/* Table Header */}
                            <div className="grid grid-cols-[1.5fr_1fr_2fr_1fr_1fr_1.5fr] bg-gray-50/80 border-b border-gray-200 sticky top-0 z-10 backdrop-blur-md">
                                <div onClick={() => requestSort('start_at')} className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest cursor-pointer hover:bg-gray-100 transition-colors flex items-center">
                                    Date & Time <SortIcon active={sortConfig.key === 'start_at'} direction={sortConfig.direction}/>
                                </div>
                                <div onClick={() => requestSort('event_type')} className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest cursor-pointer hover:bg-gray-100 transition-colors flex items-center">
                                    Type <SortIcon active={sortConfig.key === 'event_type'} direction={sortConfig.direction}/>
                                </div>
                                <div onClick={() => requestSort('title')} className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest cursor-pointer hover:bg-gray-100 transition-colors flex items-center">
                                    Event / Milestone <SortIcon active={sortConfig.key === 'title'} direction={sortConfig.direction}/>
                                </div>
                                <div onClick={() => requestSort('status')} className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest cursor-pointer hover:bg-gray-100 transition-colors flex items-center">
                                    Status <SortIcon active={sortConfig.key === 'status'} direction={sortConfig.direction}/>
                                </div>
                                <div className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest">
                                    Duration
                                </div>
                                <div onClick={() => requestSort('ad_title')} className="px-6 py-4 text-xs font-black text-gray-500 uppercase tracking-widest cursor-pointer hover:bg-gray-100 transition-colors flex items-center">
                                    Linked Project <SortIcon active={sortConfig.key === 'ad_title'} direction={sortConfig.direction}/>
                                </div>
                            </div>

                            {/* Table Body */}
                            <div className="divide-y divide-gray-100">
                                {sortedEvents.length === 0 ? (
                                    <div className="p-12 text-center text-gray-400 flex flex-col items-center">
                                        <CalendarDaysIcon className="w-12 h-12 opacity-20 mb-3"/>
                                        <span className="text-sm font-bold uppercase tracking-widest">No scheduled events found</span>
                                    </div>
                                ) : (
                                    sortedEvents.map(ev => {
                                        const typeStyle = getTypeStyles(ev.event_type);
                                        const date = new Date(ev.start_at);
                                        const isToday = new Date().toDateString() === date.toDateString();

                                        return (
                                            <div key={ev.event_id} className={`grid grid-cols-[1.5fr_1fr_2fr_1fr_1fr_1.5fr] items-center hover:bg-gray-50/80 transition-colors group ${isToday ? 'bg-indigo-50/30' : ''}`}>
                                                {/* Date */}
                                                <div className="px-6 py-5 flex flex-col justify-center">
                                                    <span className={`text-sm font-bold ${isToday ? 'text-indigo-600' : 'text-gray-900'}`}>
                                                        {date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                                                    </span>
                                                    <span className="text-xs text-gray-400 font-mono mt-0.5">
                                                        {date.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                                                    </span>
                                                </div>

                                                {/* Type */}
                                                <div className="px-6 py-5">
                                                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-black uppercase tracking-widest border ${typeStyle.bg} ${typeStyle.text} ${typeStyle.border}`}>
                                                        {typeStyle.icon} {typeStyle.label}
                                                    </span>
                                                </div>

                                                {/* Title */}
                                                <div className="px-6 py-5">
                                                    <span className="block text-sm font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                                                        {ev.title}
                                                    </span>
                                                    {ev.meta?.platform && (
                                                        <span className="text-[9px] text-gray-400 uppercase font-bold tracking-wider mt-1 block">
                                                            {ev.meta.platform}
                                                        </span>
                                                    )}
                                                </div>

                                                {/* Status */}
                                                <div className="px-6 py-5">
                                                    <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${getStatusStyles(ev.status)}`}>
                                                        {ev.status.replace('_', ' ')}
                                                    </span>
                                                </div>

                                                {/* Duration (Placeholder/Calculated) */}
                                                <div className="px-6 py-5">
                                                    <span className="text-xs text-gray-500 font-medium">
                                                        {ev.end_at ? 
                                                            `${Math.round((new Date(ev.end_at).getTime() - date.getTime()) / (1000 * 60))} min` 
                                                            : '-'
                                                        }
                                                    </span>
                                                </div>

                                                {/* Project */}
                                                <div className="px-6 py-5">
                                                    {ev.ad?.ad_title ? (
                                                        <div className="flex items-center gap-2 text-gray-600">
                                                            <ClapperboardIcon className="w-4 h-4 text-gray-300" />
                                                            <span className="text-xs font-bold truncate max-w-[150px]" title={ev.ad.ad_title}>
                                                                {ev.ad.ad_title}
                                                            </span>
                                                        </div>
                                                    ) : (
                                                        <span className="text-xs text-gray-300 italic">None</span>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {viewMode === 'month' && (
                    <div className="flex-1 flex flex-col p-8 overflow-hidden">
                        <div className="grid grid-cols-7 gap-4 mb-4 shrink-0">
                            {DAYS.map(d => (
                                <div key={d} className="text-center text-[10px] font-black text-gray-400 uppercase tracking-widest">{d}</div>
                            ))}
                        </div>
                        <div className="flex-1 grid grid-cols-7 gap-4 auto-rows-fr overflow-y-auto no-scrollbar pb-20">
                            {getDaysInMonth().map((day, idx) => (
                                <div key={idx} className={`bg-white rounded-3xl border border-gray-100 p-3 min-h-[140px] flex flex-col gap-2 relative transition-all ${!day ? 'bg-transparent border-none' : 'shadow-sm hover:shadow-lg hover:border-indigo-100'}`}>
                                    {day && (
                                        <>
                                            <span className={`text-sm font-bold w-8 h-8 flex items-center justify-center rounded-full ${new Date().getDate() === day && new Date().getMonth() === currentDate.getMonth() ? 'bg-black text-white shadow-lg' : 'text-gray-400'}`}>{day}</span>
                                            <div className="flex-1 flex flex-col gap-1.5 overflow-y-auto no-scrollbar">
                                                {getEventsForDay(day).map(ev => {
                                                    const style = getTypeStyles(ev.event_type);
                                                    return (
                                                        <div key={ev.event_id} className={`px-2 py-1.5 rounded-lg border text-[9px] font-bold truncate flex items-center gap-1.5 ${style.bg} ${style.text} ${style.border}`}>
                                                            {style.icon}
                                                            <span className="truncate">{ev.title}</span>
                                                        </div>
                                                    );
                                                })}
                                            </div>
                                        </>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            <Modal isOpen={showModal} onClose={() => setShowModal(false)} title="Schedule Production Event">
                <div className="space-y-6 p-2">
                    <div>
                        <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Event Title</label>
                        <input className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500" value={newEventTitle} onChange={(e) => setNewEventTitle(e.target.value)} placeholder="e.g. Campaign Launch" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Date & Time</label>
                            <input type="datetime-local" className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none" value={newEventDate} onChange={(e) => setNewEventDate(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Category</label>
                            <select className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none appearance-none" value={newEventType} onChange={(e) => setNewEventType(e.target.value as any)}>
                                <option value="deadline">Deadline</option>
                                <option value="review">Review</option>
                                <option value="job_run">Job Run</option>
                                <option value="launch">Launch</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-black text-gray-500 uppercase tracking-widest mb-2">Linked Project</label>
                        <select className="w-full bg-gray-50 border border-gray-200 rounded-xl p-4 font-bold text-gray-900 outline-none appearance-none" value={selectedAdId} onChange={(e) => setSelectedAdId(e.target.value)}>
                            <option value="">-- No Project Link --</option>
                            {adsList.map(ad => <option key={ad.id} value={ad.id}>{ad.ad_title}</option>)}
                        </select>
                    </div>
                    <button onClick={handleCreateEvent} disabled={isSaving} className="w-full bg-black text-white py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-gray-900 disabled:opacity-50 transition-all">
                        {isSaving ? 'Scheduling...' : 'Confirm Schedule'}
                    </button>
                </div>
            </Modal>

            {/* Approval Center Modal */}
            {showApprovalCenter && (
                <ApprovalCenter onClose={() => { setShowApprovalCenter(false); checkPendingApprovals(); loadEvents(); }} />
            )}
        </div>
    );
};

export default ContentCalendar;
