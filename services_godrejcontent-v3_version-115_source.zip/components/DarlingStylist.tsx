/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { Influencer, ChatSession, ChatMessage } from '../types';
import { startDarlingStylistSession, generateDarlingLook } from '../services/geminiService';
import { uploadBlob, updateCharacter, supabase } from '../services/supabaseClient';
import { 
    XMarkIcon, 
    SparklesIcon, 
    CheckCircleIcon,
    ArrowRightIcon,
    ChatBubbleIcon,
    PhotoIcon,
    ScissorsIcon
} from './icons';

interface DarlingStylistProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

interface StyleCard {
    product: string;
    style_name: string;
    color: string;
    visual_description: string;
}

const DarlingStylist: React.FC<DarlingStylistProps> = ({ character, onClose, onSuccess }) => {
    // Chat State
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const chatSessionRef = useRef<ChatSession | null>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    // Style State
    const [proposedStyle, setProposedStyle] = useState<StyleCard | null>(null);
    const [generatedImages, setGeneratedImages] = useState<string[]>([]);
    const [isGenerating, setIsGenerating] = useState(false);
    
    // Selection (Multi-select)
    const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        // Init Chat
        chatSessionRef.current = startDarlingStylistSession();
        
        // Initial Message
        const initMsg: ChatMessage = {
            id: 'init',
            role: 'assistant',
            text: `Hello! I'm your Darling Stylist. I'm here to give ${character.name} a stunning new look using our authentic African hair products.\n\nWhat kind of vibe are we going for today? (e.g. Corporate Chic, Traditional Wedding, Summer Festival)`,
            timestamp: Date.now()
        };
        setMessages([initMsg]);
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSendMessage = async () => {
        if (!input.trim() || !chatSessionRef.current) return;

        const userMsg: ChatMessage = { id: crypto.randomUUID(), role: 'user', text: input, timestamp: Date.now() };
        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setIsTyping(true);

        try {
            const result = await chatSessionRef.current.sendMessage({ message: userMsg.text || '' });
            const responseText = result.text || "";

            // Check for JSON Style Card extraction (Markdown aware)
            const jsonBlock = responseText.match(/```json\n([\s\S]*?)\n```/);
            const legacyMatch = responseText.match(/EXP_FINAL_STYLE:\s*(\{.*\})/s);
            
            let styleCard = null;
            let cleanText = responseText;

            if (jsonBlock) {
                try {
                    styleCard = JSON.parse(jsonBlock[1]);
                    cleanText = responseText.replace(jsonBlock[0], '').trim();
                } catch(e) { console.error("JSON parse error", e); }
            } else if (legacyMatch) {
                try {
                    styleCard = JSON.parse(legacyMatch[1]);
                    cleanText = responseText.replace(legacyMatch[0], '').trim();
                } catch(e) { console.error("Legacy parse error", e); }
            }

            setProposedStyle(styleCard);
            if (cleanText) {
                setMessages(prev => [...prev, { id: crypto.randomUUID(), role: 'assistant', text: cleanText, timestamp: Date.now() }]);
            }

        } catch (e) {
            console.error(e);
        } finally {
            setIsTyping(false);
        }
    };

    const getBaseImage = () => {
        if (character.image_url && character.image_url.startsWith('http')) return character.image_url;
        if (character.image_urls_jsonb && character.image_urls_jsonb.length > 0) return character.image_urls_jsonb[0].url;
        return "";
    };

    const urlToBase64 = async (url: string): Promise<string> => {
        try {
            const response = await fetch(url);
            const blob = await response.blob();
            return new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
                reader.readAsDataURL(blob);
            });
        } catch (e) { return ""; }
    };

    const handleGenerateLook = async () => {
        if (!proposedStyle) return;
        const baseImg = getBaseImage();
        if (!baseImg) { alert("Character needs a base image."); return; }

        setIsGenerating(true);
        setGeneratedImages([]); // clear previous
        setSelectedImages(new Set()); // clear selection
        try {
            const base64 = await urlToBase64(baseImg);
            const results = await generateDarlingLook(base64, proposedStyle.visual_description, 4); // Multiple variations
            setGeneratedImages(results);
        } catch (e) {
            console.error(e);
            alert("Generation failed");
        } finally {
            setIsGenerating(false);
        }
    };

    const toggleSelection = (b64: string) => {
        setSelectedImages(prev => {
            const next = new Set(prev);
            if (next.has(b64)) next.delete(b64);
            else next.add(b64);
            return next;
        });
    };

    const handleSaveSelection = async () => {
        if (selectedImages.size === 0 || !proposedStyle) return;
        setIsSaving(true);
        try {
            const pk = character.character_id || character.id;
            
            // Fetch fresh state to avoid overwrite
            const { data: freshChar } = await supabase
                .from('dng1_characters')
                .select('image_urls_jsonb')
                .eq('character_id', pk)
                .single();

            const currentGallery = freshChar?.image_urls_jsonb || [];
            
            // Upload all selected images in parallel
            const uploadPromises = Array.from(selectedImages).map(async (b64) => {
                const binary = atob(b64 as string);
                const array = [];
                for (let i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
                const blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
                
                const fileName = `darling_style_${Date.now()}_${Math.random().toString(36).substring(7)}.png`;
                const publicUrl = await uploadBlob(blob, fileName, 'godrej/characters');
                
                if (publicUrl) {
                    return { 
                        url: publicUrl, 
                        type: 'darling_style', 
                        description: `${proposedStyle.style_name} using ${proposedStyle.product} (${proposedStyle.color})` 
                    };
                }
                return null;
            });

            const newItems = (await Promise.all(uploadPromises)).filter(Boolean);

            if (newItems.length > 0) {
                const newGallery = [...newItems, ...currentGallery];
                await updateCharacter(pk, { image_urls_jsonb: newGallery });
                onSuccess();
            } else {
                throw new Error("Failed to upload any images.");
            }
        } catch(e) {
            console.error(e);
            alert("Failed to save");
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-gray-900/90 backdrop-blur-md flex items-center justify-center p-4 md:p-8">
            <div className="bg-white w-full max-w-6xl h-[85vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden relative border border-gray-200">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full z-20 transition-colors"><XMarkIcon className="w-6 h-6 text-gray-500"/></button>

                {/* LEFT: Consultant Chat */}
                <div className="w-1/3 bg-gray-50 border-r border-gray-200 flex flex-col">
                    <div className="p-6 border-b border-gray-200 bg-white">
                        <div className="flex items-center gap-3 mb-1">
                            <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center text-pink-600">
                                <ScissorsIcon className="w-5 h-5"/>
                            </div>
                            <div>
                                <h3 className="font-black text-gray-900 text-lg leading-none">Darling Stylist</h3>
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mt-1">Virtual Consultation</p>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-4 space-y-4">
                        {messages.map(msg => (
                            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${msg.role === 'user' ? 'bg-black text-white rounded-br-none' : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'}`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                        {isTyping && <div className="text-xs text-gray-400 font-medium px-2">Stylist is thinking...</div>}
                        <div ref={messagesEndRef} />
                    </div>

                    <div className="p-4 bg-white border-t border-gray-200">
                        <div className="relative">
                            <input 
                                className="w-full bg-gray-100 border border-transparent rounded-full px-4 py-3 text-sm focus:bg-white focus:border-pink-300 focus:ring-4 focus:ring-pink-50 outline-none transition-all pr-10"
                                placeholder="Describe the vibe..."
                                value={input}
                                onChange={(e) => setInput(e.target.value)}
                                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                            />
                            <button onClick={handleSendMessage} className="absolute right-2 top-2 p-1.5 bg-pink-600 text-white rounded-full hover:bg-pink-700 transition-colors">
                                <ArrowRightIcon className="w-4 h-4"/>
                            </button>
                        </div>
                    </div>
                </div>

                {/* RIGHT: Visual Studio */}
                <div className="flex-1 flex flex-col bg-white overflow-y-auto">
                    <div className="p-8 max-w-3xl mx-auto w-full space-y-8">
                        {/* Status Header */}
                        <div className="text-center">
                            <div className="w-20 h-20 rounded-full bg-gray-100 mx-auto mb-4 overflow-hidden border-4 border-white shadow-lg">
                                <img src={getBaseImage()} className="w-full h-full object-cover" />
                            </div>
                            <h2 className="text-2xl font-black text-gray-900">{character.name}</h2>
                            <p className="text-sm text-gray-500 font-medium">Ready for transformation</p>
                        </div>

                        {/* Style Ticket */}
                        {proposedStyle ? (
                            <div className="bg-pink-50 border border-pink-100 rounded-3xl p-6 shadow-sm animate-fade-in-up">
                                <div className="flex justify-between items-start mb-4">
                                    <h3 className="font-black text-pink-700 uppercase tracking-widest text-xs flex items-center gap-2">
                                        <SparklesIcon className="w-4 h-4"/> Proposed Look
                                    </h3>
                                    <div className="bg-white px-3 py-1 rounded-full text-[10px] font-bold text-pink-600 shadow-sm">
                                        Darling Official
                                    </div>
                                </div>
                                <div className="grid grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <label className="text-[9px] font-bold text-pink-400 uppercase block mb-1">Product</label>
                                        <p className="font-bold text-gray-900 text-lg">{proposedStyle.product}</p>
                                    </div>
                                    <div>
                                        <label className="text-[9px] font-bold text-pink-400 uppercase block mb-1">Style Name</label>
                                        <p className="font-bold text-gray-900 text-lg">{proposedStyle.style_name}</p>
                                    </div>
                                    <div className="col-span-2">
                                        <label className="text-[9px] font-bold text-pink-400 uppercase block mb-1">Visual Notes</label>
                                        <p className="text-sm text-gray-700 font-medium leading-relaxed">{proposedStyle.visual_description}</p>
                                    </div>
                                </div>
                                <button 
                                    onClick={handleGenerateLook} 
                                    disabled={isGenerating}
                                    className="w-full py-4 bg-pink-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-pink-700 transition-transform active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50"
                                >
                                    {isGenerating ? 'Generating with Nano...' : 'Approve & Generate with Nano'} <PhotoIcon className="w-4 h-4"/>
                                </button>
                            </div>
                        ) : (
                            <div className="border-2 border-dashed border-gray-200 rounded-3xl p-12 text-center text-gray-300 flex flex-col items-center gap-4">
                                <ChatBubbleIcon className="w-12 h-12 opacity-20"/>
                                <p className="font-bold text-sm uppercase tracking-widest">Consultation in Progress</p>
                            </div>
                        )}

                        {/* Generated Results Grid */}
                        {generatedImages.length > 0 && (
                            <div className="space-y-4 animate-fade-in-up">
                                <h4 className="font-bold text-gray-900 text-sm uppercase tracking-widest">Results (Nano Engine)</h4>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                    {generatedImages.map((b64, idx) => {
                                        const isSelected = selectedImages.has(b64);
                                        return (
                                            <div 
                                                key={idx} 
                                                className={`aspect-[3/4] rounded-2xl overflow-hidden cursor-pointer relative group border-4 transition-all ${isSelected ? 'border-pink-500 shadow-xl scale-105' : 'border-transparent hover:border-pink-200'}`}
                                                onClick={() => toggleSelection(b64)}
                                            >
                                                <img src={`data:image/png;base64,${b64}`} className="w-full h-full object-cover" />
                                                {isSelected && (
                                                    <div className="absolute top-2 right-2 bg-pink-500 text-white p-1 rounded-full shadow-sm">
                                                        <CheckCircleIcon className="w-4 h-4"/>
                                                    </div>
                                                )}
                                                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                                                    <span className="text-white text-[10px] font-bold uppercase tracking-widest">{isSelected ? 'Deselect' : 'Select'}</span>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                                <div className="flex justify-end pt-4">
                                    <button 
                                        onClick={handleSaveSelection} 
                                        disabled={selectedImages.size === 0 || isSaving}
                                        className="px-8 py-3 bg-black text-white rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-gray-800 disabled:opacity-50 transition-all flex items-center gap-2"
                                    >
                                        {isSaving ? 'Saving...' : `Save Selected (${selectedImages.size}) to Gallery`} <ArrowRightIcon className="w-4 h-4"/>
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default DarlingStylist;