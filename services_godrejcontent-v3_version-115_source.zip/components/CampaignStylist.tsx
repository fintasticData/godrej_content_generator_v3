
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useRef, useEffect } from 'react';
import { Influencer, AspectRatio, GaiHairstyle, Location, CharacterItem } from '../types';
import { generateImage, generateImagenImage } from '../services/geminiService';
import { uploadBlob, saveGaiHairstyle, fetchLocations, updateCharacter, supabase } from '../services/supabaseClient';
import { GoogleGenAI } from "@google/genai";
import Modal from './Modal';
import { 
    XMarkIcon, 
    SparklesIcon, 
    ShoppingBagIcon, 
    ScissorsIcon, 
    CheckCircleIcon, 
    UserIcon, 
    BoltIcon, 
    ArrowRightIcon, 
    PhotoIcon, 
    SaveIcon, 
    Square2StackIcon,
    MapPinIcon,
    MagicWandIcon,
    CameraIcon,
    UploadCloudIcon,
    ExclamationTriangleIcon,
    PlusIcon,
    FilmIcon,
    PencilSquareIcon
} from './icons';

interface CampaignStylistProps {
    character: Influencer;
    onClose: () => void;
    onSuccess: () => void;
}

const urlToBase64 = async (url: string): Promise<string> => {
    try {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
            reader.readAsDataURL(blob);
        });
    } catch { return ""; }
};

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve((reader.result as string).split(',')[1]);
        reader.readAsDataURL(file);
    });
};

interface ShotConcept {
    title: string;
    hairstyle: string;
    pose: string;
    framing: string;
    description: string;
    status: 'pending' | 'generating' | 'success' | 'saved' | 'error';
    base64?: string;
    generatedUrl?: string;
    errorMsg?: string;
}

const FORMAT_OPTIONS = [
    { id: AspectRatio.SQUARE, label: 'Insta Square', icon: <div className="w-4 h-4 border-2 border-current rounded-sm"></div> },
    { id: AspectRatio.PORTRAIT, label: 'TikTok Portrait', icon: <div className="w-3 h-5 border-2 border-current rounded-sm"></div> },
    { id: AspectRatio.LANDSCAPE, label: 'YouTube Wide', icon: <div className="w-5 h-3 border-2 border-current rounded-sm"></div> }
];

const CampaignStylist: React.FC<CampaignStylistProps> = ({ character, onClose, onSuccess }) => {
    const [step, setStep] = useState(1);
    
    // --- Step 1: Campaign Setup ---
    const [campaignTheme, setCampaignTheme] = useState('');
    const [campaignFormat, setCampaignFormat] = useState<AspectRatio>(AspectRatio.SQUARE);
    
    // Assets
    const [productImage, setProductImage] = useState<string | null>(null);
    const [productFile, setProductFile] = useState<File | null>(null);
    
    const [locations, setLocations] = useState<Location[]>([]);
    const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
    
    const [selectedOutfit, setSelectedOutfit] = useState<CharacterItem | null>(null);
    
    const fileInputRef = useRef<HTMLInputElement>(null);

    // --- AI Generator States ---
    const [showOutfitGen, setShowOutfitGen] = useState(false);
    const [showLocationGen, setShowLocationGen] = useState(false);

    // Outfit Gen
    const [outfitPrompt, setOutfitPrompt] = useState('');
    const [outfitPreview, setOutfitPreview] = useState<string | null>(null);
    const [isGenOutfit, setIsGenOutfit] = useState(false);
    const [isSavingOutfit, setIsSavingOutfit] = useState(false);

    // Location Gen
    const [locName, setLocName] = useState('');
    const [locDesc, setLocDesc] = useState('');
    const [locCategory, setLocCategory] = useState('Studio');
    const [locPreview, setLocPreview] = useState<string | null>(null);
    const [isGenLoc, setIsGenLoc] = useState(false);
    const [isSavingLoc, setIsSavingLoc] = useState(false);

    // --- Step 2: AI Director ---
    const [shotList, setShotList] = useState<ShotConcept[]>([]);
    const [isDirecting, setIsDirecting] = useState(false);

    // --- Step 3: Production ---
    const [isProducing, setIsProducing] = useState(false);
    const [productionProgress, setProductionProgress] = useState(0);
    const [isSaving, setIsSaving] = useState(false);

    useEffect(() => {
        const loadResources = async () => {
            const locs = await fetchLocations();
            setLocations(locs || []);
        };
        loadResources();
    }, []);

    const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setProductFile(file);
            setProductImage(URL.createObjectURL(file));
        }
    };

    // --- AI Generator Handlers ---

    const handleGenerateOutfit = async () => {
        if (!outfitPrompt.trim()) return;
        setIsGenOutfit(true);
        setOutfitPreview(null);
        try {
            // Use Imagen for high fidelity outfit generation
            const result = await generateImagenImage(`Fashion Outfit Isolation: ${outfitPrompt}. High-end fashion photography, white background, detailed fabric texture.`, '1:1');
            // Mock preview for blob (since imagen returns bytes)
            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const url = URL.createObjectURL(blob);
            setOutfitPreview(url);
        } catch (e) {
            console.error(e);
            alert("Failed to generate outfit.");
        } finally {
            setIsGenOutfit(false);
        }
    };

    const handleSaveOutfit = async () => {
        if (!outfitPreview) return;
        setIsSavingOutfit(true);
        try {
            const response = await fetch(outfitPreview);
            const blob = await response.blob();
            const fileName = `ai_outfit_${Date.now()}.png`;
            const url = await uploadBlob(blob, fileName, 'godrej/wardrobe');

            if (!url) throw new Error("Image upload returned no URL.");

            const newItem: CharacterItem = {
                id: crypto.randomUUID(),
                type: 'outfit',
                name: outfitPrompt.substring(0, 20) || 'New Outfit',
                image_url: url,
                description: outfitPrompt,
                created_at: new Date().toISOString()
            };

            const pk = character.character_id || character.id;
            // Robust fetch of current items
            const { data: fresh, error: fetchError } = await supabase.from('dng1_characters').select('character_items').eq('character_id', pk).single();
            if (fetchError) throw new Error("Could not fetch character inventory.");

            let current = [];
            if (fresh && Array.isArray(fresh.character_items)) {
                current = fresh.character_items;
            }

            const { error: updateError } = await updateCharacter(pk!, { character_items: [newItem, ...current] });
            
            if (updateError) throw new Error("Database update failed.");
            
            // Select it and close
            setSelectedOutfit(newItem);
            setShowOutfitGen(false);
            setOutfitPrompt('');
            setOutfitPreview(null);
            
            onSuccess(); // Refresh parent
            alert("Outfit successfully saved to wardrobe!");

        } catch (e: any) {
            console.error(e);
            alert(`Failed to save outfit: ${e.message}`);
        } finally {
            setIsSavingOutfit(false);
        }
    };

    const handleGenerateLocation = async () => {
        if (!locDesc.trim()) return;
        setIsGenLoc(true);
        setLocPreview(null);
        try {
            const prompt = `Architectural Photography: ${locName}. ${locDesc}. Cinematic lighting, 8k resolution, highly detailed.`;
            const result = await generateImagenImage(prompt, '16:9');
            const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
            const url = URL.createObjectURL(blob);
            setLocPreview(url);
        } catch (e) {
            console.error(e);
            alert("Failed to generate location.");
        } finally {
            setIsGenLoc(false);
        }
    };

    const handleSaveLocation = async () => {
        if (!locPreview || !locName.trim()) return;
        setIsSavingLoc(true);
        try {
            const response = await fetch(locPreview);
            const blob = await response.blob();
            const fileName = `ai_loc_${Date.now()}.png`;
            const url = await uploadBlob(blob, fileName, 'godrej/locations');

            if (!url) throw new Error("Upload failed.");

            const newLoc = {
                name: locName,
                city: 'Virtual Studio',
                province: 'Digital',
                country: 'South Africa',
                region: 'Global',
                category: locCategory,
                currency: 'ZAR',
                prompt: { visual: locDesc, lighting: 'Cinematic', atmosphere: 'Professional' },
                image_urls: { primary: url, variants: [] }
            };

            const { data, error } = await supabase.from('dng_locations').insert(newLoc).select().single();
            if (error) throw error;

            if (data) {
                setLocations([data, ...locations]);
                setSelectedLocation(data);
                setShowLocationGen(false);
                setLocName('');
                setLocDesc('');
                setLocPreview(null);
                alert("Location saved!");
            }
        } catch (e: any) {
            console.error(e);
            alert(`Failed to save location: ${e.message}`);
        } finally {
            setIsSavingLoc(false);
        }
    };

    // --- End AI Handlers ---

    const handleCreateBrief = async () => {
        if (!productFile && !productImage) { alert("Please upload a product."); return; }
        if (!campaignTheme) { alert("Please enter a campaign theme."); return; }

        setIsDirecting(true);
        try {
            // 1. Prepare Inputs
            let prodB64 = '';
            if (productFile) prodB64 = await fileToBase64(productFile);
            else if (productImage) prodB64 = await urlToBase64(productImage);

            // 2. Call AI Director (Gemini)
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const prompt = `
                You are a Creative Director for a high-end hair beauty campaign.
                
                CAMPAIGN THEME: "${campaignTheme}"
                CHARACTER: ${character.name} (${character.role})
                LOCATION: ${selectedLocation ? selectedLocation.name : "Studio Background"}
                OUTFIT: ${selectedOutfit ? selectedOutfit.name : "Fashionable outfit matching the theme"}
                
                TASK:
                Analyze the attached hair product image.
                Create a 3-Shot Campaign Plan that showcases the product in different hairstyles and poses.
                
                REQUIREMENTS:
                - Shot 1: Close-Up (Focus on hair texture/details).
                - Shot 2: Medium Shot (Hair + Outfit harmony).
                - Shot 3: Full Body/Dynamic (Lifestyle/Action in location).
                
                Output JSON ONLY:
                [
                    {
                        "title": "Look Name",
                        "hairstyle": "Specific hairstyle name derived from product",
                        "pose": "Detailed pose description",
                        "framing": "Close-up / Medium / Full",
                        "description": "Visual instructions for the image generator combining hair, pose, and lighting."
                    }
                ]
            `;

            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: [
                    { inlineData: { mimeType: 'image/png', data: prodB64 } },
                    { text: prompt }
                ],
                config: { responseMimeType: "application/json" }
            });

            const concepts = JSON.parse(response.text || '[]');
            setShotList(concepts.map((c: any) => ({ ...c, status: 'pending' })));
            setStep(2);

        } catch (e) {
            console.error(e);
            alert("Failed to create campaign brief.");
        } finally {
            setIsDirecting(false);
        }
    };

    const handleProduceCampaign = async () => {
        setIsProducing(true);
        setProductionProgress(0);

        try {
            const charB64 = await urlToBase64(character.image_url || character.image_urls_jsonb?.[0]?.url || '');
            
            let prodB64 = '';
            if (productFile) prodB64 = await fileToBase64(productFile);
            else if (productImage) prodB64 = await urlToBase64(productImage);

            let locB64 = '';
            if (selectedLocation?.image_urls?.primary) {
                locB64 = await urlToBase64(selectedLocation.image_urls.primary);
            }

            const newShotList = [...shotList];

            for (let i = 0; i < newShotList.length; i++) {
                const shot = newShotList[i];
                // Skip if already successfully generated or saved
                if (shot.status === 'saved' || (shot.status === 'success' && shot.base64)) continue;

                newShotList[i].status = 'generating';
                setShotList([...newShotList]);

                try {
                    // Construct References
                    const references: any = {
                        character: charB64,
                        product: prodB64, 
                    };
                    if (locB64) references.setting = locB64;

                    const fullPrompt = `
                        Fashion Photography. ${shot.title}: ${shot.description}.
                        Hairstyle: ${shot.hairstyle}.
                        Pose: ${shot.pose}.
                        Framing: ${shot.framing}.
                        Location: ${selectedLocation ? selectedLocation.name : "Studio"}.
                        Outfit: ${selectedOutfit ? selectedOutfit.name : "Stylish fashion"}.
                        Lighting: Cinematic, High Key. 8k Resolution.
                        Identity: Keep the character's facial features exactly.
                    `;

                    // Use Pro Model for Composition with selected format
                    const result = await generateImage(
                        fullPrompt, 
                        campaignFormat, // Use global campaign format
                        references,
                        undefined,
                        'gemini-3-pro-image-preview'
                    );

                    // Store Base64 immediately so we don't lose it even if upload fails
                    newShotList[i].base64 = result.base64;
                    
                    // Attempt immediate upload
                    let publicUrl: string | null = null;
                    try {
                        const binary = atob(result.base64);
                        const array = [];
                        for (let k = 0; k < binary.length; k++) array.push(binary.charCodeAt(k));
                        const blob = new Blob([new Uint8Array(array)], { type: result.mimeType || 'image/png' });
                        const fileName = `camp_shot_${i}_${Date.now()}.png`;
                        publicUrl = await uploadBlob(blob, fileName, 'godrej/campaigns');
                    } catch (uploadError) {
                        console.error("Auto-upload failed, but image generated.", uploadError);
                    }

                    newShotList[i].generatedUrl = publicUrl || undefined;
                    // Mark as success because we have the image data. We will retry upload on Save.
                    newShotList[i].status = 'success'; 
                    newShotList[i].errorMsg = undefined;

                } catch (err: any) {
                    console.error(`Generation failed for shot ${i}`, err);
                    newShotList[i].status = 'error';
                    newShotList[i].errorMsg = err.message || "Generation failed";
                }
                
                setShotList([...newShotList]);
                setProductionProgress(((i + 1) / newShotList.length) * 100);
            }
            
            setStep(3);

        } catch (e) {
            console.error(e);
            alert("Production interrupted.");
        } finally {
            setIsProducing(false);
        }
    };

    const handleSaveAll = async () => {
        setIsSaving(true);
        try {
            // Upload Product Image Reference if not already a URL
            let prodUrl = productImage;
            if (productFile && !productImage?.startsWith('http')) {
                const url = await uploadBlob(productFile, `campaign_prod_ref_${Date.now()}.png`, 'godrej/products');
                if (url) prodUrl = url;
            }

            let savedCount = 0;
            const newShotList = [...shotList];

            for (let i = 0; i < newShotList.length; i++) {
                const shot = newShotList[i];
                
                // Skip if already saved to DB
                if (shot.status === 'saved') continue;
                
                // Skip if generation failed
                if (shot.status === 'error' || !shot.base64) continue;

                // Ensure we have a URL. If produced via handleProduceCampaign, it might be there.
                // Fallback upload if base64 exists but no URL (retry logic)
                let finalUrl = shot.generatedUrl;
                if (!finalUrl && shot.base64) {
                    try {
                        const binary = atob(shot.base64);
                        const array = [];
                        for (let k = 0; k < binary.length; k++) array.push(binary.charCodeAt(k));
                        const blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
                        finalUrl = await uploadBlob(blob, `camp_shot_retry_${Date.now()}.png`, 'godrej/campaigns');
                        newShotList[i].generatedUrl = finalUrl || undefined;
                    } catch (e) {
                        console.error(`Retry upload failed for shot ${i}`, e);
                    }
                }

                if (finalUrl) {
                    const record: GaiHairstyle = {
                        Name: shot.hairstyle,
                        Characteristics: `${shot.title} - ${shot.pose}`,
                        Display: campaignTheme,
                        Transformation: "AI Campaign Director",
                        info_jsonb: {
                            theme: campaignTheme,
                            location: selectedLocation?.name,
                            outfit: selectedOutfit?.name,
                            format: campaignFormat
                        },
                        images_jsonb: {
                            generated_url: finalUrl,
                            product_url: prodUrl || ''
                        },
                        analysis_jsonb: shot,
                        ai_images: [finalUrl],
                        braid_process: {}
                    };
                    
                    await saveGaiHairstyle(record);
                    newShotList[i].status = 'saved';
                    savedCount++;
                }
            }
            
            setShotList(newShotList);
            
            if (savedCount > 0) {
                alert(`Campaign Saved! ${savedCount} shots stored.`);
                onSuccess();
            } else {
                alert("All valid shots are already saved.");
            }

        } catch (e) {
            console.error(e);
            alert("Save failed. Please check network connection.");
        } finally {
            setIsSaving(false);
        }
    };

    const updateShot = (index: number, field: keyof ShotConcept, value: string) => {
        setShotList(prev => prev.map((shot, i) => i === index ? { ...shot, [field]: value } : shot));
    };

    const handleRegenerateShot = (index: number) => {
        setShotList(prev => prev.map((shot, i) => i === index ? { ...shot, status: 'pending', base64: undefined, generatedUrl: undefined } : shot));
        // If we are in Step 3, switching status to pending allows the user to click "Produce" again
        // But better UX is to trigger produce immediately for that shot? 
        // For simplicity, let's just reset status so "Produce" picks it up, or user can edit text.
    };

    return (
        <div className="fixed inset-0 z-[200] bg-purple-900/90 backdrop-blur-md flex items-center justify-center p-4">
            <div className="bg-white w-full max-w-6xl h-[90vh] rounded-[2.5rem] shadow-2xl flex overflow-hidden border-4 border-purple-500 relative">
                <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-gray-100 hover:bg-gray-200 rounded-full z-20 transition-colors"><XMarkIcon className="w-6 h-6 text-gray-500"/></button>

                {/* Left Panel: Configuration */}
                <div className="w-[400px] bg-purple-50 p-8 flex flex-col border-r border-purple-100 overflow-y-auto">
                    <div className="mb-8">
                        <h2 className="text-2xl font-black text-purple-900 uppercase tracking-tighter mb-2">Campaign Stylist</h2>
                        <p className="text-xs font-bold text-purple-600 uppercase tracking-widest flex items-center gap-2">
                            <SparklesIcon className="w-4 h-4"/> AI Creative Director
                        </p>
                    </div>

                    <div className="space-y-6">
                        {/* 1. Theme */}
                        <div className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Campaign Theme</label>
                            <textarea 
                                className="w-full h-20 bg-gray-50 border border-gray-200 rounded-xl p-3 text-sm font-bold text-purple-900 outline-none resize-none focus:ring-2 focus:ring-purple-200"
                                placeholder="e.g. Summer Afro-Punk Festival, Golden Hour Glow..."
                                value={campaignTheme}
                                onChange={(e) => setCampaignTheme(e.target.value)}
                            />
                        </div>

                        {/* Format Selection */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block px-1">Campaign Format</label>
                            <div className="grid grid-cols-3 gap-2">
                                {FORMAT_OPTIONS.map(opt => (
                                    <button 
                                        key={opt.id}
                                        onClick={() => setCampaignFormat(opt.id)}
                                        className={`flex flex-col items-center justify-center p-2 rounded-xl border-2 transition-all ${campaignFormat === opt.id ? 'border-purple-500 bg-purple-100 text-purple-700' : 'border-gray-200 bg-white text-gray-400 hover:border-purple-200'}`}
                                    >
                                        {opt.icon}
                                        <span className="text-[8px] font-bold mt-1 uppercase text-center leading-tight">{opt.label}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* 2. Product */}
                        <div 
                            onClick={() => fileInputRef.current?.click()}
                            className="bg-white p-4 rounded-2xl border border-purple-100 shadow-sm cursor-pointer hover:border-purple-300 transition-colors group"
                        >
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Hero Product</label>
                            <div className="flex items-center gap-4">
                                <div className="w-16 h-16 bg-gray-100 rounded-xl flex items-center justify-center overflow-hidden border border-gray-200 group-hover:border-purple-200">
                                    {productImage ? <img src={productImage} className="w-full h-full object-cover"/> : <ShoppingBagIcon className="w-6 h-6 text-gray-300"/>}
                                </div>
                                <div className="flex-1">
                                    <p className="text-xs font-bold text-gray-700">{productFile ? productFile.name : "Upload Item"}</p>
                                    <p className="text-[9px] text-gray-400">Click to browse...</p>
                                </div>
                            </div>
                            <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleUpload} />
                        </div>

                        {/* 3. Wardrobe Selector */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                <UserIcon className="w-3 h-3"/> Outfit Selection
                            </label>
                            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                                <button 
                                    onClick={() => setShowOutfitGen(true)}
                                    className={`w-16 h-20 shrink-0 rounded-xl border-2 flex flex-col items-center justify-center gap-1 ${!selectedOutfit ? 'border-purple-500 bg-purple-100' : 'border-gray-200 bg-white hover:border-purple-300'}`}
                                >
                                    <MagicWandIcon className="w-4 h-4 text-purple-500"/>
                                    <span className="text-[8px] font-bold uppercase text-purple-700 text-center leading-tight px-1">AI Stylist</span>
                                </button>
                                {character.character_items?.filter((i: any) => i.type === 'outfit').map((item: any) => (
                                    <button 
                                        key={item.id}
                                        onClick={() => setSelectedOutfit(item)}
                                        className={`w-16 h-20 shrink-0 rounded-xl border-2 overflow-hidden relative ${selectedOutfit?.id === item.id ? 'border-purple-500' : 'border-gray-200'}`}
                                    >
                                        <img src={item.image_url} className="w-full h-full object-cover"/>
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* 4. Location Selector */}
                        <div className="space-y-2">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                <MapPinIcon className="w-3 h-3"/> Set Location
                            </label>
                            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                                <button 
                                    onClick={() => setShowLocationGen(true)}
                                    className={`w-24 h-16 shrink-0 rounded-xl border-2 flex flex-col items-center justify-center gap-1 ${!selectedLocation ? 'border-purple-500 bg-purple-100' : 'border-gray-200 bg-white hover:border-purple-300'}`}
                                >
                                    <MagicWandIcon className="w-4 h-4 text-purple-500"/>
                                    <span className="text-[8px] font-bold uppercase text-purple-700">AI Scout</span>
                                </button>
                                {locations.map((loc: any) => (
                                    <button 
                                        key={loc.id}
                                        onClick={() => setSelectedLocation(loc)}
                                        className={`w-24 h-16 shrink-0 rounded-xl border-2 overflow-hidden relative ${selectedLocation?.id === loc.id ? 'border-purple-500' : 'border-gray-200'}`}
                                    >
                                        {loc.image_urls?.primary ? <img src={loc.image_urls.primary} className="w-full h-full object-cover"/> : <div className="bg-gray-100 w-full h-full flex items-center justify-center text-[9px] font-bold text-gray-400">{loc.name}</div>}
                                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[8px] font-bold px-1 truncate">{loc.name}</div>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <button 
                            onClick={handleCreateBrief}
                            disabled={isDirecting}
                            className="w-full py-4 bg-purple-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-purple-700 disabled:opacity-50 flex items-center justify-center gap-2 mt-4"
                        >
                            {isDirecting ? 'Directing...' : 'Generate Campaign Brief'} <BoltIcon className="w-4 h-4"/>
                        </button>
                    </div>
                </div>

                {/* Right Panel: Director's Monitor */}
                <div className="flex-1 bg-white p-10 flex flex-col overflow-hidden">
                    {step === 1 && (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                            <CameraIcon className="w-24 h-24 text-gray-300 mb-6"/>
                            <h3 className="text-xl font-bold text-gray-400">Director's Monitor</h3>
                            <p className="text-sm text-gray-400 mt-2 max-w-xs">Configure the campaign on the left to start the creative process.</p>
                        </div>
                    )}

                    {step >= 2 && (
                        <div className="flex-1 flex flex-col gap-6 overflow-hidden">
                            <div className="flex justify-between items-center">
                                <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter">Campaign Shot List</h3>
                                {step >= 2 && (
                                    <button 
                                        onClick={handleProduceCampaign}
                                        disabled={isProducing}
                                        className="bg-black text-white px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-gray-800 transition-all flex items-center gap-2"
                                    >
                                        {isProducing ? 'Shooting...' : (step === 3 ? 'Retake Failed Shots' : 'Start Production')} <CameraIcon className="w-4 h-4"/>
                                    </button>
                                )}
                                {step === 3 && (
                                    <button 
                                        onClick={handleSaveAll}
                                        disabled={isSaving}
                                        className="bg-green-600 text-white px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:bg-green-700 transition-all flex items-center gap-2"
                                    >
                                        {isSaving ? 'Syncing...' : 'Save Campaign to DB'} <SaveIcon className="w-4 h-4"/>
                                    </button>
                                )}
                            </div>

                            <div className="grid grid-cols-3 gap-6 h-full overflow-y-auto pb-10">
                                {shotList.map((shot, idx) => (
                                    <div key={idx} className="flex flex-col gap-4 group">
                                        <div className={`rounded-[2rem] border-4 shadow-lg overflow-hidden relative ${campaignFormat === AspectRatio.SQUARE ? 'aspect-square' : campaignFormat === AspectRatio.PORTRAIT ? 'aspect-[9/16]' : 'aspect-video'} bg-gray-100 border-white`}>
                                            {shot.base64 ? (
                                                <img src={`data:image/png;base64,${shot.base64}`} className="w-full h-full object-cover animate-fade-in-up" />
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-300 p-6 text-center">
                                                    {shot.status === 'generating' ? (
                                                        <div className="w-10 h-10 border-4 border-purple-300 border-t-purple-600 rounded-full animate-spin mb-4"></div>
                                                    ) : (
                                                        <PhotoIcon className="w-12 h-12 opacity-30 mb-4"/>
                                                    )}
                                                    {shot.status === 'error' ? (
                                                        <p className="text-[10px] font-bold text-red-400 uppercase">Error: {shot.errorMsg || 'Failed'}</p>
                                                    ) : (
                                                        <p className="text-[10px] font-black uppercase tracking-widest">{shot.status === 'generating' ? 'Rendering...' : 'Pending Shot'}</p>
                                                    )}
                                                </div>
                                            )}
                                            
                                            {/* Status Badge */}
                                            {shot.status === 'saved' && (
                                                <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full font-bold uppercase text-[9px] flex items-center gap-1 shadow-xl">
                                                    <CheckCircleIcon className="w-3 h-3"/> Saved
                                                </div>
                                            )}
                                            {shot.status === 'success' && (
                                                <div className="absolute top-4 right-4 bg-blue-500 text-white px-3 py-1 rounded-full font-bold uppercase text-[9px] flex items-center gap-1 shadow-xl cursor-pointer hover:bg-blue-600" onClick={() => handleRegenerateShot(idx)}>
                                                    <ArrowRightIcon className="w-3 h-3 rotate-180"/> Re-Shoot
                                                </div>
                                            )}
                                        </div>
                                        <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 hover:border-purple-200 transition-colors">
                                            <div className="flex justify-between items-start mb-2">
                                                <span className="text-[9px] font-black text-purple-500 uppercase tracking-widest bg-purple-100 px-2 py-0.5 rounded">{shot.framing}</span>
                                                <span className="text-[9px] font-bold text-gray-400">Shot {idx+1}</span>
                                            </div>
                                            
                                            {/* Editable Fields */}
                                            <div className="space-y-2">
                                                <input 
                                                    className="w-full bg-transparent font-bold text-gray-900 leading-tight mb-1 outline-none border-b border-transparent focus:border-purple-200"
                                                    value={shot.title}
                                                    onChange={(e) => updateShot(idx, 'title', e.target.value)}
                                                />
                                                <textarea 
                                                    className="w-full bg-transparent text-[10px] text-gray-500 leading-relaxed mb-2 outline-none border-b border-transparent focus:border-purple-200 resize-none h-12"
                                                    value={shot.description}
                                                    onChange={(e) => updateShot(idx, 'description', e.target.value)}
                                                />
                                                <div className="flex items-center gap-2 text-[9px] font-bold text-gray-400">
                                                    <ScissorsIcon className="w-3 h-3"/> 
                                                    <input 
                                                        className="bg-transparent w-full outline-none focus:text-purple-600"
                                                        value={shot.hairstyle}
                                                        onChange={(e) => updateShot(idx, 'hairstyle', e.target.value)}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* AI Stylist Modal */}
            <Modal isOpen={showOutfitGen} onClose={() => setShowOutfitGen(false)} title="AI Stylist: Outfit Generator">
                <div className="space-y-6 p-2">
                    <p className="text-sm text-gray-500">Design a custom outfit for {character.name}. This will be added to their wardrobe inventory.</p>
                    <textarea 
                        className="w-full h-32 bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm font-medium outline-none resize-none focus:ring-2 focus:ring-purple-200"
                        placeholder="e.g. Red silk evening gown, high fashion, elegant drape..."
                        value={outfitPrompt}
                        onChange={(e) => setOutfitPrompt(e.target.value)}
                    />
                    {outfitPreview && (
                        <div className="aspect-square w-full max-w-xs mx-auto rounded-2xl overflow-hidden shadow-lg border border-gray-100">
                            <img src={outfitPreview} className="w-full h-full object-cover" />
                        </div>
                    )}
                    <div className="flex gap-4">
                        <button onClick={handleGenerateOutfit} disabled={isGenOutfit || !outfitPrompt.trim()} className="flex-1 py-3 bg-purple-100 text-purple-700 rounded-xl font-bold uppercase text-xs hover:bg-purple-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                            {isGenOutfit ? 'Designing...' : 'Generate Design'} <MagicWandIcon className="w-4 h-4"/>
                        </button>
                        <button onClick={handleSaveOutfit} disabled={isSavingOutfit || !outfitPreview} className="flex-1 py-3 bg-black text-white rounded-xl font-bold uppercase text-xs hover:bg-gray-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                            {isSavingOutfit ? 'Saving...' : 'Save to Wardrobe'} <CheckCircleIcon className="w-4 h-4"/>
                        </button>
                    </div>
                </div>
            </Modal>

            {/* AI Scout Modal */}
            <Modal isOpen={showLocationGen} onClose={() => setShowLocationGen(false)} title="AI Scout: Location Generator">
                <div className="space-y-6 p-2">
                    <p className="text-sm text-gray-500">Generate a new shooting location or set design. This will be saved to the Location Hub.</p>
                    <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Location Name</label>
                        <input className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold outline-none" value={locName} onChange={e => setLocName(e.target.value)} placeholder="e.g. Neon City Rooftop" />
                    </div>
                    <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Category</label>
                        <select className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-bold outline-none" value={locCategory} onChange={e => setLocCategory(e.target.value)}>
                            <option>Studio</option>
                            <option>Outdoor</option>
                            <option>Residential</option>
                            <option>Commercial</option>
                            <option>Cyberpunk</option>
                            <option>Virtual</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Visual Description</label>
                        <textarea 
                            className="w-full h-24 bg-gray-50 border border-gray-200 rounded-xl p-4 text-sm font-medium outline-none resize-none focus:ring-2 focus:ring-purple-200"
                            placeholder="Describe the environment, lighting, and mood..."
                            value={locDesc}
                            onChange={(e) => setLocDesc(e.target.value)}
                        />
                    </div>
                    {locPreview && (
                        <div className="aspect-video w-full rounded-2xl overflow-hidden shadow-lg border border-gray-100">
                            <img src={locPreview} className="w-full h-full object-cover" />
                        </div>
                    )}
                    <div className="flex gap-4">
                        <button onClick={handleGenerateLocation} disabled={isGenLoc || !locDesc.trim()} className="flex-1 py-3 bg-purple-100 text-purple-700 rounded-xl font-bold uppercase text-xs hover:bg-purple-200 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                            {isGenLoc ? 'Scouting...' : 'Generate Location'} <MagicWandIcon className="w-4 h-4"/>
                        </button>
                        <button onClick={handleSaveLocation} disabled={isSavingLoc || !locPreview} className="flex-1 py-3 bg-black text-white rounded-xl font-bold uppercase text-xs hover:bg-gray-800 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                            {isSavingLoc ? 'Saving...' : 'Save to Hub'} <CheckCircleIcon className="w-4 h-4"/>
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default CampaignStylist;
