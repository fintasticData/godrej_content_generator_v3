/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, AspectRatio, ChatSession } from '../types';
import { generateImage, startChatSession, refineImagePrompt } from '../services/geminiService';
import { PaperAirplaneIcon, SparklesIcon, PlusIcon, UserIcon, MapPinIcon, CubeIcon } from './icons';

interface ChatAssistantProps {
  onSaveGeneratedAsset: (blob: Blob, fileName: string, folder?: string, contextType?: 'product'|'character'|'setting') => Promise<void>;
}

const ChatAssistant: React.FC<ChatAssistantProps> = ({ onSaveGeneratedAsset }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Persist the chat session instance
  const chatSessionRef = useRef<ChatSession | null>(null);

  // Initialize Chat Session on Mount
  useEffect(() => {
    chatSessionRef.current = startChatSession();
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading || !chatSessionRef.current) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
        const result = await chatSessionRef.current.sendMessage({ message: userMessage.text || '' });
        
        // 1. Check for Function Calls (Tools)
        const functionCalls = result.functionCalls;
        
        if (functionCalls && functionCalls.length > 0) {
             for (const call of functionCalls) {
                 if (call.name === 'generate_image') {
                     const args = call.args as any;
                     let prompt = args.prompt;
                     const assetType = args.asset_type || 'general';

                     // IMPROVEMENT: Use JSON Transformer to refine the prompt
                     setMessages(prev => [...prev, {
                         id: crypto.randomUUID(),
                         role: 'assistant',
                         text: `Creating ${assetType}... Refining prompt with JSON transformer...`,
                         timestamp: Date.now()
                     }]);

                     try {
                         const refinement = await refineImagePrompt(prompt);
                         prompt = refinement.improved_prompt;
                     } catch(e) {
                         console.warn("Prompt refinement failed, using original.");
                     }
                     
                     // Execute the tool (Image Generation)
                     const imageResult = await generateImage(prompt, AspectRatio.LANDSCAPE);
                     
                     // Display the result to the user immediately
                     const toolMessage: ChatMessage = {
                         id: crypto.randomUUID(),
                         role: 'assistant',
                         text: `Here is the ${assetType} image.`,
                         image: {
                             base64: imageResult.base64,
                             mimeType: imageResult.mimeType,
                             assetType: assetType
                         },
                         timestamp: Date.now(),
                         isToolOutput: true
                     };
                     setMessages(prev => [...prev, toolMessage]);

                     // Send result back to the model using sendMessage with a functionResponse part
                     const toolResponse = await chatSessionRef.current.sendMessage({
                        message: [{
                            functionResponse: {
                                name: call.name,
                                response: { result: "Image generated and displayed to user successfully." }
                            }
                        }]
                     });
                     
                     // Add any follow-up text from the model after the tool execution
                     if (toolResponse.text) {
                         setMessages(prev => [...prev, {
                             id: crypto.randomUUID(),
                             role: 'assistant',
                             text: toolResponse.text,
                             timestamp: Date.now()
                         }]);
                     }
                 }
             }
        } else {
            // 2. Standard Text Response
            const aiMessage: ChatMessage = {
                id: crypto.randomUUID(),
                role: 'assistant',
                text: result.text,
                timestamp: Date.now()
            };
            setMessages(prev => [...prev, aiMessage]);
        }
    } catch (e) {
      console.error(e);
      const errorMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        text: "I encountered an error processing your request. Let's try again.",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveAsset = async (messageId: string, base64: string, mimeType: string, assetType: string = 'general') => {
    try {
        setMessages(prev => prev.map(m => m.id === messageId ? { ...m, text: `Saving to Library as ${assetType}...` } : m));
        
        // Convert base64 to blob
        const byteCharacters = atob(base64);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: mimeType });
        
        const fileName = `${assetType}_gen_${Date.now()}.png`;
        
        // Determine folder based on assetType
        let folder = 'godrej/assets';
        let contextType: 'product'|'character'|'setting'|undefined = undefined;

        if (assetType === 'character') {
            folder = 'godrej/characters';
            contextType = 'character';
        } else if (assetType === 'setting') {
            folder = 'godrej/settings';
            contextType = 'setting';
        } else if (assetType === 'product') {
            folder = 'godrej/products';
            contextType = 'product';
        }

        // Use the callback which now handles both DB saving and Context state update
        await onSaveGeneratedAsset(blob, fileName, folder, contextType);

        setMessages(prev => prev.map(m => m.id === messageId ? { ...m, text: `Saved to Library: ${assetType}!`, image: { ...m.image!, isSaved: true } } : m));
    } catch (e) {
        console.error("Failed to save asset from chat", e);
        setMessages(prev => prev.map(m => m.id === messageId ? { ...m, text: "Failed to save." } : m));
    }
  };

  return (
    <div className="flex flex-col h-full bg-white border-r border-gray-200">
        <div className="p-4 border-b border-gray-200 bg-white">
            <h3 className="font-bold text-gray-900 flex items-center gap-2">
                <SparklesIcon className="w-4 h-4 text-indigo-600" />
                AiDi Assistant
            </h3>
            <p className="text-xs text-gray-500 mt-1">Your AI Creative Director. I can create characters, settings, and products.</p>
        </div>

        <div className="flex-grow overflow-y-auto p-4 space-y-4 bg-gray-50/30">
            {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl p-3 shadow-sm ${
                        msg.role === 'user' 
                        ? 'bg-indigo-600 text-white rounded-br-none' 
                        : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none'
                    }`}>
                        {msg.text && <p className="text-sm whitespace-pre-wrap">{msg.text}</p>}
                        
                        {msg.image && (
                            <div className="mt-2 relative group rounded-lg overflow-hidden border border-gray-200">
                                <img 
                                    src={`data:${msg.image.mimeType};base64,${msg.image.base64}`} 
                                    alt="Generated" 
                                    className="w-full h-auto"
                                />
                                {!msg.image.isSaved ? (
                                    <div className="absolute inset-0 bg-white/80 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 backdrop-blur-[2px]">
                                        
                                        {/* Dynamic Save Button based on Asset Type */}
                                        {msg.image.assetType === 'character' && (
                                            <button 
                                                onClick={() => handleSaveAsset(msg.id, msg.image!.base64, msg.image!.mimeType, 'character')}
                                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1 shadow-md"
                                            >
                                                <UserIcon className="w-3 h-3" /> Save Character
                                            </button>
                                        )}
                                        {msg.image.assetType === 'setting' && (
                                            <button 
                                                onClick={() => handleSaveAsset(msg.id, msg.image!.base64, msg.image!.mimeType, 'setting')}
                                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1 shadow-md"
                                            >
                                                <MapPinIcon className="w-3 h-3" /> Save Setting
                                            </button>
                                        )}
                                        {msg.image.assetType === 'product' && (
                                            <button 
                                                onClick={() => handleSaveAsset(msg.id, msg.image!.base64, msg.image!.mimeType, 'product')}
                                                className="bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 rounded text-xs flex items-center gap-1 shadow-md"
                                            >
                                                <CubeIcon className="w-3 h-3" /> Save Product
                                            </button>
                                        )}
                                        
                                        {/* Default Save */}
                                        <button 
                                            onClick={() => handleSaveAsset(msg.id, msg.image!.base64, msg.image!.mimeType, 'general')}
                                            className="bg-white border border-gray-300 text-gray-700 hover:bg-gray-50 px-3 py-1 rounded text-xs flex items-center gap-1 shadow-sm"
                                        >
                                            <PlusIcon className="w-3 h-3" /> Save Asset
                                        </button>
                                    </div>
                                ) : (
                                    <div className="absolute top-2 right-2 bg-green-500 text-white text-[10px] px-2 py-1 rounded-full font-bold shadow-md">
                                        IN LIBRARY
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            ))}
            {isLoading && (
                <div className="flex justify-start">
                    <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-none p-3 flex gap-1 shadow-sm">
                        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></span>
                        <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></span>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-gray-200 bg-white">
            <div className="relative">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Describe a character, setting, or product..."
                    className="w-full bg-gray-50 border border-gray-300 rounded-full pl-4 pr-12 py-3 text-sm text-gray-900 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 shadow-inner"
                    disabled={isLoading}
                />
                <button 
                    onClick={handleSendMessage}
                    disabled={isLoading || !input.trim()}
                    className="absolute right-1.5 top-1.5 p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
                >
                    <PaperAirplaneIcon className="w-4 h-4" />
                </button>
            </div>
        </div>
    </div>
  );
};

export default ChatAssistant;