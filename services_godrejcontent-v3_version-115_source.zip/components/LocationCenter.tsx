
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { supabase, uploadBlob, fetchLocations, createLocation, updateLocation, deleteLocation } from '../services/supabaseClient';
import { generateImage, generateImagenImage } from '../services/geminiService';
import { Location, AspectRatio } from '../types';
import { 
    PlusIcon, 
    SearchIcon, 
    MapIcon, 
    MapPinIcon, 
    GlobeAltIcon, 
    TrashIcon, 
    SaveIcon,
    XMarkIcon,
    SparklesIcon,
    PhotoIcon,
    MagicWandIcon,
    CheckCircleIcon,
    ChevronRightIcon,
    UploadCloudIcon,
    BoltIcon,
    CameraIcon,
    PencilSquareIcon,
    ShareIcon
} from './icons';
import Modal from './Modal';

const CATEGORIES = ["Studio", "Outdoor", "Residential", "Commercial", "Cyberpunk", "Virtual", "Premium Weaves", "Shop-in-Shop", "Salon", "Retail"];

const LocationCenter: React.FC = () => {
    const [locations, setLocations] = useState<Location[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [inspectedLoc, setInspectedLoc] = useState<Location | null>(null);
    const [isSaving, setIsSaving] = useState(false);
    const [showCreateModal, setShowCreateModal] = useState(false);
    
    // Create Form State
    const [newName, setNewName] = useState('');
    const [newCity, setNewCity] = useState('');
    const [newCategory, setNewCategory] = useState('Studio');
    
    // Studio State
    const [isGenerating, setIsGenerating] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => { loadData(); }, []);

    const loadData = async () => {
        setIsLoading(true);
        const data = await fetchLocations();
        
        // Data Normalization for Prompt Fields
        const normalizedData = data.map(loc => {
            let parsedPrompt = loc.prompt;
            if (typeof parsedPrompt === 'string') {
                try { parsedPrompt = JSON.parse(parsedPrompt); } catch (e) {}
            }
            
            // Map legacy or alternative fields if standard ones are missing
            const visual = parsedPrompt.visual || parsedPrompt.visual_style || "";
            const lighting = parsedPrompt.lighting || "";
            const atmosphere = parsedPrompt.atmosphere || "";

            return {
                ...loc,
                prompt: {
                    ...parsedPrompt,
                    visual,
                    lighting,
                    atmosphere
                },
                image_urls: typeof loc.image_urls === 'string' ? JSON.parse(loc.image_urls) : (loc.image_urls || { primary: '', variants: [] })
            };
        });

        setLocations(normalizedData);
        setIsLoading(false);
    };

    const handleCreateLocation = async () => {
        if (!newName.trim()) return;
        setIsSaving(true);
        try {
            const loc: Partial<Location> = {
                name: newName,
                city: newCity || 'Global',
                province: 'Unknown',
                region: 'Global',
                category: newCategory,
                country: 'South Africa', // Default as per screenshot hint
                currency: 'ZAR',
                prompt: { visual: `High-end ${newCategory} location in ${newCity}`, lighting: 'Cinematic', atmosphere: 'Clean' },
                image_urls: { primary: '', variants: [] }
            };
            const result = await createLocation(loc);
            if (result) {
                setLocations([result, ...locations]);
                setShowCreateModal(false);
                setNewName('');
                setInspectedLoc(result);
            }
        } catch (e) { console.error(e); } finally { setIsSaving(false); }
    };

    const handleUpdateLocation = async () => {
        if (!inspectedLoc) return;
        setIsSaving(true);
        try {
            await updateLocation(inspectedLoc.id, inspectedLoc);
            setLocations(prev => prev.map(l => l.id === inspectedLoc.id ? inspectedLoc : l));
            alert("Location synchronized.");
        } catch (e) { console.error(e); } finally { setIsSaving(false); }
    };

    const handleDelete = async (id: string | number) => {
        if (!confirm("Delete this set design?")) return;
        await deleteLocation(id);
        setInspectedLoc(null);
        loadData(); // Reload to refresh list
    };

    const handleGenerateVisual = async () => {
        if (!inspectedLoc) return;
        setIsGenerating(true);
        try {
            const p = inspectedLoc.prompt;
            const fullPrompt = `Architectural Photography: ${p.visual}. Lighting: ${p.lighting}. Atmosphere: ${p.atmosphere}. 8k, highly detailed, photorealistic.`;
            
            // Use Imagen 4.0 for high fidelity location masters
            const result = await generateImagenImage(fullPrompt, '16:9');
            const blob = await (await fetch(`data:image/jpeg;base64,${result.base64}`)).blob();
            const url = await uploadBlob(blob, `set_${inspectedLoc.id}_${Date.now()}.png`, 'godrej/locations');
            
            if (url) {
                const currentImgs = inspectedLoc.image_urls || { primary: '', variants: [] };
                const updated = {
                    primary: currentImgs.primary || url,
                    variants: [url, ...(currentImgs.variants || [])]
                };
                const finalLoc = { ...inspectedLoc, image_urls: updated };
                setInspectedLoc(finalLoc);
                
                // Optimistic local update
                setLocations(prev => prev.map(l => l.id === inspectedLoc.id ? finalLoc : l));
                
                await updateLocation(inspectedLoc.id, { image_urls: updated });
            }
        } catch (e) { console.error(e); alert("Visual generation failed."); } finally { setIsGenerating(false); }
    };

    const handleUploadImage = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !inspectedLoc) return;
        setIsSaving(true);
        try {
            const url = await uploadBlob(file, `loc_manual_${Date.now()}.png`, 'godrej/locations');
            if (url) {
                const currentImgs = inspectedLoc.image_urls || { primary: '', variants: [] };
                const updated = { primary: url, variants: [url, ...(currentImgs.variants || [])] };
                const finalLoc = { ...inspectedLoc, image_urls: updated };
                setInspectedLoc(finalLoc);
                setLocations(prev => prev.map(l => l.id === inspectedLoc.id ? finalLoc : l));
                await updateLocation(inspectedLoc.id, { image_urls: updated });
            }
        } catch (e) { console.error(e); } finally { setIsSaving(false); }
    };

    const filtered = locations.filter(l => l.name.toLowerCase().includes(searchQuery.toLowerCase()) || l.city.toLowerCase().includes(searchQuery.toLowerCase()));

    return (
        <div className="w-full h-full flex flex-col bg-white overflow-hidden font-sans text-gray-900">
            {/* Header */}
            <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-20">
                <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-50 rounded-lg text-blue-600"><MapIcon className="w-5 h-5"/></div>
                    <div>
                        <h2 className="text-lg font-black uppercase tracking-tight text-gray-900">Location Hub</h2>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Shoot Set & Virtual Environment Management</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <div className="relative w-64">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                        <input 
                            className="w-full pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm outline-none focus:ring-1 focus:ring-blue-500 transition-shadow" 
                            placeholder="Search sets..." 
                            value={searchQuery} 
                            onChange={e => setSearchQuery(e.target.value)} 
                        />
                    </div>
                    <button onClick={() => setShowCreateModal(true)} className="bg-black text-white px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-widest shadow-md hover:bg-gray-800 transition-all flex items-center gap-2">
                        <PlusIcon className="w-3 h-3"/> New Set
                    </button>
                </div>
            </header>

            <div className="flex-1 flex overflow-hidden">
                {/* Left Sidebar List */}
                <div className={`${inspectedLoc ? 'w-[320px] border-r border-gray-200 bg-white' : 'w-full'} flex flex-col transition-all duration-300`}>
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        {isLoading ? (
                            <div className="flex justify-center p-12"><div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div></div>
                        ) : (
                            filtered.length === 0 ? (
                                <div className="text-center text-gray-400 py-12 flex flex-col items-center">
                                    <MapIcon className="w-12 h-12 opacity-20 mb-2"/>
                                    <p className="font-bold uppercase tracking-widest text-xs">No sets found</p>
                                </div>
                            ) : (
                                filtered.map(loc => {
                                    const isSelected = inspectedLoc?.id === loc.id;
                                    const img = loc.image_urls?.primary;
                                    
                                    return (
                                        <div 
                                            key={loc.id} 
                                            onClick={() => setInspectedLoc(loc)}
                                            className={`group relative rounded-xl overflow-hidden cursor-pointer transition-all border-2 ${isSelected ? 'border-blue-600 ring-2 ring-blue-100 shadow-lg' : 'border-transparent hover:shadow-md'}`}
                                        >
                                            {/* Card Image */}
                                            <div className="aspect-[16/9] bg-gray-100 relative">
                                                {img ? (
                                                    <img src={img} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" alt={loc.name} />
                                                ) : (
                                                    <div className="w-full h-full flex items-center justify-center text-gray-300 bg-gray-50 pattern-checkered-gray-100/50">
                                                        <MapPinIcon className="w-8 h-8 opacity-30"/>
                                                    </div>
                                                )}
                                                {/* Gradient Overlay */}
                                                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
                                                
                                                {/* Card Content Overlay */}
                                                <div className="absolute bottom-0 left-0 right-0 p-4">
                                                    <span className="text-[9px] font-bold text-blue-300 uppercase tracking-wider block mb-1">{loc.category}</span>
                                                    <h3 className="text-white font-black uppercase text-sm leading-tight line-clamp-2">{loc.name}</h3>
                                                    <p className="text-[9px] text-gray-400 font-bold mt-1 flex items-center gap-1">
                                                        <GlobeAltIcon className="w-3 h-3"/> {loc.city}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                })
                            )
                        )}
                    </div>
                </div>

                {/* Right Detail Panel */}
                {inspectedLoc && (
                    <div className="flex-1 bg-white flex flex-col animate-slide-in-right relative z-30 min-w-0">
                        {/* Detail Header */}
                        <header className="px-8 py-6 border-b border-gray-100 flex items-start justify-between bg-white sticky top-0 z-10">
                            <div className="flex gap-4 items-start">
                                <div className="w-16 h-16 rounded-xl bg-gray-50 border border-gray-200 flex items-center justify-center text-gray-300 shrink-0">
                                    <CameraIcon className="w-6 h-6"/>
                                </div>
                                <div>
                                    <h2 className="text-2xl font-black uppercase tracking-tight leading-none text-gray-900">{inspectedLoc.name}</h2>
                                    <div className="flex gap-2 mt-2">
                                        <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest bg-blue-50 px-2 py-0.5 rounded border border-blue-100">{inspectedLoc.category}</span>
                                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest bg-gray-100 px-2 py-0.5 rounded border border-gray-200 flex items-center gap-1"><MapPinIcon className="w-3 h-3"/> {inspectedLoc.city}</span>
                                    </div>
                                </div>
                            </div>
                            <button onClick={() => setInspectedLoc(null)} className="p-2 hover:bg-gray-100 rounded-full text-gray-400 transition-colors"><XMarkIcon className="w-5 h-5"/></button>
                        </header>

                        {/* Detail Content */}
                        <div className="flex-1 overflow-y-auto p-8">
                            <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr] gap-10">
                                
                                {/* LEFT COL: Prompt Configuration */}
                                <div className="space-y-8">
                                    <div className="space-y-4">
                                        <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                                            <BoltIcon className="w-4 h-4 text-blue-500"/> Environment Prompt
                                        </h4>
                                        
                                        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 space-y-4">
                                            <div>
                                                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2 block">Visual Base</label>
                                                <textarea 
                                                    className="w-full p-4 bg-white border border-gray-200 rounded-xl text-sm font-medium text-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none h-32 resize-none shadow-sm transition-all" 
                                                    value={inspectedLoc.prompt.visual} 
                                                    onChange={e => setInspectedLoc({...inspectedLoc, prompt: {...inspectedLoc.prompt, visual: e.target.value}})} 
                                                    placeholder="Describe the physical space, architecture, and props..."
                                                />
                                            </div>
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2 block">Lighting</label>
                                                    <input 
                                                        className="w-full p-3 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none" 
                                                        value={inspectedLoc.prompt.lighting} 
                                                        onChange={e => setInspectedLoc({...inspectedLoc, prompt: {...inspectedLoc.prompt, lighting: e.target.value}})} 
                                                        placeholder="e.g. Cinematic, Golden Hour"
                                                    />
                                                </div>
                                                <div>
                                                    <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2 block">Atmosphere</label>
                                                    <input 
                                                        className="w-full p-3 bg-white border border-gray-200 rounded-xl text-xs font-bold text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none" 
                                                        value={inspectedLoc.prompt.atmosphere} 
                                                        onChange={e => setInspectedLoc({...inspectedLoc, prompt: {...inspectedLoc.prompt, atmosphere: e.target.value}})} 
                                                        placeholder="e.g. Dusty, Clean, Moody"
                                                    />
                                                </div>
                                            </div>
                                            
                                            <button 
                                                onClick={handleGenerateVisual} 
                                                disabled={isGenerating} 
                                                className="w-full py-4 bg-blue-600 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-all active:scale-95"
                                            >
                                                {isGenerating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4"/>}
                                                Generate High-Fi Preview
                                            </button>
                                        </div>
                                    </div>

                                    <div className="space-y-4">
                                        <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Metadata</h4>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                                                <span className="text-[9px] font-bold text-gray-400 uppercase block mb-1">Country</span>
                                                <p className="font-bold text-sm text-gray-900">{inspectedLoc.country}</p>
                                            </div>
                                            <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                                                <span className="text-[9px] font-bold text-gray-400 uppercase block mb-1">Currency</span>
                                                <p className="font-bold text-sm text-gray-900">{inspectedLoc.currency}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {/* RIGHT COL: Gallery */}
                                <div className="space-y-4">
                                    <div className="flex justify-between items-end mb-2">
                                        <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Gallery Variants</h4>
                                        <span className="text-[9px] font-bold text-gray-400 uppercase bg-gray-100 px-2 py-0.5 rounded">{inspectedLoc.image_urls?.variants?.length || 0} ITEMS</span>
                                    </div>
                                    
                                    <div className="grid grid-cols-1 gap-4">
                                        {/* Primary/Large Preview */}
                                        <div className="aspect-video w-full bg-gray-100 rounded-2xl overflow-hidden border border-gray-200 shadow-sm relative group">
                                            {inspectedLoc.image_urls?.primary ? (
                                                <img src={inspectedLoc.image_urls.primary} className="w-full h-full object-cover" />
                                            ) : (
                                                <div className="w-full h-full flex flex-col items-center justify-center text-gray-300">
                                                    <PhotoIcon className="w-12 h-12 opacity-20 mb-2"/>
                                                    <p className="text-[10px] font-bold uppercase tracking-widest">No Visuals Yet</p>
                                                </div>
                                            )}
                                            
                                            {/* Upload Overlay */}
                                            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                                                <span className="text-white font-bold text-xs uppercase tracking-widest flex items-center gap-2"><UploadCloudIcon className="w-4 h-4"/> Upload Reference</span>
                                            </div>
                                            <input type="file" ref={fileInputRef} hidden accept="image/*" onChange={handleUploadImage} />
                                        </div>

                                        {/* Variant Grid */}
                                        {inspectedLoc.image_urls?.variants && inspectedLoc.image_urls.variants.length > 0 && (
                                            <div className="grid grid-cols-3 gap-3">
                                                {inspectedLoc.image_urls.variants.map((v, i) => (
                                                    <div 
                                                        key={i} 
                                                        className={`aspect-video rounded-xl overflow-hidden border-2 cursor-pointer transition-all ${inspectedLoc.image_urls?.primary === v ? 'border-blue-500 ring-2 ring-blue-100' : 'border-transparent hover:border-gray-300'}`}
                                                        onClick={() => setInspectedLoc({...inspectedLoc, image_urls: {...inspectedLoc.image_urls!, primary: v}})}
                                                    >
                                                        <img src={v} className="w-full h-full object-cover" />
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Footer Actions */}
                        <div className="p-6 border-t border-gray-100 bg-white flex justify-between items-center shrink-0">
                            <button onClick={() => handleDelete(inspectedLoc.id)} className="text-red-400 hover:text-red-600 text-[10px] font-bold uppercase tracking-widest px-4 py-3 hover:bg-red-50 rounded-xl transition-colors">
                                Delete Set
                            </button>
                            <button onClick={handleUpdateLocation} disabled={isSaving} className="px-8 py-3 bg-black text-white rounded-xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-gray-800 transition-all flex items-center gap-2 disabled:opacity-50">
                                {isSaving ? 'Syncing...' : 'Save & Sync'} <SaveIcon className="w-4 h-4"/>
                            </button>
                        </div>
                    </div>
                )}
                
                {!inspectedLoc && (
                    <div className="flex-1 flex flex-col items-center justify-center bg-gray-50 text-gray-300">
                        <MapIcon className="w-24 h-24 opacity-10 mb-4"/>
                        <p className="font-bold uppercase tracking-widest text-sm">Select a location to edit</p>
                    </div>
                )}
            </div>

            {/* Create Modal */}
            <Modal isOpen={showCreateModal} onClose={() => setShowCreateModal(false)} title="Add New Shooting Set">
                <div className="space-y-6 p-2">
                    <div>
                        <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Location Name</label>
                        <input className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-bold outline-none focus:ring-2 focus:ring-blue-500 text-sm" placeholder="e.g. Minimalist Loft Studio" value={newName} onChange={e => setNewName(e.target.value)} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">City</label>
                            <input className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-bold outline-none text-sm" placeholder="e.g. Johannesburg" value={newCity} onChange={e => setNewCity(e.target.value)} />
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Category</label>
                            <select className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl font-bold outline-none appearance-none text-sm cursor-pointer" value={newCategory} onChange={e => setNewCategory(e.target.value)}>
                                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                    </div>
                    <button onClick={handleCreateLocation} disabled={isSaving || !newName} className="w-full py-4 bg-black text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl hover:bg-gray-800 disabled:opacity-50 transition-all">Create Set Definition</button>
                </div>
            </Modal>
        </div>
    );
};

export default LocationCenter;
