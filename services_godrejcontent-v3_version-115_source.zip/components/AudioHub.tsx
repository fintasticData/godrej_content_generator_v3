/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { createMusicTask, createCoverTask, createSFXTask, pollTaskStatus, downloadAudioAsBlob } from '../services/musicGPTService';
import { uploadBlob, fetchAdsList, updateAdAudio } from '../services/supabaseClient';
import { AudioTask, AudioTaskType } from '../types';
import { 
    MusicIcon, 
    MicrophoneIcon, 
    PlayIcon, 
    PauseIcon,
    SparklesIcon, 
    WaveformIcon, 
    LayersIcon,
    BoltIcon,
    DownloadIcon,
    ClapperboardIcon,
    CheckCircleIcon,
    AlertTriangleIcon
} from './icons';

const AudioHub: React.FC = () => {
    const [activeTab, setActiveTab] = useState<AudioTaskType>('music');
    const [activeTaskId, setActiveTaskId] = useState<string | null>(null);
    const [currentTask, setCurrentTask] = useState<AudioTask | null>(null);
    const [history, setHistory] = useState<AudioTask[]>([]);
    
    // Project Selection
    const [projects, setProjects] = useState<{id: string, ad_title: string}[]>([]);
    const [selectedProjectId, setSelectedProjectId] = useState<string>('');
    const [isSaving, setIsSaving] = useState(false);
    const [saveSuccess, setSaveSuccess] = useState(false);
    
    // Form Inputs
    const [prompt, setPrompt] = useState('');
    const [genre, setGenre] = useState('Amapiano');
    const [duration, setDuration] = useState(15);
    const [coverUrl, setCoverUrl] = useState('');
    const [coverVoice, setCoverVoice] = useState('kanye_west_vibes');
    
    // Audio Player State
    const [isPlaying, setIsPlaying] = useState(false);
    const [playbackError, setPlaybackError] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    // Initial Load
    useEffect(() => {
        const loadProjects = async () => {
            const list = await fetchAdsList();
            setProjects(list);
        };
        loadProjects();
    }, []);

    // Polling Effect
    useEffect(() => {
        let intervalId: any;

        if (activeTaskId) {
            const checkStatus = async () => {
                try {
                    const task = await pollTaskStatus(activeTaskId);
                    setCurrentTask(task);

                    if (task.status === 'completed' || task.status === 'failed') {
                        clearInterval(intervalId);
                        // Add to history if completed
                        if (task.status === 'completed') {
                            setHistory(prev => [task, ...prev]);
                        }
                    }
                } catch (e) {
                    console.error("Polling error", e);
                    // Don't clear interval immediately on one transient error, 
                    // but could add retry logic logic here.
                }
            };

            // Poll immediately then every 3s
            checkStatus();
            intervalId = setInterval(checkStatus, 3000);
        }

        return () => clearInterval(intervalId);
    }, [activeTaskId]);

    // Reset save success message after delay
    useEffect(() => {
        if (saveSuccess) {
            const timer = setTimeout(() => setSaveSuccess(false), 3000);
            return () => clearTimeout(timer);
        }
    }, [saveSuccess]);

    // Reset playback error when URL changes
    useEffect(() => {
        setPlaybackError(false);
        setIsPlaying(false);
    }, [currentTask?.result_url]);

    // --- Handlers ---

    const handleSubmitMusic = async () => {
        if (!prompt) return;
        setSaveSuccess(false);
        try {
            const taskId = await createMusicTask(prompt, genre, duration);
            setActiveTaskId(taskId);
            // Optimistic UI update
            setCurrentTask({
                id: taskId,
                type: 'music',
                status: 'queued',
                created_at: Date.now(),
                prompt: prompt
            });
        } catch (e: any) {
            alert(`Failed to start music generation: ${e.message}`);
        }
    };

    const handleSubmitCover = async () => {
        if (!coverUrl) return;
        setSaveSuccess(false);
        try {
            const taskId = await createCoverTask(coverUrl, coverVoice, 0);
            setActiveTaskId(taskId);
            setCurrentTask({
                id: taskId,
                type: 'cover',
                status: 'queued',
                created_at: Date.now()
            });
        } catch (e: any) {
            alert(`Failed to start cover song generation: ${e.message}`);
        }
    };

    const handleSubmitSFX = async () => {
        if (!prompt) return;
        setSaveSuccess(false);
        try {
            const taskId = await createSFXTask(prompt, "general");
            setActiveTaskId(taskId);
            setCurrentTask({
                id: taskId,
                type: 'sfx',
                status: 'queued',
                created_at: Date.now()
            });
        } catch (e: any) {
            alert(`Failed to start SFX generation: ${e.message}`);
        }
    };

    const togglePlay = () => {
        if (audioRef.current) {
            if (isPlaying) audioRef.current.pause();
            else audioRef.current.play().catch(e => {
                console.error("Play failed", e);
                setPlaybackError(true);
            });
            setIsPlaying(!isPlaying);
        }
    };

    const handleDownload = async () => {
        if (currentTask?.result_url) {
            try {
                const blob = await downloadAudioAsBlob(currentTask.result_url);
                const url = window.URL.createObjectURL(blob);
                
                // Determine extension
                const ext = blob.type.includes('ogg') ? 'ogg' : 'mp3';
                
                const a = document.createElement('a');
                a.href = url;
                a.download = `fintastic_${currentTask.type}_${currentTask.id}.${ext}`;
                a.click();
            } catch (e) {
                alert("Could not download audio file directly. The API response might be invalid or restricted.");
            }
        }
    };

    const handleUseInProject = async () => {
        if (!currentTask?.result_url) return;
        if (!selectedProjectId) {
            alert("Please select a project first.");
            return;
        }

        setIsSaving(true);
        try {
            // 1. Download Blob from Generation URL
            const blob = await downloadAudioAsBlob(currentTask.result_url);
            
            // Determine file extension from mime type
            const mimeType = blob.type;
            const ext = mimeType.split('/')[1]?.replace('x-wav', 'wav').replace('mpeg', 'mp3') || 'mp3';
            
            // 2. Upload to Supabase Bucket
            const fileName = `${currentTask.type}_${Date.now()}_${currentTask.id.slice(0,6)}.${ext}`;
            const publicUrl = await uploadBlob(blob, fileName, 'godrej/audio');
            
            if (publicUrl) {
                // 3. Update Database
                const audioAsset = {
                    id: currentTask.id,
                    url: publicUrl,
                    name: currentTask.prompt || `${currentTask.type} Generated Audio`,
                    type: currentTask.type,
                    created_at: new Date().toISOString(),
                    metadata: currentTask.metadata
                };
                
                await updateAdAudio(selectedProjectId, audioAsset);
                setSaveSuccess(true);
            } else {
                throw new Error("Upload failed");
            }
        } catch (e) {
            console.error(e);
            alert("Failed to save audio to project. Check console for details.");
        } finally {
            setIsSaving(false);
        }
    };

    const renderWaveform = () => {
        return (
            <div className="flex items-center gap-1 h-12 w-full px-4 overflow-hidden">
                {Array.from({ length: 40 }).map((_, i) => (
                    <div 
                        key={i} 
                        className={`w-1 bg-indigo-500 rounded-full transition-all duration-300 ease-in-out ${isPlaying ? 'animate-pulse' : ''}`}
                        style={{ 
                            height: isPlaying ? `${Math.random() * 100}%` : '20%', 
                            animationDelay: `${i * 0.05}s` 
                        }}
                    ></div>
                ))}
            </div>
        );
    };

    const TabButton: React.FC<{ tab: AudioTaskType; label: string; icon: React.ReactNode }> = ({ tab, label, icon }) => (
        <button 
            onClick={() => { setActiveTab(tab); setActiveTaskId(null); setCurrentTask(null); }}
            className={`flex items-center gap-3 px-4 py-3 w-full rounded-xl transition-all ${
                activeTab === tab 
                ? 'bg-black text-white shadow-lg' 
                : 'text-gray-500 hover:bg-gray-100'
            }`}
        >
            {icon}
            <span className="font-bold text-sm">{label}</span>
        </button>
    );

    return (
        <div className="w-full h-full bg-gray-50 flex overflow-hidden">
            
            {/* LEFT SIDEBAR: Tools */}
            <div className="w-80 bg-white border-r border-gray-200 flex flex-col z-10 shrink-0">
                <div className="p-6 border-b border-gray-100">
                    <h2 className="text-xl font-black text-gray-900 flex items-center gap-2">
                        <span className="text-indigo-600">uG</span> Audio Studio
                    </h2>
                    <p className="text-xs text-gray-400 mt-1">Powered by MusicGPT & Cloud Run</p>
                </div>
                
                <div className="p-4 space-y-2">
                    <TabButton tab="music" label="Music Generator" icon={<MusicIcon className="w-5 h-5"/>} />
                    <TabButton tab="cover" label="Cover Songs" icon={<LayersIcon className="w-5 h-5"/>} />
                    <TabButton tab="sfx" label="SFX Generator" icon={<BoltIcon className="w-5 h-5"/>} />
                    <TabButton tab="voice" label="Voice Changer" icon={<MicrophoneIcon className="w-5 h-5"/>} />
                </div>

                <div className="mt-auto p-4 border-t border-gray-100">
                    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-4 rounded-xl border border-indigo-100">
                        <h4 className="text-xs font-bold text-indigo-900 mb-1 flex items-center gap-1"><SparklesIcon className="w-3 h-3"/> Pro Tip</h4>
                        <p className="text-[10px] text-indigo-700 leading-relaxed">
                            Try combining "Amapiano" genre with "Cinematic" mood for Fintastic ads.
                        </p>
                    </div>
                </div>
            </div>

            {/* MAIN CONTENT: Input & Results */}
            <div className="flex-1 flex flex-col min-w-0">
                
                {/* Header Area */}
                <div className="h-16 border-b border-gray-200 flex items-center justify-between px-8 bg-white shrink-0">
                    <h3 className="font-bold text-lg text-gray-800 capitalize">{activeTab} Creation</h3>
                    
                    {/* Project Selector */}
                    <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-full border border-gray-200">
                            <ClapperboardIcon className="w-4 h-4 text-gray-400" />
                            <select 
                                className="bg-transparent text-sm font-medium text-gray-700 outline-none w-48"
                                value={selectedProjectId}
                                onChange={(e) => setSelectedProjectId(e.target.value)}
                            >
                                <option value="">Select Project...</option>
                                {projects.map(p => <option key={p.id} value={p.id}>{p.ad_title}</option>)}
                            </select>
                        </div>
                        <div className="flex items-center gap-2 text-xs font-medium text-gray-500">
                            <span className="w-2 h-2 rounded-full bg-green-500"></span>
                            uG Engine Active
                        </div>
                    </div>
                </div>

                <div className="flex-1 flex overflow-hidden">
                    
                    {/* INPUT FORM (Center) */}
                    <div className="flex-1 p-8 overflow-y-auto max-w-3xl">
                        {activeTab === 'music' && (
                            <div className="space-y-6 animate-fade-in-up">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Description</label>
                                    <textarea 
                                        className="w-full h-32 border border-gray-300 rounded-xl p-4 focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-none text-lg"
                                        placeholder="Describe the track... (e.g. Upbeat afro-pop with energetic drums)"
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                    />
                                </div>
                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Genre</label>
                                        <select 
                                            className="w-full p-3 bg-white border border-gray-300 rounded-lg outline-none"
                                            value={genre}
                                            onChange={(e) => setGenre(e.target.value)}
                                        >
                                            <option>Amapiano</option>
                                            <option>Afrobeat</option>
                                            <option>House</option>
                                            <option>Hip Hop</option>
                                            <option>Cinematic</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Duration (Sec)</label>
                                        <select 
                                            className="w-full p-3 bg-white border border-gray-300 rounded-lg outline-none"
                                            value={duration}
                                            onChange={(e) => setDuration(Number(e.target.value))}
                                        >
                                            <option value={15}>15s (Preview)</option>
                                            <option value={30}>30s (Short)</option>
                                            <option value={60}>60s (Full)</option>
                                        </select>
                                    </div>
                                </div>
                                <button 
                                    onClick={handleSubmitMusic}
                                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
                                >
                                    <SparklesIcon className="w-5 h-5"/> Generate Track
                                </button>
                            </div>
                        )}

                        {activeTab === 'cover' && (
                            <div className="space-y-6 animate-fade-in-up">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Input Audio URL</label>
                                    <input 
                                        className="w-full border border-gray-300 rounded-xl p-4 focus:ring-2 focus:ring-indigo-600 outline-none"
                                        placeholder="Paste YouTube or MP3 link..."
                                        value={coverUrl}
                                        onChange={(e) => setCoverUrl(e.target.value)}
                                    />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-2">Target Voice</label>
                                    <select 
                                        className="w-full p-3 bg-white border border-gray-300 rounded-lg outline-none"
                                        value={coverVoice}
                                        onChange={(e) => setCoverVoice(e.target.value)}
                                    >
                                        <option value="kanye_west_vibes">Male Rapper Style</option>
                                        <option value="ariana_style">Female Pop Star</option>
                                        <option value="robot_fx">Futuristic Robot</option>
                                    </select>
                                </div>
                                <button 
                                    onClick={handleSubmitCover}
                                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2"
                                >
                                    <LayersIcon className="w-5 h-5"/> Convert Song
                                </button>
                            </div>
                        )}

                        {activeTab === 'sfx' && (
                            <div className="space-y-6 animate-fade-in-up">
                                <div>
                                    <label className="block text-sm font-bold text-gray-700 mb-2">Sound Effect Description</label>
                                    <textarea 
                                        className="w-full h-32 border border-gray-300 rounded-xl p-4 focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none resize-none text-lg"
                                        placeholder="Describe the sound... (e.g. Laser gun firing, Footsteps on gravel)"
                                        value={prompt}
                                        onChange={(e) => setPrompt(e.target.value)}
                                    />
                                </div>
                                <button 
                                    onClick={handleSubmitSFX}
                                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-4 rounded-xl font-bold text-lg shadow-lg flex items-center justify-center gap-2 transition-transform active:scale-95"
                                >
                                    <BoltIcon className="w-5 h-5"/> Generate SFX
                                </button>
                            </div>
                        )}
                        
                        {(activeTab === 'voice') && (
                            <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                                <MicrophoneIcon className="w-12 h-12 mb-4 opacity-20"/>
                                <p>Voice Changer is coming soon to Fintastic uG.</p>
                            </div>
                        )}
                    </div>

                    {/* RESULT PANEL (Right) */}
                    <div className="w-96 bg-gray-100 border-l border-gray-200 p-6 flex flex-col overflow-y-auto">
                        
                        {/* Active Task Card */}
                        {currentTask && (
                            <div className="bg-white rounded-2xl p-6 shadow-xl border border-indigo-100 mb-8 animate-fade-in-up">
                                <div className="flex justify-between items-start mb-4">
                                    <div>
                                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full ${
                                            currentTask.status === 'completed' ? 'bg-green-100 text-green-700' :
                                            currentTask.status === 'failed' ? 'bg-red-100 text-red-700' :
                                            'bg-indigo-100 text-indigo-700'
                                        }`}>
                                            {currentTask.status}
                                        </span>
                                        <h3 className="font-bold text-gray-900 mt-2 text-lg">
                                            {currentTask.type === 'music' ? 'Generating Beat...' : 
                                             currentTask.type === 'sfx' ? 'Creating Sound...' : 'Processing Audio...'}
                                        </h3>
                                        <p className="text-xs text-gray-400 font-mono mt-1">ID: {currentTask.id.slice(0,8)}</p>
                                    </div>
                                </div>

                                {currentTask.status === 'completed' && currentTask.result_url ? (
                                    <div className="space-y-4">
                                        <div className="bg-gray-900 rounded-xl p-4 flex items-center gap-3 text-white">
                                            <button onClick={togglePlay} className="p-3 bg-white text-black rounded-full hover:scale-105 transition-transform">
                                                {isPlaying ? <PauseIcon className="w-5 h-5"/> : <PlayIcon className="w-5 h-5 ml-0.5"/>}
                                            </button>
                                            <div className="flex-1">
                                                {renderWaveform()}
                                            </div>
                                            <audio 
                                                ref={audioRef} 
                                                src={currentTask.result_url} 
                                                onEnded={() => setIsPlaying(false)}
                                                onPlay={() => setIsPlaying(true)}
                                                onPause={() => setIsPlaying(false)}
                                                onError={(e) => {
                                                    console.error("Audio playback error", e.currentTarget.error);
                                                    setPlaybackError(true);
                                                    setIsPlaying(false);
                                                }}
                                            />
                                        </div>
                                        {playbackError && (
                                            <p className="text-[10px] text-red-500 flex items-center gap-1 justify-center">
                                                <AlertTriangleIcon className="w-3 h-3"/> Playback error. Try downloading.
                                            </p>
                                        )}
                                        <div className="grid grid-cols-2 gap-2">
                                            <button onClick={handleDownload} className="py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-xs font-bold text-gray-700 flex items-center justify-center gap-1">
                                                <DownloadIcon className="w-4 h-4"/> Download
                                            </button>
                                            <button 
                                                onClick={handleUseInProject} 
                                                disabled={isSaving || !selectedProjectId}
                                                className="py-2 bg-black text-white rounded-lg text-xs font-bold hover:bg-gray-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1"
                                                title={!selectedProjectId ? "Select a project first" : "Save to Project Assets"}
                                            >
                                                {isSaving ? 'Saving...' : (saveSuccess ? 'Saved!' : 'Use in Project')}
                                                {saveSuccess && <CheckCircleIcon className="w-3 h-3 text-green-400"/>}
                                            </button>
                                        </div>
                                        {!selectedProjectId && (
                                            <p className="text-[10px] text-red-500 text-center">Select a project above to save.</p>
                                        )}
                                    </div>
                                ) : (
                                    <div className="flex flex-col items-center py-8">
                                        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                                        <p className="text-sm text-gray-500 text-center px-4">
                                            The uG Engine is processing your request. Please wait...
                                        </p>
                                        {currentTask.status === 'failed' && (
                                            <p className="text-xs text-red-500 mt-2 font-bold">Generation Failed. Please try again.</p>
                                        )}
                                    </div>
                                )}
                            </div>
                        )}

                        {/* History List */}
                        <div>
                            <h4 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                                <LayersIcon className="w-4 h-4"/> Recent Creations
                            </h4>
                            <div className="space-y-3">
                                {history.length === 0 ? (
                                    <p className="text-sm text-gray-400 italic">No history yet.</p>
                                ) : (
                                    history.map(task => (
                                        <div key={task.id} className="bg-white p-3 rounded-xl border border-gray-200 flex items-center gap-3 hover:shadow-sm cursor-pointer" onClick={() => { setActiveTaskId(null); setCurrentTask(task); }}>
                                            <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600 font-bold shrink-0">
                                                <MusicIcon className="w-5 h-5"/>
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <p className="text-sm font-bold text-gray-800 truncate">{task.prompt || "Generated Audio"}</p>
                                                <p className="text-[10px] text-gray-400">{new Date(task.created_at).toLocaleTimeString()}</p>
                                            </div>
                                            <button className="text-gray-400 hover:text-indigo-600"><PlayIcon className="w-4 h-4"/></button>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
};

export default AudioHub;