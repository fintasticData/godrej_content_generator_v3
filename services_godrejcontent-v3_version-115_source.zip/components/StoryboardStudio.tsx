
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect } from 'react';
import { 
    SB_Shot, 
    SB_Project, 
    AspectRatio,
    Influencer,
    Product,
    Location
} from '../types';
import { analyzeScriptToShots, generateStoryboardFrame, extractCharactersAndScenes } from '../services/geminiService';
import { uploadBlob, fetchCharacters, fetchProducts, fetchLocations, supabase } from '../services/supabaseClient';
import {
    SparklesIcon,
    ArrowRightIcon,
    FilmIcon,
    PhotoIcon,
    UserIcon,
    PlusIcon,
    TrashIcon,
    CheckCircleIcon,
    DragHandleIcon,
    MagicWandIcon,
    XMarkIcon,
    CubeIcon,
    MapPinIcon,
    AlertTriangleIcon,
    BoltIcon,
    SaveIcon,
    PencilSquareIcon,
    ChevronRightIcon,
    CameraIcon,
    PlayIcon,
    EyeIcon
} from './icons';

// --- UI Components ---

const NotificationToast: React.FC<{ message: string, type: 'success' | 'error', onClose: () => void }> = ({ message, type, onClose }) => (
    <div className={`fixed top-24 right-8 z-[200] px-6 py-4 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in-up border ${type === 'error' ? 'bg-white border-red-100 text-red-600' : 'bg-black text-white border-black'}`}>
        {type === 'error' ? <AlertTriangleIcon className="w-5 h-5"/> : <CheckCircleIcon className="w-5 h-5 text-green-400"/>}
        <span className="text-sm font-bold">{message}</span>
        <button onClick={onClose}><XMarkIcon className="w-4 h-4 opacity-50 hover:opacity-100"/></button>
    </div>
);

const ConfirmModal: React.FC<{ isOpen: boolean, title: string, message: string, onConfirm: () => void, onCancel: () => void }> = ({ isOpen, title, message, onConfirm, onCancel }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[300] bg-gray-900/50 backdrop-blur-sm flex items-center justify-center p-4" onClick={onCancel}>
            <div className="bg-white rounded-2xl p-8 max-w-sm w-full shadow-2xl transform transition-all scale-100" onClick={e => e.stopPropagation()}>
                <h3 className="text-xl font-black text-gray-900 mb-2">{title}</h3>
                <p className="text-sm text-gray-500 mb-6 leading-relaxed">{message}</p>
                <div className="flex gap-3">
                    <button onClick={onCancel} className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs uppercase tracking-widest transition-colors">Cancel</button>
                    <button onClick={onConfirm} className="flex-1 py-3 bg-black text-white hover:bg-gray-800 font-bold rounded-xl text-xs uppercase tracking-widest transition-colors shadow-lg">Confirm</button>
                </div>
            </div>
        </div>
    );
};

const StoryboardLightbox: React.FC<{
    shots: SB_Shot[];
    initialIndex: number;
    onClose: () => void;
}> = ({ shots, initialIndex, onClose }) => {
    const [index, setIndex] = useState(initialIndex);
    const shot = shots[index];

    const next = () => setIndex(i => (i + 1) % shots.length);
    const prev = () => setIndex(i => (i - 1 + shots.length) % shots.length);

    useEffect(() => {
        const handleKey = (e: KeyboardEvent) => {
            if (e.key === 'ArrowRight') next();
            if (e.key === 'ArrowLeft') prev();
            if (e.key === 'Escape') onClose();
        };
        window.addEventListener('keydown', handleKey);
        return () => window.removeEventListener('keydown', handleKey);
    }, [shots.length]);

    if (!shot) return null;

    return (
        <div className="fixed inset-0 z-[400] bg-black/95 backdrop-blur-xl flex flex-col items-center justify-center p-8 animate-fade-in-up">
            <button onClick={onClose} className="absolute top-6 right-6 p-2 text-white/50 hover:text-white transition-colors z-50"><XMarkIcon className="w-8 h-8"/></button>
            
            <div className="flex-1 w-full flex items-center justify-between gap-4 md:gap-12 max-w-[90vw]">
                <button onClick={prev} className="p-4 hover:bg-white/10 rounded-full text-white transition-colors shrink-0"><ChevronRightIcon className="w-8 h-8 rotate-180"/></button>
                
                <div className="flex-1 h-full flex flex-col items-center justify-center gap-8 min-h-0">
                    <div className="relative aspect-video w-full max-h-[60vh] bg-gray-900 rounded-2xl overflow-hidden shadow-2xl border border-gray-800 ring-1 ring-white/10">
                        {shot.imageUrl ? (
                            <img src={shot.imageUrl} className="w-full h-full object-contain" />
                        ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center text-gray-600">
                                <FilmIcon className="w-20 h-20 opacity-20 mb-4"/>
                                <span className="text-xl font-black uppercase tracking-widest opacity-50">Shot {shot.order} Pending</span>
                            </div>
                        )}
                        <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-white text-xs font-bold border border-white/10 flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                            Shot {index + 1} / {shots.length}
                        </div>
                    </div>
                    
                    <div className="max-w-4xl text-center space-y-4">
                        <p className="text-xl md:text-2xl font-medium text-white leading-relaxed drop-shadow-md">{shot.action}</p>
                        <div className="flex flex-wrap gap-3 justify-center">
                            <span className="px-3 py-1 rounded-full bg-white/10 text-gray-300 text-[10px] font-bold uppercase tracking-widest border border-white/10 flex items-center gap-2">
                                <CameraIcon className="w-3 h-3"/> {shot.camera}
                            </span>
                            <span className="px-3 py-1 rounded-full bg-white/10 text-gray-300 text-[10px] font-bold uppercase tracking-widest border border-white/10 flex items-center gap-2">
                                <BoltIcon className="w-3 h-3"/> {shot.movement}
                            </span>
                            <span className="px-3 py-1 rounded-full bg-white/10 text-gray-300 text-[10px] font-bold uppercase tracking-widest border border-white/10">
                                {shot.duration}s
                            </span>
                        </div>
                    </div>
                </div>

                <button onClick={next} className="p-4 hover:bg-white/10 rounded-full text-white transition-colors shrink-0"><ChevronRightIcon className="w-8 h-8"/></button>
            </div>
            
            {/* Timeline Strip */}
            <div className="h-24 mt-8 flex gap-3 overflow-x-auto max-w-5xl w-full px-4 no-scrollbar items-center justify-center pb-2">
                {shots.map((s, i) => (
                    <button 
                        key={s.id} 
                        onClick={() => setIndex(i)}
                        className={`relative h-16 aspect-video rounded-lg overflow-hidden border-2 transition-all shrink-0 duration-300 ${i === index ? 'border-indigo-500 scale-110 z-10 shadow-[0_0_15px_rgba(99,102,241,0.5)]' : 'border-transparent opacity-40 hover:opacity-100 hover:scale-105'}`}
                    >
                        {s.imageUrl ? <img src={s.imageUrl} className="w-full h-full object-cover"/> : <div className="w-full h-full bg-gray-800 flex items-center justify-center text-[8px] text-gray-500 font-bold">{i+1}</div>}
                    </button>
                ))}
            </div>
        </div>
    );
};

// --- Sub-Component: Story Input ---
const StoryInput: React.FC<{ 
    onAnalyze: (title: string, concept: string, format: 'tvc'|'social'|'explainer') => void,
    isAnalyzing: boolean,
    initialTitle: string,
    initialConcept: string
}> = ({ onAnalyze, isAnalyzing, initialTitle, initialConcept }) => {
    const [title, setTitle] = useState(initialTitle);
    const [concept, setConcept] = useState(initialConcept);
    const [format, setFormat] = useState<'tvc'|'social'|'explainer'>('social');

    return (
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-in-up">
            <div className="text-center space-y-2">
                <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter">Start Your Story</h2>
                <p className="text-gray-500">Describe your idea, script, or scene. The AI Director will auto-assign assets and shots.</p>
            </div>
            
            <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-gray-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
                    <FilmIcon className="w-64 h-64 text-indigo-900"/>
                </div>
                
                <div className="relative z-10 space-y-6">
                    <div>
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Project Title</label>
                        <input 
                            className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 font-bold text-gray-900 outline-none focus:ring-2 focus:ring-indigo-500"
                            placeholder="e.g. Summer Launch Campaign"
                            value={title}
                            onChange={(e) => setTitle(e.target.value)}
                        />
                    </div>

                    <div className="flex justify-center gap-4 py-2">
                        {['social', 'tvc', 'explainer'].map(f => (
                            <button 
                                key={f}
                                onClick={() => setFormat(f as any)}
                                className={`px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${format === f ? 'bg-black text-white shadow-lg' : 'bg-gray-50 text-gray-500 hover:bg-gray-100'}`}
                            >
                                {f}
                            </button>
                        ))}
                    </div>

                    <div>
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Story / Script</label>
                        <textarea 
                            className="w-full h-48 bg-gray-50 border border-gray-200 rounded-3xl p-6 text-lg font-medium outline-none focus:ring-4 focus:ring-indigo-100 transition-all resize-none shadow-inner"
                            placeholder="e.g. A young woman walks down a busy Tokyo street at night. Neon lights reflect in her glasses. She stops to look at a holographic billboard..."
                            value={concept}
                            onChange={(e) => setConcept(e.target.value)}
                        />
                    </div>

                    <div className="flex justify-end">
                        <button 
                            onClick={() => onAnalyze(title, concept, format)}
                            disabled={!concept.trim() || !title.trim() || isAnalyzing}
                            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl hover:scale-105 transition-all flex items-center gap-3 disabled:opacity-50 disabled:scale-100"
                        >
                            {isAnalyzing ? (
                                <>Auto-Casting & Directing <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div></>
                            ) : (
                                <>Generate Shot List <ArrowRightIcon className="w-5 h-5"/></>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- Sub-Component: Project Asset Manager ---
const ProjectAssetManager: React.FC<{
    project: SB_Project;
    setProject: React.Dispatch<React.SetStateAction<SB_Project>>;
    availableCharacters: Influencer[];
    availableProducts: Product[];
    availableLocations: Location[];
}> = ({ project, setProject, availableCharacters, availableProducts, availableLocations }) => {
    
    // Selection Handlers
    const toggleCharacter = (char: Influencer) => {
        const id = char.character_id || char.id || '';
        const exists = project.characters.some(c => c.id === id);
        
        let newChars = [];
        if (exists) {
            newChars = project.characters.filter(c => c.id !== id);
        } else {
            newChars = [...project.characters, {
                id,
                name: char.name,
                description: char.description,
                imageUrl: char.image_url || char.image_urls_jsonb?.[0]?.url || ''
            }];
        }
        setProject(prev => ({ ...prev, characters: newChars }));
    };

    const toggleProduct = (prod: Product) => {
        const exists = project.products.some(p => p.id === prod.id);
        
        let newProds = [];
        if (exists) {
            newProds = project.products.filter(p => p.id !== prod.id);
        } else {
            const img = typeof prod.image === 'string' ? prod.image : prod.image?.primary;
            newProds = [...project.products, {
                id: prod.id,
                name: prod.product_name,
                imageUrl: img || ''
            }];
        }
        setProject(prev => ({ ...prev, products: newProds }));
    };

    const toggleLocation = (loc: Location) => {
        const exists = project.locations.some(l => l.id === String(loc.id));
        
        let newLocs = [];
        if (exists) {
            newLocs = project.locations.filter(l => l.id !== String(loc.id));
        } else {
            newLocs = [...project.locations, {
                id: String(loc.id),
                name: loc.name,
                imageUrl: loc.image_urls?.primary || ''
            }];
        }
        setProject(prev => ({ ...prev, locations: newLocs }));
    };

    const AssetSection = ({ title, icon, items, selectedIds, onToggle, type }: any) => (
        <div className="space-y-4">
            <h3 className="font-black text-gray-900 uppercase tracking-tight flex items-center gap-2 text-sm">{icon} {title}</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {items.map((item: any) => {
                    const id = type === 'location' ? String(item.id) : (type === 'character' ? (item.character_id || item.id) : item.id);
                    const isSelected = selectedIds.has(id);
                    const img = type === 'product' 
                        ? (typeof item.image === 'string' ? item.image : item.image?.primary)
                        : (type === 'character' ? (item.image_url || item.image_urls_jsonb?.[0]?.url) : item.image_urls?.primary);
                    
                    return (
                        <div 
                            key={id} 
                            onClick={() => onToggle(item)}
                            className={`relative aspect-square rounded-2xl overflow-hidden cursor-pointer group border-4 transition-all ${isSelected ? 'border-indigo-600 ring-4 ring-indigo-100 transform scale-105 shadow-xl' : 'border-transparent hover:border-gray-200'}`}
                        >
                            {img ? <img src={img} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-gray-100 flex items-center justify-center text-gray-300"><PhotoIcon className="w-8 h-8"/></div>}
                            <div className={`absolute inset-0 flex flex-col justify-end p-3 transition-colors ${isSelected ? 'bg-indigo-900/40' : 'bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100'}`}>
                                <p className="text-white text-xs font-bold leading-tight truncate">{item.name || item.product_name}</p>
                                {isSelected && <div className="absolute top-2 right-2 bg-indigo-600 text-white rounded-full p-1"><CheckCircleIcon className="w-3 h-3"/></div>}
                            </div>
                        </div>
                    );
                })}
                {items.length === 0 && (
                    <div className="col-span-full py-8 text-center border-2 border-dashed border-gray-200 rounded-2xl text-gray-400">
                        <p className="text-xs font-bold uppercase tracking-widest">No {title.toLowerCase()} available</p>
                    </div>
                )}
            </div>
        </div>
    );

    return (
        <div className="max-w-6xl mx-auto space-y-10 animate-fade-in-up pb-20">
            <div className="text-center space-y-2 mb-8">
                <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter">Project Assets</h2>
                <p className="text-gray-500">Select assets for this project. Single selections will act as global defaults.</p>
            </div>

            <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-gray-100 space-y-10">
                <AssetSection 
                    title="Cast & Characters" 
                    icon={<UserIcon className="w-5 h-5 text-purple-500"/>} 
                    items={availableCharacters} 
                    selectedIds={new Set(project.characters.map(c => c.id))}
                    onToggle={toggleCharacter}
                    type="character"
                />
                
                <div className="h-px bg-gray-100 w-full"></div>

                <AssetSection 
                    title="Products" 
                    icon={<CubeIcon className="w-5 h-5 text-orange-500"/>} 
                    items={availableProducts} 
                    selectedIds={new Set(project.products.map(p => p.id))}
                    onToggle={toggleProduct}
                    type="product"
                />

                <div className="h-px bg-gray-100 w-full"></div>

                <AssetSection 
                    title="Locations & Sets" 
                    icon={<MapPinIcon className="w-5 h-5 text-blue-500"/>} 
                    items={availableLocations} 
                    selectedIds={new Set(project.locations.map(l => l.id))}
                    onToggle={toggleLocation}
                    type="location"
                />
            </div>
        </div>
    );
};

// --- Sub-Component: Shot Card ---
const ShotCard: React.FC<{
    shot: SB_Shot;
    index: number;
    character?: { id: string, name: string };
    product?: { id: string, name: string };
    location?: { id: string, name: string };
    onUpdate: (id: string, field: string, value: any) => void;
    onDelete: (id: string) => void;
    onGenerate: (id: string) => void;
    onAssignChar: (shotId: string) => void;
    onAssignProd: (shotId: string) => void;
    onAssignLoc: (shotId: string) => void;
}> = ({ shot, index, character, product, location, onUpdate, onDelete, onGenerate, onAssignChar, onAssignProd, onAssignLoc }) => {
    return (
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-lg transition-all group flex gap-6 items-start">
            {/* Left: Drag / Order */}
            <div className="flex flex-col items-center gap-2 pt-2">
                <span className="text-gray-300 cursor-move"><DragHandleIcon className="w-5 h-5"/></span>
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center font-bold text-xs text-gray-500">{index + 1}</div>
            </div>

            {/* Middle: Data Inputs */}
            <div className="flex-1 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Camera</label>
                        <input className="w-full bg-gray-50 border-transparent rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none" value={shot.camera} onChange={(e) => onUpdate(shot.id, 'camera', e.target.value)} />
                    </div>
                    <div>
                        <label className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Movement</label>
                        <input className="w-full bg-gray-50 border-transparent rounded-lg px-3 py-2 text-sm font-bold text-gray-800 focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none" value={shot.movement} onChange={(e) => onUpdate(shot.id, 'movement', e.target.value)} />
                    </div>
                </div>
                
                <div>
                    <label className="text-[9px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Action Description</label>
                    <textarea className="w-full bg-gray-50 border-transparent rounded-xl px-4 py-3 text-sm font-medium text-gray-700 h-20 resize-none focus:bg-white focus:ring-2 focus:ring-indigo-100 outline-none leading-relaxed" value={shot.action} onChange={(e) => onUpdate(shot.id, 'action', e.target.value)} />
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    <button 
                        onClick={() => onAssignChar(shot.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border transition-all ${character ? 'bg-purple-50 text-purple-700 border-purple-200' : 'bg-gray-50 text-gray-400 border-transparent hover:bg-gray-100'}`}
                        title="Assign Character"
                    >
                        <UserIcon className="w-3 h-3"/> {character ? character.name : 'Cast'}
                    </button>
                    <button 
                        onClick={() => onAssignLoc(shot.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border transition-all ${location ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-gray-50 text-gray-400 border-transparent hover:bg-gray-100'}`}
                        title="Assign Location"
                    >
                        <MapPinIcon className="w-3 h-3"/> {location ? location.name : 'Set'}
                    </button>
                    <button 
                        onClick={() => onAssignProd(shot.id)}
                        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest border transition-all ${product ? 'bg-orange-50 text-orange-700 border-orange-200' : 'bg-gray-50 text-gray-400 border-transparent hover:bg-gray-100'}`}
                        title="Assign Product"
                    >
                        <CubeIcon className="w-3 h-3"/> {product ? product.name : 'Item'}
                    </button>
                    <div className="h-4 w-px bg-gray-200 mx-2"></div>
                    <span className="text-[10px] font-bold text-gray-400 uppercase">{shot.duration}s</span>
                </div>
            </div>

            {/* Right: Visual */}
            <div className="w-64 shrink-0 flex flex-col gap-3">
                <div className="aspect-video bg-gray-100 rounded-xl overflow-hidden relative group/frame border border-gray-200">
                    {shot.imageUrl ? (
                        <img src={shot.imageUrl} className="w-full h-full object-cover" />
                    ) : (
                        <div className="w-full h-full flex flex-col items-center justify-center text-gray-300">
                            {shot.status === 'generating' ? (
                                <div className="w-8 h-8 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mb-2"></div>
                            ) : (
                                <PhotoIcon className="w-10 h-10 opacity-20"/>
                            )}
                            <span className="text-[9px] font-bold uppercase tracking-widest">{shot.status === 'generating' ? 'Rendering' : 'No Frame'}</span>
                        </div>
                    )}
                </div>
                <div className="flex gap-2">
                    <button 
                        onClick={() => onGenerate(shot.id)}
                        disabled={shot.status === 'generating'}
                        className="flex-1 py-3 bg-black text-white rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-gray-800 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                    >
                        <MagicWandIcon className="w-3 h-3"/> {shot.imageUrl ? 'Regen' : 'Generate'}
                    </button>
                    <button onClick={() => onDelete(shot.id)} className="p-3 bg-red-50 text-red-400 rounded-xl hover:bg-red-100 transition-colors">
                        <TrashIcon className="w-4 h-4"/>
                    </button>
                </div>
            </div>
        </div>
    );
};

// --- Sub-Component: Asset Picker Modal ---
const AssetPicker: React.FC<{ 
    title: string,
    items: { id: string, name: string, imageUrl: string }[], 
    onSelect: (id: string) => void,
    onClose: () => void 
}> = ({ title, items, onSelect, onClose }) => (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[200] flex items-center justify-center p-4" onClick={onClose}>
        <div className="bg-white rounded-[2rem] p-6 max-w-2xl w-full max-h-[80vh] overflow-hidden flex flex-col shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-6">
                <h3 className="font-black text-xl uppercase tracking-tight">{title}</h3>
                <button onClick={onClose}><XMarkIcon className="w-6 h-6 text-gray-400"/></button>
            </div>
            {items.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                    <SparklesIcon className="w-12 h-12 mx-auto mb-2 opacity-20"/>
                    <p className="text-xs font-bold uppercase tracking-widest">No assets available.</p>
                    <p className="text-[10px] mt-2">Go back to the Assets tab to add more.</p>
                </div>
            ) : (
                <div className="grid grid-cols-3 gap-4 overflow-y-auto p-1">
                    {items.map(item => (
                        <button 
                            key={item.id} 
                            onClick={() => onSelect(item.id)}
                            className="flex flex-col items-center gap-3 p-4 rounded-2xl border border-gray-100 hover:border-indigo-300 hover:bg-indigo-50 transition-all group"
                        >
                            <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-200 border-2 border-white shadow-md">
                                <img src={item.imageUrl || ''} className="w-full h-full object-cover" />
                            </div>
                            <span className="font-bold text-sm text-gray-700 group-hover:text-indigo-700 text-center">{item.name}</span>
                        </button>
                    ))}
                </div>
            )}
        </div>
    </div>
);

// --- MAIN PLUGIN COMPONENT ---
const StoryboardStudio: React.FC = () => {
    // State
    const [activeTab, setActiveTab] = useState<'input' | 'assets' | 'shots' | 'review'>('input');
    const [project, setProject] = useState<SB_Project>({
        id: crypto.randomUUID(),
        title: 'New Storyboard',
        concept: '',
        format: 'social',
        tone: '',
        shots: [],
        characters: [],
        products: [],
        locations: []
    });
    
    // UI State
    const [isThinking, setIsThinking] = useState(false);
    const [isSaving, setIsSaving] = useState(false);
    const [availableCharacters, setAvailableCharacters] = useState<Influencer[]>([]);
    const [availableProducts, setAvailableProducts] = useState<Product[]>([]);
    const [availableLocations, setAvailableLocations] = useState<Location[]>([]);
    
    // Pickers
    const [showCharPicker, setShowCharPicker] = useState<string | null>(null); // Shot ID
    const [showProdPicker, setShowProdPicker] = useState<string | null>(null); // Shot ID
    const [showLocPicker, setShowLocPicker] = useState<string | null>(null); // Shot ID

    const [frameStyle, setFrameStyle] = useState<'sketch'|'animatic'|'photoreal'>('animatic');
    const [lightboxIndex, setLightboxIndex] = useState<number | null>(null); // For Cinema Mode
    
    const [notification, setNotification] = useState<{message: string, type: 'success' | 'error'} | null>(null);
    const [confirmModal, setConfirmModal] = useState<{isOpen: boolean, title: string, message: string, onConfirm: () => void} | null>(null);

    useEffect(() => {
        // Pre-load library assets
        const loadAssets = async () => {
            const [chars, prods, locs] = await Promise.all([
                fetchCharacters(),
                fetchProducts(),
                fetchLocations()
            ]);
            setAvailableCharacters(chars || []);
            setAvailableProducts(prods || []);
            setAvailableLocations(locs || []);
        };
        loadAssets();
    }, []);

    useEffect(() => {
        if(notification) {
            const timer = setTimeout(() => setNotification(null), 3000);
            return () => clearTimeout(timer);
        }
    }, [notification]);

    // --- Actions ---

    // Auto-Assign logic invoked when switching to Shots tab or manually
    const autoAssignAssets = () => {
        if (!project.shots.length) return;

        const singleChar = project.characters.length === 1 ? project.characters[0] : null;
        const singleLoc = project.locations.length === 1 ? project.locations[0] : null;
        const singleProd = project.products.length === 1 ? project.products[0] : null;

        const updatedShots = project.shots.map(shot => {
            let newShot = { ...shot };

            // Assign Location (Consistency Priority)
            if (!newShot.assignedLocationId) {
                if (singleLoc) {
                    newShot.assignedLocationId = singleLoc.id;
                } else if (project.locations.length > 1) {
                    // Try naive match
                    const match = project.locations.find(l => shot.setting.toLowerCase().includes(l.name.toLowerCase()));
                    if (match) newShot.assignedLocationId = match.id;
                }
            }

            // Assign Product (Consistency Priority)
            if (!newShot.assignedProductId) {
                if (singleProd) {
                    newShot.assignedProductId = singleProd.id;
                } else if (project.products.length > 1) {
                    const match = project.products.find(p => 
                        shot.action.toLowerCase().includes(p.name.toLowerCase()) || 
                        shot.subject.toLowerCase().includes(p.name.toLowerCase())
                    );
                    if (match) newShot.assignedProductId = match.id;
                }
            }

            // Assign Character
            if (!newShot.assignedCharacterId) {
                if (singleChar) {
                    newShot.assignedCharacterId = singleChar.id;
                } else if (project.characters.length > 1) {
                    const match = project.characters.find(c => shot.subject.toLowerCase().includes(c.name.toLowerCase()));
                    if (match) newShot.assignedCharacterId = match.id;
                }
            }

            return newShot;
        });

        setProject(prev => ({ ...prev, shots: updatedShots }));
    };

    const handleTabChange = (tab: typeof activeTab) => {
        if (tab === 'shots' && activeTab === 'assets') {
            autoAssignAssets();
            setNotification({ message: "Assets synced to Shot List.", type: 'success' });
        }
        setActiveTab(tab);
    };

    const handleAnalyzeScript = async (title: string, concept: string, format: 'tvc'|'social'|'explainer') => {
        setIsThinking(true);
        try {
            // Parallel execution: Get Shot List AND Extracted Entities
            const [shotsData, extractionData] = await Promise.all([
                analyzeScriptToShots(concept, format, 30),
                extractCharactersAndScenes(concept)
            ]);
            
            // 1. Process Shots
            const newShots: SB_Shot[] = shotsData.map((s: any) => ({
                id: crypto.randomUUID(),
                order: s.order,
                camera: s.camera,
                movement: s.movement,
                subject: s.subject,
                action: s.action,
                setting: s.setting,
                lighting: s.lighting,
                duration: s.duration,
                status: 'draft'
            }));

            // 2. Auto-Assign Assets (Pre-selection for Project)
            const autoCharacters: any[] = [];
            const autoLocations: any[] = [];
            const autoProducts: any[] = [];

            // A. Characters
            if (extractionData.characters) {
                extractionData.characters.forEach((extracted: any) => {
                    const match = availableCharacters.find(c => 
                        c.name.toLowerCase().includes(extracted.name.toLowerCase()) || 
                        (c.alias && c.alias.toLowerCase().includes(extracted.name.toLowerCase()))
                    );
                    if (match && !autoCharacters.find(c => c.id === (match.character_id || match.id))) {
                        autoCharacters.push({
                            id: match.character_id || match.id,
                            name: match.name,
                            description: match.description,
                            imageUrl: match.image_url || match.image_urls_jsonb?.[0]?.url || ''
                        });
                    }
                });
            }
            // Fallback Char Match if extraction missed
            if (autoCharacters.length === 0) {
                availableCharacters.forEach(c => {
                    if (concept.toLowerCase().includes(c.name.toLowerCase()) && !autoCharacters.find(ac => ac.id === (c.character_id || c.id))) {
                        autoCharacters.push({
                            id: c.character_id || c.id,
                            name: c.name,
                            description: c.description,
                            imageUrl: c.image_url || c.image_urls_jsonb?.[0]?.url || ''
                        });
                    }
                });
            }

            // B. Locations
            if (extractionData.locations) {
                extractionData.locations.forEach((extracted: any) => {
                    const match = availableLocations.find(l => l.name.toLowerCase().includes(extracted.name.toLowerCase()));
                    if (match && !autoLocations.find(l => l.id === String(match.id))) {
                        autoLocations.push({
                            id: String(match.id),
                            name: match.name,
                            imageUrl: match.image_urls?.primary || ''
                        });
                    }
                });
            }

            // C. Products (Naive Match)
            availableProducts.forEach(p => {
                if (concept.toLowerCase().includes(p.product_name.toLowerCase()) && !autoProducts.find(ap => ap.id === p.id)) {
                    autoProducts.push({
                        id: p.id,
                        name: p.product_name,
                        imageUrl: typeof p.image === 'string' ? p.image : p.image?.primary
                    });
                }
            });

            setProject(prev => ({
                ...prev,
                title,
                concept,
                format,
                shots: newShots,
                characters: autoCharacters,
                locations: autoLocations,
                products: autoProducts
            }));
            
            // Move to Assets step first
            handleTabChange('assets');
            setNotification({ message: "Script Analyzed! Review Assets.", type: 'success' });
        } catch (e: any) {
            console.error(e);
            setNotification({ message: `Analysis failed: ${e.message}`, type: 'error' });
        } finally {
            setIsThinking(false);
        }
    };

    const updateShot = (id: string, field: string, value: any) => {
        setProject(prev => ({
            ...prev,
            shots: prev.shots.map(s => s.id === id ? { ...s, [field]: value } : s)
        }));
    };

    const handleDeleteShotClick = (id: string) => {
        setConfirmModal({
            isOpen: true,
            title: "Delete Shot",
            message: "Are you sure you want to remove this shot?",
            onConfirm: () => {
                deleteShot(id);
                setConfirmModal(null);
            }
        });
    };

    const deleteShot = (id: string) => {
        setProject(prev => ({
            ...prev,
            shots: prev.shots.filter(s => s.id !== id)
        }));
    };

    const assignAssetToShot = (shotId: string, assetId: string, type: 'character'|'product'|'location') => {
        if (type === 'character') updateShot(shotId, 'assignedCharacterId', assetId);
        if (type === 'product') updateShot(shotId, 'assignedProductId', assetId);
        if (type === 'location') updateShot(shotId, 'assignedLocationId', assetId);
        
        setShowCharPicker(null);
        setShowProdPicker(null);
        setShowLocPicker(null);
    };

    const generateFrame = async (shotId: string) => {
        const shot = project.shots.find(s => s.id === shotId);
        if (!shot) return;

        updateShot(shotId, 'status', 'generating');

        try {
            const references: any = {};

            // 1. Character Ref
            if (shot.assignedCharacterId) {
                const char = project.characters.find(c => c.id === shot.assignedCharacterId);
                if (char && char.imageUrl) {
                    references.character = await urlToBase64(char.imageUrl);
                }
            }

            // 2. Product Ref
            if (shot.assignedProductId) {
                const prod = project.products.find(p => p.id === shot.assignedProductId);
                if (prod && prod.imageUrl) {
                    references.product = await urlToBase64(prod.imageUrl);
                }
            }

            // 3. Location Ref
            if (shot.assignedLocationId) {
                const loc = project.locations.find(l => l.id === shot.assignedLocationId);
                if (loc && loc.imageUrl) {
                    references.location = await urlToBase64(loc.imageUrl);
                }
            }

            const base64 = await generateStoryboardFrame(shot, frameStyle, AspectRatio.LANDSCAPE, references);
            
            if (base64) {
                const binary = atob(base64);
                const array = [];
                for (let i = 0; i < binary.length; i++) array.push(binary.charCodeAt(i));
                const blob = new Blob([new Uint8Array(array)], { type: 'image/png' });
                
                const url = await uploadBlob(blob, `sb_frame_${shotId}_${Date.now()}.png`, 'godrej/storyboards');
                
                if (url) {
                    updateShot(shotId, 'imageUrl', url);
                    updateShot(shotId, 'status', 'done');
                }
            } else {
                throw new Error("No image generated");
            }
        } catch (e) {
            console.error(e);
            updateShot(shotId, 'status', 'draft'); 
            setNotification({ message: "Frame generation failed", type: 'error' });
        }
    };

    const urlToBase64 = async (url: string): Promise<string> => {
        try {
            const resp = await fetch(url);
            const blob = await resp.blob();
            return new Promise((resolve) => {
                const reader = new FileReader();
                reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
                reader.readAsDataURL(blob);
            });
        } catch(e) { return ""; }
    }

    const handleBatchGenerateClick = () => {
        const pending = project.shots.filter(s => !s.imageUrl);
        if (pending.length === 0) return;
        
        setConfirmModal({
            isOpen: true,
            title: "Generate All Frames",
            message: `Generate frames for ${pending.length} shots? This might take a minute.`,
            onConfirm: () => {
                handleBatchGenerate();
                setConfirmModal(null);
            }
        });
    };

    const handleBatchGenerate = async () => {
        const pending = project.shots.filter(s => !s.imageUrl);
        for (const shot of pending) {
            await generateFrame(shot.id);
        }
    };

    // --- Save to DB ---
    const handleSaveProject = async () => {
        if (!project.title || project.shots.length === 0) return;
        setIsSaving(true);
        try {
            // 1. Prepare Ad Payload
            const adPayload = {
                id: project.id,
                ad_title: project.title,
                concept: project.concept,
                ad_style: project.format,
                status: 'storyboard',
                characters: JSON.stringify(project.characters), // Store project cast
                ad_data: JSON.stringify({
                    products: project.products,
                    locations: project.locations,
                    tone: project.tone
                }),
                // Generate storyboard_urls JSON for AdsViewer thumbnail logic
                storyboard_urls: JSON.stringify(project.shots.filter(s => s.imageUrl).map(s => ({
                    url: s.imageUrl,
                    prompt: s.action
                })))
            };

            // 2. Upsert Ad
            const { error: adError } = await supabase.from('dng1_ads').upsert(adPayload);
            if(adError) throw adError;

            // 3. Upsert Scenes (Clean way: Delete existing scenes for this project and re-insert to handle re-ordering/deletion)
            // Ideally we'd use upsert with precise IDs, but bulk replace is safer for sync
            await supabase.from('dng1_ad_scenes').delete().eq('ad_id', project.id);

            const scenesPayload = project.shots.map((shot, index) => ({
                id: shot.id,
                ad_id: project.id,
                scene_number: index + 1,
                description: shot.action, // Main description
                scene_image_url: shot.imageUrl,
                status: shot.status === 'done' ? 'done' : 'pending',
                scene_data: JSON.stringify({
                    visual_prompt: shot.action, // Required for Studio
                    camera: shot.camera,
                    movement: shot.movement,
                    lighting: shot.lighting,
                    setting: shot.setting,
                    subject: shot.subject,
                    duration: shot.duration,
                    assigned_character_id: shot.assignedCharacterId,
                    assigned_product_id: shot.assignedProductId,
                    assigned_location_id: shot.assignedLocationId
                })
            }));

            const { error: sceneError } = await supabase.from('dng1_ad_scenes').insert(scenesPayload);
            if(sceneError) throw sceneError;

            setNotification({ message: "Project saved to Library!", type: 'success' });

        } catch (e: any) {
            console.error("Save error", e);
            setNotification({ message: `Save failed: ${e.message}`, type: 'error' });
        } finally {
            setIsSaving(false);
        }
    };

    return (
        <div className="w-full h-full flex flex-col bg-gray-50 overflow-hidden font-sans">
            {notification && <NotificationToast message={notification.message} type={notification.type} onClose={() => setNotification(null)} />}
            {confirmModal && <ConfirmModal isOpen={confirmModal.isOpen} title={confirmModal.title} message={confirmModal.message} onConfirm={confirmModal.onConfirm} onCancel={() => setConfirmModal(null)} />}
            
            {/* LIGHTBOX OVERLAY */}
            {lightboxIndex !== null && (
                <StoryboardLightbox 
                    shots={project.shots} 
                    initialIndex={lightboxIndex} 
                    onClose={() => setLightboxIndex(null)}
                />
            )}

            {/* Header */}
            <header className="h-20 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0 shadow-sm z-20">
                <div className="flex items-center gap-4">
                    <div className="bg-gradient-to-tr from-indigo-500 to-purple-600 p-2.5 rounded-xl text-white shadow-lg">
                        <FilmIcon className="w-6 h-6"/>
                    </div>
                    <div>
                        <h1 className="text-xl font-black text-gray-900 uppercase tracking-tight">Storyboard Studio</h1>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Plugin v1.2 • Auto-Assign</p>
                    </div>
                </div>

                <div className="flex bg-gray-100 p-1 rounded-xl">
                    <button onClick={() => handleTabChange('input')} className={`px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'input' ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-gray-700'}`}>1. Input</button>
                    <button onClick={() => handleTabChange('assets')} className={`px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'assets' ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-gray-700'}`}>2. Assets</button>
                    <button onClick={() => handleTabChange('shots')} disabled={project.shots.length === 0} className={`px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'shots' ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-gray-700 disabled:opacity-50'}`}>3. Planner</button>
                    <button onClick={() => handleTabChange('review')} disabled={project.shots.length === 0} className={`px-6 py-2.5 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'review' ? 'bg-white shadow text-black' : 'text-gray-500 hover:text-gray-700 disabled:opacity-50'}`}>4. Review</button>
                </div>
            </header>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8 relative">
                {activeTab === 'input' && (
                    <StoryInput 
                        onAnalyze={handleAnalyzeScript} 
                        isAnalyzing={isThinking} 
                        initialTitle={project.title}
                        initialConcept={project.concept}
                    />
                )}

                {activeTab === 'assets' && (
                    <div className="flex flex-col gap-4">
                        <div className="flex justify-end px-8">
                            <button onClick={() => handleTabChange('shots')} className="bg-black text-white px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs shadow-lg hover:scale-105 transition-all flex items-center gap-2">
                                <BoltIcon className="w-4 h-4 text-yellow-400"/> Sync to Shots
                            </button>
                        </div>
                        <ProjectAssetManager 
                            project={project}
                            setProject={setProject}
                            availableCharacters={availableCharacters}
                            availableProducts={availableProducts}
                            availableLocations={availableLocations}
                        />
                    </div>
                )}

                {activeTab === 'shots' && (
                    <div className="max-w-5xl mx-auto pb-20">
                        <div className="flex justify-between items-center mb-8 sticky top-0 bg-gray-50 z-10 py-4 border-b border-gray-200">
                            <div>
                                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">Shot Planner</h3>
                                <p className="text-xs text-gray-500 font-medium">{project.shots.length} Shots • {project.shots.reduce((a,b)=>a+b.duration,0)}s Total</p>
                            </div>
                            <div className="flex gap-4">
                                <button onClick={autoAssignAssets} className="text-xs font-bold text-indigo-600 hover:bg-indigo-50 px-4 py-2 rounded-lg transition-colors flex items-center gap-2 border border-indigo-200">
                                    <BoltIcon className="w-3 h-3"/> Auto-Assign
                                </button>
                                <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm">
                                    <span className="text-[10px] font-bold text-gray-400 uppercase">Style</span>
                                    <select className="text-xs font-bold text-gray-800 bg-transparent outline-none cursor-pointer" value={frameStyle} onChange={(e: any) => setFrameStyle(e.target.value)}>
                                        <option value="sketch">Rough Sketch</option>
                                        <option value="animatic">Color Animatic</option>
                                        <option value="photoreal">Photoreal (Pro)</option>
                                    </select>
                                </div>
                                <button onClick={handleBatchGenerateClick} className="bg-black text-white px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest shadow-lg hover:bg-gray-800 transition-all flex items-center gap-2">
                                    <SparklesIcon className="w-4 h-4 text-yellow-400"/> Generate All Frames
                                </button>
                            </div>
                        </div>

                        <div className="space-y-6">
                            {project.shots.map((shot, idx) => (
                                <ShotCard 
                                    key={shot.id} 
                                    shot={shot} 
                                    index={idx} 
                                    character={project.characters.find(c => c.id === shot.assignedCharacterId)}
                                    product={project.products.find(p => p.id === shot.assignedProductId)}
                                    location={project.locations.find(l => l.id === shot.assignedLocationId)}
                                    onUpdate={updateShot}
                                    onDelete={() => handleDeleteShotClick(shot.id)}
                                    onGenerate={generateFrame}
                                    onAssignChar={(id) => setShowCharPicker(id)}
                                    onAssignProd={(id) => setShowProdPicker(id)}
                                    onAssignLoc={(id) => setShowLocPicker(id)}
                                />
                            ))}
                            <button 
                                onClick={() => setProject(p => ({...p, shots: [...p.shots, { id: crypto.randomUUID(), order: p.shots.length + 1, camera: 'Wide', movement: 'Static', subject: 'Subject', action: 'Action', setting: 'Setting', lighting: 'Daylight', duration: 4, status: 'draft' }] }))}
                                className="w-full py-6 border-2 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center text-gray-400 hover:border-indigo-400 hover:text-indigo-500 hover:bg-indigo-50 transition-all gap-2"
                            >
                                <PlusIcon className="w-8 h-8"/>
                                <span className="font-bold text-xs uppercase tracking-widest">Add New Shot</span>
                            </button>
                        </div>
                    </div>
                )}

                {activeTab === 'review' && (
                    <div className="max-w-6xl mx-auto pb-20">
                        <div className="flex justify-between items-center mb-8">
                            <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight text-center">Visual Board</h3>
                            <div className="flex gap-3">
                                <button
                                    onClick={() => setLightboxIndex(0)}
                                    className="bg-white border border-gray-200 text-gray-700 px-6 py-3 rounded-xl font-bold uppercase tracking-widest text-xs shadow-sm hover:bg-gray-50 transition-all flex items-center gap-2"
                                >
                                    <EyeIcon className="w-4 h-4"/> Cinema Mode
                                </button>
                                <button 
                                    onClick={handleSaveProject} 
                                    disabled={isSaving}
                                    className="bg-black text-white px-8 py-3 rounded-xl font-bold uppercase tracking-widest text-xs shadow-xl hover:scale-105 transition-all flex items-center gap-3 disabled:opacity-50"
                                >
                                    {isSaving ? 'Saving...' : 'Save to Library'} <SaveIcon className="w-4 h-4"/>
                                </button>
                            </div>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                            {project.shots.map((shot, idx) => (
                                <div 
                                    key={shot.id} 
                                    onClick={() => setLightboxIndex(idx)}
                                    className="bg-white p-3 rounded-2xl shadow-sm border border-gray-100 cursor-pointer hover:shadow-xl hover:-translate-y-1 transition-all group"
                                >
                                    <div className="aspect-video bg-gray-100 rounded-xl overflow-hidden mb-3 border border-gray-200 relative">
                                        {shot.imageUrl ? (
                                            <img src={shot.imageUrl} className="w-full h-full object-cover"/>
                                        ) : (
                                            <div className="w-full h-full flex items-center justify-center text-gray-300 text-xs font-bold uppercase">No Image</div>
                                        )}
                                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <div className="bg-white/20 backdrop-blur-md p-2 rounded-full text-white border border-white/30">
                                                <EyeIcon className="w-4 h-4"/>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="flex justify-between items-start">
                                        <div className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-[10px] font-bold shrink-0">{idx + 1}</div>
                                        <p className="text-[10px] text-gray-500 font-medium text-right leading-tight max-w-[150px] line-clamp-2">{shot.action}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>

            {/* Modals */}
            {showCharPicker && (
                <AssetPicker 
                    title="Assign Character"
                    items={project.characters} 
                    onSelect={(id) => assignAssetToShot(showCharPicker, id, 'character')} 
                    onClose={() => setShowCharPicker(null)} 
                />
            )}
            {showProdPicker && (
                <AssetPicker 
                    title="Assign Product"
                    items={project.products} 
                    onSelect={(id) => assignAssetToShot(showProdPicker, id, 'product')} 
                    onClose={() => setShowProdPicker(null)} 
                />
            )}
            {showLocPicker && (
                <AssetPicker 
                    title="Assign Location"
                    items={project.locations} 
                    onSelect={(id) => assignAssetToShot(showLocPicker, id, 'location')} 
                    onClose={() => setShowLocPicker(null)} 
                />
            )}
        </div>
    );
};

export default StoryboardStudio;
