
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState, useEffect, useRef } from 'react';
import { 
    generateScriptFromBrief,
    extractCharactersAndScenes,
    generateImagenImage,
    generateImage,
    mapAssetsToScenes,
    enhanceVisualPrompt,
    ANIMATIC_STYLES
} from '../services/geminiService';
import { uploadBlob, supabase, fetchCharacters, fetchProducts, createLocation } from '../services/supabaseClient';
import { AspectRatio, StoryboardScene, BrandIdentity, Product, Asset } from '../types';
import { 
    ArrowRightIcon, 
    MagicWandIcon, 
    CheckCircleIcon, 
    PlusIcon, 
    XMarkIcon, 
    UserIcon, 
    SearchIcon, 
    CubeIcon, 
    PhotoIcon, 
    PencilSquareIcon, 
    ArrowPathIcon, 
    MapPinIcon, 
    TrashIcon, 
    UploadCloudIcon, 
    FilmIcon, 
    EyeIcon, 
    BoltIcon, 
    ListBulletIcon, 
    FramesModeIcon, 
    LinkIcon, 
    ExclamationTriangleIcon,
    SparklesIcon,
    SaveIcon,
    GlobeAltIcon
} from './icons';
import Modal from './Modal';
import AssetStudio from './AssetStudio';
import StoryboardSceneCard from './StoryboardSceneCard';

interface StoryboardGeneratorProps {
  adId?: string | null;
  onOpenInStudio: (adId: string) => void;
  setBreadcrumb?: (name: string | null) => void;
}

export interface CompositionAsset {
    id: string;
    url: string;
    type: 'character' | 'setting' | 'product';
    name: string;
}

export interface SceneCard extends StoryboardScene {
    id: string;
    imageUrl?: string;
    endImageUrl?: string;
    videoUrl?: string;
    status: 'pending' | 'generating' | 'done' | 'error';
    editablePrompt?: string;
    editableEndPrompt?: string;
    showDebug?: boolean; // Toggle for AI Logic View
    composition?: {
        characters: CompositionAsset[];
        location?: CompositionAsset;
        product?: CompositionAsset;
    };
}

interface ExtendedStoryboardCharacter {
    id: string;
    name: string;
    role: string;
    description: string;
    visual_prompt: string;
    imageUrl?: string;
    status: 'idle' | 'generating' | 'done' | 'error' | 'matched' | 'unassigned';
}

interface ExtractedLocation {
    id: string;
    name: string;
    description: string;
    visual_style: string;
    imageUrl?: string;
    status: 'idle' | 'generating' | 'done' | 'error';
    visual_prompt?: string; // Added for editable prompt
}

type WizardStep = 'ask' | 'assets' | 'check';
type ProjectScope = 'animatix' | 'ad' | 'movie';
type StoryboardMode = 'standard' | 'animatics';

// Helper to convert URL to Base64 for Gemini
const urlToBase64 = async (url: string): Promise<string> => {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        resolve(base64);
      };
      reader.readAsDataURL(blob);
    });
  } catch (e) {
    console.error("Failed to convert image to base64", e);
    return "";
  }
};

export const StoryboardGenerator: React.FC<StoryboardGeneratorProps> = ({ adId, onOpenInStudio, setBreadcrumb }) => {
  // ... (Keep existing state hooks) ...
  const [step, setStep] = useState<WizardStep>('ask');
  
  // --- Step 1: ASK ---
  const [campaignTitle, setCampaignTitle] = useState('');
  const [coreIdea, setCoreIdea] = useState('');
  const [targetAudience, setTargetAudience] = useState('Gen Z');
  const [contextSetting, setContextSetting] = useState('Global'); // New Context State
  const [selectedBrandId, setSelectedBrandId] = useState('');
  const [brands, setBrands] = useState<BrandIdentity[]>([]);
  const [brandSearch, setBrandSearch] = useState('');
  const [isBrandDropdownOpen, setIsBrandDropdownOpen] = useState(false);
  const [scriptText, setScriptText] = useState('');
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [projectScope, setProjectScope] = useState<ProjectScope>('ad');
  const [quickMode, setQuickMode] = useState(false); 
  const [scriptMode, setScriptMode] = useState<'ai' | 'manual'>('ai');
  const [storyboardMode, setStoryboardMode] = useState<StoryboardMode>('standard');
  const [animaticStyle, setAnimaticStyle] = useState<string>('cinematic-previs');

  // --- Step 2: ASSETS ---
  const [characters, setCharacters] = useState<ExtendedStoryboardCharacter[]>([]);
  const [locations, setLocations] = useState<ExtractedLocation[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  
  const [isExtracting, setIsExtracting] = useState(false);
  const [isLoadingProject, setIsLoadingProject] = useState(false);
  const [extractError, setExtractError] = useState<string | null>(null);
  const [isMapping, setIsMapping] = useState(false);
  
  // Interaction State
  const [showAssetBrowser, setShowAssetBrowser] = useState(false);
  const [replacingAsset, setReplacingAsset] = useState<{ id: string, type: 'character' | 'setting' | 'product' } | null>(null);
  const [assetStepTab, setAssetStepTab] = useState<'cast' | 'locations' | 'products'>('cast');
  const [influencers, setInfluencers] = useState<any[]>([]);
  
  // Inline Editing
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [enhancingAsset, setEnhancingAsset] = useState<{id: string, type: 'character'|'setting'|'product'} | null>(null);

  // --- Step 3: CHECK ---
  const [scenes, setScenes] = useState<SceneCard[]>([]);
  const [activeAssetSlot, setActiveAssetSlot] = useState<{ sceneId: string, type: 'character' | 'setting' | 'product', isMulti?: boolean } | null>(null);
  const [isBatchGenerating, setIsBatchGenerating] = useState(false);
  const [isSavingAll, setIsSavingAll] = useState(false);

  // --- Step 4: RESULT ---
  const [createdAdId, setCreatedAdId] = useState<string | null>(adId || null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ... (Keep existing Effects and loadInitial) ...
  useEffect(() => {
      if (setBreadcrumb) setBreadcrumb(campaignTitle || "Storyboard Generator");
  }, [campaignTitle]);

  const loadInitial = async () => {
      const { data } = await supabase.from('dng1_brand_identity').select('*');
      if (data) setBrands(data);
      
      const influencerData = await fetchCharacters();
      setInfluencers(influencerData || []);

      if (adId && adId !== 'new') {
          setIsLoadingProject(true); // Distinct from extraction
          try {
              // 1. Fetch Ad with Scenes
              const { data: ad, error } = await supabase
                  .from('dng1_ads')
                  .select('*, scenes:dng1_ad_scenes(*)')
                  .eq('id', adId)
                  .single();
              
              if (error || !ad) throw new Error("Ad not found");

              // 2. Hydrate State
              setCampaignTitle(ad.ad_title);
              setCoreIdea(ad.concept || '');
              setScriptText(ad.concept || '');
              setCreatedAdId(ad.id);
              if (ad.product_id) setSelectedBrandId(ad.product_id);
              if (ad.ad_style === 'animatix' || ad.ad_style === 'animatics') {
                  setStoryboardMode('animatics');
                  setProjectScope('animatix');
              } else {
                  setStoryboardMode('standard');
                  setProjectScope(ad.ad_style as ProjectScope);
              }
              
              // Restore Assets
              if (ad.characters) {
                  let loadedChars = ad.characters;
                  if (typeof loadedChars === 'string') loadedChars = JSON.parse(loadedChars);
                  
                  setCharacters(loadedChars.map((c: any) => ({
                      ...c,
                      status: c.status || 'matched'
                  })));
              }
              
              if (ad.ad_data?.locations) {
                  setLocations(ad.ad_data.locations.map((l: any) => ({
                      ...l,
                      visual_prompt: l.visual_prompt || `${l.description}, ${l.visual_style}`
                  })));
              }
              if (ad.ad_data?.products) setProducts(ad.ad_data.products);

              // Restore Scenes
              if (ad.scenes && ad.scenes.length > 0) {
                  const sortedScenes = ad.scenes.sort((a: any, b: any) => a.scene_number - b.scene_number);
                  const mappedScenes = sortedScenes.map((s: any) => {
                      let sceneData = s.scene_data;
                      if (typeof sceneData === 'string') sceneData = JSON.parse(sceneData);
                      
                      return {
                          id: s.id,
                          scene_number: s.scene_number,
                          description: s.description,
                          visual_prompt_start: sceneData?.prompt || s.description,
                          status: s.status === 'done' ? 'done' : 'pending',
                          imageUrl: s.scene_image_url,
                          composition: sceneData?.composition || { characters: [], location: undefined, product: undefined }
                      };
                  });
                  setScenes(mappedScenes);
                  setStep('check');
              } else if (ad.characters && ad.characters.length > 0) {
                  setStep('assets');
              } else {
                  setStep('ask');
              }

          } catch(e) {
              console.error("Error loading project", e);
          } finally {
              setIsLoadingProject(false);
          }
      }
  };

  useEffect(() => { loadInitial(); }, [adId]);

  // Robust saving function that accepts current state explicitly
  const saveToDb = async (newChars: any[], newLocs: any[], newProds: any[]) => {
      if (!createdAdId) return;
      await supabase.from('dng1_ads').update({
          characters: newChars,
          ad_data: { locations: newLocs, products: newProds }
      }).eq('id', createdAdId);
  };

  // ... (Other handlers) ...
  const handleBrandSelect = async (brand: BrandIdentity) => {
      setSelectedBrandId(brand.id);
      setBrandSearch(brand.brand_name);
      setIsBrandDropdownOpen(false);
      
      const prods = await fetchProducts(brand.id);
      setProducts(prods.map(p => ({
          ...p,
          image: typeof p.image === 'string' ? {primary: p.image} : (p.image || {primary: ''})
      })));
  };

  const handleGenerateScript = async () => {
      if (!campaignTitle.trim()) { alert("Title required."); return; }
      setIsGeneratingScript(true);
      try {
          const generated = await generateScriptFromBrief(coreIdea, campaignTitle, projectScope, quickMode ? 2 : 4, contextSetting);
          setScriptText(generated);
          setScriptMode('manual');
          
          const { data } = await supabase.from('dng1_ads').insert({
              ad_title: campaignTitle,
              concept: generated,
              product_id: selectedBrandId || null,
              status: 'draft',
              ad_style: storyboardMode === 'animatics' ? 'animatics' : projectScope
          }).select().single();
          if (data) setCreatedAdId(data.id);
      } catch(e) { console.error(e); } finally { setIsGeneratingScript(false); }
  };

  const handleAnalyzeScript = async () => {
      if (!scriptText.trim()) return;
      setIsExtracting(true);
      setExtractError(null);
      
      try {
          let targetAdId = createdAdId;
          if (!targetAdId || targetAdId === 'new') {
              const { data } = await supabase.from('dng1_ads').insert({
                  ad_title: campaignTitle || "Untitled Storyboard",
                  concept: scriptText,
                  status: 'draft',
                  ad_style: storyboardMode === 'animatics' ? 'animatics' : 'ad'
              }).select().single();
              if (data) {
                  setCreatedAdId(data.id);
                  targetAdId = data.id;
              } else {
                  throw new Error("Failed to initialize project record.");
              }
          }

          const { characters: extracted, scenes: extractedScenes, locations: extractedLocs } = await extractCharactersAndScenes(scriptText);
          
          const mappedCast = extracted.map(char => {
              const match = influencers.find(i => i.name.includes(char.name));
              return {
                  ...char,
                  id: match ? match.character_id : crypto.randomUUID(),
                  imageUrl: match?.image_url,
                  status: match ? 'matched' : 'unassigned'
              };
          });
          setCharacters(mappedCast);
          
          setLocations(extractedLocs.map(l => ({ 
              ...l, 
              id: crypto.randomUUID(), 
              status: 'idle',
              visual_prompt: `${l.description}. ${l.visual_style}`
          })));

          const newScenes = extractedScenes.map(s => ({
              id: crypto.randomUUID(),
              scene_number: s.scene_number,
              description: s.description,
              status: 'pending',
              visual_prompt_start: s.visual_prompt_start,
              composition: { characters: [], location: undefined, product: undefined }
          }));
          setScenes(newScenes as SceneCard[]);

          if (targetAdId) {
              await supabase.from('dng1_ads').update({ 
                  characters: mappedCast, 
                  ad_data: { locations: extractedLocs, products: products },
                  concept: scriptText
              }).eq('id', targetAdId);
          }

          setStep('assets');
      } catch(e: any) { 
          console.error("Extraction error:", e);
          setExtractError(e.message || "Script analysis failed.");
      } finally { 
          setIsExtracting(false); 
      }
  };

  const handleEnhanceAssetPrompt = async (id: string, type: 'character'|'setting'|'product') => {
      setEnhancingAsset({id, type});
      try {
          let currentPrompt = '';
          if (type === 'character') {
              const c = characters.find(x => x.id === id);
              currentPrompt = c?.visual_prompt || '';
          } else if (type === 'setting') {
              const l = locations.find(x => x.id === id);
              currentPrompt = l?.visual_prompt || l?.description || '';
          } else {
              const p = products.find(x => x.id === id);
              currentPrompt = p?.product_insight || p?.product_name || '';
          }

          if (!currentPrompt) return;

          const enhanced = await enhanceVisualPrompt(currentPrompt);

          if (type === 'character') {
              setCharacters(prev => prev.map(c => c.id === id ? { ...c, visual_prompt: enhanced } : c));
          } else if (type === 'setting') {
              setLocations(prev => prev.map(l => l.id === id ? { ...l, visual_prompt: enhanced } : l));
          } else {
              setProducts(prev => prev.map(p => p.id === id ? { ...p, product_insight: enhanced } : p));
          }
      } catch(e) {
          console.error(e);
      } finally {
          setEnhancingAsset(null);
      }
  };

  const handleAssetLibrarySelect = (assets: Asset[]) => {
      if (assets.length === 0) return;
      const asset = assets[0];
      
      if (activeAssetSlot) {
          setScenes(prev => prev.map(s => {
              if (s.id !== activeAssetSlot.sceneId) return s;
              const comp = s.composition || { characters: [] };
              
              if (activeAssetSlot.type === 'character') {
                  if (comp.characters && comp.characters.some(c => c.id === asset.id)) return s;
                  return { 
                      ...s, 
                      composition: { 
                          ...comp, 
                          characters: [...(comp.characters || []), { id: asset.id, url: asset.publicURL, name: asset.name, type: 'character' }] 
                      } 
                  };
              } else if (activeAssetSlot.type === 'setting') {
                  return { ...s, composition: { ...comp, location: { id: asset.id, url: asset.publicURL, name: asset.name, type: 'setting' } } };
              } else {
                  return { ...s, composition: { ...comp, product: { id: asset.id, url: asset.publicURL, name: asset.name, type: 'product' } } };
              }
          }));
          setActiveAssetSlot(null);
      } else if (replacingAsset) {
          let newChars = characters;
          let newLocs = locations;
          let newProds = products;

          if (replacingAsset.type === 'character') {
              newChars = characters.map(c => c.id === replacingAsset.id ? { ...c, imageUrl: asset.publicURL, status: 'matched', name: asset.name } : c);
              setCharacters(newChars);
          } else if (replacingAsset.type === 'setting') {
              newLocs = locations.map(l => l.id === replacingAsset.id ? { ...l, imageUrl: asset.publicURL, status: 'done', name: asset.name } : l);
              setLocations(newLocs);
          } else if (replacingAsset.type === 'product') {
              newProds = products.map(p => p.id === replacingAsset.id ? { ...p, image: { primary: asset.publicURL, variants: [] }, product_name: asset.name } : p);
              setProducts(newProds);
          }
          
          saveToDb(newChars, newLocs, newProds); // Immediate save
          setReplacingAsset(null);
      }
      setShowAssetBrowser(false);
  };

  const handleAssetUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'character'|'setting'|'product', id: string) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const folder = type === 'character' ? 'godrej/characters' : type === 'setting' ? 'godrej/settings' : 'godrej/products';
      const url = await uploadBlob(file, `${type}_${Date.now()}.png`, folder);
      
      if (url) {
          let newChars = characters;
          let newLocs = locations;
          let newProds = products;

          if (type === 'character') {
              newChars = characters.map(c => c.id === id ? { ...c, imageUrl: url, status: 'done' } : c);
              setCharacters(newChars);
          }
          if (type === 'setting') {
              newLocs = locations.map(l => l.id === id ? { ...l, imageUrl: url, status: 'done' } : l);
              setLocations(newLocs);
          }
          if (type === 'product') {
              newProds = products.map(p => p.id === id ? { ...p, image: { primary: url, variants: [] } } : p);
              setProducts(newProds);
          }
          saveToDb(newChars, newLocs, newProds); // Immediate save
      }
  };

  const handleGenerateAsset = async (type: 'character'|'setting'|'product', id: string, prompt: string) => {
      try {
          // Optimistic loading state
          if (type === 'character') setCharacters(prev => prev.map(c => c.id === id ? { ...c, status: 'generating' } : c));
          if (type === 'setting') setLocations(prev => prev.map(l => l.id === id ? { ...l, status: 'generating' } : l));
          
          const result = await generateImagenImage(prompt, '1:1');
          const blob = await (await fetch(`data:image/png;base64,${result.base64}`)).blob();
          const url = await uploadBlob(blob, `${type}_gen_${Date.now()}.png`, `godrej/${type}s`);
          
          if (url) {
              let newChars = characters;
              let newLocs = locations;
              let newProds = products;

              if (type === 'character') {
                  newChars = characters.map(c => c.id === id ? { ...c, imageUrl: url, status: 'done' } : c);
                  setCharacters(newChars);
              }
              if (type === 'setting') {
                  newLocs = locations.map(l => l.id === id ? { ...l, imageUrl: url, status: 'done' } : l);
                  setLocations(newLocs);
                  
                  // **CRITICAL FIX**: Save to Location Hub explicitly
                  const locItem = newLocs.find(l => l.id === id);
                  if (locItem) {
                      try {
                          await createLocation({
                              name: locItem.name,
                              city: contextSetting || 'Global',
                              category: 'Studio',
                              prompt: { visual: prompt, lighting: 'Cinematic', atmosphere: 'Professional' },
                              image_urls: { primary: url, variants: [] }
                          });
                      } catch (e) {
                          console.error("Failed to save to Location Hub", e);
                      }
                  }
              }
              // Persist immediately with the fresh arrays
              await saveToDb(newChars, newLocs, newProds);
          }
      } catch(e) {
          alert("Generation failed");
          if (type === 'character') setCharacters(prev => prev.map(c => c.id === id ? { ...c, status: 'error' } : c));
          if (type === 'setting') setLocations(prev => prev.map(l => l.id === id ? { ...l, status: 'error' } : l));
      }
  };

  const handleDeleteAsset = (id: string, type: 'character'|'setting'|'product') => {
      let newChars = characters;
      let newLocs = locations;
      let newProds = products;

      if (type === 'character') {
          newChars = characters.filter(c => c.id !== id);
          setCharacters(newChars);
      }
      if (type === 'setting') {
          newLocs = locations.filter(l => l.id !== id);
          setLocations(newLocs);
      }
      if (type === 'product') {
          newProds = products.filter(p => p.id !== id);
          setProducts(newProds);
      }
      saveToDb(newChars, newLocs, newProds);
  };

  const handleProceedToComposition = async () => {
      setIsMapping(true);
      // Ensure latest state is saved before proceeding
      await saveToDb(characters, locations, products);

      // TIMEOUT GUARD: Force proceed after 8 seconds if AI hangs
      const timeout = new Promise((resolve) => setTimeout(() => resolve(null), 8000));

      try {
          // AI AUTO-MAPPING
          const mappingPromise = mapAssetsToScenes(
              scenes, 
              characters || [], 
              locations || [], 
              products || []
          );
          
          const mapping: any = await Promise.race([mappingPromise, timeout]);
          
          // FAILURE / TIMEOUT FALLBACK LOGIC
          if (!mapping || !Array.isArray(mapping)) {
              console.warn("AI mapping timed out. Applying Smart Fallback.");
              
              const fallbackLoc = locations[0];
              const fallbackProd = products[0];

              const fallbackScenes = scenes.map(s => {
                  // Fallback Character Logic:
                  // 1. Try simple name match in description (case-insensitive)
                  let matchedChars = characters.filter(c => s.description.toLowerCase().includes(c.name.toLowerCase()));
                  
                  // 2. If no text match, assign ALL characters (so none are lost)
                  if (matchedChars.length === 0) {
                      matchedChars = characters;
                  }

                  const compositionChars = matchedChars.map(c => ({
                      id: c.id,
                      url: c.imageUrl!,
                      name: c.name,
                      type: 'character' as const
                  })).filter(c => c.url); // Ensure valid URL

                  return {
                      ...s,
                      composition: {
                          characters: compositionChars,
                          location: fallbackLoc ? { id: fallbackLoc.id, url: fallbackLoc.imageUrl!, name: fallbackLoc.name, type: 'setting' as const } : undefined,
                          product: fallbackProd ? { 
                              id: fallbackProd.id, 
                              url: (typeof fallbackProd.image === 'string' ? fallbackProd.image : fallbackProd.image?.primary) || '', 
                              name: fallbackProd.product_name, 
                              type: 'product' as const 
                          } : undefined
                      }
                  };
              });
              
              setScenes(fallbackScenes);
              setStep('check');
              return;
          }

          // SUCCESSFUL MAPPING
          setScenes(prevScenes => prevScenes.map((scene, idx) => {
              const map = mapping.find((m: any) => m.scene_id === scene.id);
              
              let assignedChars: CompositionAsset[] = [];
              let assignedLoc: CompositionAsset | undefined;
              let assignedProd: CompositionAsset | undefined;

              if (map) {
                  assignedChars = Array.isArray(map.character_ids) 
                    ? map.character_ids.map((cid: string) => {
                        const c = characters.find(char => char.id === cid);
                        return c && c.imageUrl ? { id: c.id, url: c.imageUrl, name: c.name, type: 'character' as const } : null;
                    }).filter(Boolean) as CompositionAsset[]
                    : [];

                  const loc = locations.find(l => l.id === map.location_id && l.imageUrl);
                  if (loc) assignedLoc = { id: loc.id, url: loc.imageUrl!, name: loc.name, type: 'setting' as const };

                  const prod = products.find(p => p.id === map.product_id);
                  if (prod) {
                      const img = typeof prod.image === 'string' ? prod.image : prod.image?.primary;
                      assignedProd = { id: prod.id, url: img || '', name: prod.product_name, type: 'product' as const };
                  }
              }

              // Special Rule: Ensure last scene has a product if none assigned
              if (idx === prevScenes.length - 1 && !assignedProd && products.length > 0) {
                  const p = products[0];
                  const img = typeof p.image === 'string' ? p.image : p.image?.primary;
                  if (img) {
                      assignedProd = { id: p.id, url: img, name: p.product_name, type: 'product' as const };
                  }
              }

              return {
                  ...scene,
                  composition: {
                      characters: assignedChars,
                      location: assignedLoc,
                      product: assignedProd
                  }
              };
          }));

          setStep('check');
      } catch (e) {
          console.error("Auto-mapping error", e);
          setStep('check'); 
      } finally {
          setIsMapping(false);
      }
  };

  const generateSingleSceneImage = async (sceneId: string) => {
      const sceneIndex = scenes.findIndex(s => s.id === sceneId);
      const scene = scenes[sceneIndex];
      const isLastScene = sceneIndex === scenes.length - 1;

      if (!scene) return;

      setScenes(current => current.map(s => s.id === sceneId ? { ...s, status: 'generating' } : s));

      try {
          let prompt = scene.editablePrompt || scene.visual_prompt_start || scene.description || "";
          
          const comp = scene.composition;
          
          if (comp?.characters && comp.characters.length > 0) {
              const charNames = comp.characters.map(c => c.name).join(' and ');
              prompt += ` Featuring ${charNames}.`;
          }
          
          if (comp?.location) prompt += ` Setting: ${comp.location.name}.`;
          
          // Force product focus on last scene if not explicit
          if (isLastScene) {
             prompt += ` **FINAL SHOT:** Cinematic Movie Poster style featuring the product. Heroic lighting, title safe composition, 8k resolution.`;
          } else if (comp?.product) {
             prompt += ` Product: ${comp.product.name}.`;
          }

          const references: any = {};
          
          if (comp?.characters && comp.characters.length > 0) {
              const charBase64s = [];
              for (const char of comp.characters) {
                  if (char.url) {
                      const b64 = await urlToBase64(char.url);
                      if (b64) charBase64s.push(b64);
                  }
              }
              if (charBase64s.length > 0) references.characters = charBase64s;
          }

          if (comp?.location?.url) references.setting = await urlToBase64(comp.location.url);
          if (comp?.product?.url) references.product = await urlToBase64(comp.product.url);

          // If last scene and no product reference assigned, try to find a global product fallback
          if (isLastScene && !references.product && products.length > 0) {
              const p = products[0];
              const pUrl = typeof p.image === 'string' ? p.image : p.image?.primary;
              if (pUrl) {
                  references.product = await urlToBase64(pUrl);
                  prompt += ` Promoting Product: ${p.product_name}.`;
              }
          }

          let animaticPrompt = "";
          if (storyboardMode === 'animatics') {
              const styleDesc = ANIMATIC_STYLES[animaticStyle as keyof typeof ANIMATIC_STYLES] || ANIMATIC_STYLES['cinematic-previs'];
              animaticPrompt = styleDesc;
          }

          const res = await generateImage(
              prompt, 
              AspectRatio.LANDSCAPE, 
              references,
              storyboardMode === 'animatics' ? animaticPrompt : undefined
          );
          
          const blob = await (await fetch(`data:${res.mimeType};base64,${res.base64}`)).blob();
          const url = await uploadBlob(blob, `scene_${scene.id}_${Date.now()}.png`, 'godrej/generated');

          if (url) {
              setScenes(current => current.map(s => s.id === scene.id ? { ...s, status: 'done', imageUrl: url } : s));

              if (createdAdId) {
                  await supabase.from('dng1_ad_scenes').upsert({
                      id: scene.id,
                      ad_id: createdAdId,
                      scene_number: scene.scene_number,
                      description: scene.description,
                      scene_image_url: url,
                      status: 'done',
                      scene_data: {
                          prompt: prompt,
                          composition: comp
                      }
                  }, { onConflict: 'id' });
              }
          }
      } catch (e) {
          console.error(`Failed to generate scene ${scene.id}`, e);
          setScenes(current => current.map(s => s.id === scene.id ? { ...s, status: 'error' } : s));
          alert(`Generation failed for Scene ${scene.scene_number}`);
      }
  };

  const handleGenerateAllScenes = async () => {
      setIsBatchGenerating(true);
      const scenesToGen = [...scenes];
      for (const scene of scenesToGen) {
          if (scene.status !== 'done') { 
             await generateSingleSceneImage(scene.id);
          }
      }
      setIsBatchGenerating(false);
  };

  const handleFinish = async () => {
      setIsSavingAll(true);
      try {
          const payload = scenes.map((s, idx) => {
              let startFrameUrl = s.imageUrl;
              let endFrameUrl = null;
              
              // Continuity: Set this scene's End Frame to be the Next Scene's Start Frame
              // This ensures visual flow between scenes
              if (idx < scenes.length - 1) {
                  const nextScene = scenes[idx + 1];
                  if (nextScene.imageUrl) {
                      endFrameUrl = nextScene.imageUrl;
                  }
              }

              // Last Scene Logic: Ensure product ending
              if (idx === scenes.length - 1) {
                  // If we generated a poster, we might want to end on it or fade to product
                  const assigned = s.composition?.product;
                  if (assigned?.url) {
                      // End on the raw product image for a clean logo/packshot
                      endFrameUrl = assigned.url;
                  } else if (products.length > 0) {
                      const p = products[0];
                      endFrameUrl = typeof p.image === 'string' ? p.image : p.image?.primary;
                  }
              }

              return {
                  id: s.id,
                  ad_id: createdAdId,
                  scene_number: s.scene_number,
                  description: s.description,
                  scene_image_url: startFrameUrl || null, 
                  scene_end_image_url: endFrameUrl ? [endFrameUrl] : null, 
                  status: s.status === 'done' ? 'done' : 'pending',
                  scene_data: {
                      prompt: s.editablePrompt || s.visual_prompt_start || s.description,
                      composition: s.composition,
                      end_frame_url: endFrameUrl
                  }
              };
          });

          const { error } = await supabase.from('dng1_ad_scenes').upsert(payload, { onConflict: 'id' });
          if (error) throw error;

          if (createdAdId) {
              onOpenInStudio(createdAdId);
          }
      } catch(e) {
          console.error("Failed to save storyboard", e);
          alert("Failed to save storyboard to database.");
      } finally {
          setIsSavingAll(false);
      }
  };

  const handleSplitScene = async (index: number) => {
      const sceneToSplit = scenes[index];
      const newSceneId = crypto.randomUUID();
      const newScene: SceneCard = {
          ...sceneToSplit,
          id: newSceneId,
          scene_number: sceneToSplit.scene_number + 0.1,
          description: `${sceneToSplit.description} (Part 2)`,
          visual_prompt_start: sceneToSplit.visual_prompt_start,
          status: 'pending',
          imageUrl: undefined,
          videoUrl: undefined
      };
      const newScenes = [...scenes];
      newScenes.splice(index + 1, 0, newScene);
      const renumbered = newScenes.map((s, i) => ({ ...s, scene_number: i + 1 }));
      setScenes(renumbered);
  };

  const handleMergeScene = async (index: number) => {
      if (index >= scenes.length - 1) return;
      const current = scenes[index];
      const next = scenes[index + 1];
      const mergedDescription = `${current.description} ${next.description}`;
      const mergedPrompt = `${current.editablePrompt || current.visual_prompt_start} ${next.editablePrompt || next.visual_prompt_start}`;
      const mergedScene = {
          ...current,
          description: mergedDescription,
          editablePrompt: mergedPrompt,
          visual_prompt_start: mergedPrompt
      };
      const newScenes = [...scenes];
      newScenes.splice(index, 2, mergedScene);
      const renumbered = newScenes.map((s, i) => ({ ...s, scene_number: i + 1 }));
      setScenes(renumbered);
  };

  // Wrapper for SceneCard interaction
  const handleRemoveAsset = (sceneId: string, type: 'character'|'setting'|'product', index?: number) => {
      setScenes(prev => prev.map(s => {
          if (s.id !== sceneId) return s;
          const comp = { ...(s.composition || { characters: [] }) };
          
          if (type === 'character' && typeof index === 'number') {
              comp.characters = comp.characters.filter((_, i) => i !== index);
          } else if (type === 'setting') {
              comp.location = undefined;
          } else if (type === 'product') {
              comp.product = undefined;
          }
          return { ...s, composition: comp };
      }));
  };

  return (
    <div className="flex w-full h-full bg-gray-50 overflow-hidden font-sans relative">
        <Modal isOpen={showAssetBrowser} onClose={() => setShowAssetBrowser(false)} title="Select Asset from Library">
            <div className="h-[75vh] -m-6">
                <AssetStudio onAssetsSelected={handleAssetLibrarySelect} />
            </div>
        </Modal>

        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
            <header className="h-16 bg-white border-b border-gray-200 flex items-center justify-between px-6 shrink-0 z-20 shadow-sm">
                <div className="flex items-center gap-3"><div className="p-2 bg-purple-50 rounded-lg text-[#9063CD]"><MagicWandIcon className="w-5 h-5"/></div><h2 className="text-lg font-bold text-gray-900">Storyboard Generator</h2></div>
                <div className="flex gap-4 items-center">
                    <div className="flex gap-2">
                        {[1, 2, 3].map(s => (
                            <div key={s} className={`w-8 h-1 rounded-full ${step === (s===1?'ask':s===2?'assets':'check') ? 'bg-[#9063CD]' : 'bg-gray-200'}`}></div>
                        ))}
                    </div>
                </div>
            </header>

            <div className="flex-1 overflow-y-auto p-8">
                {isLoadingProject ? (
                    <div className="flex h-full items-center justify-center flex-col gap-4">
                        <div className="w-16 h-16 border-4 border-[#9063CD] border-t-transparent rounded-full animate-spin"></div>
                        <p className="text-gray-500 font-bold animate-pulse">Loading Project Data...</p>
                    </div>
                ) : isExtracting ? (
                    <div className="flex h-full items-center justify-center flex-col gap-4">
                        <div className="w-16 h-16 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                        <p className="text-indigo-600 font-bold animate-pulse">Analyzing Script & Casting Characters...</p>
                        <p className="text-xs text-gray-400">This may take a moment.</p>
                    </div>
                ) : (
                    <div className="max-w-7xl mx-auto space-y-12">
                        
                        {/* Error Banner */}
                        {extractError && (
                            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 animate-fade-in-up">
                                <ExclamationTriangleIcon className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                                <div>
                                    <h4 className="font-bold text-red-800 text-sm">Analysis Error</h4>
                                    <p className="text-xs text-red-600 mt-1">{extractError}</p>
                                    <button 
                                        onClick={() => setStep('assets')} // Force proceed to manual mode
                                        className="mt-2 text-xs font-bold text-red-700 underline hover:text-red-900"
                                    >
                                        Skip AI & Continue Manually
                                    </button>
                                </div>
                            </div>
                        )}

                        {step === 'ask' && (
                            <div className="animate-fade-in-up space-y-6">
                                <div className="bg-white p-10 rounded-[3rem] shadow-xl border border-gray-200 space-y-8 relative overflow-hidden">
                                    <div className="flex justify-between items-start relative z-10">
                                        <div>
                                            <h1 className="text-4xl font-black text-gray-900 mb-2">Project Inception</h1>
                                            <p className="text-gray-500 font-medium">Define your vision and creative direction.</p>
                                        </div>
                                        <button className="bg-blue-50 text-blue-600 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-blue-100">+ Add New Brand</button>
                                    </div>

                                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                                        {/* Left Column: Context */}
                                        <div className="space-y-8">
                                            <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                                                <button 
                                                    onClick={() => { setProjectScope('ad'); setQuickMode(false); setStoryboardMode('standard'); }}
                                                    className={`flex-shrink-0 min-w-[140px] flex-1 py-4 border-2 rounded-2xl font-bold text-xs uppercase tracking-widest transition-all ${storyboardMode === 'standard' && !quickMode ? 'border-[#9063CD] bg-purple-50 text-[#9063CD]' : 'border-gray-200 text-gray-400 hover:border-gray-300'}`}
                                                >
                                                    Standard Campaign<br/><span className="text-[9px] opacity-60 normal-case">Full narrative (32s).</span>
                                                </button>
                                                <button 
                                                    onClick={() => { setProjectScope('animatix'); setQuickMode(false); setStoryboardMode('animatics'); }}
                                                    className={`flex-shrink-0 min-w-[140px] flex-1 py-4 border-2 rounded-2xl font-bold text-xs uppercase tracking-widest transition-all relative ${storyboardMode === 'animatics' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-gray-200 text-gray-400 hover:border-gray-300'}`}
                                                >
                                                    Animatics Builder <FramesModeIcon className="w-3 h-3 absolute top-2 right-2"/>
                                                    <br/><span className="text-[9px] opacity-60 normal-case">Pre-vis sketches & motion.</span>
                                                </button>
                                                <button 
                                                    onClick={() => { setProjectScope('ad'); setQuickMode(true); setStoryboardMode('standard'); }}
                                                    className={`flex-shrink-0 min-w-[140px] flex-1 py-4 border-2 rounded-2xl font-bold text-xs uppercase tracking-widest transition-all relative ${quickMode ? 'border-orange-400 bg-orange-50 text-orange-600' : 'border-gray-200 text-gray-400 hover:border-gray-300'}`}
                                                >
                                                    Quick 2-Scene <BoltIcon className="w-3 h-3 absolute top-2 right-2"/>
                                                    <br/><span className="text-[9px] opacity-60 normal-case">Modular Capsules (2x8s).</span>
                                                </button>
                                            </div>

                                            {storyboardMode === 'animatics' && (
                                                <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100">
                                                    <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2 block">Animatic Style Preset</label>
                                                    <select 
                                                        value={animaticStyle} 
                                                        onChange={(e) => setAnimaticStyle(e.target.value)}
                                                        className="w-full p-3 bg-white border border-indigo-200 rounded-lg text-sm font-bold text-indigo-900 outline-none"
                                                    >
                                                        {Object.keys(ANIMATIC_STYLES).map(key => (
                                                            <option key={key} value={key}>{key.replace('-', ' ').toUpperCase()}</option>
                                                        ))}
                                                    </select>
                                                    <p className="text-[10px] text-indigo-400 mt-2 italic">
                                                        "{ANIMATIC_STYLES[animaticStyle as keyof typeof ANIMATIC_STYLES]}"
                                                    </p>
                                                </div>
                                            )}

                                            <div className="space-y-6">
                                                <div>
                                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Project Title</label>
                                                    <input 
                                                        className="w-full text-3xl font-black text-gray-900 border-b-2 border-gray-100 py-2 outline-none focus:border-[#9063CD] bg-transparent placeholder-gray-300" 
                                                        placeholder="Campaign Title" 
                                                        value={campaignTitle} 
                                                        onChange={(e) => setCampaignTitle(e.target.value)} 
                                                    />
                                                </div>
                                                <div className="relative">
                                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Target Brand</label>
                                                    <div className="relative">
                                                        <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                                                        <input 
                                                            className="w-full bg-gray-50 rounded-xl p-4 pl-12 font-bold text-gray-900 outline-none focus:ring-2 focus:ring-[#9063CD]" 
                                                            placeholder="Select a brand..." 
                                                            value={brandSearch} 
                                                            onFocus={() => setIsBrandDropdownOpen(true)}
                                                            onChange={(e) => { setBrandSearch(e.target.value); setIsBrandDropdownOpen(true); }}
                                                        />
                                                    </div>
                                                    {isBrandDropdownOpen && (
                                                        <div className="absolute top-full left-0 right-0 mt-2 bg-white shadow-xl rounded-xl z-30 max-h-48 overflow-y-auto border border-gray-100">
                                                            {brands.filter(b => b.brand_name.toLowerCase().includes(brandSearch.toLowerCase())).map(b => (
                                                                <button key={b.id} onClick={() => handleBrandSelect(b)} className="w-full text-left p-3 hover:bg-gray-50 font-bold text-sm text-gray-900">{b.brand_name}</button>
                                                            ))}
                                                        </div>
                                                    )}
                                                </div>
                                                {/* Cultural Context Input */}
                                                <div>
                                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 flex items-center gap-2"><GlobeAltIcon className="w-3 h-3"/> Cultural Context / Region</label>
                                                    <input 
                                                        className="w-full bg-gray-50 rounded-xl p-4 font-bold text-gray-900 outline-none focus:ring-2 focus:ring-[#9063CD]" 
                                                        placeholder="e.g. South Africa, India, Global, Urban Kenya..." 
                                                        value={contextSetting} 
                                                        onChange={(e) => setContextSetting(e.target.value)}
                                                    />
                                                    <p className="text-[9px] text-gray-400 mt-1 italic">Defines local accents, fashion, and environment cues for the AI.</p>
                                                </div>
                                            </div>
                                        </div>

                                        {/* Right Column: Creative Brief */}
                                        <div className="space-y-6 flex flex-col h-full">
                                            <div className="flex justify-between items-center">
                                                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Creative Brief / Script</label>
                                                <div className="flex bg-gray-100 p-1 rounded-lg">
                                                    <button onClick={() => setScriptMode('ai')} className={`px-3 py-1 rounded text-[10px] font-bold uppercase ${scriptMode === 'ai' ? 'bg-white shadow text-black' : 'text-gray-500'}`}>AI Co-Pilot</button>
                                                    <button onClick={() => setScriptMode('manual')} className={`px-3 py-1 rounded text-[10px] font-bold uppercase ${scriptMode === 'manual' ? 'bg-white shadow text-black' : 'text-gray-500'}`}>Manual Script</button>
                                                </div>
                                            </div>
                                            
                                            <div className="flex-1 relative">
                                                <textarea 
                                                    className="w-full h-full bg-gray-50 rounded-[2rem] p-6 font-medium text-gray-700 outline-none focus:ring-2 focus:ring-[#9063CD] resize-none" 
                                                    placeholder="Describe your concept or paste script here..." 
                                                    value={scriptText || coreIdea} 
                                                    onChange={(e) => scriptMode === 'manual' ? setScriptText(e.target.value) : setCoreIdea(e.target.value)} 
                                                />
                                                <button className="absolute top-4 right-6 text-xs font-bold text-[#9063CD] hover:underline flex items-center gap-1">
                                                    <UploadCloudIcon className="w-3 h-3"/> Upload Reference
                                                </button>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="flex justify-end pt-4">
                                        {scriptMode === 'ai' ? (
                                            <button onClick={handleGenerateScript} disabled={isGeneratingScript} className="w-full bg-indigo-50 text-indigo-700 hover:bg-indigo-100 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-none transition-all">
                                                {isGeneratingScript ? 'Writing...' : 'Draft Production Script'}
                                            </button>
                                        ) : (
                                            <button onClick={handleAnalyzeScript} disabled={!scriptText.trim()} className="w-full bg-black text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-gray-800 transition-all flex items-center justify-center gap-2">
                                                Analyze & Proceed to Assets <ArrowRightIcon className="w-4 h-4"/>
                                            </button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )}

                        {step === 'assets' && (
                            <div className="animate-fade-in-up space-y-8">
                                {/* ... (Keep existing ASSETS step UI) ... */}
                                <div className="flex justify-between items-end">
                                    <div><h1 className="text-4xl font-black text-gray-900 uppercase tracking-tighter">Project Assets</h1><p className="text-gray-500 font-medium">Curate visual elements for the scene composer.</p></div>
                                    <div className="flex gap-3">
                                        <button onClick={() => saveToDb(characters, locations, products)} disabled={isSavingAll} className="bg-white text-gray-700 border border-gray-200 px-6 py-4 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-gray-50 transition-all">
                                            {isSavingAll ? 'Saving...' : 'Save Draft'}
                                        </button>
                                        <button onClick={handleProceedToComposition} disabled={isMapping} className="bg-black text-white px-8 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-gray-800 transition-all shadow-lg">
                                            {isMapping ? 'Mixing Scenes (AI)...' : 'Proceed to Composition'} <ArrowRightIcon className="w-4 h-4"/>
                                        </button>
                                    </div>
                                </div>

                                <div className="flex gap-2 border-b border-gray-200">
                                    {['cast', 'locations', 'products'].map(t => (
                                        <button key={t} onClick={() => setAssetStepTab(t as any)} className={`px-6 py-3 font-bold text-xs uppercase tracking-widest border-b-2 transition-all ${assetStepTab === t ? 'border-[#9063CD] text-[#9063CD]' : 'border-transparent text-gray-400 hover:text-gray-600'}`}>{t}</button>
                                    ))}
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                    {assetStepTab === 'cast' && (
                                        <>
                                            {characters.map(char => (
                                                <div key={char.id} className="bg-white rounded-3xl border border-gray-200 p-6 flex flex-col gap-4 shadow-sm hover:shadow-md transition-all group relative">
                                                    <button onClick={() => handleDeleteAsset(char.id, 'character')} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><XMarkIcon className="w-4 h-4"/></button>
                                                    <div className="flex justify-between items-start">
                                                        <div><h3 className="font-black text-xl text-gray-900 leading-none">{char.name}</h3><span className="text-[10px] font-bold text-gray-400 uppercase">{char.role}</span></div>
                                                        {char.status === 'matched' || char.status === 'done' ? <CheckCircleIcon className="w-5 h-5 text-green-500"/> : <ArrowPathIcon className="w-5 h-5 text-orange-400 animate-pulse"/>}
                                                    </div>
                                                    <div className="aspect-square bg-gray-50 rounded-2xl overflow-hidden relative group/image">
                                                        {char.imageUrl ? <img src={char.imageUrl} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-gray-300"><UserIcon className="w-12 h-12"/></div>}
                                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/image:opacity-100 flex flex-col items-center justify-center gap-2 transition-opacity">
                                                            <button onClick={() => { setReplacingAsset({ id: char.id, type: 'character' }); setShowAssetBrowser(true); }} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100">Select Library</button>
                                                            <button onClick={() => fileInputRef.current?.click()} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100" onMouseEnter={() => { if (fileInputRef.current) fileInputRef.current.onchange = (e: any) => handleAssetUpload(e, 'character', char.id); }}>Upload</button>
                                                        </div>
                                                    </div>
                                                    
                                                    {/* Editable Prompt */}
                                                    <div className="px-1 mt-2">
                                                        <div className="flex justify-between items-center mb-1">
                                                            <label className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Visual Prompt</label>
                                                            <button 
                                                                onClick={() => handleEnhanceAssetPrompt(char.id, 'character')}
                                                                disabled={enhancingAsset?.id === char.id}
                                                                className="text-[9px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-2 py-0.5 rounded transition-colors"
                                                            >
                                                                {enhancingAsset?.id === char.id ? '...' : <><MagicWandIcon className="w-2 h-2"/> Enhance</>}
                                                            </button>
                                                        </div>
                                                        <textarea 
                                                            className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-[10px] font-medium text-gray-600 resize-none h-16 focus:ring-1 focus:ring-[#9063CD] outline-none leading-relaxed transition-colors focus:bg-white"
                                                            value={char.visual_prompt}
                                                            onChange={(e) => setCharacters(prev => prev.map(c => c.id === char.id ? { ...c, visual_prompt: e.target.value } : c))}
                                                        />
                                                    </div>

                                                    <button onClick={() => handleGenerateAsset('character', char.id, char.visual_prompt)} className="w-full py-3 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center justify-center gap-2">
                                                        <MagicWandIcon className="w-3 h-3"/> Generate Visual
                                                    </button>
                                                </div>
                                            ))}
                                            <button onClick={() => setCharacters([...characters, { id: crypto.randomUUID(), name: 'New Cast', role: 'Talent', description: '', visual_prompt: 'A person...', status: 'unassigned' }])} className="border-2 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center gap-2 text-gray-400 hover:border-[#9063CD] hover:text-[#9063CD] transition-all min-h-[300px]"><PlusIcon className="w-8 h-8"/><span className="font-bold text-xs uppercase tracking-widest">Add Character</span></button>
                                        </>
                                    )}

                                    {assetStepTab === 'locations' && (
                                        <>
                                            {locations.map(loc => (
                                                <div key={loc.id} className="bg-white rounded-3xl border border-gray-200 p-6 flex flex-col gap-4 shadow-sm hover:shadow-md transition-all group relative">
                                                    <button onClick={() => handleDeleteAsset(loc.id, 'setting')} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><XMarkIcon className="w-4 h-4"/></button>
                                                    <div className="flex justify-between items-start">
                                                        <div><h3 className="font-black text-xl text-gray-900 leading-none">{loc.name}</h3><span className="text-[10px] font-bold text-gray-400 uppercase">Location</span></div>
                                                        {loc.status === 'done' ? <CheckCircleIcon className="w-5 h-5 text-green-500"/> : <ArrowPathIcon className="w-5 h-5 text-orange-400"/>}
                                                    </div>
                                                    <div className="aspect-video bg-gray-50 rounded-2xl overflow-hidden relative group/image">
                                                        {loc.imageUrl ? <img src={loc.imageUrl} className="w-full h-full object-cover"/> : <div className="w-full h-full flex items-center justify-center text-gray-300"><MapPinIcon className="w-12 h-12"/></div>}
                                                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/image:opacity-100 flex flex-col items-center justify-center gap-2 transition-opacity">
                                                            <button onClick={() => { setReplacingAsset({ id: loc.id, type: 'setting' }); setShowAssetBrowser(true); }} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100">Select Library</button>
                                                            <button onClick={() => fileInputRef.current?.click()} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100" onMouseEnter={() => { if (fileInputRef.current) fileInputRef.current.onchange = (e: any) => handleAssetUpload(e, 'setting', loc.id); }}>Upload</button>
                                                        </div>
                                                    </div>

                                                    {/* Editable Prompt */}
                                                    <div className="px-1 mt-2">
                                                        <div className="flex justify-between items-center mb-1">
                                                            <label className="text-[9px] font-bold text-gray-400 uppercase tracking-wider">Visual Prompt</label>
                                                            <button 
                                                                onClick={() => handleEnhanceAssetPrompt(loc.id, 'setting')}
                                                                disabled={enhancingAsset?.id === loc.id}
                                                                className="text-[9px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-2 py-0.5 rounded transition-colors"
                                                            >
                                                                {enhancingAsset?.id === loc.id ? '...' : <><MagicWandIcon className="w-2 h-2"/> Enhance</>}
                                                            </button>
                                                        </div>
                                                        <textarea 
                                                            className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-[10px] font-medium text-gray-600 resize-none h-16 focus:ring-1 focus:ring-[#9063CD] outline-none leading-relaxed transition-colors focus:bg-white"
                                                            value={loc.visual_prompt || ''}
                                                            onChange={(e) => setLocations(prev => prev.map(l => l.id === loc.id ? { ...l, visual_prompt: e.target.value } : l))}
                                                        />
                                                    </div>

                                                    <button onClick={() => handleGenerateAsset('setting', loc.id, loc.visual_prompt || loc.description)} className="w-full py-3 bg-indigo-50 text-indigo-600 rounded-xl font-bold text-[10px] uppercase tracking-widest hover:bg-indigo-100 transition-all flex items-center justify-center gap-2">
                                                        <MagicWandIcon className="w-3 h-3"/> Generate Visual
                                                    </button>
                                                </div>
                                            ))}
                                            <button onClick={() => setLocations([...locations, { id: crypto.randomUUID(), name: 'New Location', description: 'Describe place...', visual_style: 'Cinematic', status: 'idle' }])} className="border-2 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center gap-2 text-gray-400 hover:border-[#9063CD] hover:text-[#9063CD] transition-all min-h-[250px]"><PlusIcon className="w-8 h-8"/><span className="font-bold text-xs uppercase tracking-widest">Add Location</span></button>
                                        </>
                                    )}

                                    {assetStepTab === 'products' && (
                                        <>
                                            {products.map(prod => {
                                                const img = typeof prod.image === 'string' ? prod.image : prod.image?.primary;
                                                return (
                                                    <div key={prod.id} className="bg-white rounded-3xl border border-gray-200 p-6 flex flex-col gap-4 shadow-sm hover:shadow-md transition-all group relative">
                                                        <button onClick={() => handleDeleteAsset(prod.id, 'product')} className="absolute top-4 right-4 text-gray-300 hover:text-red-500"><XMarkIcon className="w-4 h-4"/></button>
                                                        <div className="flex justify-between items-start">
                                                            {editingProductId === prod.id ? (
                                                                <input className="font-bold text-lg border-b border-gray-300 w-full" value={prod.product_name} onChange={(e) => setProducts(prev => prev.map(p => p.id === prod.id ? { ...p, product_name: e.target.value } : p))} />
                                                            ) : (
                                                                <div><h3 className="font-black text-xl text-gray-900 leading-none">{prod.product_name}</h3><span className="text-[10px] font-bold text-gray-400 uppercase">Product</span></div>
                                                            )}
                                                            <button onClick={() => setEditingProductId(editingProductId === prod.id ? null : prod.id)} className="text-gray-400 hover:text-indigo-600"><PencilSquareIcon className="w-4 h-4"/></button>
                                                        </div>
                                                        <div className="aspect-square bg-gray-50 rounded-2xl overflow-hidden relative group/image p-4 flex items-center justify-center">
                                                            {img ? <img src={img} className="max-w-full max-h-full object-contain"/> : <CubeIcon className="w-16 h-16 text-gray-200"/>}
                                                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/image:opacity-100 flex flex-col items-center justify-center gap-2 transition-opacity">
                                                                <button onClick={() => { setReplacingAsset({ id: prod.id, type: 'product' }); setShowAssetBrowser(true); }} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100">Select Library</button>
                                                                <button onClick={() => fileInputRef.current?.click()} className="bg-white text-black px-4 py-2 rounded-lg text-[10px] font-bold uppercase hover:bg-gray-100" onMouseEnter={() => { if (fileInputRef.current) fileInputRef.current.onchange = (e: any) => handleAssetUpload(e, 'product', prod.id); }}>Upload</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                            <button onClick={() => setProducts([...products, { id: crypto.randomUUID(), product_name: 'New SKU' }])} className="border-2 border-dashed border-gray-300 rounded-3xl flex flex-col items-center justify-center gap-2 text-gray-400 hover:border-[#9063CD] hover:text-[#9063CD] transition-all min-h-[250px]"><PlusIcon className="w-8 h-8"/><span className="font-bold text-xs uppercase tracking-widest">Add Product</span></button>
                                        </>
                                    )}
                                </div>
                            </div>
                        )}

                        {step === 'check' && (
                            <div className="animate-fade-in-up space-y-8">
                                <div className="flex justify-between items-end">
                                    <div><h1 className="text-4xl font-black text-gray-900 uppercase tracking-tighter">Scene Composition</h1><p className="text-gray-500 font-medium">Review and render your storyboard sequence.</p></div>
                                    <div className="flex gap-4">
                                        <button onClick={handleGenerateAllScenes} disabled={isBatchGenerating} className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-indigo-700 transition-all shadow-lg">
                                            {isBatchGenerating ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <SparklesIcon className="w-4 h-4"/>}
                                            {isBatchGenerating ? 'Batch Rendering...' : 'Render All Scenes'}
                                        </button>
                                        <button onClick={handleFinish} disabled={isSavingAll} className="bg-black text-white px-8 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center gap-2 hover:bg-gray-800 transition-all shadow-lg">
                                            {isSavingAll ? 'Saving...' : 'Finish & Export'} <ArrowRightIcon className="w-4 h-4"/>
                                        </button>
                                    </div>
                                </div>

                                <div className="grid grid-cols-1 gap-6 pb-20">
                                    {scenes.map((scene, idx) => {
                                        // Continuity: Default End Frame to Next Scene's Start Frame
                                        const nextScene = scenes[idx + 1];
                                        const displayScene = {
                                            ...scene,
                                            endImageUrl: scene.endImageUrl || nextScene?.imageUrl
                                        };

                                        return (
                                        <StoryboardSceneCard
                                            key={scene.id}
                                            scene={displayScene}
                                            index={idx}
                                            isLast={idx === scenes.length - 1}
                                            onGenerate={generateSingleSceneImage}
                                            onUpdatePrompt={(id, val) => setScenes(prev => prev.map(s => s.id === id ? { ...s, editablePrompt: val } : s))}
                                            onToggleDebug={(id) => setScenes(prev => prev.map(s => s.id === id ? { ...s, showDebug: !s.showDebug } : s))}
                                            onSplit={handleSplitScene}
                                            onMerge={handleMergeScene}
                                            onDelete={(id) => setScenes(prev => prev.filter(s => s.id !== id))}
                                            onAddAsset={(id, type) => { setActiveAssetSlot({ sceneId: id, type }); setShowAssetBrowser(true); }}
                                            onRemoveAsset={handleRemoveAsset}
                                        />
                                    )})}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <Modal isOpen={showAssetBrowser} onClose={() => setShowAssetBrowser(false)} title="Select Asset from Library">
                <div className="h-[75vh] -m-6">
                    <AssetStudio onAssetsSelected={handleAssetLibrarySelect} />
                </div>
            </Modal>
        </div>
    );
};

export default StoryboardGenerator;
