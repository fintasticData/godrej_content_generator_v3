
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { SparklesIcon, ExclamationTriangleIcon, CheckCircleIcon, PhotoIcon, KeyIcon, BoltIcon, MagicWandIcon } from './icons';

type SystemTab = 'requirements' | 'database' | 'ai' | 'frontend' | 'diagnostics';

const SystemInfo: React.FC = () => {
    const [activeTab, setActiveTab] = useState<SystemTab>('requirements');

    // Diagnostic State
    const [testKey, setTestKey] = useState('');
    const [testPrompt, setTestPrompt] = useState('A futuristic robot holding a neon sign that says "GODREJ"');
    const [testStatus, setTestStatus] = useState<'idle' | 'running' | 'success' | 'error'>('idle');
    const [testResult, setTestResult] = useState<string | null>(null);
    const [testLog, setTestLog] = useState<string>('');

    const TabButton: React.FC<{ tab: SystemTab; label: string; }> = ({ tab, label }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-5 py-2.5 text-sm font-medium rounded-lg transition-colors ${
                activeTab === tab
                ? 'bg-[#9063CD] text-white shadow-md'
                : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
            }`}
        >
            {label}
        </button>
    );
    
    const Section: React.FC<{title: string, children: React.ReactNode}> = ({title, children}) => (
        <div className="mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-3 border-b-2 border-[#9063CD] pb-2">{title}</h3>
            <div className="text-gray-700 leading-relaxed space-y-4">
              {children}
            </div>
        </div>
    );
    
    const Code: React.FC<{children: React.ReactNode}> = ({children}) => (
      <code className="bg-gray-100 text-[#9063CD] px-2 py-1 rounded-md text-sm font-mono border border-gray-200">{children}</code>
    );

    const maskKey = (key?: string) => {
        if (!key) return 'Not Set';
        if (key.length < 10) return '********';
        return `${key.slice(0, 4)}...${key.slice(-4)}`;
    };

    const runImageGenTest = async (specificSource?: 'G' | 'X') => {
        setTestStatus('running');
        setTestLog('Initializing GoogleGenAI client...');
        setTestResult(null);

        try {
            let apiKeyToUse = testKey.trim();
            let sourceLabel = 'Manual Input';

            if (!apiKeyToUse) {
                if (specificSource === 'G') {
                    apiKeyToUse = process.env.API_KEY_G || '';
                    sourceLabel = 'API_KEY_G (Env)';
                } else if (specificSource === 'X') {
                    apiKeyToUse = process.env.API_KEY || '';
                    sourceLabel = 'API_KEY (Env)';
                } else {
                    if (process.env.API_KEY_G) {
                        apiKeyToUse = process.env.API_KEY_G;
                        sourceLabel = 'API_KEY_G (Default)';
                    } else {
                        apiKeyToUse = process.env.API_KEY || '';
                        sourceLabel = 'API_KEY (Fallback)';
                    }
                }
            }

            setTestLog(prev => prev + `\nSelected Source: ${sourceLabel}`);
            
            if (!apiKeyToUse) {
                throw new Error(`No API Key found for ${sourceLabel}. Check environment variables.`);
            }

            const ai = new GoogleGenAI({ apiKey: apiKeyToUse });
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash-image',
                contents: { parts: [{ text: testPrompt }] }
            });

            if (response.candidates?.[0]?.content?.parts) {
                for (const part of response.candidates[0].content.parts) {
                    if (part.inlineData) {
                        setTestResult(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
                        setTestStatus('success');
                        setTestLog(prev => prev + '\nSuccess! Image data extracted.');
                        return;
                    }
                }
            }
            throw new Error("No image data found in response.");
        } catch (e: any) {
            setTestStatus('error');
            setTestLog(prev => prev + `\nERROR: ${e.message}`);
        }
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'requirements':
                return (
                    <>
                        <Section title="Environment and Location Mapping">
                            <p>The platform utilizes the <Code>dng_locations</Code> repository to manage environmental continuity.</p>
                            <ul className="list-decimal list-inside space-y-2 pl-4">
                                <li><strong>Global Consistency:</strong> Locations are defined by City/Province to ensure relevance.</li>
                                <li><strong>Prompt Engineering:</strong> Reusable visual descriptor blocks (JSONB) drive renderers.</li>
                            </ul>
                        </Section>
                        <Section title="Character Wardrobe Architecture">
                            <p>Talent management now utilizes a dual-path JSON registry:</p>
                            <ul className="list-disc list-inside space-y-2 pl-4">
                                <li><strong>Registry:</strong> Stored in <Code>character_items</Code> as a structured asset array.</li>
                                <li><strong>History:</strong> Stored in <Code>image_urls_jsonb</Code> for full visual audit trails.</li>
                                <li><strong>Types:</strong> Support for Outfits, Accessories, Bags, Watches, and Belts.</li>
                            </ul>
                        </Section>
                    </>
                );
            case 'database':
                return (
                    <>
                        <Section title="Location Persistence: dng_locations">
                            <div className="space-y-4 font-mono text-sm bg-gray-50 p-4 rounded-lg border border-gray-200">
                                <p><strong className="text-[#9063CD]">id (bigserial)</strong>: Master PK.</p>
                                <p><Code>prompt (jsonb)</Code>: Visual, lighting, and atmosphere tokens.</p>
                            </div>
                        </Section>
                        <Section title="Character Persistence: dng1_characters">
                            <div className="space-y-4 font-mono text-sm bg-gray-50 p-4 rounded-lg border border-gray-200">
                                <p><strong className="text-[#9063CD]">character_items (jsonb)</strong>: Asset Registry (Outfits, Accessories).</p>
                                <p><Code>image_urls_jsonb</Code>: Visual history array.</p>
                                <p><Code>character_jsonb</Code>: Behavioral and psychological matrices.</p>
                            </div>
                        </Section>
                    </>
                );
            case 'ai':
                return (
                    <>
                        <Section title="Visual Generation Engine (Image Models)">
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                               <div className="bg-white p-6 rounded-2xl border border-indigo-100 shadow-sm">
                                   <div className="flex items-center gap-2 mb-4">
                                       <BoltIcon className="w-5 h-5 text-indigo-500"/>
                                       <h4 className="font-black uppercase tracking-widest text-sm">Nano Banana</h4>
                                   </div>
                                   <p className="text-[10px] font-mono text-gray-400 mb-2">gemini-2.5-flash-image</p>
                                   <p className="text-sm text-gray-600 mb-4">Optimized for high-speed, instruction-based image editing.</p>
                                   <ul className="text-xs text-gray-500 space-y-1 list-disc pl-4">
                                       <li>Outfit Creation (Text-to-Outfit)</li>
                                       <li>Style Transfer (Edit Image)</li>
                                       <li>Wardrobe Iterations</li>
                                   </ul>
                               </div>
                               <div className="bg-white p-6 rounded-2xl border border-purple-100 shadow-sm">
                                   <div className="flex items-center gap-2 mb-4">
                                       <MagicWandIcon className="w-5 h-5 text-[#9063CD]"/>
                                       <h4 className="font-black uppercase tracking-widest text-sm">Nano Banana Pro</h4>
                                   </div>
                                   <p className="text-[10px] font-mono text-gray-400 mb-2">gemini-3-pro-image-preview</p>
                                   <p className="text-sm text-gray-600 mb-4">High-fidelity composition, identity retention, and complex rendering.</p>
                                   <ul className="text-xs text-gray-500 space-y-1 list-disc pl-4">
                                       <li>Product Showcase / Case Views</li>
                                       <li>Hairstyle Mapping (Face Swap)</li>
                                       <li>Master Set Renders</li>
                                   </ul>
                               </div>
                           </div>
                        </Section>
                        <Section title="Cognitive Engines">
                           <ul className="list-disc list-inside space-y-2 pl-4">
                                <li><strong>Gemini 3 Flash:</strong> Psychometric profiling and marketing blurb generation.</li>
                                <li><strong>Gemini 3 Pro:</strong> Creative scriptwriting and cross-scene continuity analysis.</li>
                           </ul>
                        </Section>
                    </>
                );
            case 'frontend':
                 return (
                    <>
                        <Section title="Component Architecture">
                           <p>Integrated "Product Casing" UX for accessory isolation using the <Code>character_items</Code> registry.</p>
                        </Section>
                        <Section title="Storyboard Logic">
                            <p>Dual-frame synchronization ensures <strong>Continuity Anchors</strong> between A/B frames before video commit.</p>
                        </Section>
                    </>
                );
            case 'diagnostics':
                return (
                    <>
                        <Section title="Environment Configuration">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                                <div className={`p-4 rounded-xl border shadow-sm transition-all ${process.env.API_KEY_G ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                                    <div className="flex items-center justify-between mb-2">
                                        <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-500">API_KEY_G</h4>
                                        <span className="text-[9px] font-bold bg-white px-2 py-0.5 rounded text-gray-400 border border-gray-100">Priority 1</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        {process.env.API_KEY_G ? <CheckCircleIcon className="w-5 h-5 text-green-500"/> : <ExclamationTriangleIcon className="w-5 h-5 text-gray-300"/>}
                                        <span className={`font-mono text-sm font-bold ${process.env.API_KEY_G ? 'text-green-800' : 'text-gray-400'}`}>
                                            {maskKey(process.env.API_KEY_G)}
                                        </span>
                                    </div>
                                </div>
                                <div className={`p-4 rounded-xl border shadow-sm transition-all ${process.env.API_KEY ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                                    <div className="flex items-center justify-between mb-2">
                                        <h4 className="text-[10px] font-black uppercase tracking-widest text-gray-500">API_KEY</h4>
                                        <span className="text-[9px] font-bold bg-white px-2 py-0.5 rounded text-gray-400 border border-gray-100">Priority 2</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        {process.env.API_KEY ? <CheckCircleIcon className="w-5 h-5 text-green-500"/> : <ExclamationTriangleIcon className="w-5 h-5 text-gray-300"/>}
                                        <span className={`font-mono text-sm font-bold ${process.env.API_KEY ? 'text-green-800' : 'text-gray-400'}`}>
                                            {maskKey(process.env.API_KEY)}
                                        </span>
                                    </div>
                                </div>
                                <div className="p-4 rounded-xl border bg-indigo-50 border-indigo-200 shadow-sm">
                                    <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-500 mb-2">System Status</h4>
                                    <div className="flex items-center gap-2">
                                        <div className={`w-3 h-3 rounded-full ${process.env.API_KEY_G || process.env.API_KEY ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                                        <span className="font-bold text-sm text-indigo-900">
                                            {process.env.API_KEY_G ? 'Using API_KEY_G' : (process.env.API_KEY ? 'Using API_KEY' : 'NO KEY DETECTED')}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </Section>
                        <Section title="Connection Test">
                            <div className="bg-gray-50 border border-gray-200 rounded-2xl p-6 space-y-6">
                                <input type="password" className="w-full p-3 border border-gray-300 rounded-lg text-sm" placeholder="Optional Override Key" value={testKey} onChange={(e) => setTestKey(e.target.value)} />
                                <input type="text" className="w-full p-3 border border-gray-300 rounded-lg text-sm" value={testPrompt} onChange={(e) => setTestPrompt(e.target.value)} />
                                <div className="flex gap-4">
                                    <button onClick={() => runImageGenTest('G')} disabled={testStatus === 'running'} className="px-6 py-3 bg-green-600 text-white font-bold rounded-lg text-xs uppercase tracking-widest shadow-md">Test API_KEY_G</button>
                                    <button onClick={() => runImageGenTest('X')} disabled={testStatus === 'running'} className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg text-xs uppercase tracking-widest shadow-md">Test API_KEY</button>
                                </div>
                                <div className="bg-gray-900 text-green-400 font-mono text-xs p-4 rounded-lg h-48 overflow-y-auto whitespace-pre-wrap shadow-inner">
                                    {testLog || '> Ready to test...'}
                                </div>
                                {testResult && (
                                    <div className="mt-4 border-t border-gray-200 pt-4 animate-fade-in-up">
                                        <h4 className="text-sm font-bold text-gray-900 mb-2">Test Result:</h4>
                                        <img src={testResult} className="w-64 h-64 bg-gray-200 rounded-lg overflow-hidden border border-gray-300 shadow-sm" />
                                    </div>
                                )}
                            </div>
                        </Section>
                    </>
                );
            default: return null;
        }
    };
    
    return (
        <div className="w-full h-full flex flex-col gap-6 p-8 bg-white rounded-lg border border-gray-200 shadow-lg overflow-y-auto no-scrollbar">
            <header>
                <h2 className="text-3xl font-bold text-gray-900 mb-2 uppercase tracking-tighter">Production System Specs</h2>
                <p className="text-gray-500 font-medium uppercase tracking-widest text-[10px]">Technical documentation for the Godrej Content Platform.</p>
            </header>
            <nav className="flex items-center gap-2 flex-wrap">
                <TabButton tab="requirements" label="Core Specs" />
                <TabButton tab="database" label="Persistence" />
                <TabButton tab="ai" label="AI Engines" />
                <TabButton tab="frontend" label="UX Patterns" />
                <TabButton tab="diagnostics" label="Diagnostics" />
            </nav>
            <main className="flex-grow mt-4 border-t border-gray-200 pt-6 no-scrollbar">
                {renderContent()}
            </main>
        </div>
    );
};

export default SystemInfo;
