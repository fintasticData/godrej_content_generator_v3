/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, Type, Schema, FunctionDeclaration, Tool, GenerateContentResponse, Part } from "@google/genai";
import { AspectRatio, VeoModel, Resolution, GenerationMode, ImageModel } from '../types';

const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const ANIMATIC_STYLES = {
  'cinematic-previs': "High contrast, storyboard sketch, cinematic lighting, rough shading",
  'anime': "Anime style storyboard, clean lines, dynamic angles",
  'watercolor': "Watercolor storyboard, soft colors, mood focus",
  'pencil': "Pencil sketch, rough, loose lines"
};

// --- Text & Logic Utilities ---

export const brainstormContentIdeas = async (context: string, topic: string, count: number, channel: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate ${count} content ideas for ${channel}. Context: ${context}. Topic: ${topic}. 
        
        CRITICAL: You MUST return a JSON array. Each item MUST include a 'video_prompt' object.
        
        Return a JSON array of objects where each object contains:
        - day: string
        - caption: string
        - visual_prompt: string (for image generation)
        - video_prompt: object (Structured video generation prompt) containing:
            - subject: string (Detailed description)
            - action: string (Specific movement)
            - camera: string (Angles and moves)
            - lighting: string
            - atmosphere: string
            - full_prompt: string (Elaborate, detailed paragraph for video AI, combining all elements)`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const analyzeImage = async (base64: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            { inlineData: { mimeType: 'image/png', data: base64 } },
            { text: "Analyze this image. Return a JSON object with: description (string), tags (array of strings), colors (array of hex strings)." }
        ],
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '{}');
};

export const generateAssetProfile = async (concept: string, type: 'character'|'setting'|'product') => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a detailed profile for a ${type} based on this concept: "${concept}".
        Return JSON with:
        - name: string
        - backstory: string
        - details: array of strings
        - visual_prompt: string (highly detailed description for image generation)`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '{}');
};

export const enhanceVisualPrompt = async (prompt: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Enhance this visual prompt for a text-to-image model. Make it more descriptive, adding lighting, texture, and style details. Keep it under 50 words. Prompt: "${prompt}"`,
    });
    return response.text || prompt;
};

export const generateInsights = async (prompt: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide 3 creative insights or angles for this concept: "${prompt}". Return as JSON array of strings.`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const enhanceSceneDescription = async (prompt: string) => {
    return enhanceVisualPrompt(prompt);
};

export const generateTransitionPrompt = async (startBase64: string, endBase64: string | null, originalPrompt: string) => {
    const parts: Part[] = [{ inlineData: { mimeType: 'image/png', data: startBase64 } }];
    if (endBase64) parts.push({ inlineData: { mimeType: 'image/png', data: endBase64 } });
    parts.push({ text: `Analyze these frames (Start and optional End). Describe the motion or transition that happens between them to match this context: "${originalPrompt}". Return a concise video generation prompt describing the action.` });

    const response = await getAi().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: parts
    });
    return response.text || originalPrompt;
};

export const refineImagePrompt = async (prompt: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Refine this image prompt for better results: "${prompt}". Return JSON with { improved_prompt: string, explanation: string, style_notes: string }.`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '{}');
};

export const generateScriptFromBrief = async (brief: string, title: string, format: string, duration: number, context: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Write a video script for "${title}". Format: ${format}. Duration: approx ${duration} scenes. Cultural Context: ${context}. Brief: ${brief}.
        Output ONLY the script text, formatted with SCENE headers and descriptions.`,
    });
    return response.text || '';
};

export const extractCharactersAndScenes = async (script: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Analyze this script. Extract characters, locations, and scenes.
        Return JSON object:
        {
            "characters": [{ "name": string, "description": string, "role": string }],
            "locations": [{ "name": string, "description": string, "visual_style": string }],
            "scenes": [{ "scene_number": number, "description": string, "visual_prompt_start": string }]
        }
        Script:
        ${script}`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '{}');
};

export const mapAssetsToScenes = async (scenes: any[], characters: any[], locations: any[], products: any[]) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Map the provided assets to the scenes based on the scene descriptions.
        
        Scenes: ${JSON.stringify(scenes.map(s => ({ id: s.id, desc: s.description })))}
        Characters: ${JSON.stringify(characters.map(c => ({ id: c.id, name: c.name })))}
        Locations: ${JSON.stringify(locations.map(l => ({ id: l.id, name: l.name })))}
        Products: ${JSON.stringify(products.map(p => ({ id: p.id, name: p.product_name })))}
        
        Return JSON array of objects: { scene_id: string, character_ids: string[], location_id: string, product_id: string }.
        If no fit, leave ids null or empty array.`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const brainstormBrand = async (input: string) => {
    // Legacy placeholder, can be removed or aliased
    return generateAssetProfile(input, 'product'); 
}

export const researchBrandWithGoogle = async (query: string) => {
    // Uses Google Search Grounding
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Research the brand "${query}". Provide a detailed brand identity profile including:
        - brand_essence (persona, purpose, core_values)
        - visual_identity (logo_description, typography, color_palette with hex)
        - market_positioning (target_audience, usp)
        - origin (country)
        Return valid JSON matching the structure.`,
        config: { 
            tools: [{ googleSearch: {} }],
            responseMimeType: 'application/json'
        }
    });
    return JSON.parse(response.text || '{}');
};

export const brainstormInfluencer = async (concept: string) => generateAssetProfile(concept, 'character');

export const generateCharacterBio = async (name: string, role: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Write a compelling 2-paragraph bio for a character named ${name}, who is a ${role}.`,
    });
    return response.text || '';
};

export const generateProductBlurb = async (name: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Write a short, catchy marketing blurb for a product named ${name}.`,
    });
    return response.text || '';
};

export const brainstormProductShots = async (productName: string, insight: string, mood: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate 4 distinct product photography concepts for "${productName}" (${insight}). Mood: ${mood}.
        Return JSON array of objects: { type: string (e.g. Hero, Lifestyle), visual_prompt: string }`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const generateQuickClipIdea = async (assets: any, type: 'creative' | 'trending') => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate a video concept for a short social media clip. 
        Type: ${type}. Assets available: ${JSON.stringify(assets)}.
        Return JSON: { prompt: string (video generation prompt), sources: string[] (urls of trend sources if any) }`,
        config: { 
            responseMimeType: 'application/json',
            tools: type === 'trending' ? [{ googleSearch: {} }] : undefined
        }
    });
    return JSON.parse(response.text || '{}');
};

export const analyzeAssetAttributes = async (base64: string, type: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            { inlineData: { mimeType: 'image/png', data: base64 } },
            { text: `Describe the visual attributes of this ${type} for use in a video generation prompt. Focus on appearance, colors, and style. Keep it concise.` }
        ],
    });
    return response.text || '';
};

export const analyzeHairReference = async (base64: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
            { inlineData: { mimeType: 'image/png', data: base64 } },
            { text: "Analyze the hairstyle in this image. Describe texture, color, length, and style keywords. Return markdown." }
        ],
    });
    return response.text || '';
};

export const brainstormItemRange = async (topic: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Brainstorm a fashion/product collection based on "${topic}". 
        Return JSON array of 5 items: { name: string, type: string, isolation_prompt: string, styling_injection: string }`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const brainstormDarlingTrends = async (vibe: string, products: string[], brandVoice: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Generate 4 trend concepts for Darling Hair. Vibe: ${vibe}. Available Products: ${products.join(', ')}. Brand Voice: ${brandVoice}.
        Return JSON array: { style_name: string, product_used: string, description: string, visual_prompt: string }`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const brainstormLookbook = async (context: string, theme: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Generate 4 distinct fashion looks for a character lookbook. Context: ${context}. Theme: ${theme}.
        Return JSON array: { name: string, prompt: string }`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const analyzeScriptToShots = async (script: string, format: string, count: number) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Analyze this script and break it down into a shot list. Format: ${format}. Max shots: ${count}.
        Return JSON array of objects: { order: number, camera: string, movement: string, subject: string, action: string, setting: string, lighting: string, duration: number }
        Script: ${script}`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

export const researchFashionTrends = async (occasion: string, location: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Research current fashion trends for ${occasion} in ${location}. 
        Return JSON array of 3 top trends: { name: string, description: string, type: string (outfit/accessory) }`,
        config: { 
            tools: [{ googleSearch: {} }],
            responseMimeType: 'application/json'
        }
    });
    return JSON.parse(response.text || '[]');
};

export const refineFashionTrends = async (items: any[], feedback: string, context: string) => {
    const response = await getAi().models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Refine these fashion items based on feedback: "${feedback}". Context: ${context}.
        Current Items: ${JSON.stringify(items)}.
        Return updated JSON array of items.`,
        config: { responseMimeType: 'application/json' }
    });
    return JSON.parse(response.text || '[]');
};

// --- Image Generation Utilities ---

// Generic Image Generation (Router)
export const generateImage = async (
    prompt: string, 
    aspectRatio: AspectRatio, 
    references?: { character?: string, product?: string, setting?: string, logo?: string, style?: string }, 
    stylePrompt?: string,
    modelOverride?: string
) => {
    const ai = getAi();
    // Default to Nano Banana (Flash Image) unless overriden or specific needs
    const model = modelOverride || ImageModel.NANO_BANANA;
    
    // Convert Aspect Ratio enum to string "1:1", "16:9", etc.
    const arString = aspectRatio === AspectRatio.SQUARE ? '1:1' : aspectRatio === AspectRatio.LANDSCAPE ? '16:9' : '9:16';

    const parts: Part[] = [{ text: prompt }];
    if (stylePrompt) parts.push({ text: `Style: ${stylePrompt}` });

    // Add references as inline data
    if (references) {
        if (references.character) parts.push({ inlineData: { mimeType: 'image/png', data: references.character } });
        if (references.product) parts.push({ inlineData: { mimeType: 'image/png', data: references.product } });
        if (references.setting) parts.push({ inlineData: { mimeType: 'image/png', data: references.setting } });
        if (references.logo) parts.push({ inlineData: { mimeType: 'image/png', data: references.logo } });
        if (references.style) parts.push({ inlineData: { mimeType: 'image/png', data: references.style } });
    }

    const response = await ai.models.generateContent({
        model: model,
        contents: { parts },
        config: {
            imageConfig: {
                aspectRatio: arString,
                imageSize: "1K" // Default
            }
        }
    });

    // Extract image from response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return {
                base64: part.inlineData.data,
                mimeType: part.inlineData.mimeType
            };
        }
    }
    throw new Error("No image generated");
};

// Explicit Imagen Call (Higher Quality / Different Model)
export const generateImagenImage = async (prompt: string, aspectRatio: string) => {
    // FIX: Using Imagen 4 as requested.
    const ai = getAi();
    const model = ImageModel.IMAGEN_4; // 'imagen-4.0-generate-001'
    
    // Using standard AspectRatio strings for Gemini Image
    const arString = aspectRatio === '1:1' ? '1:1' : aspectRatio === '9:16' ? '9:16' : '16:9';

    const response = await ai.models.generateImages({
        model: model,
        prompt: prompt,
        config: {
            numberOfImages: 1,
            aspectRatio: arString,
            outputMimeType: 'image/jpeg'
        }
    });
    
    const imageBytes = response.generatedImages?.[0]?.image?.imageBytes;
    if (imageBytes) {
        return { base64: imageBytes, mimeType: 'image/jpeg' };
    }
    throw new Error("Imagen generation failed");
};

export const editImage = async (
    baseImageBase64: string, 
    prompt: string, 
    refImageBase64?: string, 
    aspectRatio?: AspectRatio,
    model: string = ImageModel.NANO_BANANA
) => {
    const ai = getAi();
    const parts: Part[] = [
        { inlineData: { mimeType: 'image/png', data: baseImageBase64 } },
        { text: prompt }
    ];
    
    if (refImageBase64) {
        parts.push({ inlineData: { mimeType: 'image/png', data: refImageBase64 } });
    }

    const arString = aspectRatio === AspectRatio.LANDSCAPE ? '16:9' : aspectRatio === AspectRatio.PORTRAIT ? '9:16' : '1:1';

    const response = await ai.models.generateContent({
        model: model,
        contents: { parts },
        config: {
            imageConfig: { aspectRatio: arString }
        }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return {
                base64: part.inlineData.data,
                mimeType: part.inlineData.mimeType
            };
        }
    }
    throw new Error("Image edit failed");
};

export const generateFashionItem = async (description: string) => {
    return generateImagenImage(`Fashion Product Photography: ${description}. Isolated on white background. 8k resolution.`, '1:1');
};

export const generateStoryboardFrame = async (shot: any, style: string, ratio: AspectRatio, refs?: any) => {
    let prompt = `Storyboard Frame: ${shot.action}. Camera: ${shot.camera}. Style: ${style}.`;
    if (style === 'photoreal') prompt += " Photorealistic, cinematic lighting.";
    else if (style === 'sketch') prompt += " Black and white loose sketch.";
    
    // Only use Nano Banana Pro for complex photoreal shots to combine references, otherwise Nano Banana
    const model = style === 'photoreal' ? ImageModel.NANO_BANANA_PRO : ImageModel.NANO_BANANA;
    
    const result = await generateImage(prompt, ratio, refs, undefined, model);
    return result.base64;
};

export const mapHairstyle = async (charB64: string, styleB64: string, maskB64?: string, opts?: any) => {
    const prompt = `Change hairstyle to match reference. ${opts?.stylePreset || ''}. 
    ${opts?.matchPose ? 'Match pose.' : ''} 
    ${opts?.retainOutfit ? 'Keep outfit.' : ''} 
    ${opts?.retainBackground ? 'Keep background.' : ''}`;
    
    return editImage(charB64, prompt, styleB64, opts?.aspectRatio, ImageModel.NANO_BANANA);
};

export const generateDarlingLook = async (base64: string, description: string, count: number) => {
    // Loop for count, using generateImage (Nano Banana)
    const results = [];
    for(let i=0; i<count; i++) {
        try {
            const res = await editImage(base64, `Apply Darling Hair Look: ${description}. Photorealistic.`, undefined, AspectRatio.PORTRAIT);
            results.push(res.base64);
        } catch(e) { console.error(e); }
    }
    return results;
};

// --- Video Generation (Veo) ---

export const generateVideo = async (params: any) => {
    const ai = getAi();
    // Default config based on params
    const model = params.model || VeoModel.VEO_FAST;
    const ar = params.aspectRatio === AspectRatio.LANDSCAPE ? '16:9' : '9:16';
    const res = params.resolution || Resolution.P720;

    // Construct request
    let request: any = {
        model,
        prompt: params.prompt,
        config: {
            numberOfVideos: 1,
            resolution: res,
            aspectRatio: ar
        }
    };

    // Add inputs
    if (params.startFrame) {
        request.image = {
            imageBytes: params.startFrame.base64,
            mimeType: params.startFrame.file.type || 'image/png'
        };
    }
    
    if (params.endFrame) {
        request.config.lastFrame = {
            imageBytes: params.endFrame.base64,
            mimeType: params.endFrame.file.type || 'image/png'
        };
    }

    // Handle reference images if mode is ingredients/references
    if (params.mode === GenerationMode.REFERENCES_TO_VIDEO && params.referenceImages?.length > 0) {
        request.model = VeoModel.VEO;
        const refs = params.referenceImages.map((ref: any) => ({
            image: { imageBytes: ref.base64, mimeType: ref.file.type },
            referenceType: 'ASSET' // VideoGenerationReferenceType.ASSET
        }));
        request.config.referenceImages = refs;
    }

    let operation: any = await ai.models.generateVideos(request);

    // Poll
    while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 5000));
        operation = await ai.operations.getVideosOperation({ operation });
    }

    if (operation.error) throw new Error(operation.error.message);

    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    if (typeof downloadLink !== 'string') throw new Error("No video URI");

    // Fetch video blob
    const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
    const blob = await response.blob();

    return { blob, response: operation.response };
};

// --- Chat Sessions ---

export const startChatSession = () => {
    const ai = getAi();
    return ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
            systemInstruction: "You are an AI Creative Assistant. Help generate ideas for content, characters, and campaigns. You can use tools to generate images.",
            tools: [{ 
                functionDeclarations: [{
                    name: 'generate_image',
                    description: 'Generate an image based on a prompt.',
                    parameters: {
                        type: Type.OBJECT,
                        properties: {
                            prompt: { type: Type.STRING, description: 'The visual prompt.' },
                            asset_type: { type: Type.STRING, description: 'character, setting, or product' }
                        },
                        required: ['prompt']
                    }
                }] 
            }]
        }
    });
};

export const startDarlingStylistSession = () => {
    const ai = getAi();
    return ai.chats.create({
        model: 'gemini-3-flash-preview',
        config: {
            systemInstruction: "You are the Darling Hair Stylist AI. Expert in African hairstyles, weaves, braids (Jozi, Abuja, SuperStar). Consult the user and recommend styles. Output JSON style cards when a look is decided.",
        }
    });
};

// --- Logic Placeholders ---

export const constructStitchPayload = (adId: string, title: string, scenes: any[], watermark: string, w: number, h: number) => {
    return {
        project_id: adId,
        title: title,
        resolution: { width: w, height: h },
        watermark_url: watermark,
        timeline: scenes.map(s => ({
            id: s.id,
            video_url: s.videoUrl,
            duration: s.duration || 5,
            transition: s.scene_data?.transition
        }))
    };
};

export const stitchProject = async (adId: string, title: string, scenes: any[], watermark: string, w: number, h: number) => {
    // This would typically call a Cloud Function or backend service
    console.log("Stitching project...", { adId, title, scenes, watermark });
    // Simulate delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    return true;
};