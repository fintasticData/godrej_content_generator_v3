/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AudioTask, AudioTaskStatus, AudioTaskType } from "../types";

// The unified compute engine backend
const UG_BACKEND_URL = 'https://ubiquitous-garbanzo-cloudrun-590056908332.europe-west1.run.app';

// --- API Interactions ---

export const createMusicTask = async (
    prompt: string,
    genre: string,
    duration: number
): Promise<string> => {
    try {
        const response = await fetch(`${UG_BACKEND_URL}/musicgpt/generate-music`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, genre, duration }),
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Backend Error (${response.status}): ${errorText}`);
        }
        
        const data = await response.json();
        return data.task_id;
    } catch (e) {
        console.error("Music generation request failed:", e);
        throw e;
    }
};

export const createCoverTask = async (
    audioUrl: string,
    voiceId: string,
    pitch: number
): Promise<string> => {
    try {
        const response = await fetch(`${UG_BACKEND_URL}/musicgpt/cover-song`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ audio_url: audioUrl, voice_id: voiceId, pitch }),
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Backend Error (${response.status}): ${errorText}`);
        }

        const data = await response.json();
        return data.task_id;
    } catch (e) {
        console.error("Cover song request failed:", e);
        throw e;
    }
};

export const createSFXTask = async (
    prompt: string,
    category: string
): Promise<string> => {
    try {
        const response = await fetch(`${UG_BACKEND_URL}/musicgpt/generate-sfx`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt, category }),
        });

        if (!response.ok) {
             const errorText = await response.text();
             throw new Error(`Backend Error (${response.status}): ${errorText}`);
        }

        const data = await response.json();
        return data.task_id;
    } catch (e) {
        console.error("SFX generation request failed:", e);
        throw e;
    }
};

// --- Polling Logic ---

export const pollTaskStatus = async (taskId: string): Promise<AudioTask> => {
    try {
        const response = await fetch(`${UG_BACKEND_URL}/musicgpt/status/${taskId}`);
        if (!response.ok) {
             const errorText = await response.text();
             throw new Error(`Status Check Error (${response.status}): ${errorText}`);
        }
        return await response.json();
    } catch (e) {
        console.error(`Polling failed for task ${taskId}:`, e);
        throw e;
    }
};

export const downloadAudioAsBlob = async (audioUrl: string): Promise<Blob> => {
    try {
        const response = await fetch(audioUrl);
        if (!response.ok) throw new Error(`Failed to download audio: ${response.statusText}`);
        return await response.blob();
    } catch (e) {
        console.error("Audio download failed:", e);
        throw e; 
    }
}