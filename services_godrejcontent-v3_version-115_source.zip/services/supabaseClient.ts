
// ... existing imports
import { createClient } from '@supabase/supabase-js';
import { DynamicAsset, Product, BrandIdentity, CalendarEvent, Job, ContentItem, GenerationJob, SceneSchedule, Location, GaiHairstyle } from '../types';

const supabaseUrl = 'https://nrxakqdgbomnfftvoaqy.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5yeGFrcWRnYm9tbmZmdHZvYXF5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI0NjM0NjEsImV4cCI6MjA2ODAzOTQ2MX0.038H5UnkRh7d5SvgE0ZjNl3AYHioW64mfuOxV6IN2t8';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const uploadBlob = async (blob: Blob, fileName: string, folder: string = 'godrej/generated'): Promise<string | null> => {
// ... existing uploadBlob code
  try {
    const filePath = `${folder}/${fileName}`;
    const { error: uploadError } = await supabase.storage
      .from('RetailData')
      .upload(filePath, blob, {
        upsert: true,
        contentType: blob.type
      });

    if (uploadError) throw uploadError;

    const { data } = supabase.storage
      .from('RetailData')
      .getPublicUrl(filePath);

    return data.publicUrl;
  } catch (error) {
    console.error('Error uploading blob:', error);
    return null;
  }
};

// ... existing code for Hairstyle, Locations, Jobs, Calendar, Brands, Products, Characters ...

// --- Hairstyle Details (gai_hairstyles_details) ---

export const saveGaiHairstyle = async (hairstyle: GaiHairstyle) => {
    try {
        const { data, error } = await supabase
            .from('gai_hairstyles_details')
            .insert(hairstyle)
            .select()
            .single();
        if (error) throw error;
        return data as GaiHairstyle;
    } catch (e) {
        console.error("Error saving hairstyle", e);
        return null;
    }
};

export const fetchGaiHairstyles = async () => {
    try {
        const { data, error } = await supabase
            .from('gai_hairstyles_details')
            .select('*')
            .order('id', { ascending: false });
        if (error) throw error;
        return data as GaiHairstyle[];
    } catch (e) {
        console.error("Error fetching hairstyles", e);
        return [];
    }
};

// --- Locations Management (dng_locations) ---

export const fetchLocations = async () => {
    try {
        const { data, error } = await supabase
            .from('dng_locations')
            .select('*')
            .order('created_at', { ascending: false });
        if (error) throw error;
        return data as Location[];
    } catch (e) {
        console.error("Error fetching locations", e);
        return [];
    }
};

export const createLocation = async (location: Partial<Location>) => {
    try {
        const { data, error } = await supabase
            .from('dng_locations')
            .insert(location)
            .select()
            .single();
        if (error) throw error;
        return data as Location;
    } catch (e) {
        console.error("Error creating location", e);
        return null;
    }
};

export const updateLocation = async (id: string | number, updates: Partial<Location>) => {
    try {
        const { data, error } = await supabase
            .from('dng_locations')
            .update(updates)
            .eq('id', id)
            .select()
            .single();
        if (error) throw error;
        return data as Location;
    } catch (e) {
        console.error("Error updating location", e);
        return null;
    }
};

export const deleteLocation = async (id: string | number) => {
    try {
        const { error } = await supabase
            .from('dng_locations')
            .delete()
            .eq('id', id);
        if (error) throw error;
        return true;
    } catch (e) {
        console.error("Error deleting location", e);
        return false;
    }
};

// --- Job Queue Management (fdv_jobs) ---

export const createJob = async (jobType: string, requestPayload: any): Promise<Job | null> => {
    try {
        const { data, error } = await supabase
            .from('fdv_jobs')
            .insert({
                job_type: jobType,
                provider: 'vertex-veo', // Or appropriate provider
                status: 'queued',
                request: requestPayload
            })
            .select()
            .single();
        
        if (error) throw error;
        return data as Job;
    } catch (e) {
        console.error("Error creating job", e);
        return null;
    }
};

// --- Calendar Management ---

export const fetchCalendarEvents = async (start: Date, end: Date) => {
    try {
        const { data, error } = await supabase
            .from('dng1_calendar_events')
            .select(`
                *,
                ad:dng1_ads ( ad_title )
            `)
            .gte('start_at', start.toISOString())
            .lte('start_at', end.toISOString());
        
        if (error) throw error;
        return data as CalendarEvent[];
    } catch (e) {
        console.error("Error fetching calendar", e);
        return [];
    }
};

export const fetchGlobalSchedules = async (start: Date, end: Date) => {
    try {
        // Fetch social content schedules
        const { data, error } = await supabase
            .from('dng1_scene_schedule')
            .select(`
                *,
                scene:dng1_ad_scenes (
                    description
                ),
                character:dng1_characters (
                    name
                )
            `)
            .gte('scheduled_for', start.toISOString())
            .lte('scheduled_for', end.toISOString());

        if (error) throw error;
        return data || [];
    } catch (e) {
        console.error("Error fetching global schedules", e);
        return [];
    }
};

export const createCalendarEvent = async (event: Partial<CalendarEvent>) => {
    try {
        const { data, error } = await supabase
            .from('dng1_calendar_events')
            .insert(event)
            .select()
            .single();
        if (error) throw error;
        return data;
    } catch(e) {
        console.error("Error creating event", e);
        return null;
    }
};

// --- Product & Brand Portfolio ---

export const fetchBrands = async () => {
    try {
        const { data, error } = await supabase.from('dng1_brand_identity').select('*');
        if (error) throw error;
        return data as BrandIdentity[];
    } catch(e) {
        console.error("Error fetching brands", e);
        return [];
    }
}

export const createBrand = async (brand: Partial<BrandIdentity>) => {
    try {
        const { data, error } = await supabase.from('dng1_brand_identity').insert(brand).select().single();
        if (error) throw error;
        return data;
    } catch(e) {
        console.error("Error creating brand", e);
        return null;
    }
}

export const fetchProducts = async (brandId?: string) => {
    try {
        let query = supabase.from('dng1_products').select('*');
        if (brandId) query = query.eq('brand_id', brandId);
        
        const { data, error } = await query;
        if (error) throw error;
        return data as Product[];
    } catch(e) {
        console.error("Error fetching products", e);
        return [];
    }
}

export const createProduct = async (product: Partial<Product>) => {
    try {
        const { data, error } = await supabase.from('dng1_products').insert(product).select().single();
        if (error) throw error;
        return data;
    } catch(e: any) {
        console.error("Error creating product:", e.message || JSON.stringify(e));
        return null;
    }
}

export const updateProduct = async (id: string, updates: Partial<Product>) => {
    try {
        const { data, error } = await supabase.from('dng1_products').update(updates).eq('id', id).select().single();
        if (error) throw error;
        return data;
    } catch(e) {
        console.error("Error updating product", e);
        return null;
    }
}

export const deleteProduct = async (id: string) => {
    try {
        const { error } = await supabase.from('dng1_products').delete().eq('id', id);
        if (error) throw error;
        return true;
    } catch(e) {
        console.error("Error deleting product", e);
        return false;
    }
}

// --- Character / Influencer Management (dng1_characters) ---

export const fetchCharacters = async () => {
    try {
        const { data, error } = await supabase
            .from('dng1_characters')
            .select('*')
            .order('created_at', { ascending: false });
        if (error) throw error;
        return data;
    } catch (e) {
        console.error("Error fetching characters", e);
        return [];
    }
};

export const updateCharacter = async (character_id: string, updates: any) => {
    try {
        const { data, error } = await supabase
            .from('dng1_characters')
            .update(updates)
            .eq('character_id', character_id)
            .select()
            .single();
        if (error) throw error;
        return data;
    } catch (e) {
        console.error("Error updating character", e);
        return null;
    }
};

export const createCharacter = async (charData: any) => {
    try {
        const { data, error } = await supabase
            .from('dng1_characters')
            .insert(charData)
            .select()
            .single();
        if (error) throw error;
        return data;
    } catch (e) {
        console.error("Error creating character", e);
        return null;
    }
};

export const deleteCharacter = async (character_id: string) => {
    try {
        const { error } = await supabase
            .from('dng1_characters')
            .delete()
            .eq('character_id', character_id);
        if (error) throw error;
        return true;
    } catch (e) {
        console.error("Error deleting character", e);
        return false;
    }
}

// --- Legacy Asset Library Functions ---

export const saveDynamicAsset = async (elementType: string, nameIdentifier: string, publicUrl: string, metadata: any): Promise<DynamicAsset | null> => {
  try {
    const assetData = { element_type: elementType, name_identifier: nameIdentifier, asset_data: metadata, asset_urls: { primary: publicUrl } };
    const { data, error } = await supabase.from('dng1_dynamic_asset_library_skinny').insert(assetData).select().single();
    if (error) throw error;
    return data as DynamicAsset;
  } catch (err) { return null; }
};

export const updateDynamicAsset = async (id: number, updates: Partial<DynamicAsset>): Promise<DynamicAsset | null> => {
    try {
        const { data, error } = await supabase.from('dng1_dynamic_asset_library_skinny').update(updates).eq('id', id).select().single();
        if (error) throw error;
        return data as DynamicAsset;
    } catch (err) { return null; }
};

export const deleteDynamicAsset = async (id: number): Promise<boolean> => {
    try {
        const { error } = await supabase.from('dng1_dynamic_asset_library_skinny').delete().eq('id', id);
        if (error) throw error;
        return true;
    } catch (err) { return false; }
};

export const fetchDynamicAssets = async (typeFilter?: string): Promise<DynamicAsset[]> => {
  try {
    let query = supabase.from('dng1_dynamic_asset_library_skinny').select('*').order('created_at', { ascending: false });
    if (typeFilter && typeFilter !== 'all') query = query.eq('element_type', typeFilter);
    const { data, error } = await query;
    if (error) throw error;
    return data as DynamicAsset[];
  } catch (err) { return []; }
};

export const fetchAdsList = async (): Promise<{id: string, ad_title: string}[]> => {
    try {
        const { data, error } = await supabase.from('dng1_ads').select('id, ad_title').order('created_at', { ascending: false });
        if (error) throw error;
        return data || [];
    } catch (error) { return []; }
}

export const duplicateAdProject = async (originalAdId: string): Promise<string | null> => {
// ... duplicateAdProject code
    try {
        const { data: originalAd, error: adError } = await supabase.from('dng1_ads').select('*').eq('id', originalAdId).single();
        if (adError || !originalAd) throw new Error("Original ad not found");
        const { data: originalScenes, error: scenesError } = await supabase.from('dng1_ad_scenes').select('*').eq('ad_id', originalAdId);
        if (scenesError) throw new Error("Failed to fetch scenes");
        const { id: _oldAdId, created_at: _ca, updated_at: _ua, ...adData } = originalAd;
        const { data: newAd, error: createError } = await supabase.from('dng1_ads').insert({ ...adData, ad_title: `${originalAd.ad_title} (Remix)`, status: 'draft' }).select().single();
        if (createError || !newAd) throw createError;
        if (originalScenes && originalScenes.length > 0) {
            const newScenes = originalScenes.map(scene => {
                const { id: _oldSceneId, created_at: _sc, ad_id: _oldAdRef, ...sceneData } = scene;
                return { ...sceneData, id: crypto.randomUUID(), ad_id: newAd.id };
            });
            const { error: copyScenesError } = await supabase.from('dng1_ad_scenes').insert(newScenes);
            if (copyScenesError) throw copyScenesError;
        }
        return newAd.id;
    } catch (e) { return null; }
};

export const updateAdAudio = async (adId: string, audioAsset: any) => {
    try {
        const { data: currentAd, error: fetchError } = await supabase.from('dng1_ads').select('audio_jsonb').eq('id', adId).single();
        if (fetchError) throw fetchError;
        let newAudioData: any[] = [];
        const currentData = currentAd?.audio_jsonb;
        if (currentData) {
            if (Array.isArray(currentData)) newAudioData = [...currentData, audioAsset];
            else newAudioData = [currentData, audioAsset];
        } else {
            newAudioData = [audioAsset];
        }
        const { error: updateError } = await supabase.from('dng1_ads').update({ audio_jsonb: newAudioData }).eq('id', adId);
        if (updateError) throw updateError;
        return true;
    } catch (error) { return false; }
}

// --- Content Engine Methods ---

export const fetchContentItems = async (characterId: string, channel: string): Promise<ContentItem[]> => {
    try {
        const { data, error } = await supabase
            .from('dng1_character_content_items')
            .select('*')
            .eq('character_id', characterId)
            .eq('channel', channel)
            .order('created_at', { ascending: false });
        
        if (error) throw error;
        
        // Fetch latest job status for each item (optimization: could be a join view)
        const items = data as ContentItem[];
        for (let item of items) {
            const { data: job } = await supabase
                .from('dng1_content_generation_jobs')
                .select('status')
                .eq('content_item_id', item.content_item_id)
                .order('queued_at', { ascending: false })
                .limit(1)
                .single();
            if (job) item.latest_job_status = job.status;
        }
        
        return items;
    } catch (e) {
        console.error("Error fetching content items", e);
        return [];
    }
};

export const createContentItem = async (item: Partial<ContentItem>): Promise<ContentItem | null> => {
    try {
        const { data, error } = await supabase
            .from('dng1_character_content_items')
            .insert(item)
            .select()
            .single();
        if (error) throw error;
        return data as ContentItem;
    } catch (e) {
        console.error("Error creating content item", e);
        return null;
    }
};

export const updateContentItem = async (id: string, updates: Partial<ContentItem>) => {
    try {
        const { data, error } = await supabase
            .from('dng1_character_content_items')
            .update(updates)
            .eq('content_item_id', id)
            .select()
            .single();
        if (error) throw error;
        return data;
    } catch (e) {
        console.error("Error updating content item", e);
        return null;
    }
};

export const createGenerationJob = async (contentItemId: string, characterId: string, jobType: string, input: any) => {
// ... existing createGenerationJob code
    try {
        const { data, error } = await supabase.from('dng1_content_generation_jobs').insert({ content_item_id: contentItemId, character_id: characterId, job_type: jobType, status: 'queued', input_jsonb: input }).select().single();
        if (error) throw error;
        return data as GenerationJob;
    } catch (e) { return null; }
};

export const updateContentItemStatus = async (id: string, status: string) => {
    try {
        const { error } = await supabase
            .from('dng1_character_content_items')
            .update({ status })
            .eq('content_item_id', id);
        if (error) throw error;
    } catch (e) {
        console.error("Error updating content status", e);
    }
};

// Ensure a dng1_ad_scene record exists for scheduling
export const ensureSceneForContentItem = async (contentItem: ContentItem, adTitle = "Social Content"): Promise<string | null> => {
// ... existing ensureSceneForContentItem code
    try {
        if (contentItem.meta_jsonb?.scene_id) return contentItem.meta_jsonb.scene_id;
        let adId = null;
        const { data: ads } = await supabase.from('dng1_ads').select('id').eq('ad_title', `${adTitle} - ${contentItem.character_id}`).limit(1);
        if (ads && ads.length > 0) {
            adId = ads[0].id;
        } else {
            const { data: newAd } = await supabase.from('dng1_ads').insert({ ad_title: `${adTitle} - ${contentItem.character_id}`, status: 'active', ad_style: 'Social Container' }).select().single();
            if (newAd) adId = newAd.id;
        }
        if (!adId) throw new Error("Could not find/create container ad");
        const { data: scene, error } = await supabase.from('dng1_ad_scenes').insert({ ad_id: adId, scene_number: 1, description: contentItem.brief || contentItem.theme || "Content Item", status: 'done', scene_data: { content_item_id: contentItem.content_item_id }, scene_image_url: contentItem.meta_jsonb?.generated_assets?.[0] || null }).select().single();
        if (error) throw error;
        const newMeta = { ...contentItem.meta_jsonb, scene_id: scene.id };
        await supabase.from('dng1_character_content_items').update({ meta_jsonb: newMeta }).eq('content_item_id', contentItem.content_item_id);
        return scene.id;
    } catch (e) { return null; }
};

export const fetchSchedule = async (characterId: string) => {
// ... existing fetchSchedule code
    try {
        const { data, error } = await supabase.from('v_dng1_scene_schedule').select('*').eq('character_id', characterId).order('scheduled_for', { ascending: true });
        if (error) throw error;
        return data as SceneSchedule[];
    } catch (e) { return []; }
};

export const upsertSchedule = async (scheduleData: any) => {
// ... existing upsertSchedule code
    try {
        const { data, error } = await supabase.from('dng1_scene_schedule').upsert(scheduleData, { onConflict: 'scene_id' }).select().single();
        if (error) throw error;
        return data;
    } catch (e) { return null; }
};

export const updateApprovalStatus = async (scheduleId: string, approverField: string, status: string) => {
// ... existing updateApprovalStatus code
    try {
        const updates: any = {};
        updates[approverField] = status;
        const { error } = await supabase.from('dng1_scene_schedule').update(updates).eq('schedule_id', scheduleId);
        if (error) throw error;
        return true;
    } catch (e) { return false; }
};

// --- Approval Workflow ---

export const fetchPendingApprovals = async () => {
// ... existing fetchPendingApprovals code
    try {
        const { data, error } = await supabase.from('dng1_scene_schedule').select(`*, scene:dng1_ad_scenes (scene_image_url, description, scene_data), character:dng1_characters (name, image_url, character_id)`).eq('publish_status', 'pending_approval').order('scheduled_for', { ascending: true });
        if (error) throw error;
        return data as SceneSchedule[];
    } catch (e) { return []; }
};

export const submitApproval = async (scheduleId: string, approverKey: 'approver1_status' | 'approver2_status' | 'approver3_status', status: 'approved' | 'rejected', notes?: string) => {
// ... existing submitApproval code
    try {
        const updatePayload: any = {};
        updatePayload[approverKey] = status;
        const { data: current } = await supabase.from('dng1_scene_schedule').select('*').eq('schedule_id', scheduleId).single();
        if (current) {
            const newState = { ...current, ...updatePayload };
            const allApproved = newState.approver1_status === 'approved' && newState.approver2_status === 'approved' && newState.approver3_status === 'approved';
            if (allApproved) { updatePayload.publish_status = 'approved'; }
        }
        const { error } = await supabase.from('dng1_scene_schedule').update(updatePayload).eq('schedule_id', scheduleId);
        if (error) throw error;
        return true;
    } catch (e) { return false; }
}
